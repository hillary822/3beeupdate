# Migration Guide - Move to Your Own Supabase Project

## 🚀 Quick Migration Steps

### 1. Create New Supabase Project

1. Go to [supabase.com/dashboard](https://supabase.com/dashboard)
2. Click "New Project"
3. Choose organization and region
4. **Note your PROJECT_REF** (e.g., `abcd1234efgh5678`)

### 2. Get Your Project Credentials

From your new project dashboard:

- **Project URL**: `https://YOUR_PROJECT_REF.supabase.co`
- **Anon Key**: Settings → API → anon public key
- **Service Role Key**: Settings → API → service_role secret key

### 3. Run Migration Commands

```bash
# Link to your new project
npx supabase link --project-ref YOUR_PROJECT_REF

# Push all database migrations (124 files)
npx supabase db push --project-ref YOUR_PROJECT_REF

# Deploy all Edge Functions
npx supabase functions deploy --project-ref YOUR_PROJECT_REF
```

### 4. Configure Environment Variables

**In Supabase Dashboard** → Settings → Functions, add:

```env
SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
CCPAYMENT_API_KEY=your_ccpayment_key
CCPAYMENT_MERCHANT_ID=your_merchant_id
CCPAYMENT_APPID=your_app_id
CCPAYMENT_APPSECRET=your_app_secret
NOWPAYMENTS_API_KEY=your_nowpayments_key
NOWPAYMENTS_PUBLIC_KEY=your_nowpayments_public_key
NOWPAYMENTS_IPN_SECRET=your_nowpayments_secret
RESEND_API_KEY=your_resend_key
```

### 5. Update Frontend Environment

Create `.env.local` file:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key
```

### 6. Test Your Migration

```bash
# Start the application
npm run dev

# Test webhook endpoints
curl -X POST https://YOUR_PROJECT_REF.supabase.co/functions/v1/ccpayment-webhook \
  -H "Content-Type: application/json" \
  -d '{"test": "migration_test"}'
```

## 📊 What Gets Migrated

### Database Schema (124 migrations):

- ✅ **User System**: profiles, authentication, referrals
- ✅ **Trading System**: trades, trade_codes, signals
- ✅ **Financial System**: deposits, withdrawals, balances
- ✅ **Wallet System**: wallets, transactions, CCPayment integration
- ✅ **KYC System**: verifications, document storage
- ✅ **Admin System**: user management, platform settings

### Edge Functions (14 functions):

- ✅ **Payment Processing**: CCPayment, NOWPayments
- ✅ **Wallet Management**: creation, balance checking
- ✅ **Admin Operations**: user updates, deposit management
- ✅ **KYC Processing**: document handling
- ✅ **Webhooks**: payment confirmations

### Storage Buckets:

- ✅ **KYC Documents**: secure document storage
- ✅ **User Uploads**: profile images, documents

## 🔧 Troubleshooting

### Common Issues:

1. **Migration Fails**:

   ```bash
   npx supabase db reset --project-ref YOUR_PROJECT_REF
   npx supabase db push --project-ref YOUR_PROJECT_REF
   ```

2. **Functions Not Deploying**:

   ```bash
   npx supabase functions deploy --debug --project-ref YOUR_PROJECT_REF
   ```

3. **Environment Variables Missing**:
   - Check Supabase Dashboard → Settings → Functions
   - Ensure all required keys are added

### Verification Steps:

1. **Database**: Check tables exist in Supabase dashboard
2. **Functions**: Test webhook endpoints with curl
3. **Frontend**: Login/register should work
4. **Payments**: CCPayment integration should respond

## 🎯 Benefits of Your Own Project

- ✅ **Full Control**: Your own database and functions
- ✅ **Custom Domain**: Use your own domain
- ✅ **Scalability**: Dedicated resources
- ✅ **Security**: Your own API keys and secrets
- ✅ **Monitoring**: Your own logs and analytics
- ✅ **Backups**: Control your own data backups

## 📞 Support

If you encounter issues:

1. Check Supabase logs in dashboard
2. Use `--debug` flag with CLI commands
3. Verify environment variables are set correctly
4. Test each component individually

Your new trading platform will be fully independent and under your control!
