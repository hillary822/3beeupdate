// Add this to your server.js file after line 40 (after the /health endpoint)

// Get outbound IP endpoint
app.get("/get-ip", async (req, res) => {
  try {
    const axios = require("axios");
    const response = await axios.get("https://api.ipify.org?format=json");
    res.json({
      outbound_ip: response.data.ip,
      timestamp: new Date().toISOString(),
      message: "This is the IP address that CCPayment will see",
    });
  } catch (error) {
    res.status(500).json({
      error: "Failed to get IP",
      message: error.message,
    });
  }
});
