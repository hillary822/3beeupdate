
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera } from "lucide-react";

interface VerificationAlertProps {
  profile: {
    verified: boolean;
    id: string;
  };
  onNavigateToSettings: () => void;
  onNavigateToVerification?: () => void;
}

const VerificationAlert = ({ profile, onNavigateToSettings, onNavigateToVerification }: VerificationAlertProps) => {
  if (profile.verified) return null;

  const handleVerifyClick = () => {
    if (onNavigateToVerification) {
      // If we have a direct verification handler, use it
      onNavigateToVerification();
    } else {
      // Otherwise navigate to settings
      onNavigateToSettings();
    }
  };

  return (
    <Card className="bg-yellow-900/20 border-yellow-500/50 mb-6">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-yellow-400 font-semibold">Identity Verification Required</h3>
            <p className="text-yellow-200 text-sm">Complete verification to enable withdrawals and trading</p>
          </div>
          <Button 
            className="bg-gradient-primary hover:shadow-glow text-primary-foreground"
            onClick={handleVerifyClick}
          >
            <Camera className="h-4 w-4 mr-2" />
            Verify Now
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default VerificationAlert;
