import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { ArrowRight, Loader2 } from "lucide-react";

interface TransferHistoryModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface TransferRecord {
  id: string;
  from_account: string;
  to_account: string;
  amount: number;
  fee_amount?: number;
  created_at: string;
  status: string;
}

const TransferHistoryModal = ({ open, onOpenChange }: TransferHistoryModalProps) => {
  const [transfers, setTransfers] = useState<TransferRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    if (open && user) {
      fetchTransferHistory();
    }
  }, [open, user]);

  const fetchTransferHistory = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('transfer_history')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
        console.error('Error fetching transfer history:', error);
        setTransfers([]);
      } else {
        const transferData = data?.map(transfer => ({
          id: transfer.id,
          from_account: transfer.from_account,
          to_account: transfer.to_account,
          amount: transfer.amount,
          fee_amount: transfer.fee_amount,
          created_at: transfer.created_at,
          status: transfer.status
        })) || [];
        setTransfers(transferData);
      }
    } catch (error) {
      console.error('Error:', error);
      setTransfers([]);
    } finally {
      setLoading(false);
    }
  };

  const formatAccountName = (account: string) => {
    return account.charAt(0).toUpperCase() + account.slice(1);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-900/95 backdrop-blur-md border-slate-700/50 text-white max-w-2xl max-h-[80vh] shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-white">Transfer History</DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="h-[500px] pr-4">
          {loading ? (
            <div className="flex items-center justify-center h-32">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : transfers.length === 0 ? (
            <div className="text-center text-slate-400 py-8">
              No transfer history found
            </div>
          ) : (
            <div className="space-y-3">
              {transfers.map((transfer) => (
                <Card key={transfer.id} className="bg-slate-800/80 backdrop-blur-sm border-slate-700/50 hover:bg-slate-800/90 transition-all duration-200 animate-fade-in">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center space-x-2">
                          <span className="text-white font-medium">
                            {formatAccountName(transfer.from_account)}
                          </span>
                          <ArrowRight className="h-4 w-4 text-slate-400" />
                          <span className="text-white font-medium">
                            {formatAccountName(transfer.to_account)}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-white font-semibold">
                          ${transfer.amount.toFixed(2)}
                        </div>
                        {transfer.fee_amount && transfer.fee_amount > 0 && (
                          <div className="text-red-400 text-sm">
                            Fee: ${transfer.fee_amount.toFixed(2)}
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mt-3">
                      <div className="text-slate-400 text-sm">
                        {formatDate(transfer.created_at)}
                      </div>
                      <Badge 
                        variant={transfer.status === 'completed' ? 'default' : 'secondary'}
                        className={transfer.status === 'completed' 
                          ? 'bg-blue-600 text-white border-blue-500' 
                          : 'bg-yellow-600 text-white border-yellow-500'
                        }
                      >
                        {transfer.status}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};

export default TransferHistoryModal;