import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Wallet, CreditCard } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import WalletDepositModal from "./WalletDepositModal";
import ManualDepositStep from "./deposit/ManualDepositStep";

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDeposit: () => void;
}

type DepositMethod = 'nowpayments' | 'manual' | null;

const DepositModal = ({ isOpen, onClose, onDeposit }: DepositModalProps) => {
  const { toast } = useToast();
  const [selectedMethod, setSelectedMethod] = useState<DepositMethod>(null);
  const [amount, setAmount] = useState(100);
  const [selectedCurrency, setSelectedCurrency] = useState('USDT');

  const handleMethodSelect = (method: DepositMethod) => {
    setSelectedMethod(method);
  };

  const handleBack = () => {
    if (selectedMethod) {
      setSelectedMethod(null);
    } else {
      onClose();
    }
  };

  const handleDepositCreated = (depositId: string) => {
    toast({
      title: "Success",
      description: "Deposit request created successfully",
    });
    onDeposit();
    onClose();
    setSelectedMethod(null);
  };

  const handleClose = () => {
    onClose();
    setSelectedMethod(null);
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-md bg-slate-900 border-slate-700">
          <DialogHeader>
            <div className="flex items-center space-x-2">
              {selectedMethod && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleBack}
                  className="p-1"
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              )}
              <DialogTitle>
                {selectedMethod === 'nowpayments' ? 'Crypto Deposit (NOWPayments)' : 
                 selectedMethod === 'manual' ? 'Deposit Funds' : 
                 'Deposit Funds'}
              </DialogTitle>
            </div>
          </DialogHeader>

          {!selectedMethod ? (
            <div className="space-y-4">
              <p className="text-slate-400 text-sm">
                Select your deposit method:
              </p>

              {/* NOWPayments Option - Temporarily Disabled */}
              {/*
              <Button
                onClick={() => handleMethodSelect('nowpayments')}
                className="w-full h-auto p-4 flex flex-col items-start space-y-2 bg-slate-800 hover:bg-slate-700 border border-slate-600"
                variant="outline"
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-500/20 rounded-lg">
                    <CreditCard className="h-5 w-5 text-blue-400" />
                  </div>
                  <div className="text-left">
                    <h3 className="font-semibold">Deposit USDT (Recommended)</h3>
                    <p className="text-sm text-slate-400">Instant processing via NOWPayments</p>
                  </div>
                </div>
              </Button>
              */}

              {/* Manual Deposit Option - Now the primary option */}
              <Button
                onClick={() => handleMethodSelect('manual')}
                className="w-full h-auto p-4 flex flex-col items-start space-y-2 bg-slate-800 hover:bg-slate-700 border border-slate-600"
                variant="outline"
              >
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-green-500/20 rounded-lg">
                    <Wallet className="h-5 w-5 text-green-400" />
                  </div>
                  <div className="text-left">
                    <h3 className="font-semibold">Deposit Funds</h3>
                    <p className="text-sm text-slate-400">USDT, ETH, or BTC - Manual verification</p>
                  </div>
                </div>
              </Button>
            </div>
          ) : selectedMethod === 'manual' ? (
            <ManualDepositStep
              amount={amount}
              selectedCurrency={selectedCurrency}
              onBack={handleBack}
              onDepositCreated={handleDepositCreated}
            />
          ) : null}
        </DialogContent>
      </Dialog>

      {/* NOWPayments Modal - Temporarily Disabled */}
      {/*
      {selectedMethod === 'nowpayments' && (
        <WalletDepositModal
          isOpen={true}
          onClose={handleBack}
          onDepositCompleted={onDeposit}
        />
      )}
      */}
    </>
  );
};

export default DepositModal;