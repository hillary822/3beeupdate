
import { Dispatch, SetStateAction } from "react";
import TradesTab from "@/components/dashboard/TradesTab";
import DepositsTab from "@/components/dashboard/DepositsTab";
import WithdrawalsTab from "@/components/dashboard/WithdrawalsTab";
import ReferralsTab from "@/components/dashboard/ReferralsTab";
import AccountSettingsTab from "@/components/dashboard/AccountSettingsTab";
import MobileAssetView from "@/components/dashboard/MobileAssetView";
import TradingForm from "@/components/trading/TradingForm";
import VerificationAlert from "@/components/dashboard/VerificationAlert";
import UserCodesSection from "@/components/dashboard/UserCodesSection";

interface DashboardMobileContentProps {
  activeTab: string;
  profile: any;
  totalBalance: number;
  winRate: number;
  showBalance: boolean;
  setShowBalance: Dispatch<SetStateAction<boolean>>;
  setActiveTab: Dispatch<SetStateAction<string>>;
  setShowTransferModal: Dispatch<SetStateAction<boolean>>;
  accountBalances: {
    exchange: number;
    trade: number;
    perpetual: number;
  };
  trades: any[];
  deposits: any[];
  withdrawals: any[];
  referralCount: number;
  isLoading: boolean;
  onNavigate: (path: string) => void;
  onTradeCompleted: () => Promise<void>;
  onDeposit: () => void;
  onWithdraw: () => void;
  onCopyReferralCode: () => void;
  onLogout: () => void;
  onNavigateToVerification: () => void;
  onNavigateToSettings: () => void;
  settingsInitialTab: string;
}

const DashboardMobileContent = ({
  activeTab,
  profile,
  totalBalance,
  winRate,
  showBalance,
  setShowBalance,
  setActiveTab,
  setShowTransferModal,
  accountBalances,
  trades,
  deposits,
  withdrawals,
  referralCount,
  isLoading,
  onNavigate,
  onTradeCompleted,
  onDeposit,
  onWithdraw,
  onCopyReferralCode,
  onLogout,
  onNavigateToVerification,
  onNavigateToSettings,
  settingsInitialTab,
}: DashboardMobileContentProps) => {
  const renderTabContent = () => {
    switch (activeTab) {
      case "assets":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-white">Assets</h3>
            <MobileAssetView
              profile={profile}
              totalBalance={totalBalance}
              winRate={winRate}
              showBalance={showBalance}
              setShowBalance={setShowBalance}
              setActiveTab={setActiveTab}
              setShowTransferModal={setShowTransferModal}
              accountBalances={accountBalances}
              onNavigate={onNavigate}
              onTradeCompleted={onTradeCompleted}
              trades={trades}
            />
          </div>
        );
      case "trades":
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-white">Invite Me</h3>
            <UserCodesSection onTradeCompleted={onTradeCompleted} />
            <div>
              <TradingForm 
                pair="BTC-USDT" 
                currentPrice={45000} 
                type="spot" 
                onTradeCompleted={onTradeCompleted}
              />
            </div>
            <TradesTab trades={trades} onTradeCompleted={onTradeCompleted} />
          </div>
        );
      case "deposits":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-white">Deposits</h3>
            <DepositsTab deposits={deposits} onDeposit={onDeposit} loading={isLoading} />
          </div>
        );
      case "withdrawals":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-white">Withdrawals</h3>
            <VerificationAlert 
              profile={profile} 
              onNavigateToSettings={onNavigateToSettings}
            />
            <WithdrawalsTab />
          </div>
        );
      case "referrals":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-white">Referrals</h3>
            <ReferralsTab 
              referralCode={profile.referral_code || ''}
              referralCount={referralCount}
              onCopyReferralCode={onCopyReferralCode}
            />
          </div>
        );
      case "settings":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-white">Settings</h3>
            <VerificationAlert 
              profile={profile} 
              onNavigateToSettings={onNavigateToSettings}
              onNavigateToVerification={onNavigateToVerification}
            />
            <AccountSettingsTab initialTab={settingsInitialTab} />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="lg:hidden w-full max-w-full overflow-x-hidden">
      <div className="space-y-4 w-full max-w-full">
        <div className="w-full max-w-full overflow-x-hidden">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default DashboardMobileContent;
