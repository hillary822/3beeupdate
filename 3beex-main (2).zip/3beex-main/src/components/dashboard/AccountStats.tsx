
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CreditCard, User, TrendingUp, Users } from "lucide-react";

interface AccountStatsProps {
  trades: any[];
}

const AccountStats = ({ trades }: AccountStatsProps) => {
  // Calculate stats from trades
  const totalTrades = trades?.length || 0;
  const completedTrades = trades?.filter(trade => trade.status === 'completed') || [];
  const totalProfit = completedTrades.reduce((sum, trade) => {
    const profit = Number(trade.profit) || 0;
    return sum + profit;
  }, 0);
  
  const winRate = completedTrades.length > 0 ? 
    (completedTrades.filter(trade => {
      const profit = Number(trade.profit) || 0;
      return profit > 0;
    }).length / completedTrades.length * 100) : 0;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center">
            <CreditCard className="h-6 w-6 text-primary" />
            <div className="ml-3">
              <p className="text-xs font-medium text-muted-foreground">Total Trades</p>
              <p className="text-lg font-bold text-foreground">{totalTrades}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center">
            <User className="h-6 w-6 text-blue-400" />
            <div className="ml-3">
              <p className="text-xs font-medium text-muted-foreground">Completed</p>
              <p className="text-lg font-bold text-foreground">{completedTrades.length}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center">
            <TrendingUp className="h-6 w-6 text-purple-400" />
            <div className="ml-3">
              <p className="text-xs font-medium text-muted-foreground">Total Profit</p>
              <p className={`text-lg font-bold ${totalProfit >= 0 ? 'text-primary' : 'text-red-400'}`}>
                ${totalProfit.toFixed(2)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center">
            <Users className="h-6 w-6 text-yellow-400" />
            <div className="ml-3">
              <p className="text-xs font-medium text-muted-foreground">Win Rate</p>
              <p className="text-lg font-bold text-foreground">{winRate.toFixed(1)}%</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AccountStats;
