import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X, Mail, ExternalLink, Phone, MessageCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface CustomerSupportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const CustomerSupportModal = ({ open, onOpenChange }: CustomerSupportModalProps) => {
  const [supportEmail, setSupportEmail] = useState("support@3beetex.com");
  const [supportWhatsapp, setSupportWhatsapp] = useState("+1234567890");
  const [supportTelegram, setSupportTelegram] = useState("@3beetex_support");
  const [loading, setLoading] = useState(false);

  const loadSupportContacts = async () => {
    if (loading) return;
    
    setLoading(true);
    try {
      // Load all support contact methods
      const { data: emailData } = await supabase
        .from('platform_settings')
        .select('value')
        .eq('key', 'support_email')
        .single();

      const { data: whatsappData } = await supabase
        .from('platform_settings')
        .select('value')
        .eq('key', 'support_whatsapp')
        .single();

      const { data: telegramData } = await supabase
        .from('platform_settings')
        .select('value')
        .eq('key', 'support_telegram')
        .single();

      if (emailData?.value) {
        setSupportEmail(emailData.value);
      }
      if (whatsappData?.value) {
        setSupportWhatsapp(whatsappData.value);
      }
      if (telegramData?.value) {
        setSupportTelegram(telegramData.value);
      }
    } catch (error) {
      console.error('Error loading support contacts:', error);
    } finally {
      setLoading(false);
    }
  };

  // Load contacts each time modal opens
  useEffect(() => {
    if (open) {
      loadSupportContacts();
    }
  }, [open]);

  const handleEmailSupport = () => {
    window.location.href = `mailto:${supportEmail}?subject=Support Request`;
  };

  const handleWhatsAppSupport = () => {
    const phoneNumber = supportWhatsapp.replace(/[^\d+]/g, '');
    const message = encodeURIComponent('Hi, I need support with my account.');
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank');
  };

  const handleTelegramSupport = () => {
    let telegramUrl = supportTelegram;
    if (telegramUrl.startsWith('@')) {
      telegramUrl = `https://t.me/${telegramUrl.substring(1)}`;
    } else if (!telegramUrl.startsWith('http')) {
      telegramUrl = `https://t.me/${telegramUrl}`;
    }
    window.open(telegramUrl, '_blank');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg w-full mx-auto bg-slate-800 border-slate-700 text-white">
        <DialogHeader className="relative">
          <DialogTitle className="text-white text-lg font-semibold pr-8">
            Customer Support
          </DialogTitle>
          <Button
            onClick={() => onOpenChange(false)}
            variant="ghost"
            size="sm"
            className="absolute right-0 top-0 h-8 w-8 p-0 hover:bg-slate-700 text-white"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <div className="text-center">
            <MessageCircle className="h-16 w-16 mx-auto text-blue-400 mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">
              Get Help from Our Support Team
            </h3>
            <p className="text-slate-300 mb-6">
              Choose your preferred way to contact us. We're here to help!
            </p>
          </div>

          <div className="space-y-4">
            {/* Email Support */}
            <div className="bg-slate-700 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-blue-400" />
                  <div>
                    <p className="text-white font-medium">Email Support</p>
                    <p className="text-slate-300 text-sm">{loading ? 'Loading...' : supportEmail}</p>
                  </div>
                </div>
                <Button 
                  onClick={handleEmailSupport}
                  variant="outline"
                  size="sm"
                  className="border-slate-600 text-white hover:bg-slate-600"
                  disabled={loading}
                >
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* WhatsApp Support */}
            <div className="bg-slate-700 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-green-400" />
                  <div>
                    <p className="text-white font-medium">WhatsApp Support</p>
                    <p className="text-slate-300 text-sm">{loading ? 'Loading...' : supportWhatsapp}</p>
                  </div>
                </div>
                <Button 
                  onClick={handleWhatsAppSupport}
                  variant="outline"
                  size="sm"
                  className="border-slate-600 text-white hover:bg-slate-600"
                  disabled={loading}
                >
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Telegram Support */}
            <div className="bg-slate-700 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <MessageCircle className="h-5 w-5 text-blue-500" />
                  <div>
                    <p className="text-white font-medium">Telegram Support</p>
                    <p className="text-slate-300 text-sm">{loading ? 'Loading...' : supportTelegram}</p>
                  </div>
                </div>
                <Button 
                  onClick={handleTelegramSupport}
                  variant="outline"
                  size="sm"
                  className="border-slate-600 text-white hover:bg-slate-600"
                  disabled={loading}
                >
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <div className="text-center">
            <p className="text-slate-400 text-sm">
              Response times may vary. For urgent matters, try WhatsApp or Telegram for faster responses.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default CustomerSupportModal;