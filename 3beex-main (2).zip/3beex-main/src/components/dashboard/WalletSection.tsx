import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, RefreshCw, Wallet, Eye, EyeOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface AssignedWallet {
  id: string;
  address: string;
  currency: string;
  assigned_at: string;
}

interface WalletAssignResponse {
  success: boolean;
  message?: string;
  error?: string;
  wallet?: AssignedWallet;
}

const WalletSection = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [assignedWallet, setAssignedWallet] = useState<AssignedWallet | null>(null);
  const [loading, setLoading] = useState(true);
  const [assigning, setAssigning] = useState(false);
  const [showAddress, setShowAddress] = useState(true);

  useEffect(() => {
    if (user) {
      fetchAssignedWallet();
    }
  }, [user]);

  const fetchAssignedWallet = async () => {
    try {
      setLoading(true);
      // For now, we'll use the existing pre_generated_wallets table
      // until the migration creates the wallet_assignments table
      const { data, error } = await supabase
        .from('pre_generated_wallets')
        .select('*')
        .eq('assigned_to_user_id', user?.id)
        .eq('currency', 'USDT')
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setAssignedWallet({
          id: data.id,
          address: data.address,
          currency: data.currency,
          assigned_at: data.assigned_at || new Date().toISOString()
        });
      }
    } catch (error) {
      console.error('Error fetching assigned wallet:', error);
    } finally {
      setLoading(false);
    }
  };

  const assignWallet = async () => {
    setAssigning(true);
    try {
      console.log('Requesting wallet assignment...');
      const { data, error } = await supabase.rpc('assign_wallet_to_user', {
        user_id_input: user?.id,
        currency_input: 'USDT'
      });

      console.log('Assign wallet response:', data, error);

      if (error) {
        throw new Error(`Database error: ${error.message}`);
      }

      // Type cast the response to our expected interface
      const response = data as unknown as WalletAssignResponse;

      if (response?.success) {
        setAssignedWallet(response.wallet!);
        
        toast({
          title: "USDT Deposit Address Assigned",
          description: "Your USDT deposit address has been assigned successfully.",
        });
      } else {
        throw new Error(response?.error || 'Failed to assign wallet address');
      }
    } catch (error) {
      console.error('Error assigning wallet:', error);
      toast({
        title: "Wallet Assignment Failed", 
        description: error instanceof Error ? error.message : "Failed to assign deposit address. Please try again or contact support.",
        variant: "destructive",
      });
    } finally {
      setAssigning(false);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: "Address copied to clipboard",
      });
    } catch (error) {
      console.error('Failed to copy:', error);
      toast({
        title: "Copy Failed",
        description: "Failed to copy address to clipboard",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
            <span className="ml-2 text-white">Loading wallet...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wallet className="h-5 w-5 text-green-400" />
            <CardTitle className="text-white">USDT Deposit Wallet</CardTitle>
          </div>
          {assignedWallet && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAddress(!showAddress)}
              className="text-white hover:bg-slate-700"
            >
              {showAddress ? <EyeOff size={16} /> : <Eye size={16} />}
            </Button>
          )}
        </div>
        <CardDescription className="text-slate-400">
          Your personal USDT deposit address
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {assignedWallet ? (
          <div className="bg-slate-700 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <Badge variant="secondary" className="bg-green-600 text-white">
                {assignedWallet.currency}
              </Badge>
              <Badge variant="outline" className="border-blue-500 text-blue-500">
                Assigned
              </Badge>
            </div>
            
            <div>
              <p className="text-sm text-slate-400 mb-1">Deposit Address</p>
              <div className="flex items-center gap-2 bg-slate-800 rounded p-2">
                <div className="flex-1 text-xs text-green-400 break-all font-mono">
                  {showAddress ? assignedWallet.address : "••••••••••••••••••••••••••••••••"}
                </div>
                <Button
                  onClick={() => copyToClipboard(assignedWallet.address)}
                  size="sm"
                  variant="ghost"
                  className="text-slate-300 hover:text-white px-2"
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
            
            <div>
              <p className="text-sm text-slate-400 mb-1">Assigned Date</p>
              <p className="text-sm text-white">
                {new Date(assignedWallet.assigned_at).toLocaleDateString()}
              </p>
            </div>

            <div className="bg-green-900/20 border border-green-600 rounded-lg p-3 mt-4">
              <h4 className="text-green-400 font-medium mb-2">Important Notes:</h4>
              <ul className="text-sm text-slate-300 space-y-1">
                <li>• Only send USDT to this address</li>
                <li>• This is your personal deposit address</li>
                <li>• Deposits are processed automatically</li>
                <li>• Contact support if you have any issues</li>
              </ul>
            </div>
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-slate-400 mb-4">No USDT deposit address assigned yet</p>
            <Button
              onClick={assignWallet}
              disabled={assigning}
              className="bg-green-600 hover:bg-green-700"
            >
              {assigning ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Assigning Address...
                </>
              ) : (
                "Get USDT Deposit Address"
              )}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default WalletSection;
