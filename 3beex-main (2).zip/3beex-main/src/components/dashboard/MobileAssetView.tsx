
import { Dispatch, SetStateAction } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Eye } from "lucide-react";
import ActionButtons from "./ActionButtons";
import AccountBalances from "./AccountBalances";
import AccountStats from "./AccountStats";

interface MobileAssetViewProps {
  profile: any;
  totalBalance: number;
  winRate: number;
  showBalance: boolean;
  setShowBalance: Dispatch<SetStateAction<boolean>>;
  setActiveTab: Dispatch<SetStateAction<string>>;
  setShowTransferModal: Dispatch<SetStateAction<boolean>>;
  accountBalances: {
    exchange: number;
    trade: number;
    perpetual: number;
  };
  onNavigate: (path: string) => void;
  onTradeCompleted: () => Promise<void>;
  trades: any[];
}

const MobileAssetView = ({
  profile,
  totalBalance,
  winRate,
  showBalance,
  setShowBalance,
  setActiveTab,
  setShowTransferModal,
  accountBalances,
  onNavigate,
  onTradeCompleted,
  trades,
}: MobileAssetViewProps) => {
  return (
    <div className="space-y-6 w-full overflow-x-hidden">
      {/* Balance Card with Gradient */}
      <Card className="mb-8 bg-gradient-primary border-primary shadow-glow">
        <CardHeader>
          <CardTitle className="text-white flex items-center justify-between">
            <div className="flex flex-col">
              <span>Total Assets</span>
              <span className="text-sm font-normal text-primary-foreground/80">
                {profile?.vip_level && profile.vip_level > 0 
                  ? `VIP Level ${profile.vip_level}` 
                  : "Standard Account"}
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowBalance(!showBalance)}
              className="text-white hover:bg-white/10"
            >
              <Eye className="h-4 w-4" />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold text-white mb-2">
            {showBalance ? `$${totalBalance.toFixed(2)}` : "****"}
          </div>
          <p className="text-primary-foreground/80">Win Rate: {winRate.toFixed(1)}%</p>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <ActionButtons
        setActiveTab={setActiveTab}
        setShowTransferModal={setShowTransferModal}
        onNavigate={onNavigate}
      />

      {/* Account Sections */}
      <AccountBalances
        accountBalances={accountBalances}
        onNavigate={onNavigate}
      />

      <AccountStats trades={trades} />
    </div>
  );
};

export default MobileAssetView;
