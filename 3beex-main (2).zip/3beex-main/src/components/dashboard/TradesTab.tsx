
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Trade {
  id: string;
  trade_code: string;
  type: string;
  asset: string;
  amount: number;
  profit: number;
  status: string;
  started_at?: string;
  completed_at?: string;
  created_at: string;
  trade_codes?: {
    profit_percentage: number;
    duration_minutes: number;
    note: string | null;
  };
}

interface TradesTabProps {
  trades: Trade[];
  onTradeCompleted?: () => Promise<void>;
}

const getStatusDisplay = (trade: Trade) => {
  if (trade.status === 'active') {
    return { text: 'Ongoing Trade', color: 'bg-yellow-500' };
  } else if (trade.status === 'completed') {
    return { text: 'Settled', color: 'bg-blue-500 text-green-400' };
  } else {
    return { text: trade.status, color: 'bg-gray-500' };
  }
};

const TradesTab = ({ trades, onTradeCompleted }: TradesTabProps) => {
  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">Trading History</CardTitle>
        <CardDescription className="text-slate-400">
          Your executed trades and profits
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <div className="max-h-[70vh] overflow-auto">
          {trades.length === 0 ? (
            <div className="text-slate-400 text-center py-8">No trades yet</div>
          ) : (
            <div className="space-y-2 p-3">
              {trades.map((trade) => {
                const status = getStatusDisplay(trade);
                return (
                  <div
                    key={trade.id}
                    className="bg-slate-700/50 rounded-lg border border-slate-600 p-3 hover:bg-slate-700/70 transition-colors"
                  >
                    {/* Header Row - Mobile Optimized */}
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge 
                          variant={trade.type === "BUY" ? "default" : "destructive"} 
                          className={`text-xs px-2 py-0.5 ${
                            trade.type === "BUY" 
                              ? "bg-green-500 hover:bg-green-600 text-white" 
                              : "bg-red-500 hover:bg-red-600 text-white"
                          }`}
                        >
                          {trade.type}
                        </Badge>
                         <span className="text-white font-medium text-sm">
                           {trade.asset}
                           {trade.trade_codes?.note && (
                             <span className="text-slate-400 text-xs italic ml-2">
                               {trade.trade_codes.note}
                             </span>
                           )}
                         </span>
                      </div>
                      <Badge 
                        className={`${status.color} text-xs px-2 py-0.5 whitespace-nowrap`}
                      >
                        {status.text}
                      </Badge>
                    </div>

                    {/* Details Grid - Responsive */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <div className="space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Order ID:</span>
                          <span className="text-white font-mono text-xs">
                            {trade.id.substring(0, 8)}...
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Copy Code:</span>
                           <span className="text-white font-mono text-xs">
                             {trade.trade_code}
                           </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Turnover:</span>
                          <span className="text-white font-medium">${Number(trade.amount || 0).toFixed(2)}</span>
                        </div>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Profit/Loss:</span>
                          <span className={`font-medium ${(Number(trade.trade_codes?.profit_percentage || 0)) >= 0 ? "text-green-400" : "text-red-400"}`}>
                            {(Number(trade.trade_codes?.profit_percentage || 0)) >= 0 ? "+" : ""}{Number(trade.trade_codes?.profit_percentage || 0).toFixed(1)}% ({(Number(trade.profit) || 0) >= 0 ? "+" : ""}${Number(trade.profit || 0).toFixed(2)})
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Duration:</span>
                          <span className="text-slate-300">{trade.trade_codes?.duration_minutes || 15}m</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-slate-400">Date:</span>
                          <span className="text-slate-300 text-xs">
                            {new Date(trade.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Expires At for Active Trades */}
                    {trade.status === 'active' && trade.started_at && (
                      <div className="mt-2 pt-2 border-t border-slate-600">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">Expires At:</span>
                          <span className="text-white">
                            {new Date(new Date(trade.started_at).getTime() + (trade.trade_codes?.duration_minutes || 15) * 60 * 1000).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default TradesTab;
