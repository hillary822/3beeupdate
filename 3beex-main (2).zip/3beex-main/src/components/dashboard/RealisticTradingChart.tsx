import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect } from "react";
import { TrendingUp, TrendingDown } from "lucide-react";

interface OrderBookData {
  price: number;
  quantity: number;
  type: 'buy' | 'sell';
}

interface CryptoPrice {
  usd: number;
  usd_24h_change: number;
  usd_market_cap: number;
  usd_24h_vol: number;
}

const RealisticTradingChart = () => {
  const [currentPrice, setCurrentPrice] = useState(105184.31);
  const [priceChange, setPriceChange] = useState(0);
  const [priceChangePercent, setPriceChangePercent] = useState(0);
  const [marketCap, setMarketCap] = useState(0);
  const [volume24h, setVolume24h] = useState(0);
  const [orderBook, setOrderBook] = useState<OrderBookData[]>([]);
  const [high24h, setHigh24h] = useState(0);
  const [low24h, setLow24h] = useState(0);

  // Fetch live Bitcoin price from CoinGecko
  const fetchLivePrice = async () => {
    try {
      const response = await fetch(
        'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd&include_24hr_change=true&include_market_cap=true&include_24hr_vol=true'
      );
      const data = await response.json();
      
      if (data.bitcoin) {
        const btcData: CryptoPrice = data.bitcoin;
        setCurrentPrice(btcData.usd);
        // Calculate dollar amount change from percentage
        const dollarChange = (btcData.usd * btcData.usd_24h_change) / 100;
        setPriceChange(dollarChange);
        setPriceChangePercent(btcData.usd_24h_change);
        setMarketCap(btcData.usd_market_cap);
        setVolume24h(btcData.usd_24h_vol);
        
        // Calculate 24h high and low based on current price and change
        const changeAmount = (btcData.usd * btcData.usd_24h_change) / 100;
        setHigh24h(btcData.usd + Math.abs(changeAmount) * 0.5);
        setLow24h(btcData.usd - Math.abs(changeAmount) * 0.5);
      }
    } catch (error) {
      console.error('Error fetching live price:', error);
      // Keep existing fallback values if API fails
    }
  };

  // Generate realistic order book data based on current price
  useEffect(() => {
    const generateOrderBook = () => {
      const book: OrderBookData[] = [];
      const basePrice = currentPrice;
      
      // Generate sell orders (higher prices)
      for (let i = 0; i < 8; i++) {
        book.push({
          price: basePrice + (i + 1) * Math.random() * 200 + 100,
          quantity: Math.random() * 2 + 0.1,
          type: 'sell'
        });
      }
      
      // Generate buy orders (lower prices)
      for (let i = 0; i < 8; i++) {
        book.push({
          price: basePrice - (i + 1) * Math.random() * 200 + 50,
          quantity: Math.random() * 2 + 0.1,
          type: 'buy'
        });
      }
      
      setOrderBook(book.sort((a, b) => b.price - a.price));
    };

    generateOrderBook();
    const interval = setInterval(generateOrderBook, 8000);
    return () => clearInterval(interval);
  }, [currentPrice]);

  // Fetch live price on mount and set up periodic updates
  useEffect(() => {
    fetchLivePrice();
    const priceTimer = setInterval(fetchLivePrice, 30000); // Update every 30 seconds
    return () => clearInterval(priceTimer);
  }, []);

  const formatMarketCap = (value: number) => {
    if (value >= 1e12) return `$${(value / 1e12).toFixed(1)}T`;
    if (value >= 1e9) return `$${(value / 1e9).toFixed(1)}B`;
    if (value >= 1e6) return `$${(value / 1e6).toFixed(1)}M`;
    return `$${value.toFixed(0)}`;
  };

  const formatVolume = (value: number) => {
    if (value >= 1e9) return `${(value / 1e9).toFixed(1)}B`;
    if (value >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
    if (value >= 1e3) return `${(value / 1e3).toFixed(1)}K`;
    return value.toFixed(0);
  };

  return (
    <Card className="bg-slate-900 border-slate-700 text-white">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="text-white font-bold text-lg">₿ BTC/USDT</div>
            <Badge variant="outline" className="text-green-400 border-green-400">
              LIVE
            </Badge>
          </div>
          <div className={`flex items-center gap-1 text-sm font-semibold ${priceChangePercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {priceChangePercent >= 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            <span>{priceChangePercent >= 0 ? '+' : ''}{priceChangePercent.toFixed(2)}%</span>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Current Price Display - Styled like Spot Trading */}
        <div className="bg-slate-800/50 rounded-lg p-4 text-right">
          <div className="text-3xl font-bold text-white mb-1">
            ${currentPrice.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
          </div>
          <div className={`flex items-center justify-end gap-1 text-sm ${priceChangePercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {priceChangePercent >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
            <span>
              {priceChangePercent >= 0 ? '+' : ''}{Math.abs(priceChange).toFixed(2)} ({priceChangePercent >= 0 ? '+' : ''}{priceChangePercent.toFixed(2)}%)
            </span>
          </div>
        </div>

        {/* Order Book */}
        <div className="bg-slate-800/50 rounded-lg p-3">
          <div className="flex justify-between text-xs text-slate-300 mb-2">
            <span>Price (USDT)</span>
            <span>Amount (BTC)</span>
          </div>
          
          <div className="space-y-1 max-h-32 overflow-y-auto">
            {orderBook.slice(0, 12).map((order, index) => (
              <div key={index} className="flex justify-between text-xs">
                <span className={order.type === 'sell' ? 'text-red-400' : 'text-green-400'}>
                  ${order.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <span className="text-white">{order.quantity.toFixed(4)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Market Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-800/50 rounded-lg p-3">
            <div className="text-xs text-slate-400">24h High</div>
            <div className="text-lg font-bold text-green-400">
              ${high24h.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-3">
            <div className="text-xs text-slate-400">24h Low</div>
            <div className="text-lg font-bold text-red-400">
              ${low24h.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
        </div>

        {/* Volume and Market Cap */}
        <div className="bg-slate-800/50 rounded-lg p-3">
          <div className="flex justify-between items-center">
            <div>
              <div className="text-xs text-slate-400">24h Volume</div>
              <div className="text-lg font-bold">
                {formatVolume(volume24h)} BTC
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400">Market Cap</div>
              <div className="text-lg font-bold">
                {formatMarketCap(marketCap)}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RealisticTradingChart;
