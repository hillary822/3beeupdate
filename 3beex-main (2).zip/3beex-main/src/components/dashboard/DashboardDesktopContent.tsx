
// Desktop dashboard content component
import { Dispatch, SetStateAction } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DepositsTab from "@/components/dashboard/DepositsTab";
import WithdrawalsTab from "@/components/dashboard/WithdrawalsTab";
import ReferralsTab from "@/components/dashboard/ReferralsTab";

import AccountSettingsTab from "@/components/dashboard/AccountSettingsTab";
import DesktopTradesTab from "@/components/dashboard/DesktopTradesTab";
import VerificationAlert from "@/components/dashboard/VerificationAlert";
import UserCodesSection from "@/components/dashboard/UserCodesSection";

interface DashboardDesktopContentProps {
  profile: any;
  totalBalance: number;
  winRate: number;
  showBalance: boolean;
  setShowBalance: Dispatch<SetStateAction<boolean>>;
  setActiveTab: Dispatch<SetStateAction<string>>;
  setShowTransferModal: Dispatch<SetStateAction<boolean>>;
  accountBalances: {
    exchange: number;
    trade: number;
    perpetual: number;
  };
  trades: any[];
  deposits: any[];
  withdrawals: any[];
  referralCount: number;
  isLoading: boolean;
  onNavigate: (path: string) => void;
  onTradeCompleted: () => Promise<void>;
  onDeposit: () => void;
  onWithdraw: () => void;
  onCopyReferralCode: () => void;
  onNavigateToVerification: () => void;
  onNavigateToSettings: () => void;
  settingsInitialTab: string;
}

const DashboardDesktopContent = ({
  profile,
  totalBalance,
  winRate,
  showBalance,
  setShowBalance,
  setActiveTab,
  setShowTransferModal,
  accountBalances,
  trades,
  deposits,
  withdrawals,
  referralCount,
  isLoading,
  onNavigate,
  onTradeCompleted,
  onDeposit,
  onWithdraw,
  onCopyReferralCode,
  onNavigateToVerification,
  onNavigateToSettings,
  settingsInitialTab,
}: DashboardDesktopContentProps) => {
  return (
    <div className="hidden lg:block">
      <Tabs defaultValue="trades" className="space-y-6">
        <div className="overflow-x-auto">
          <TabsList className="bg-slate-800 grid grid-cols-5 lg:grid-cols-5 min-w-max lg:min-w-0">
            <TabsTrigger value="trades" className="text-xs sm:text-sm">Trades</TabsTrigger>
            <TabsTrigger value="deposits" className="text-xs sm:text-sm">Deposits</TabsTrigger>
            <TabsTrigger value="withdrawals" className="text-xs sm:text-sm">Withdrawals</TabsTrigger>
            <TabsTrigger value="referrals" className="text-xs sm:text-sm">Referrals</TabsTrigger>
            <TabsTrigger value="settings" className="text-xs sm:text-sm">Settings</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="trades">
          <DesktopTradesTab
            profile={profile}
            totalBalance={totalBalance}
            winRate={winRate}
            showBalance={showBalance}
            setShowBalance={setShowBalance}
            setActiveTab={setActiveTab}
            setShowTransferModal={setShowTransferModal}
            accountBalances={accountBalances}
            trades={trades}
            onNavigate={onNavigate}
            onTradeCompleted={onTradeCompleted}
          />
        </TabsContent>

        <TabsContent value="deposits" className="space-y-4">
          <DepositsTab deposits={deposits} onDeposit={onDeposit} loading={isLoading} />
        </TabsContent>

        <TabsContent value="withdrawals" className="space-y-4">
          <VerificationAlert 
            profile={profile} 
            onNavigateToSettings={onNavigateToSettings}
          />
          <WithdrawalsTab />
        </TabsContent>

        <TabsContent value="referrals" className="space-y-4">
          <ReferralsTab 
            referralCode={profile.referral_code || ''}
            referralCount={referralCount}
            onCopyReferralCode={onCopyReferralCode}
          />
        </TabsContent>


        <TabsContent value="settings" className="space-y-4">
          <VerificationAlert 
            profile={profile} 
            onNavigateToSettings={onNavigateToSettings}
            onNavigateToVerification={onNavigateToVerification}
          />
          <AccountSettingsTab initialTab={settingsInitialTab} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DashboardDesktopContent;
