
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { MessageCircle } from "lucide-react";
import KYCVerificationTab from "./KYCVerificationTab";
import CustomerSupportModal from "./CustomerSupportModal";

interface AccountSettingsTabProps {
  initialTab?: string;
}

const AccountSettingsTab = ({ initialTab = "account" }: AccountSettingsTabProps) => {
  const { toast } = useToast();
  const { user, profile, refreshProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState(initialTab);
  const [supportModalOpen, setSupportModalOpen] = useState(false);
  const [userForm, setUserForm] = useState({
    username: "",
    email: "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });

  useEffect(() => {
    if (profile && user) {
      setUserForm({
        username: profile.username || "",
        email: user.email || "",
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
      });
    }
  }, [profile, user]);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  const handleUpdateDetails = async () => {
    if (!user || !profile) return;

    setLoading(true);
    try {
      // Update profile
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ 
          username: userForm.username,
          updated_at: new Date().toISOString() 
        })
        .eq('id', user.id);

      if (profileError) throw profileError;

      // Update email if changed
      if (userForm.email !== user.email) {
        const { error: emailError } = await supabase.auth.updateUser({
          email: userForm.email
        });

        if (emailError) throw emailError;
      }

      toast({
        title: "Details Updated",
        description: "Your account details have been updated successfully.",
      });

      await refreshProfile();
    } catch (error: any) {
      console.error('Error updating details:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to update details. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCustomerSupport = () => {
    setSupportModalOpen(true);
  };

  const handleChangePassword = async () => {
    if (!userForm.currentPassword || !userForm.newPassword) {
      toast({
        title: "Error",
        description: "Please fill in all password fields.",
        variant: "destructive",
      });
      return;
    }

    if (userForm.newPassword !== userForm.confirmPassword) {
      toast({
        title: "Error",
        description: "New passwords do not match.",
        variant: "destructive",
      });
      return;
    }

    if (userForm.newPassword.length < 6) {
      toast({
        title: "Error",
        description: "New password must be at least 6 characters long.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      // Sign in with current password to verify
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user?.email || "",
        password: userForm.currentPassword
      });

      if (signInError) {
        throw new Error("Current password is incorrect.");
      }

      // Update password
      const { error: updateError } = await supabase.auth.updateUser({
        password: userForm.newPassword
      });

      if (updateError) throw updateError;

      toast({
        title: "Password Changed",
        description: "Your password has been updated successfully.",
      });

      // Clear password fields
      setUserForm({
        ...userForm,
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
      });
    } catch (error: any) {
      console.error('Error changing password:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to change password. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
      <TabsList className="bg-slate-800 grid grid-cols-2">
        <TabsTrigger value="account" className="text-xs sm:text-sm">Account Details</TabsTrigger>
        <TabsTrigger value="verification" className="text-xs sm:text-sm">Identity Verification</TabsTrigger>
      </TabsList>

      <TabsContent value="account" className="space-y-6">
        {/* Status Badges */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Account Status</CardTitle>
            <CardDescription className="text-slate-400">
              Your current account privileges and status
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2 flex-wrap">
              {profile?.user_id && (
                <Badge variant="secondary" className="bg-slate-700 text-slate-300">
                  ID: {profile.user_id}
                </Badge>
              )}
              {profile?.vip_level && profile.vip_level > 0 && (
                <Badge variant="secondary" className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
                  VIP {profile.vip_level}
                </Badge>
              )}
              {profile?.premium && (
                <Badge variant="secondary" className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
                  Extra Signal
                </Badge>
              )}
            </div>
            <div className="mt-4">
              <Button 
                onClick={handleCustomerSupport}
                variant="outline"
                className="border-slate-600 text-white font-bold hover:bg-slate-700"
              >
                <MessageCircle className="h-4 w-4 mr-2" />
                Customer Support
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Account Details */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Account Details</CardTitle>
            <CardDescription className="text-slate-400">
              Update your account information
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-white">Username</Label>
                <Input
                  id="username"
                  value={userForm.username}
                  onChange={(e) => setUserForm({...userForm, username: e.target.value})}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={userForm.email}
                  onChange={(e) => setUserForm({...userForm, email: e.target.value})}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
            </div>
            <Button 
              onClick={handleUpdateDetails} 
              disabled={loading}
              className="bg-gradient-primary hover:shadow-glow"
            >
              {loading ? "Updating..." : "Update Details"}
            </Button>
          </CardContent>
        </Card>

        {/* Password Change */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Change Password</CardTitle>
            <CardDescription className="text-slate-400">
              Update your account password for security
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="currentPassword" className="text-white">Current Password</Label>
              <Input
                id="currentPassword"
                type="password"
                value={userForm.currentPassword}
                onChange={(e) => setUserForm({...userForm, currentPassword: e.target.value})}
                className="bg-slate-700 border-slate-600 text-white"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="newPassword" className="text-white">New Password</Label>
                <Input
                  id="newPassword"
                  type="password"
                  value={userForm.newPassword}
                  onChange={(e) => setUserForm({...userForm, newPassword: e.target.value})}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-white">Confirm New Password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={userForm.confirmPassword}
                  onChange={(e) => setUserForm({...userForm, confirmPassword: e.target.value})}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
            </div>
            <Button 
              onClick={handleChangePassword} 
              disabled={loading}
              className="bg-gradient-primary hover:shadow-glow"
            >
              {loading ? "Changing..." : "Change Password"}
            </Button>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="verification">
        <KYCVerificationTab />
      </TabsContent>
      
      <CustomerSupportModal 
        key={supportModalOpen ? 'open' : 'closed'}
        open={supportModalOpen} 
        onOpenChange={setSupportModalOpen} 
      />
    </Tabs>
  );
};

export default AccountSettingsTab;
