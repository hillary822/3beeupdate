import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface UserCode {
  id: string;
  code: string;
  trade_code_id: string;
  sent_at: string;
  is_used: boolean;
  used_at: string | null;
  trade_codes?: {
    asset: string;
    profit_percentage: number;
    duration_minutes: number;
    minimum_balance: number;
    note: string | null;
    signal_type: string;
  };
}

interface UserCodesSectionProps {
  onTradeCompleted?: () => void;
}

const UserCodesSection = ({ onTradeCompleted }: UserCodesSectionProps) => {
  const [userCodes, setUserCodes] = useState<UserCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [tradingCode, setTradingCode] = useState<string | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  const fetchUserCodes = async () => {
    if (!user) return;

    try {
      // First get user codes
      const { data: userCodesData, error: userCodesError } = await supabase
        .from('user_codes')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_used', false)
        .order('sent_at', { ascending: false });

      if (userCodesError) {
        console.error('Error fetching user codes:', userCodesError);
        return;
      }

      if (!userCodesData || userCodesData.length === 0) {
        setUserCodes([]);
        return;
      }

      // Get trade codes for these user codes
      const tradeCodeIds = userCodesData.map(uc => uc.trade_code_id);
      const { data: tradeCodesData, error: tradeCodesError } = await supabase
        .from('trade_codes')
        .select('id, asset, profit_percentage, duration_minutes, minimum_balance, note, signal_type')
        .in('id', tradeCodeIds);

      if (tradeCodesError) {
        console.error('Error fetching trade codes:', tradeCodesError);
        return;
      }

      // Combine the data
      const combinedData = userCodesData.map(userCode => {
        const tradeCode = tradeCodesData?.find(tc => tc.id === userCode.trade_code_id);
        return {
          ...userCode,
          trade_codes: tradeCode
        };
      });

      // Filter out expired codes based on sent_at + duration
      const now = new Date();
      const activeCodes = combinedData.filter(code => {
        if (!code.trade_codes?.duration_minutes) return true;
        const expiryTime = new Date(code.sent_at);
        expiryTime.setMinutes(expiryTime.getMinutes() + code.trade_codes.duration_minutes);
        return now < expiryTime;
      });

      setUserCodes(activeCodes);
    } catch (error) {
      console.error('Error fetching user codes:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserCodes();
  }, [user]);

  const handleUseCode = async (code: UserCode) => {
    if (!user) return;

    setTradingCode(code.code);
    try {
      // Use the existing trade code system
      const { data, error } = await supabase.rpc('use_trade_code', {
        code_input: code.code,
        user_id_input: user.id
      });

      if (error) {
        console.error('Error using trade code:', error);
        toast({
          title: "Error",
          description: error.message || "Failed to use trade code",
          variant: "destructive",
        });
        return;
      }

      if (!(data as any).success) {
        toast({
          title: "Error",
          description: (data as any).error || "Failed to use trade code",
          variant: "destructive",
        });
        return;
      }

      // Mark the user code as used
      await supabase
        .from('user_codes')
        .update({ 
          is_used: true, 
          used_at: new Date().toISOString() 
        })
        .eq('id', code.id);

      toast({
        title: "Trade Started",
        description: `Trading ${(data as any).asset} with ${(data as any).amount_invested} USDT`,
      });

      // Refresh codes and trigger completion callback
      fetchUserCodes();
      onTradeCompleted?.();
    } catch (error) {
      console.error('Error using trade code:', error);
      toast({
        title: "Error",
        description: "Failed to use trade code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setTradingCode(null);
    }
  };

  if (loading) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="text-center text-slate-400">Loading your codes...</div>
        </CardContent>
      </Card>
    );
  }

  if (userCodes.length === 0) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Your Invitation Signals</CardTitle>
          <CardDescription className="text-slate-400">
            Invitation codes will appear here if eligible
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center text-slate-400 py-4">
            No new trade codes available
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">Your Invitation Signals</CardTitle>
        <CardDescription className="text-slate-400">
          Click "Trade Code" to use any of these codes instantly
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {userCodes.map((code) => {
          const tradeCode = code.trade_codes;
          const expiryTime = new Date(code.sent_at);
          if (tradeCode?.duration_minutes) {
            expiryTime.setMinutes(expiryTime.getMinutes() + tradeCode.duration_minutes);
          }
          
          return (
            <div
              key={code.id}
              className="p-4 bg-slate-700 rounded-lg border border-slate-600 space-y-3"
            >
              {/* Header Row */}
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge 
                    variant={tradeCode?.signal_type === "BUY" ? "default" : "destructive"}
                    className={`text-xs px-2 py-0.5 ${
                      tradeCode?.signal_type === "BUY" 
                        ? "bg-green-500 hover:bg-green-600 text-white" 
                        : "bg-red-500 hover:bg-red-600 text-white"
                    }`}
                  >
                    {tradeCode?.signal_type || "BUY"}
                  </Badge>
                  <span className="text-white font-medium text-sm">{tradeCode?.asset || "Unknown"}</span>
                </div>
                <Badge 
                  variant="secondary" 
                  className="text-xs px-2 py-0.5 whitespace-nowrap bg-yellow-500 text-white"
                >
                  New Signal
                </Badge>
              </div>

              {/* Details Grid - Responsive */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Signal Code:</span>
                    <div className="text-right">
                      <span className="text-white font-mono text-xs block">
                        {code.code}
                      </span>
                      {tradeCode?.note && (
                        <span className="text-slate-400 text-xs italic">
                          {tradeCode.note}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Required Amount:</span>
                    <span className="text-white font-medium">${Number(tradeCode?.minimum_balance || 0).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Duration:</span>
                    <span className="text-white">{tradeCode?.duration_minutes || 15}m</span>
                  </div>
                </div>
                
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Expected Profit:</span>
                    <span className="text-green-400">
                      +{Number(tradeCode?.profit_percentage || 0).toFixed(1)}%
                      <span className="text-xs ml-1">
                        (+${((Number(tradeCode?.minimum_balance || 0) * Number(tradeCode?.profit_percentage || 0)) / 100).toFixed(2)})
                      </span>
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Expires:</span>
                    <span className="text-white text-xs">
                      {expiryTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Received:</span>
                    <span className="text-white text-xs">
                      {new Date(code.sent_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="flex justify-center pt-2 border-t border-slate-600">
                <Button
                  onClick={() => handleUseCode(code)}
                  disabled={tradingCode === code.code}
                  className="bg-blue-600 hover:bg-blue-700 text-yellow-400 px-6 py-2"
                >
                  {tradingCode === code.code ? "Processing..." : "Click To Confirm Order"}
                </Button>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};

export default UserCodesSection;