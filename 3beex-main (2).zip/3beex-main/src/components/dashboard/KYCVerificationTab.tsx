
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Upload, CheckCircle, XCircle, Clock, Mail, Search, ChevronDown, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { kycCountries } from "@/utils/countryData";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

interface VerificationSubmission {
  id: string;
  verification_type: 'basic' | 'advanced';
  status: 'pending' | 'approved' | 'rejected';
  full_name?: string;
  country?: string;
  state?: string;
  id_card_number?: string;
  submitted_at: string;
  reviewed_at?: string;
  admin_notes?: string;
}


const KYCVerificationTab = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [verifications, setVerifications] = useState<VerificationSubmission[]>([]);
  
  // Basic verification state
  const [basicForm, setBasicForm] = useState({
    fullName: '',
    country: '',
    state: '',
    idNumber: ''
  });
  const [countryOpen, setCountryOpen] = useState(false);
  
  // Advanced verification state - now using base64 strings
  const [advancedFiles, setAdvancedFiles] = useState<{
    id_front?: string;
    id_back?: string;
    selfie_with_id?: string;
  }>({});

  useEffect(() => {
    if (user) {
      fetchVerifications();
    }
  }, [user]);

  const fetchVerifications = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('kyc_verifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching verifications:', error);
        return;
      }

      setVerifications(data || []);
    } catch (error) {
      console.error('Error in fetchVerifications:', error);
    }
  };

  const getVerificationByType = (type: 'basic' | 'advanced') => {
    return verifications.find(v => v.verification_type === type);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-4 w-4 text-primary" />;
      case 'rejected':
        return <XCircle className="h-4 w-4 text-red-400" />;
      default:
        return <Clock className="h-4 w-4 text-yellow-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-primary';
      case 'rejected':
        return 'bg-red-600';
      default:
        return 'bg-yellow-600';
    }
  };

  const handleBasicSubmit = async () => {
    console.log('handleBasicSubmit called');
    console.log('User:', user);
    console.log('Basic form:', basicForm);
    
    if (!user) {
      console.error('No user found');
      toast({
        title: "Authentication Error",
        description: "Please log in to submit verification",
        variant: "destructive",
      });
      return;
    }
    
    console.log('Starting basic verification submission for user:', user.id);
    
    if (!basicForm.fullName || !basicForm.country || !basicForm.state || !basicForm.idNumber) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    const existingBasic = getVerificationByType('basic');
    if (existingBasic && existingBasic.status === 'pending') {
      toast({
        title: "Request Already Pending",
        description: "You already have a pending basic verification request. Please wait for it to be reviewed.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      console.log('Submitting basic verification data:', {
        user_id: user.id,
        full_name: basicForm.fullName,
        country: basicForm.country,
        state: basicForm.state,
        id_card_number: basicForm.idNumber
      });

      if (existingBasic) {
        console.log('Updating existing basic verification:', existingBasic.id);
        // Update existing basic verification
        const { data, error } = await supabase
          .from('kyc_verifications')
          .update({
            full_name: basicForm.fullName,
            country: basicForm.country,
            state: basicForm.state,
            id_card_number: basicForm.idNumber,
            status: 'pending',
            submitted_at: new Date().toISOString()
          })
          .eq('id', existingBasic.id)
          .select();

        if (error) {
          console.error('Supabase update error:', error);
          throw error;
        }
        console.log('Update successful:', data);
      } else {
        console.log('Creating new basic verification');
        // Create new basic verification
        const { data, error } = await supabase
          .from('kyc_verifications')
          .insert({
            user_id: user.id,
            verification_type: 'basic',
            full_name: basicForm.fullName,
            country: basicForm.country,
            state: basicForm.state,
            id_card_number: basicForm.idNumber,
            status: 'pending'
          })
          .select();

        if (error) {
          console.error('Supabase insert error:', error);
          throw error;
        }
        console.log('Insert successful:', data);
      }

      toast({
        title: "Basic Verification Submitted",
        description: "Your basic verification has been submitted for review",
      });

      // Reset form and refetch
      setBasicForm({ fullName: '', country: '', state: '', idNumber: '' });
      await fetchVerifications();
    } catch (error: any) {
      console.error('Error submitting basic verification:', {
        message: error?.message,
        details: error?.details,
        hint: error?.hint,
        code: error?.code
      });
      
      let errorMessage = "Failed to submit basic verification. Please try again.";
      if (error?.message) {
        errorMessage = `Submission failed: ${error.message}`;
      }
      
      toast({
        title: "Submission Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const handleAdvancedSubmit = async () => {
    if (!user) return;
    
    if (!advancedFiles.id_front || !advancedFiles.id_back || !advancedFiles.selfie_with_id) {
      toast({
        title: "Missing Files",
        description: "Please upload all required documents",
        variant: "destructive",
      });
      return;
    }

    const existingAdvanced = getVerificationByType('advanced');
    if (existingAdvanced && existingAdvanced.status === 'pending') {
      toast({
        title: "Request Already Pending",
        description: "You already have a pending advanced verification request. Please wait for it to be reviewed.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      console.log('Starting advanced verification submission via email...');

      let verificationId: string;

      if (existingAdvanced) {
        verificationId = existingAdvanced.id;
      } else {
        // Create new advanced verification record
        const { data, error } = await supabase
          .from('kyc_verifications')
          .insert({
            user_id: user.id,
            verification_type: 'advanced',
            status: 'pending'
          })
          .select()
          .single();

        if (error) throw error;
        verificationId = data.id;
      }

      // Get user profile for email
      const { data: profile } = await supabase
        .from('profiles')
        .select('username, email')
        .eq('id', user.id)
        .single();

      // Send documents via email
      const { data, error } = await supabase.functions.invoke('send-kyc-documents', {
        body: {
          user_id: user.id,
          user_email: profile?.email || user.email,
          username: profile?.username || 'Unknown',
          verification_id: verificationId,
          documents: {
            id_front: advancedFiles.id_front,
            id_back: advancedFiles.id_back,
            selfie_with_id: advancedFiles.selfie_with_id
          }
        }
      });

      if (error) throw error;

      toast({
        title: "Advanced Verification Submitted",
        description: "Your documents have been submitted. Admin will review your submission.",
        variant: "default",
      });

      // Reset files and refetch
      setAdvancedFiles({});
      await fetchVerifications();
    } catch (error) {
      console.error('Error submitting advanced verification:', error);
      toast({
        title: "Submission Failed",
        description: error instanceof Error ? error.message : "Failed to submit advanced verification. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFileSelect = async (type: 'id_front' | 'id_back' | 'selfie_with_id', event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      console.log(`Selected file for ${type}:`, {
        name: file.name,
        size: file.size,
        type: file.type
      });

      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        toast({
          title: "File too large",
          description: "Please select a file smaller than 10MB",
          variant: "destructive",
        });
        return;
      }

      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid file type",
          description: "Please select an image file (JPG, PNG, etc.)",
          variant: "destructive",
        });
        return;
      }

      try {
        const base64String = await convertFileToBase64(file);
        setAdvancedFiles(prev => ({
          ...prev,
          [type]: base64String
        }));
      } catch (error) {
        console.error('Error converting file to base64:', error);
        toast({
          title: "File Error",
          description: "Failed to process the selected file",
          variant: "destructive",
        });
      }
    }
  };

  const basicVerification = getVerificationByType('basic');
  const advancedVerification = getVerificationByType('advanced');

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-white mb-2">Account Verification</h2>
        <p className="text-slate-400">Complete your verification to unlock all features</p>
      </div>

      {/* Verification Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white font-semibold">Basic Verification</h3>
                <p className="text-slate-400 text-sm">Identity information</p>
              </div>
              <div className="flex items-center gap-2">
                {basicVerification ? (
                  <>
                    {getStatusIcon(basicVerification.status)}
                    <Badge className={getStatusColor(basicVerification.status)}>
                      {basicVerification.status}
                    </Badge>
                  </>
                ) : (
                  <Badge variant="outline">Not Started</Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white font-semibold">Advanced Verification</h3>
                <p className="text-slate-400 text-sm">Document verification</p>
              </div>
              <div className="flex items-center gap-2">
                {advancedVerification ? (
                  <>
                    {getStatusIcon(advancedVerification.status)}
                    <Badge className={getStatusColor(advancedVerification.status)}>
                      {advancedVerification.status}
                    </Badge>
                  </>
                ) : (
                  <Badge variant="outline">Not Started</Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Basic Verification Form */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            Basic Verification
            {basicVerification?.status === 'approved' && <CheckCircle className="h-5 w-5 text-primary" />}
          </CardTitle>
          <CardDescription className="text-slate-400">
            Provide your basic information for identity verification
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {basicVerification?.status === 'approved' ? (
            <div className="bg-primary/20 border border-primary/30 rounded-lg p-4">
              <div className="flex items-center gap-2 text-primary mb-2">
                <CheckCircle className="h-4 w-4" />
                <span className="font-semibold">Verification Approved</span>
              </div>
              <p className="text-primary/80 text-sm">
                Your basic verification has been approved. You can now proceed with advanced verification if needed.
              </p>
            </div>
          ) : (
            <>
              {basicVerification?.status === 'rejected' && (
                <div className="bg-red-900/20 border border-red-600/30 rounded-lg p-4">
                  <div className="flex items-center gap-2 text-red-400 mb-2">
                    <XCircle className="h-4 w-4" />
                    <span className="font-semibold">Verification Rejected</span>
                  </div>
                  {basicVerification.admin_notes && (
                    <p className="text-red-300 text-sm">{basicVerification.admin_notes}</p>
                  )}
                </div>
              )}

              {basicVerification?.status === 'pending' && (
                <div className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-4">
                  <div className="flex items-center gap-2 text-yellow-400 mb-2">
                    <Clock className="h-4 w-4" />
                    <span className="font-semibold">Verification Pending</span>
                  </div>
                  <p className="text-yellow-300 text-sm">
                    Your basic verification is being reviewed. Please wait for approval before submitting a new request.
                  </p>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="text-white">Full Name *</Label>
                  <Input
                    id="fullName"
                    value={basicForm.fullName}
                    onChange={(e) => setBasicForm(prev => ({ ...prev, fullName: e.target.value }))}
                    placeholder="Enter your full name"
                    className="bg-slate-700 border-slate-600 text-white"
                    disabled={basicVerification?.status === 'pending'}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="country" className="text-white">Country *</Label>
                  <Popover open={countryOpen} onOpenChange={setCountryOpen}>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        aria-expanded={countryOpen}
                        className="w-full justify-between bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
                        disabled={basicVerification?.status === 'pending'}
                      >
                        {basicForm.country
                          ? kycCountries.find((country) => country.value === basicForm.country)?.label
                          : "Select your country"}
                        <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0 bg-slate-700 border-slate-600">
                      <Command className="bg-slate-700">
                        <CommandInput 
                          placeholder="Search countries..." 
                          className="text-white border-slate-600"
                        />
                        <CommandList className="max-h-60">
                          <CommandEmpty className="text-slate-400">No country found.</CommandEmpty>
                          <CommandGroup>
                            {kycCountries.map((country) => (
                              <CommandItem
                                key={country.value}
                                value={country.label}
                                onSelect={() => {
                                  setBasicForm(prev => ({ ...prev, country: country.value }));
                                  setCountryOpen(false);
                                }}
                                className="text-white hover:bg-slate-600 cursor-pointer"
                              >
                                <Check
                                  className={cn(
                                    "mr-2 h-4 w-4",
                                    basicForm.country === country.value ? "opacity-100" : "opacity-0"
                                  )}
                                />
                                {country.label}
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="state" className="text-white">State/Province *</Label>
                  <Input
                    id="state"
                    value={basicForm.state}
                    onChange={(e) => setBasicForm(prev => ({ ...prev, state: e.target.value }))}
                    placeholder="Enter your state or province"
                    className="bg-slate-700 border-slate-600 text-white"
                    disabled={basicVerification?.status === 'pending'}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="idNumber" className="text-white">ID Card Number *</Label>
                  <Input
                    id="idNumber"
                    value={basicForm.idNumber}
                    onChange={(e) => setBasicForm(prev => ({ ...prev, idNumber: e.target.value }))}
                    placeholder="Enter your ID number"
                    className="bg-slate-700 border-slate-600 text-white"
                    disabled={basicVerification?.status === 'pending'}
                  />
                </div>
              </div>

              <Button 
                onClick={handleBasicSubmit}
                disabled={loading || basicVerification?.status === 'pending'}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {loading ? "Submitting..." : "Submit Basic Verification"}
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      {/* Advanced Verification Form */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            Advanced Verification
            {advancedVerification?.status === 'approved' && <CheckCircle className="h-5 w-5 text-primary" />}
            <Mail className="h-5 w-5 text-blue-400" />
          </CardTitle>
          <CardDescription className="text-slate-400">
            Upload documents - they will be sent securely via email for review
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {advancedVerification?.status === 'approved' ? (
            <div className="bg-primary/20 border border-primary/30 rounded-lg p-4">
              <div className="flex items-center gap-2 text-primary mb-2">
                <CheckCircle className="h-4 w-4" />
                <span className="font-semibold">Advanced Verification Approved</span>
              </div>
              <p className="text-primary/80 text-sm">
                Your advanced verification has been approved. All features are now available to you.
              </p>
            </div>
          ) : (
            <>
              {advancedVerification?.status === 'rejected' && (
                <div className="bg-red-900/20 border border-red-600/30 rounded-lg p-4">
                  <div className="flex items-center gap-2 text-red-400 mb-2">
                    <XCircle className="h-4 w-4" />
                    <span className="font-semibold">Advanced Verification Rejected</span>
                  </div>
                  {advancedVerification.admin_notes && (
                    <p className="text-red-300 text-sm">{advancedVerification.admin_notes}</p>
                  )}
                </div>
              )}

              {advancedVerification?.status === 'pending' && (
                <div className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-4">
                  <div className="flex items-center gap-2 text-yellow-400 mb-2">
                    <Clock className="h-4 w-4" />
                    <span className="font-semibold">Advanced Verification Pending</span>
                  </div>
                  <p className="text-yellow-300 text-sm">
                    Your advanced verification is being reviewed. Please wait for approval before submitting a new request.
                  </p>
                </div>
              )}

              <div className="bg-blue-900/20 border border-blue-600/30 rounded-lg p-4 mb-4">
                <div className="flex items-center gap-2 text-blue-400 mb-2">
                  <Mail className="h-4 w-4" />
                  <span className="font-semibold">Secure Email Delivery</span>
                </div>
                <p className="text-blue-300 text-sm">
                  Your documents will be securely sent to our admin team via email for review. This ensures reliable delivery without storage issues.
                </p>
              </div>

              <div className="space-y-4">
                <div className="text-slate-300 text-sm">
                  Please upload clear photos of your government-issued ID and a selfie holding the ID.
                  Max file size: 10MB per image. Supported formats: JPG, PNG, GIF, WEBP.
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* ID Front */}
                  <div className="space-y-2">
                    <Label className="text-white">ID Front *</Label>
                    <div className="border-2 border-dashed border-slate-600 rounded-lg p-4 text-center hover:border-slate-500 transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileSelect('id_front', e)}
                        className="hidden"
                        id="id_front"
                        disabled={advancedVerification?.status === 'pending'}
                      />
                      <label htmlFor="id_front" className={`cursor-pointer ${advancedVerification?.status === 'pending' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                        <Upload className="h-6 w-6 text-slate-400 mx-auto mb-2" />
                        <p className="text-slate-400 text-sm">
                          {advancedFiles.id_front ? "✓ ID front selected" : "Click to upload ID front"}
                        </p>
                      </label>
                    </div>
                  </div>

                  {/* ID Back */}
                  <div className="space-y-2">
                    <Label className="text-white">ID Back *</Label>
                    <div className="border-2 border-dashed border-slate-600 rounded-lg p-4 text-center hover:border-slate-500 transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileSelect('id_back', e)}
                        className="hidden"
                        id="id_back"
                        disabled={advancedVerification?.status === 'pending'}
                      />
                      <label htmlFor="id_back" className={`cursor-pointer ${advancedVerification?.status === 'pending' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                        <Upload className="h-6 w-6 text-slate-400 mx-auto mb-2" />
                        <p className="text-slate-400 text-sm">
                          {advancedFiles.id_back ? "✓ ID back selected" : "Click to upload ID back"}
                        </p>
                      </label>
                    </div>
                  </div>

                  {/* Selfie with ID */}
                  <div className="space-y-2">
                    <Label className="text-white">Selfie with ID *</Label>
                    <div className="border-2 border-dashed border-slate-600 rounded-lg p-4 text-center hover:border-slate-500 transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileSelect('selfie_with_id', e)}
                        className="hidden"
                        id="selfie_with_id"
                        disabled={advancedVerification?.status === 'pending'}
                      />
                      <label htmlFor="selfie_with_id" className={`cursor-pointer ${advancedVerification?.status === 'pending' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                        <Upload className="h-6 w-6 text-slate-400 mx-auto mb-2" />
                        <p className="text-slate-400 text-sm">
                          {advancedFiles.selfie_with_id ? "✓ Selfie selected" : "Click to upload selfie"}
                        </p>
                      </label>
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={handleAdvancedSubmit}
                  disabled={loading || !advancedFiles.id_front || !advancedFiles.id_back || !advancedFiles.selfie_with_id || advancedVerification?.status === 'pending'}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  {loading ? "Sending Documents..." : "Submit Advanced Verification"}
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default KYCVerificationTab;
