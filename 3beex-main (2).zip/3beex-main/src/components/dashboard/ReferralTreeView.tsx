import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronRight, User, Users, DollarSign } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ReferralNode {
  id: string;
  username: string;
  email: string;
  user_id: number;
  referral_code: string;
  created_at: string;
  earnings: number;
  children: ReferralNode[];
  isExpanded?: boolean;
  level: number;
  exchange_balance: number;
  trade_balance: number;
  perpetual_balance: number;
  total_balance: number;
  status: 'active' | 'inactive';
}

interface ReferralTreeViewProps {
  userId: string;
  isAdminView?: boolean;
}

const ReferralTreeView = ({ userId, isAdminView = false }: ReferralTreeViewProps) => {
  const [referralTree, setReferralTree] = useState<ReferralNode | null>(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalReferrals: 0,
    totalEarnings: 0,
    directReferrals: 0
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchReferralTree();
  }, [userId]);

  const fetchReferralTree = async () => {
    setLoading(true);
    try {
      console.log('Fetching referral tree for user:', userId, 'isAdminView:', isAdminView);
      
      // Get the root user first
      const { data: rootUser, error: rootError } = await supabase
        .from('profiles')
        .select('id, username, email, user_id, referral_code, created_at, exchange_balance, trade_balance, perpetual_balance')
        .eq('id', userId)
        .single();

      if (rootError || !rootUser) {
        console.error('Error fetching root user:', rootError);
        throw new Error('User not found');
      }

      console.log('Root user found:', rootUser);

      // Build the tree recursively
      const tree = await buildReferralTree(rootUser, 0);
      console.log('Built referral tree:', tree);
      setReferralTree(tree);

      // Calculate stats
      const stats = calculateTreeStats(tree);
      console.log('Calculated stats:', stats);
      setStats(stats);
    } catch (error) {
      console.error('Error fetching referral tree:', error);
      toast({
        title: "Error",
        description: "Failed to load referral tree",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const buildReferralTree = async (user: any, level: number): Promise<ReferralNode> => {
    console.log(`Building tree for user ${user.username} at level ${level}`);
    
    if (level >= 50) { // Prevent infinite recursion, limit to 50 levels
      console.log('Max level reached, stopping recursion');
      const totalBalance = (user.exchange_balance || 0) + (user.trade_balance || 0) + (user.perpetual_balance || 0);
      return {
        ...user,
        earnings: 0,
        children: [],
        isExpanded: false,
        level,
        exchange_balance: user.exchange_balance || 0,
        trade_balance: user.trade_balance || 0,
        perpetual_balance: user.perpetual_balance || 0,
        total_balance: totalBalance,
        status: totalBalance > 0 ? 'active' : 'inactive'
      };
    }

    // Get direct referrals - use service role for admin view to bypass RLS
    let referralsQuery = supabase
      .from('referrals')
      .select(`
        earnings,
        referred_id
      `)
      .eq('referrer_id', user.id);
      
    const { data: referrals, error } = await referralsQuery;

    console.log(`Found ${referrals?.length || 0} referrals for user ${user.username}:`, referrals);

    if (error) {
      console.error('Error fetching referrals for user:', user.id, error);
      const totalBalance = (user.exchange_balance || 0) + (user.trade_balance || 0) + (user.perpetual_balance || 0);
      return {
        ...user,
        earnings: 0,
        children: [],
        isExpanded: level < 2, // Auto-expand first 2 levels
        level,
        exchange_balance: user.exchange_balance || 0,
        trade_balance: user.trade_balance || 0,
        perpetual_balance: user.perpetual_balance || 0,
        total_balance: totalBalance,
        status: totalBalance > 0 ? 'active' : 'inactive'
      };
    }

    const children: ReferralNode[] = [];
    let totalEarnings = 0;

    if (referrals && referrals.length > 0) {
      console.log(`Processing ${referrals.length} referrals for ${user.username}`);
      
      // Get profile data for all referred users
      const referredIds = referrals.map(r => r.referred_id);
      console.log('Fetching profiles for referred IDs:', referredIds);
      
      const { data: referredProfiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, username, email, user_id, referral_code, created_at, exchange_balance, trade_balance, perpetual_balance')
        .in('id', referredIds);

      console.log('Fetched referred profiles:', referredProfiles, 'Error:', profilesError);

      if (!profilesError && referredProfiles && referredProfiles.length > 0) {
        console.log(`Found ${referredProfiles.length} profiles for ${referrals.length} referrals`);
        
        for (const referral of referrals) {
          const profile = referredProfiles.find(p => p.id === referral.referred_id);
          if (profile) {
            console.log(`Building child tree for ${profile.username}`);
            const child = await buildReferralTree(profile, level + 1);
            children.push(child);
            totalEarnings += Number(referral.earnings || 0);
          } else {
            console.log(`No profile found for referred_id: ${referral.referred_id}`);
          }
        }
      } else {
        console.log('No profiles found or error occurred:', profilesError);
      }
    } else {
      console.log(`No referrals found for ${user.username}`);
    }

    const totalBalance = (user.exchange_balance || 0) + (user.trade_balance || 0) + (user.perpetual_balance || 0);
    
    return {
      ...user,
      earnings: totalEarnings,
      children,
      isExpanded: level < 2, // Auto-expand first 2 levels
      level,
      exchange_balance: user.exchange_balance || 0,
      trade_balance: user.trade_balance || 0,
      perpetual_balance: user.perpetual_balance || 0,
      total_balance: totalBalance,
      status: totalBalance > 0 ? 'active' : 'inactive'
    };
  };

  const calculateTreeStats = (node: ReferralNode): typeof stats => {
    let totalReferrals = 0;
    let totalEarnings = node.earnings;
    const directReferrals = node.children.length;

    const traverse = (currentNode: ReferralNode) => {
      totalReferrals += currentNode.children.length;
      totalEarnings += currentNode.earnings;
      
      currentNode.children.forEach(child => traverse(child));
    };

    traverse(node);

    return {
      totalReferrals,
      totalEarnings,
      directReferrals
    };
  };

  const toggleExpanded = (nodeId: string) => {
    const updateNode = (node: ReferralNode): ReferralNode => {
      if (node.id === nodeId) {
        return { ...node, isExpanded: !node.isExpanded };
      }
      return {
        ...node,
        children: node.children.map(updateNode)
      };
    };

    if (referralTree) {
      setReferralTree(updateNode(referralTree));
    }
  };

  const renderTreeNode = (node: ReferralNode) => {
    const hasChildren = node.children.length > 0;
    const indentLevel = Math.min(node.level * 20, 200); // Max indent of 200px

    return (
      <div key={node.id} className="w-full">
        <div 
          className={`flex items-center gap-2 p-2 rounded-md mb-1 transition-colors border ${
            isAdminView 
              ? "bg-slate-700/50 hover:bg-slate-700/70 border-slate-600" 
              : "bg-card/50 hover:bg-card/70 border-border"
          }`}
          style={{ marginLeft: `${indentLevel}px` }}
        >
          {hasChildren ? (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => toggleExpanded(node.id)}
              className="p-1 h-6 w-6"
            >
              {node.isExpanded ? (
                <ChevronDown className="h-3 w-3" />
              ) : (
                <ChevronRight className="h-3 w-3" />
              )}
            </Button>
          ) : (
            <div className="w-6 h-6 flex items-center justify-center">
              <User className={`h-3 w-3 ${isAdminView ? "text-slate-400" : "text-slate-400"}`} />
            </div>
          )}
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`font-medium text-sm ${isAdminView ? "text-white" : "text-foreground"}`}>{node.username}</span>
              <Badge variant="outline" className={`text-xs ${isAdminView ? "text-slate-300 border-slate-500" : ""}`}>
                ID: {node.user_id}
              </Badge>
              {node.level > 0 && (
                <Badge variant="secondary" className={`text-xs ${isAdminView ? "bg-slate-600 text-slate-200" : ""}`}>
                  Level {node.level}
                </Badge>
              )}
              <Badge 
                variant={node.status === 'active' ? 'default' : 'destructive'} 
                className="text-xs"
              >
                {node.status === 'active' ? 'Active' : 'Inactive'}
              </Badge>
              {isAdminView && node.total_balance > 0 && (
                <Badge variant="outline" className="text-xs text-green-400 border-green-400">
                  ${node.total_balance.toFixed(2)}
                </Badge>
              )}
            </div>
            <div className={`text-xs truncate ${isAdminView ? "text-slate-300" : "text-muted-foreground"}`}>{node.email}</div>
          </div>
          
          <div className="flex items-center gap-2 text-sm">
            {hasChildren && (
              <div className={`flex items-center gap-1 ${isAdminView ? "text-blue-400" : "text-primary"}`}>
                <Users className="h-3 w-3" />
                <span>{node.children.length}</span>
              </div>
            )}
            {node.earnings > 0 && (
              <div className={`flex items-center gap-1 ${isAdminView ? "text-green-400" : "text-primary"}`}>
                <DollarSign className="h-3 w-3" />
                <span>${node.earnings.toFixed(2)}</span>
              </div>
            )}
          </div>
        </div>
        
        {hasChildren && node.isExpanded && (
          <div className="space-y-1">
            {node.children.map(child => renderTreeNode(child))}
          </div>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <Card className={isAdminView ? "bg-slate-800 border-slate-700" : ""}>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className={`animate-spin rounded-full h-8 w-8 border-b-2 ${isAdminView ? "border-blue-400" : "border-primary"}`}></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!referralTree) {
    return (
      <Card className={isAdminView ? "bg-slate-800 border-slate-700" : ""}>
        <CardContent className="p-6">
          <div className={`text-center ${isAdminView ? "text-slate-300" : "text-muted-foreground"}`}>
            No referral data available
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className={isAdminView ? "bg-slate-800 border-slate-700" : ""}>
          <CardContent className="p-4">
            <div className="text-center">
              <p className={`text-2xl font-bold ${isAdminView ? "text-white" : "text-foreground"}`}>{stats.directReferrals}</p>
              <p className={`${isAdminView ? "text-slate-300" : "text-muted-foreground"}`}>Direct Referrals</p>
            </div>
          </CardContent>
        </Card>
        <Card className={isAdminView ? "bg-slate-800 border-slate-700" : ""}>
          <CardContent className="p-4">
            <div className="text-center">
              <p className={`text-2xl font-bold ${isAdminView ? "text-blue-400" : "text-primary"}`}>{stats.totalReferrals}</p>
              <p className={`${isAdminView ? "text-slate-300" : "text-muted-foreground"}`}>Total Network</p>
            </div>
          </CardContent>
        </Card>
        <Card className={isAdminView ? "bg-slate-800 border-slate-700" : ""}>
          <CardContent className="p-4">
            <div className="text-center">
              <p className={`text-2xl font-bold ${isAdminView ? "text-green-400" : "text-primary"}`}>${stats.totalEarnings.toFixed(2)}</p>
              <p className={`${isAdminView ? "text-slate-300" : "text-muted-foreground"}`}>Total Earnings</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Referral Tree */}
      <Card className={isAdminView ? "bg-slate-800 border-slate-700" : ""}>
        <CardHeader>
          <CardTitle className={`flex items-center gap-2 ${isAdminView ? "text-white" : "text-foreground"}`}>
            <Users className="h-5 w-5" />
            {isAdminView ? 'User Referral Tree' : 'Your Referral Network'}
          </CardTitle>
        </CardHeader>
        <CardContent className="max-h-96 overflow-y-auto">
          <div className="space-y-1">
            {renderTreeNode(referralTree)}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ReferralTreeView;