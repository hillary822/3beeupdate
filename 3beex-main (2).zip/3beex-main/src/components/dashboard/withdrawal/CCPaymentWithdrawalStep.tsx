import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { ccPaymentSupabase } from "@/integrations/supabase/client";
import { Loader2, ArrowUpRight, CheckCircle, AlertCircle } from "lucide-react";

interface CCPaymentWithdrawalStepProps {
  onSuccess: () => void;
  onCancel: () => void;
}

const CCPaymentWithdrawalStep = ({
  onSuccess,
  onCancel,
}: CCPaymentWithdrawalStepProps) => {
  const { toast } = useToast();
  const { user, profile } = useAuth();
  const [withdrawalAmount, setWithdrawalAmount] = useState("");
  const [walletAddress, setWalletAddress] = useState("");
  const [loading, setLoading] = useState(false);
  const [kycVerified, setKycVerified] = useState(false);
  const [checkingKyc, setCheckingKyc] = useState(true);
  const [step, setStep] = useState<"form" | "processing" | "success">("form");
  const [withdrawalId, setWithdrawalId] = useState("");

  useEffect(() => {
    if (user) {
      checkKycStatus();
    }
  }, [user]);

  const checkKycStatus = async () => {
    if (!user) return;

    setCheckingKyc(true);
    try {
      const { data, error } = await ccPaymentSupabase
        .from("profiles")
        .select("verified")
        .eq("id", user.id)
        .single();

      if (error) {
        console.error("Error checking KYC status:", error);
        setKycVerified(false);
      } else {
        setKycVerified(data?.verified || false);
      }
    } catch (error) {
      console.error("Error checking KYC status:", error);
      setKycVerified(false);
    } finally {
      setCheckingKyc(false);
    }
  };

  const handleCreateWithdrawal = async () => {
    if (!withdrawalAmount || parseFloat(withdrawalAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid withdrawal amount",
        variant: "destructive",
      });
      return;
    }

    if (!walletAddress) {
      toast({
        title: "Missing Wallet Address",
        description: "Please enter your USDT wallet address",
        variant: "destructive",
      });
      return;
    }

    if (!user || !profile) {
      toast({
        title: "Authentication Error",
        description: "Please log in to make a withdrawal",
        variant: "destructive",
      });
      return;
    }

    const amount = parseFloat(withdrawalAmount);
    if (amount > (profile.exchange_balance || 0)) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough balance for this withdrawal",
        variant: "destructive",
      });
      return;
    }

    if (!kycVerified) {
      toast({
        title: "KYC Verification Required",
        description:
          "You must complete both basic and advanced KYC verification before withdrawing funds.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setStep("processing");

    try {
      const { data, error } = await ccPaymentSupabase.functions.invoke(
        "ccpayment-create-withdrawal",
        {
          body: {
            user_id: user.id,
            amount: amount,
            currency: "USDT",
            address: walletAddress,
          },
        }
      );

      if (error) {
        throw error;
      }

      if (data.order_id) {
        setWithdrawalId(data.order_id);
        setStep("success");

        toast({
          title: "Withdrawal Initiated",
          description:
            "Your withdrawal has been submitted and is being processed",
        });
      } else {
        throw new Error("Invalid response from withdrawal processor");
      }
    } catch (error: any) {
      console.error("Withdrawal creation error:", error);
      toast({
        title: "Withdrawal Error",
        description:
          error.message || "Failed to create withdrawal. Please try again.",
        variant: "destructive",
      });
      setStep("form");
    } finally {
      setLoading(false);
    }
  };

  if (checkingKyc) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
          <span className="ml-2 text-white">
            Checking verification status...
          </span>
        </CardContent>
      </Card>
    );
  }

  if (!kycVerified) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-500" />
            KYC Verification Required
          </CardTitle>
          <CardDescription className="text-slate-400">
            Complete verification to withdraw funds
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-red-900/20 border border-red-800 rounded-lg">
            <p className="text-red-400 mb-3">
              You must complete both basic and advanced KYC verification before
              you can withdraw funds.
            </p>
            <p className="text-slate-400 text-sm">
              Please go to Account Settings to complete your verification.
            </p>
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={onCancel}
              className="flex-1 border-slate-600 text-white hover:bg-slate-700"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                // Navigate to account settings - you may need to implement this navigation
                toast({
                  title: "Navigate to Account Settings",
                  description:
                    "Please complete your KYC verification in Account Settings",
                });
                onCancel();
              }}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              Go to Settings
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (step === "form") {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <ArrowUpRight className="h-5 w-5" />
            Withdraw Funds
          </CardTitle>
          <CardDescription className="text-slate-400">
            Withdraw USDT to your external wallet
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-3 bg-slate-700 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Available Balance:</span>
              <span className="text-white font-semibold">
                ${profile?.exchange_balance?.toFixed(2) || "0.00"}
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount" className="text-white">
              Withdrawal Amount (USDT)
            </Label>
            <Input
              id="amount"
              type="number"
              placeholder="Enter amount to withdraw"
              value={withdrawalAmount}
              onChange={(e) => setWithdrawalAmount(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
              min="1"
              step="0.01"
              disabled={loading}
            />
            <p className="text-sm text-slate-400">Minimum withdrawal: $1.00</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address" className="text-white">
              USDT Wallet Address
            </Label>
            <Input
              id="address"
              type="text"
              placeholder="Enter your USDT wallet address"
              value={walletAddress}
              onChange={(e) => setWalletAddress(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white font-mono text-sm"
              disabled={loading}
            />
            <p className="text-sm text-slate-400">
              Make sure this is a valid USDT address
            </p>
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={onCancel}
              className="flex-1 border-slate-600 text-white hover:bg-slate-700"
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateWithdrawal}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                "Withdraw Funds"
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (step === "processing") {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Loader2 className="h-5 w-5 animate-spin" />
            Processing Withdrawal
          </CardTitle>
          <CardDescription className="text-slate-400">
            Please wait while we process your withdrawal
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center py-6">
            <Loader2 className="h-16 w-16 text-blue-500 mx-auto mb-4 animate-spin" />
            <h3 className="text-white text-lg font-semibold mb-2">
              Processing Your Withdrawal
            </h3>
            <p className="text-slate-400 mb-4">
              We're processing your ${withdrawalAmount} USDT withdrawal. This
              may take a few moments.
            </p>
            <div className="p-3 bg-slate-700 rounded-lg">
              <p className="text-sm text-slate-300">
                <strong>Amount:</strong> ${withdrawalAmount} USDT
              </p>
              <p className="text-sm text-slate-300 mt-1 break-all">
                <strong>Address:</strong> {walletAddress}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (step === "success") {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            Withdrawal Submitted
          </CardTitle>
          <CardDescription className="text-slate-400">
            Your withdrawal is being processed
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center py-6">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-white text-lg font-semibold mb-2">
              Withdrawal Submitted Successfully!
            </h3>
            <p className="text-slate-400 mb-4">
              Your ${withdrawalAmount} USDT withdrawal has been submitted and is
              being processed.
            </p>
            <div className="p-3 bg-slate-700 rounded-lg mb-4">
              <p className="text-sm text-slate-300">
                <strong>Withdrawal ID:</strong> {withdrawalId}
              </p>
              <p className="text-sm text-slate-300 mt-1 break-all">
                <strong>Address:</strong> {walletAddress}
              </p>
            </div>
            <Badge
              variant="outline"
              className="border-green-600 text-green-400"
            >
              Processing
            </Badge>
          </div>

          <Button
            onClick={onSuccess}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            Continue
          </Button>
        </CardContent>
      </Card>
    );
  }

  return null;
};

export default CCPaymentWithdrawalStep;
