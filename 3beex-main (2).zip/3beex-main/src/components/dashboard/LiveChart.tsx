
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLiveChartData } from "@/hooks/useLiveChartData";
import PriceDisplay from "./PriceDisplay";
import RealisticTradingChart from "./RealisticTradingChart";

const LiveChart = () => {
  const { chartData, currentPrice, priceChange, isLoading } = useLiveChartData();

  if (isLoading) {
    return (
      <Card className="bg-black border-gray-800">
        <CardContent className="flex items-center justify-center h-[300px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-400 mx-auto mb-2"></div>
            <div className="text-gray-400 text-sm">Loading chart...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return <RealisticTradingChart />;
};

export default LiveChart;
