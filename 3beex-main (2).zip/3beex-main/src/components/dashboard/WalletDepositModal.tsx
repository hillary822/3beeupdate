import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Bitcoin, ExternalLink } from "lucide-react";
import { useNOWPayments } from "@/hooks/useNOWPayments";
import { useToast } from "@/hooks/use-toast";

interface WalletDepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDepositCompleted: () => void;
}

const WalletDepositModal = ({ isOpen, onClose, onDepositCompleted }: WalletDepositModalProps) => {
  const { toast } = useToast();
  const [amount, setAmount] = useState("");
  const [selectedCurrency, setSelectedCurrency] = useState("btc");
  const { createPayment, getSupportedCurrencies, loading } = useNOWPayments();

  const supportedCurrencies = getSupportedCurrencies();

  useEffect(() => {
    if (isOpen) {
      setAmount("");
      setSelectedCurrency("btc");
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than 0",
        variant: "destructive",
      });
      return;
    }

    const result = await createPayment({
      amount: numAmount,
      currency: 'usd',
      pay_currency: selectedCurrency
    });

    if (result?.success && result.payment_url) {
      // Open NOWPayments in new tab
      window.open(result.payment_url, '_blank');
      
      toast({
        title: "Payment Gateway Opened",
        description: "Complete your payment in the new window",
      });
      
      // Close modal and trigger refresh
      handleClose();
    }
  };

  const handleClose = () => {
    setAmount("");
    setSelectedCurrency("btc");
    onClose();
    onDepositCompleted();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Bitcoin className="h-5 w-5 text-orange-400" />
            Crypto Deposit
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Deposit funds using Bitcoin, Ethereum, and other cryptocurrencies
          </DialogDescription>
        </DialogHeader>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                ₿
              </div>
              Wallet Deposit
            </CardTitle>
            <CardDescription className="text-slate-300">
              Secure crypto payments via wallet deposit
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="amount" className="text-white">Amount (USD)</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="Enter amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  min="1"
                  step="0.01"
                  required
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="currency" className="text-white">Pay with</Label>
                <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder="Select cryptocurrency" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    {supportedCurrencies.map((currency) => (
                      <SelectItem key={currency.code} value={currency.code} className="text-white">
                        <div className="flex items-center gap-2">
                          <span>{currency.symbol}</span>
                          <span>{currency.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-slate-700 rounded-lg p-4 space-y-2">
                <h4 className="text-white font-medium">How it works:</h4>
                <ul className="text-slate-300 text-sm space-y-1">
                  <li>1. Enter the amount you want to deposit</li>
                  <li>2. Choose your preferred USDT network</li>
                  <li>3. Securely Complete Payment</li>
                  <li>4. Your balance will be updated automatically</li>
                </ul>
              </div>

              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleClose}
                  className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-orange-600 hover:bg-orange-700 text-white"
                  disabled={loading || !amount || parseFloat(amount) <= 0}
                >
                  {loading ? (
                    "Creating Payment..."
                  ) : (
                    <div className="flex items-center gap-2">
                      <span>Pay with Crypto</span>
                      <ExternalLink className="h-4 w-4" />
                    </div>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
};

export default WalletDepositModal;