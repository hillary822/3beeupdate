
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, TreePine } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import ReferralTreeView from "./ReferralTreeView";

interface ReferralsTabProps {
  referralCode: string;
  referralCount: number;
  onCopyReferralCode: () => void;
}

const ReferralsTab = ({ referralCode }: ReferralsTabProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [referralCount, setReferralCount] = useState(0);
  const [referralEarnings, setReferralEarnings] = useState(0);

  // Create referral link using current domain
  const referralLink = `${window.location.origin}/?ref=${referralCode}`;

  useEffect(() => {
    if (user) {
      fetchReferralData();
    }
  }, [user]);

  const fetchReferralData = async () => {
    if (!user) return;

    try {
      // Count referrals made by this user
      const { data: referrals, error: referralsError } = await supabase
        .from('referrals')
        .select('*')
        .eq('referrer_id', user.id);

      if (referralsError) {
        console.error('Error fetching referrals:', referralsError);
      } else {
        console.log('Referrals fetched:', referrals);
        setReferralCount(referrals?.length || 0);
        
        // Calculate total earnings from referrals
        const totalEarnings = referrals?.reduce((sum, ref) => sum + (Number(ref.earnings) || 0), 0) || 0;
        setReferralEarnings(totalEarnings);
      }
    } catch (error) {
      console.error('Error in fetchReferralData:', error);
    }
  };

  const handleCopyReferralLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard",
    });
  };

  if (!user) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-6">
          <div className="text-center text-slate-400">
            Please log in to view your referrals
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-background border-border">
      <CardHeader>
        <CardTitle className="text-foreground">Referral Program</CardTitle>
        <CardDescription className="text-muted-foreground">
          Invite friends and earn rewards
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="overview" className="text-foreground">Overview</TabsTrigger>
            <TabsTrigger value="tree" className="text-foreground">
              <TreePine className="h-4 w-4 mr-2 text-foreground" />
              <span className="text-foreground">Network Tree</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="space-y-2">
              <Label className="text-foreground">Your Referral Link</Label>
              <div className="flex gap-2">
                <Input
                  value={referralLink}
                  readOnly
                  className="font-mono text-sm bg-background text-foreground border-border"
                />
                <Button onClick={handleCopyReferralLink} variant="default" className="bg-primary text-primary-foreground hover:bg-primary/90">
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-background border-border">
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-foreground">{referralCount}</p>
                    <p className="text-muted-foreground">Direct Referrals</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-background border-border">
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-400">${referralEarnings.toFixed(2)}</p>
                    <p className="text-muted-foreground">Referral Earnings</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="tree" className="space-y-4">
            <ReferralTreeView userId={user.id} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default ReferralsTab;
