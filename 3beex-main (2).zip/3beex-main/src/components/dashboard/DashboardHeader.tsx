
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { User } from "lucide-react";
import { Profile } from "@/types/auth";
import LanguageTranslator from "@/components/LanguageTranslator";
import LogoutButton from "@/components/LogoutButton";

interface DashboardHeaderProps {
  onLogout: () => void;
  profile: Profile | null;
  activeTab?: string;
}

const DashboardHeader = ({ onLogout, profile, activeTab }: DashboardHeaderProps) => {
  return (
    <div className="flex justify-between items-center mb-6 lg:mb-8">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <User className="h-5 w-5 text-slate-400" />
          <span className="text-slate-300 text-sm">Welcome back,</span>
          <span className="text-white font-medium">{profile?.username}</span>
        </div>
        <div className="flex gap-2">
          {profile?.user_id && (
            <Badge variant="secondary" className="bg-slate-700 text-slate-300">
              ID: {profile.user_id}
            </Badge>
          )}
        </div>
      </div>
      <div className="flex items-center gap-2">
        <LanguageTranslator />
        {activeTab !== "assets" && (
          <LogoutButton
            variant="ghost"
            size="icon"
            className="h-10 w-10 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-600"
          />
        )}
      </div>
    </div>
  );
};

export default DashboardHeader;
