
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye } from "lucide-react";
import ActionButtons from "./ActionButtons";
import AccountBalances from "./AccountBalances";
import AccountStats from "./AccountStats";
import TradingForm from "@/components/trading/TradingForm";
import TradesTab from "./TradesTab";

import UserCodesSection from "./UserCodesSection";

interface DesktopTradesTabProps {
  profile: any;
  totalBalance: number;
  winRate: number;
  showBalance: boolean;
  setShowBalance: (show: boolean) => void;
  setActiveTab: (tab: string) => void;
  setShowTransferModal: (show: boolean) => void;
  accountBalances: {
    exchange: number;
    trade: number;
    perpetual: number;
  };
  trades: any[];
  onNavigate: (path: string) => void;
  onTradeCompleted: () => Promise<void>;
}

const DesktopTradesTab = ({
  profile,
  totalBalance,
  winRate,
  showBalance,
  setShowBalance,
  setActiveTab,
  setShowTransferModal,
  accountBalances,
  trades,
  onNavigate,
  onTradeCompleted
}: DesktopTradesTabProps) => {
  return (
    <div className="space-y-4">
      {/* Balance Card with Gradient */}
      <Card className="mb-8 bg-gradient-primary border-primary shadow-glow">
        <CardHeader>
          <CardTitle className="text-white flex items-center justify-between">
            <div className="flex flex-col">
              <span>Total Assets</span>
              <span className="text-sm font-normal text-primary-foreground/80">
                {profile?.vip_level && profile.vip_level > 0 
                  ? `VIP Level ${profile.vip_level}` 
                  : "Standard Account"}
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowBalance(!showBalance)}
              className="text-white hover:bg-white/10"
            >
              <Eye className="h-4 w-4" />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold text-white mb-2">
            {showBalance ? `$${totalBalance.toFixed(2)}` : "****"}
          </div>
          <p className="text-primary-foreground/80">Win Rate: {winRate.toFixed(1)}%</p>
        </CardContent>
      </Card>

      {/* Action Buttons for Desktop */}
      <div className="max-w-md">
        <ActionButtons
          setActiveTab={setActiveTab}
          setShowTransferModal={setShowTransferModal}
          onNavigate={onNavigate}
        />
      </div>


      {/* Account Sections */}
      <div className="mb-6">
        <AccountBalances
          accountBalances={accountBalances}
          onNavigate={onNavigate}
        />
      </div>

      <AccountStats trades={trades} />
      
      {/* User Codes Section */}
      <UserCodesSection onTradeCompleted={onTradeCompleted} />
      
      <div className="grid lg:grid-cols-2 gap-6">
        <div>
          <h3 className="text-xl font-semibold mb-4 text-white">Copy Trading</h3>
          <TradingForm 
            pair="BTC-USDT" 
            currentPrice={45000} 
            type="spot" 
            onTradeCompleted={onTradeCompleted}
          />
        </div>
        <div>
          <TradesTab trades={trades} onTradeCompleted={onTradeCompleted} />
        </div>
      </div>
    </div>
  );
};

export default DesktopTradesTab;
