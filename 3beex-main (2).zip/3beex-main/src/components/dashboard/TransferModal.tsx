import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { ArrowRightLeft, AlertTriangle } from "lucide-react";

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  accountBalances: {
    exchange: number;
    trade: number;
    perpetual: number;
  };
  onTransfer: (fromAccount: string, toAccount: string, amount: number) => void;
  checkTransferFee: (fromAccount: string, toAccount: string, amount: number) => Promise<any>;
}

const TransferModal = ({ isOpen, onClose, accountBalances, onTransfer, checkTransferFee }: TransferModalProps) => {
  const [fromAccount, setFromAccount] = useState<string>("");
  const [toAccount, setToAccount] = useState<string>("");
  const [amount, setAmount] = useState<string>("");
  const [error, setError] = useState<string>("");
  const [showFeeDialog, setShowFeeDialog] = useState(false);
  const [feeInfo, setFeeInfo] = useState<any>(null);

  const accounts = [
    { value: "exchange", label: "Exchange", balance: accountBalances.exchange },
    { value: "trade", label: "Trade", balance: accountBalances.trade },
    { value: "perpetual", label: "Perpetual", balance: accountBalances.perpetual }
  ];

  const handleTransfer = async () => {
    setError("");
    
    if (!fromAccount || !toAccount || !amount) {
      setError("Please fill in all fields");
      return;
    }

    if (fromAccount === toAccount) {
      setError("From and To accounts must be different");
      return;
    }

    const transferAmount = parseFloat(amount);
    if (isNaN(transferAmount) || transferAmount <= 0) {
      setError("Please enter a valid amount");
      return;
    }

    const fromBalance = accountBalances[fromAccount as keyof typeof accountBalances];
    if (transferAmount > fromBalance) {
      setError("Insufficient balance in source account");
      return;
    }

    // Check if fee will be applied
    try {
      const feeCheck = await checkTransferFee(fromAccount, toAccount, transferAmount);
      
      if (feeCheck && feeCheck.will_apply_fee) {
        setFeeInfo(feeCheck);
        setShowFeeDialog(true);
        return;
      }
      
      // No fee, proceed with transfer
      await executeTransfer(transferAmount);
    } catch (error) {
      setError("Error checking transfer fee");
    }
  };

  const executeTransfer = async (transferAmount: number) => {
    await onTransfer(fromAccount, toAccount, transferAmount);
    
    // Reset form
    setFromAccount("");
    setToAccount("");
    setAmount("");
    setFeeInfo(null);
    onClose();
  };

  const handleConfirmWithFee = async () => {
    const transferAmount = parseFloat(amount);
    setShowFeeDialog(false);
    await executeTransfer(transferAmount);
  };

  const handleMaxClick = () => {
    if (fromAccount) {
      const maxBalance = accountBalances[fromAccount as keyof typeof accountBalances];
      setAmount(maxBalance.toString());
    }
  };

  const swapAccounts = () => {
    const temp = fromAccount;
    setFromAccount(toAccount);
    setToAccount(temp);
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold">Transfer Funds</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 pt-4">
            {/* From Account */}
            <div className="space-y-2">
              <Label htmlFor="from-account" className="text-sm font-medium text-slate-300">
                From Account
              </Label>
              <Select value={fromAccount} onValueChange={setFromAccount}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Select source account" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  {accounts.map((account) => (
                    <SelectItem 
                      key={account.value} 
                      value={account.value}
                      className="text-white hover:bg-slate-600"
                    >
                      <div className="flex justify-between items-center w-full">
                        <span>{account.label}</span>
                        <span className="text-blue-400 ml-2">${account.balance.toFixed(2)}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Swap Button */}
            <div className="flex justify-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={swapAccounts}
                className="text-slate-400 hover:text-white"
                disabled={!fromAccount || !toAccount}
              >
                <ArrowRightLeft className="h-4 w-4" />
              </Button>
            </div>

            {/* To Account */}
            <div className="space-y-2">
              <Label htmlFor="to-account" className="text-sm font-medium text-slate-300">
                To Account
              </Label>
              <Select value={toAccount} onValueChange={setToAccount}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Select destination account" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  {accounts
                    .filter(account => account.value !== fromAccount)
                    .map((account) => (
                      <SelectItem 
                        key={account.value} 
                        value={account.value}
                        className="text-white hover:bg-slate-600"
                      >
                        <div className="flex justify-between items-center w-full">
                          <span>{account.label}</span>
                          <span className="text-blue-400 ml-2">${account.balance.toFixed(2)}</span>
                        </div>
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>

            {/* Amount */}
            <div className="space-y-2">
              <Label htmlFor="amount" className="text-sm font-medium text-slate-300">
                Amount
              </Label>
              <div className="relative">
                <Input
                  id="amount"
                  type="number"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white pl-8 pr-16"
                  step="0.01"
                  min="0"
                />
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400">$</span>
                {fromAccount && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleMaxClick}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-xs text-blue-400 hover:text-blue-300 h-6 px-2"
                  >
                    MAX
                  </Button>
                )}
              </div>
              {fromAccount && (
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Available:</span>
                  <span className="text-blue-400">
                    ${accountBalances[fromAccount as keyof typeof accountBalances].toFixed(2)}
                  </span>
                </div>
              )}
            </div>

            {/* Error Message */}
            {error && (
              <div className="text-red-400 text-sm bg-red-900/20 p-3 rounded-lg">
                {error}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={onClose}
                className="flex-1 bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
              >
                Cancel
              </Button>
              <Button
                onClick={handleTransfer}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
              >
                Transfer
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Fee Confirmation Dialog */}
      <AlertDialog open={showFeeDialog} onOpenChange={setShowFeeDialog}>
        <AlertDialogContent className="bg-slate-800 border-slate-700 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-orange-400">
              <AlertTriangle className="h-5 w-5" />
              Transfer Fee Applied
            </AlertDialogTitle>
            <AlertDialogDescription className="text-slate-300">
              Since you haven't doubled your trade account balance, a 25% fee will be applied to this transfer.
              
              {feeInfo && (
                <div className="mt-4 space-y-2 bg-slate-700/50 p-4 rounded-lg">
                  <div className="flex justify-between">
                    <span>Transfer Amount:</span>
                    <span className="text-white">${feeInfo.original_amount?.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-orange-400">
                    <span>Fee (25%):</span>
                    <span>-${feeInfo.fee_amount?.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-600 pt-2 font-semibold">
                    <span>You will receive:</span>
                    <span className="text-blue-400">${feeInfo.final_amount?.toFixed(2)}</span>
                  </div>
                </div>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel 
              onClick={() => setShowFeeDialog(false)}
              className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600"
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmWithFee}
              className="bg-orange-600 hover:bg-orange-700 text-white"
            >
              Proceed with Fee
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default TransferModal;
