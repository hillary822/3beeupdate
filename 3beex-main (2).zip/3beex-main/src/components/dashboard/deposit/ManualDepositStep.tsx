import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Copy, Check, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { ccPaymentSupabase } from "@/integrations/supabase/client";

interface ManualDepositStepProps {
  amount: number;
  selectedCurrency: string;
  onBack: () => void;
  onDepositCreated: (depositId: string) => void;
}

interface DepositAddress {
  id: string;
  currency: string;
  network: string;
  address: string;
}

const ManualDepositStep = ({
  amount,
  selectedCurrency,
  onBack,
  onDepositCreated,
}: ManualDepositStepProps) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [addresses, setAddresses] = useState<DepositAddress[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAddress, setSelectedAddress] = useState<DepositAddress | null>(
    null
  );
  const [transactionId, setTransactionId] = useState("");

  useEffect(() => {
    fetchDepositAddresses();
  }, []);

  const fetchDepositAddresses = async () => {
    try {
      const { data, error } = await supabase
        .from("manual_deposit_addresses")
        .select("*")
        .eq("is_active", true);

      if (error) throw error;

      // Custom order: USDT first, then ETH, then BTC, then others alphabetically
      const customOrder = ["USDT", "ETH", "BTC"];
      const sortedData = (data || []).sort((a, b) => {
        const aIndex = customOrder.indexOf(a.currency);
        const bIndex = customOrder.indexOf(b.currency);

        // If both currencies are in the custom order, sort by their position
        if (aIndex !== -1 && bIndex !== -1) {
          return aIndex - bIndex;
        }

        // If only one is in the custom order, prioritize it
        if (aIndex !== -1) return -1;
        if (bIndex !== -1) return 1;

        // If neither is in the custom order, sort alphabetically
        return a.currency.localeCompare(b.currency);
      });

      setAddresses(sortedData);

      // Auto-select the matching currency if available
      const matchingAddress = sortedData?.find(
        (addr) => addr.currency === selectedCurrency
      );
      if (matchingAddress) {
        setSelectedAddress(matchingAddress);
      } else if (sortedData && sortedData.length > 0) {
        setSelectedAddress(sortedData[0]);
      }
    } catch (error) {
      console.error("Error fetching deposit addresses:", error);
      toast({
        title: "Error",
        description: "Failed to load deposit addresses",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 2000);
      toast({
        title: "Copied!",
        description: `${field} copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleConfirmDeposit = async () => {
    if (!selectedAddress || !user || !transactionId.trim()) return;

    try {
      const { data: depositData, error: depositError } = await ccPaymentSupabase
        .from("deposits")
        .insert({
          user_id: user.id,
          amount: parseFloat(amount),
          method: "manual_deposit",
          status: "pending",
          payment_method_name: selectedAddress.currency,
          wallet_address: selectedAddress.address,
          transaction_hash: transactionId.trim() || null,
        })
        .select()
        .single();

      if (depositError) throw depositError;

      toast({
        title: "Deposit Request Created",
        description:
          "Your manual deposit request has been submitted. Please send the funds and wait for confirmation.",
      });

      onDepositCreated(depositData.id);
    } catch (error) {
      console.error("Error creating deposit:", error);
      toast({
        title: "Error",
        description: "Failed to create deposit request",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (addresses.length === 0) {
    return (
      <div className="text-center p-8">
        <p className="text-slate-400 mb-4">
          No deposit addresses available at the moment.
        </p>
        <Button onClick={onBack} variant="outline">
          Go Back
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4 py-2">
      <div className="text-center">
        <h3 className="text-xl font-semibold mb-2 text-white">
          Manual Deposit
        </h3>
        <p className="text-slate-400">
          Send <span className="text-white font-medium">${amount}</span> worth
          of cryptocurrency to the address below
        </p>
      </div>

      {/* Currency Selection */}
      <div className="space-y-3">
        <label className="text-sm font-medium text-white">
          Select Currency:
        </label>
        <div className="grid grid-cols-3 gap-3">
          {addresses.map((address) => (
            <Button
              key={address.id}
              variant={
                selectedAddress?.id === address.id ? "default" : "outline"
              }
              className={`flex flex-col h-auto py-3 ${
                selectedAddress?.id === address.id
                  ? "bg-blue-600 text-white hover:bg-blue-700"
                  : "bg-slate-700 text-white border-slate-600 hover:bg-slate-600"
              }`}
              onClick={() => setSelectedAddress(address)}
            >
              <span className="font-semibold">{address.currency}</span>
              <span className="text-xs opacity-75">{address.network}</span>
            </Button>
          ))}
        </div>
      </div>

      {selectedAddress && (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center justify-between text-white">
              <span>{selectedAddress.currency} Deposit</span>
              <Badge variant="secondary" className="bg-slate-600 text-white">
                {selectedAddress.network} Network
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Deposit Address */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">
                Deposit Address:
              </label>
              <div className="flex items-center space-x-2 p-3 bg-slate-900 rounded-lg">
                <code className="flex-1 text-sm break-all text-white">
                  {selectedAddress.address}
                </code>
                <Button
                  size="sm"
                  variant="ghost"
                  className="text-slate-400 hover:text-white"
                  onClick={() => handleCopy(selectedAddress.address, "Address")}
                >
                  {copiedField === "Address" ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            {/* Amount */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">
                Amount (USD equivalent):
              </label>
              <div className="flex items-center space-x-2 p-3 bg-slate-900 rounded-lg">
                <code className="flex-1 text-sm text-white">${amount}</code>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleCopy(amount.toString(), "Amount")}
                >
                  {copiedField === "Amount" ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            {/* Instructions */}
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
              <h4 className="font-medium text-blue-400 mb-2">
                Important Instructions:
              </h4>
              <ul className="text-sm text-blue-300 space-y-1">
                <li>
                  • Send exactly the USD equivalent amount in{" "}
                  {selectedAddress.currency}
                </li>
                <li>• Use only the {selectedAddress.network} network</li>
                <li>• Your deposit will be credited after confirmation</li>
                <li>
                  • Processing time: 15-30 minutes after network confirmation
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Transaction ID Input */}
      {selectedAddress && (
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="pt-6">
            <div className="space-y-2">
              <Label htmlFor="txid" className="text-sm font-medium text-white">
                Transaction ID (TXID) <span className="text-red-400">*</span>
              </Label>
              <Input
                id="txid"
                type="text"
                placeholder="Enter your transaction ID"
                value={transactionId}
                onChange={(e) => setTransactionId(e.target.value)}
                className="bg-slate-900 border-slate-600 text-white placeholder:text-slate-400"
              />
              <p className="text-xs text-slate-400">
                Required: Enter the transaction ID from your blockchain
                transaction
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex space-x-3">
        <Button
          onClick={onBack}
          variant="outline"
          className="flex-1 bg-slate-700 text-white border-slate-600 hover:bg-slate-600 hover:text-white"
        >
          Back
        </Button>
        <Button
          onClick={handleConfirmDeposit}
          className="flex-1 bg-gradient-primary hover:shadow-glow"
          disabled={!selectedAddress || !transactionId.trim()}
        >
          I've Sent the Funds
        </Button>
      </div>
    </div>
  );
};

export default ManualDepositStep;
