
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

interface DepositAmountStepProps {
  onNext: (amount: string) => void;
  onCancel: () => void;
}

const DepositAmountStep = ({ onNext, onCancel }: DepositAmountStepProps) => {
  const { toast } = useToast();
  const [depositAmount, setDepositAmount] = useState("");

  const handleSubmit = () => {
    if (!depositAmount || parseFloat(depositAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid deposit amount",
        variant: "destructive",
      });
      return;
    }
    onNext(depositAmount);
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="amount" className="text-white">
          Deposit Amount (USD)
        </Label>
        <Input
          id="amount"
          type="number"
          placeholder="Enter amount to deposit"
          value={depositAmount}
          onChange={(e) => setDepositAmount(e.target.value)}
          className="bg-slate-700 border-slate-600 text-white"
          min="1"
          step="0.01"
        />
      </div>
      
      <div className="flex gap-3">
        <Button
          variant="outline"
          onClick={onCancel}
          className="flex-1 border-slate-600 text-white hover:bg-slate-700"
        >
          Cancel
        </Button>
        <Button
          onClick={handleSubmit}
          className="flex-1"
        >
          Continue
        </Button>
      </div>
    </div>
  );
};

export default DepositAmountStep;
