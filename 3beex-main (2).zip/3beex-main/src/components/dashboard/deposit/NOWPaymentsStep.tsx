import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { useNOWPayments } from "@/hooks/useNOWPayments";

interface NOWPaymentsStepProps {
  onBack: () => void;
  onSuccess: () => void;
}

const NOWPaymentsStep = ({ onBack, onSuccess }: NOWPaymentsStepProps) => {
  const [amount, setAmount] = useState("");
  const [selectedCurrency, setSelectedCurrency] = useState("btc");
  const { createPayment, getSupportedCurrencies, loading } = useNOWPayments();

  const supportedCurrencies = getSupportedCurrencies();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) {
      return;
    }

    const result = await createPayment({
      amount: numAmount,
      currency: 'USD',
      pay_currency: selectedCurrency
    });

    if (result?.success && result.payment_url) {
      // Redirect to NOWPayments
      window.open(result.payment_url, '_blank');
      onSuccess();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h3 className="text-lg font-semibold text-white">Crypto Payment</h3>
      </div>

      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
              ₿
            </div>
            Wallet Deposit
          </CardTitle>
          <CardDescription className="text-slate-300">
            Pay with Bitcoin, Ethereum, USDT and other cryptocurrencies
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="amount" className="text-white">Amount (USD)</Label>
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                min="1"
                step="0.01"
                required
                className="bg-slate-700 border-slate-600 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="currency" className="text-white">Pay with</Label>
              <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Select cryptocurrency" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  {supportedCurrencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code} className="text-white">
                      <div className="flex items-center gap-2">
                        <span>{currency.symbol}</span>
                        <span>{currency.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="bg-slate-700 rounded-lg p-4 space-y-2">
              <h4 className="text-white font-medium">How it works:</h4>
              <ul className="text-slate-300 text-sm space-y-1">
                <li>1. Enter the amount you want to deposit</li>
                <li>2. Choose your preferred USDT network</li>
                <li>3. Securely Complete Payment</li>
                <li>4. Your balance will be updated automatically</li>
              </ul>
            </div>

            <Button
              type="submit"
              className="w-full bg-orange-600 hover:bg-orange-700 text-white"
              disabled={loading || !amount || parseFloat(amount) <= 0}
            >
              {loading ? (
                "Creating Payment..."
              ) : (
                <div className="flex items-center gap-2">
                  <span>Pay with Crypto</span>
                  <ExternalLink className="h-4 w-4" />
                </div>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default NOWPaymentsStep;