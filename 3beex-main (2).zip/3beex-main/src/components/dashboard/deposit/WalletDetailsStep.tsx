
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, Shield, Eye, EyeOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AssignedWallet {
  id: string;
  address: string;
  currency: string;
  assigned_at: string;
}

interface WalletDetailsStepProps {
  assignedWallet: AssignedWallet;
  depositAmount: string;
  onBack: () => void;
  onSent: () => void;
}

const WalletDetailsStep = ({ assignedWallet, depositAmount, onBack, onSent }: WalletDetailsStepProps) => {
  const { toast } = useToast();
  const [showAddress, setShowAddress] = useState(true);

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: "Address copied to clipboard",
      });
    } catch (error) {
      console.error('Failed to copy:', error);
      toast({
        title: "Copy Failed",
        description: "Failed to copy address to clipboard",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-700 rounded-lg p-4 space-y-4">
        <div className="flex items-center justify-between">
          <Badge variant="secondary" className="bg-primary text-white">
            {assignedWallet.currency}
          </Badge>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="border-blue-500 text-blue-500">
              <Shield className="h-3 w-3 mr-1" />
              Assigned
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAddress(!showAddress)}
              className="text-white hover:bg-slate-600 px-2"
            >
              {showAddress ? <EyeOff size={14} /> : <Eye size={14} />}
            </Button>
          </div>
        </div>

        <div className="text-center py-4">
          <div className="bg-slate-800 rounded-lg p-3 mb-4">
            <p className="text-sm text-slate-400 mb-2">Amount to Send</p>
            <div className="text-2xl font-bold text-primary mb-3">
              ${depositAmount} USDT
            </div>
            <p className="text-sm text-slate-400 mb-2">Your Deposit Address</p>
            <p className="text-xs text-yellow-400 mb-2 font-medium">TRC20 (Tron) Network</p>
            <div className="bg-slate-900 rounded p-2 text-xs break-all text-primary font-mono">
              {showAddress ? assignedWallet.address : "••••••••••••••••••••••••••••••••"}
            </div>
            <Button
              onClick={() => copyToClipboard(assignedWallet.address)}
              className="w-full mt-2 text-white flex items-center gap-2"
              size="sm"
            >
              <Copy className="h-3 w-3" />
              Copy Address
            </Button>
          </div>
        </div>
      </div>

      <div className="bg-primary/20 border border-primary rounded-lg p-4">
        <h4 className="text-primary font-medium mb-2 flex items-center gap-2">
          <Shield className="h-4 w-4" />
          Instructions
        </h4>
        <ul className="text-sm text-slate-300 space-y-1">
          <li>• Send exactly ${depositAmount} USDT to the address above</li>
          <li>• Only send USDT to this address</li>
          <li>• Click "Sent" after completing the transfer</li>
          <li>• Your balance will be updated automatically</li>
          <li>• Processing typically takes 5-15 minutes</li>
        </ul>
      </div>

      <div className="flex gap-3">
        <Button
          variant="outline"
          onClick={onBack}
          className="flex-1 border-slate-600 text-white hover:bg-slate-700"
        >
          Back
        </Button>
        <Button
          onClick={onSent}
          className="flex-1"
        >
          Sent
        </Button>
      </div>
    </div>
  );
};

export default WalletDetailsStep;
