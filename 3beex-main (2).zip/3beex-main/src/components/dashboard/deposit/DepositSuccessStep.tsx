
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

interface DepositSuccessStepProps {
  depositAmount: string;
  onDone: () => void;
}

const DepositSuccessStep = ({ depositAmount, onDone }: DepositSuccessStepProps) => {
  return (
    <div className="text-center py-6 space-y-4">
      <div className="flex justify-center">
        <CheckCircle className="h-16 w-16 text-primary" />
      </div>
      <div className="space-y-2">
        <h3 className="text-xl font-semibold text-white">Deposit Submitted!</h3>
        <p className="text-slate-300">
          Your deposit of ${depositAmount} USDT has been submitted for verification.
        </p>
        <p className="text-slate-400 text-sm">
          It will be credited to your account automatically once confirmed on the blockchain.
        </p>
      </div>
      <Button
        onClick={onDone}
        className="w-full"
      >
        Done
      </Button>
    </div>
  );
};

export default DepositSuccessStep;
