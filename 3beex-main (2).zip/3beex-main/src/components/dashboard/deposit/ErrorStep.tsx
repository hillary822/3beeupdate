
import { Button } from "@/components/ui/button";

interface ErrorStepProps {
  onRetry: () => void;
}

const ErrorStep = ({ onRetry }: ErrorStepProps) => {
  return (
    <div className="text-center py-6">
      <p className="text-slate-400 mb-4">Failed to assign deposit address</p>
      <Button onClick={onRetry} className="">
        Retry
      </Button>
    </div>
  );
};

export default ErrorStep;
