import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft } from "lucide-react";
import ManualDepositStep from "./ManualDepositStep";

interface ManualDepositFormProps {
  onClose: () => void;
  onDepositCreated: () => void;
}

const ManualDepositForm = ({ onClose, onDepositCreated }: ManualDepositFormProps) => {
  const [step, setStep] = useState<'form' | 'deposit'>('form');
  const [amount, setAmount] = useState<string>('');
  const [selectedCurrency, setSelectedCurrency] = useState<string>('');

  const handleContinue = () => {
    if (amount && selectedCurrency) {
      setStep('deposit');
    }
  };

  const handleBack = () => {
    if (step === 'deposit') {
      setStep('form');
    } else {
      onClose();
    }
  };

  if (step === 'deposit') {
    return (
      <ManualDepositStep
        amount={parseFloat(amount)}
        selectedCurrency={selectedCurrency}
        onBack={handleBack}
        onDepositCreated={onDepositCreated}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleBack}
          className="text-slate-400 hover:text-white p-1"
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h2 className="text-xl font-semibold text-white">Manual Deposit</h2>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="currency" className="text-white">Select Currency</Label>
          <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
            <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
              <SelectValue placeholder="Choose currency" />
            </SelectTrigger>
            <SelectContent className="bg-slate-700 border-slate-600">
              <SelectItem value="USDT" className="text-white hover:bg-slate-600 focus:bg-slate-600 focus:text-white">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center text-xs font-bold text-white">₮</div>
                  <span className="text-white">USDT (TRC20 Network)</span>
                </div>
              </SelectItem>
              <SelectItem value="ETH" className="text-white hover:bg-slate-600 focus:bg-slate-600 focus:text-white">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-xs font-bold text-white">Ξ</div>
                  <span className="text-white">ETH (Ethereum Network)</span>
                </div>
              </SelectItem>
              <SelectItem value="BTC" className="text-white hover:bg-slate-600 focus:bg-slate-600 focus:text-white">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center text-xs font-bold text-white">₿</div>
                  <span className="text-white">BTC (Bitcoin Network)</span>
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="amount" className="text-white">Amount (USD)</Label>
          <Input
            id="amount"
            type="number"
            placeholder="Enter amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
            min="1"
            step="0.01"
          />
        </div>

        <Button
          onClick={handleContinue}
          disabled={!amount || !selectedCurrency || parseFloat(amount) <= 0}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white"
        >
          Continue
        </Button>
      </div>
    </div>
  );
};

export default ManualDepositForm;