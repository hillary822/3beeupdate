
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PaymentMethod {
  id: string;
  name: string;
  display_name: string;
  wallet_address: string;
}

interface DepositFormStepProps {
  selectedMethod: PaymentMethod;
  amount: string;
  transactionHash: string;
  onAmountChange: (amount: string) => void;
  onTransactionHashChange: (hash: string) => void;
  onBack: () => void;
  onSubmit: () => void;
  loading: boolean;
}

const DepositFormStep = ({
  selectedMethod,
  amount,
  transactionHash,
  onAmountChange,
  onTransactionHashChange,
  onBack,
  onSubmit,
  loading
}: DepositFormStepProps) => {
  const { toast } = useToast();
  const [copiedAddress, setCopiedAddress] = useState(false);

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedAddress(true);
      toast({
        title: "Copied!",
        description: "Wallet address copied to clipboard",
      });
      setTimeout(() => setCopiedAddress(false), 2000);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy address",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label className="text-white">Amount (USD)</Label>
        <Input
          type="number"
          placeholder="Enter amount to deposit"
          value={amount}
          onChange={(e) => onAmountChange(e.target.value)}
          className="bg-slate-700 border-slate-600 text-white"
        />
      </div>

      <div className="space-y-2">
        <Label className="text-white">Send {selectedMethod.display_name} to:</Label>
        <p className="text-xs text-yellow-400 font-medium">TRC20 (Tron) Network</p>
        <div className="bg-slate-700 border border-slate-600 rounded-md p-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-slate-300 break-all">
              {selectedMethod.wallet_address}
            </span>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => copyToClipboard(selectedMethod.wallet_address)}
              className="ml-2 text-yellow-500 hover:text-yellow-400"
            >
              {copiedAddress ? <Check size={16} /> : <Copy size={16} />}
            </Button>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-white">Transaction Hash (Optional)</Label>
        <Input
          type="text"
          placeholder="Enter transaction hash after sending"
          value={transactionHash}
          onChange={(e) => onTransactionHashChange(e.target.value)}
          className="bg-slate-700 border-slate-600 text-white"
        />
        <p className="text-xs text-slate-400">
          You can add this later once your transaction is confirmed
        </p>
      </div>

      <div className="bg-slate-700 border border-slate-600 rounded-md p-3">
        <p className="text-sm text-slate-300">
          <strong>Instructions:</strong>
        </p>
        <ol className="text-xs text-slate-400 mt-2 space-y-1 list-decimal list-inside">
          <li>Copy the wallet address above</li>
          <li>Send ${amount || '0'} worth of {selectedMethod.display_name} to this address</li>
          <li>Add transaction hash (optional)</li>
          <li>Click "Submit Deposit Request"</li>
          <li>Wait for admin approval</li>
        </ol>
      </div>

      <div className="flex gap-2">
        <Button
          onClick={onBack}
          variant="outline"
          className="flex-1 border-slate-600 text-slate-300 hover:text-white"
        >
          Back
        </Button>
        <Button
          onClick={onSubmit}
          disabled={loading || !amount}
          className="flex-1"
        >
          {loading ? "Submitting..." : "Submit Deposit Request"}
        </Button>
      </div>
    </div>
  );
};

export default DepositFormStep;
