
import { Button } from "@/components/ui/button";

interface PaymentMethod {
  id: string;
  name: string;
  display_name: string;
  wallet_address: string;
}

interface PaymentMethodSelectorProps {
  paymentMethods: PaymentMethod[];
  onMethodSelect: (method: PaymentMethod) => void;
}

const PaymentMethodSelector = ({ paymentMethods, onMethodSelect }: PaymentMethodSelectorProps) => {
  return (
    <div className="space-y-4">
      <p className="text-slate-300 text-sm">Choose your preferred payment method:</p>
      <div className="space-y-3">
        {paymentMethods.map((method) => (
          <Button
            key={method.id}
            onClick={() => onMethodSelect(method)}
            className="w-full bg-slate-700 hover:bg-slate-600 text-white border border-slate-600 justify-start"
            variant="outline"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-black font-bold text-sm">
                {method.name === 'BTC' ? '₿' : '₮'}
              </div>
              <span>{method.display_name}</span>
            </div>
          </Button>
        ))}
      </div>
    </div>
  );
};

export default PaymentMethodSelector;
