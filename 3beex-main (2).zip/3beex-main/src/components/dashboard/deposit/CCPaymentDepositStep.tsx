import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { ccPaymentSupabase } from "@/integrations/supabase/client";
import {
  Loader2,
  Coins,
  Link,
  Wallet,
  Copy,
  CheckCircle,
  ArrowLeft,
} from "lucide-react";

interface CCPaymentDepositStepProps {
  onSuccess: () => void;
  onCancel: () => void;
}

interface Coin {
  symbol: string;
  name: string;
  logoUrl: string;
  coinId: number;
  chains: Chain[];
}

interface Chain {
  name: string;
  network: string;
  fee: string;
  minDeposit: string;
  confirmations: number;
  contract?: string;
  precision: number;
  canWithdraw: boolean;
  isSupportMemo: boolean;
  maximumWithdrawAmount?: string;
  displayName?: string; // For UI display (TRC20, ERC20)
  originalName?: string; // For API calls (TRX, ETH)
}

const CCPaymentDepositStep = ({
  onSuccess,
  onCancel,
}: CCPaymentDepositStepProps) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [loadingCoins, setLoadingCoins] = useState(true);
  const [step, setStep] = useState<"coin" | "chain" | "address">("coin");
  const [selectedCoin, setSelectedCoin] = useState<Coin | null>(null);
  const [selectedChain, setSelectedChain] = useState<Chain | null>(null);
  const [depositAddress, setDepositAddress] = useState("");
  const [addressCopied, setAddressCopied] = useState(false);
  const [availableCoins, setAvailableCoins] = useState<Coin[]>([]);

  // Fetch available coins from CCPayment on component mount
  useEffect(() => {
    fetchAvailableCoins();
  }, []);

  const fetchAvailableCoins = async () => {
    setLoadingCoins(true);
    try {
      const { data, error } = await ccPaymentSupabase.functions.invoke(
        "ccpayment-get-coins"
      );

      if (error) {
        throw error;
      }

      if (data?.success && data?.coins) {
        // Filter to show only USDT with TRX and ETH networks, display as TRC20 and ERC20
        const filteredCoins = data.coins
          .filter((coin: any) => coin.symbol === "USDT")
          .map((coin: any) => ({
            ...coin,
            chains: coin.chains
              .filter(
                (chain: any) => chain.name === "TRX" || chain.name === "ETH"
              )
              .map((chain: any) => ({
                ...chain,
                // Display TRX as TRC20 and ETH as ERC20 in UI
                displayName:
                  chain.name === "TRX"
                    ? "TRC20"
                    : chain.name === "ETH"
                    ? "ERC20"
                    : chain.name,
                // Keep original name for API calls
                originalName: chain.name,
              })),
          }))
          .filter((coin: any) => coin.chains.length > 0); // Only include if it has supported chains

        setAvailableCoins(filteredCoins);
        console.log(
          `Loaded ${filteredCoins.length} filtered coins (USDT only with TRX/ETH as TRC20/ERC20)`
        );
      } else {
        throw new Error(data?.error || "Failed to fetch available coins");
      }
    } catch (error) {
      console.error("Error fetching coins:", error);
      toast({
        title: "Failed to Load Coins",
        description:
          "Could not fetch available cryptocurrencies. Please try again.",
        variant: "destructive",
      });
      // Fallback to USDT with TRX/ETH (displayed as TRC20/ERC20) if API fails
      setAvailableCoins([
        {
          symbol: "USDT",
          name: "Tether USD",
          logoUrl: "",
          coinId: 0,
          chains: [
            {
              name: "TRX",
              displayName: "TRC20",
              originalName: "TRX",
              network: "Tron blockchain",
              fee: "0.025 USDT",
              minDeposit: "0 USDT",
              confirmations: 6,
              precision: 6,
              canWithdraw: true,
              isSupportMemo: false,
            },
            {
              name: "ETH",
              displayName: "ERC20",
              originalName: "ETH",
              network: "Ethereum",
              fee: "0.025 USDT",
              minDeposit: "0 USDT",
              confirmations: 12,
              precision: 6,
              canWithdraw: true,
              isSupportMemo: false,
            },
          ],
        },
      ]);
    } finally {
      setLoadingCoins(false);
    }
  };

  const handleCoinSelect = (coin: Coin) => {
    setSelectedCoin(coin);
    if (coin.chains.length === 1) {
      // If only one chain, auto-select it
      setSelectedChain(coin.chains[0]);
      setStep("address");
      generateDepositAddress(coin, coin.chains[0]);
    } else {
      setStep("chain");
    }
  };

  const handleChainSelect = (chain: Chain) => {
    setSelectedChain(chain);
    setStep("address");
    generateDepositAddress(selectedCoin!, chain);
  };

  const generateDepositAddress = async (coin: Coin, chain: Chain) => {
    if (!user) return;

    setLoading(true);
    try {
      const requestBody = {
        userId: user.id,
        currency: coin.symbol,
        chain: chain.originalName || chain.name, // Use originalName for API calls (TRX, ETH)
      };

      console.log("🚀 Making assign-wallet request with:", requestBody);
      console.log("📋 Selected coin:", coin);
      console.log("⛓️  Selected chain:", chain);

      // Call the wallet assignment function to get/create a deposit address
      const { data, error } = await ccPaymentSupabase.functions.invoke(
        "assign-wallet",
        {
          body: requestBody,
        }
      );

      console.log("📨 assign-wallet response:", { data, error });

      if (error) {
        throw error;
      }

      if (data?.success && data?.wallet?.address) {
        setDepositAddress(data.wallet.address);
      } else {
        throw new Error(data?.error || "Failed to generate deposit address");
      }
    } catch (error) {
      console.error("Address generation error:", error);
      toast({
        title: "Address Generation Failed",
        description:
          error.message ||
          "Failed to generate deposit address. Please try again.",
        variant: "destructive",
      });
      // Go back to chain selection
      setStep("chain");
    } finally {
      setLoading(false);
    }
  };

  const copyAddress = async () => {
    try {
      await navigator.clipboard.writeText(depositAddress);
      setAddressCopied(true);
      toast({
        title: "Address Copied",
        description: "Deposit address copied to clipboard",
      });
      setTimeout(() => setAddressCopied(false), 2000);
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy address to clipboard",
        variant: "destructive",
      });
    }
  };

  const goBack = () => {
    if (step === "chain") {
      setStep("coin");
      setSelectedCoin(null);
    } else if (step === "address") {
      if (selectedCoin?.chains.length === 1) {
        setStep("coin");
        setSelectedCoin(null);
        setSelectedChain(null);
      } else {
        setStep("chain");
        setSelectedChain(null);
      }
      setDepositAddress("");
    }
  };

  // Step 1: Coin Selection
  if (step === "coin") {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Coins className="h-5 w-5" />
            Select Coin
          </CardTitle>
          <CardDescription className="text-slate-400">
            Choose the cryptocurrency you want to deposit
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {loadingCoins ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
              <span className="ml-2 text-white">
                Loading available coins...
              </span>
            </div>
          ) : (
            <>
              {availableCoins.map((coin) => (
                <Button
                  key={coin.symbol}
                  onClick={() => handleCoinSelect(coin)}
                  variant="outline"
                  className="w-full h-16 border-slate-600 hover:bg-slate-700 flex items-center justify-between p-4"
                >
                  <div className="flex items-center gap-3">
                    {coin.logoUrl ? (
                      <img
                        src={coin.logoUrl}
                        alt={coin.symbol}
                        className="w-8 h-8 rounded-full"
                        onError={(e) => {
                          // Fallback to text if image fails to load
                          e.currentTarget.style.display = "none";
                          e.currentTarget.nextElementSibling.style.display =
                            "flex";
                        }}
                      />
                    ) : null}
                    <div
                      className="w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center text-white text-sm font-bold"
                      style={{ display: coin.logoUrl ? "none" : "flex" }}
                    >
                      {coin.symbol.charAt(0)}
                    </div>
                    <div className="text-left">
                      <div className="text-white font-semibold">
                        {coin.symbol}
                      </div>
                      <div className="text-slate-400 text-sm">{coin.name}</div>
                    </div>
                  </div>
                  <div className="text-slate-400">
                    {coin.chains.length} network
                    {coin.chains.length > 1 ? "s" : ""}
                  </div>
                </Button>
              ))}

              <div className="flex gap-3 mt-6">
                <Button
                  variant="outline"
                  onClick={onCancel}
                  className="flex-1 border-slate-600 text-white hover:bg-slate-700"
                >
                  Cancel
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    );
  }

  // Step 2: Chain Selection
  if (step === "chain" && selectedCoin) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Link className="h-5 w-5" />
            Select Network
          </CardTitle>
          <CardDescription className="text-slate-400">
            Choose the network for {selectedCoin.symbol} deposit
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {selectedCoin.chains.map((chain) => (
            <Button
              key={chain.name}
              onClick={() => handleChainSelect(chain)}
              variant="outline"
              className="w-full h-auto border-slate-600 hover:bg-slate-700 p-4"
            >
              <div className="w-full">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-white font-semibold">
                    {chain.displayName || chain.name}
                  </div>
                  <Badge
                    variant="outline"
                    className="border-slate-500 text-slate-300"
                  >
                    {chain.network}
                  </Badge>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs text-slate-400">
                  <div>Fee: {chain.fee}</div>
                  <div>Min: {chain.minDeposit}</div>
                  <div>{chain.confirmations} confirmations</div>
                </div>
              </div>
            </Button>
          ))}

          <div className="flex gap-3 mt-6">
            <Button
              variant="outline"
              onClick={goBack}
              className="flex-1 border-slate-600 text-white hover:bg-slate-700"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Step 3: Deposit Address
  if (step === "address" && selectedCoin && selectedChain) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Wallet className="h-5 w-5" />
            Deposit Address
          </CardTitle>
          <CardDescription className="text-slate-400">
            Send {selectedCoin.symbol} to this address
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
              <span className="ml-2 text-white">Generating address...</span>
            </div>
          ) : (
            <>
              {/* Selected coin and chain info */}
              <div className="p-4 bg-slate-700 rounded-lg">
                <div className="flex items-center gap-3 mb-3">
                  {selectedCoin.logoUrl ? (
                    <img
                      src={selectedCoin.logoUrl}
                      alt={selectedCoin.symbol}
                      className="w-8 h-8 rounded-full"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center text-white text-sm font-bold">
                      {selectedCoin.symbol.charAt(0)}
                    </div>
                  )}
                  <div>
                    <div className="text-white font-semibold">
                      {selectedCoin.symbol} (
                      {selectedChain.displayName || selectedChain.name})
                    </div>
                    <div className="text-slate-400 text-sm">
                      {selectedChain.network}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-slate-400">Network Fee:</span>
                    <div className="text-white">{selectedChain.fee}</div>
                  </div>
                  <div>
                    <span className="text-slate-400">Min Deposit:</span>
                    <div className="text-white">{selectedChain.minDeposit}</div>
                  </div>
                </div>
              </div>

              {/* Deposit Address */}
              <div className="space-y-3">
                <div className="text-white font-medium">Deposit Address:</div>
                <div className="p-4 bg-slate-700 rounded-lg border-2 border-dashed border-slate-600">
                  <div className="text-white font-mono text-sm break-all mb-3">
                    {depositAddress}
                  </div>
                  <Button
                    onClick={copyAddress}
                    variant="outline"
                    size="sm"
                    className="w-full border-slate-600 text-white hover:bg-slate-600"
                  >
                    {addressCopied ? (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy Address
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* Important Notes */}
              <div className="p-4 bg-yellow-900/20 border border-yellow-800 rounded-lg">
                <div className="text-yellow-400 font-medium mb-2">
                  Important Notes:
                </div>
                <ul className="text-yellow-300 text-sm space-y-1">
                  <li>• Only send {selectedCoin.symbol} to this address</li>
                  <li>
                    • Use {selectedChain.displayName || selectedChain.name}{" "}
                    network only
                  </li>
                  <li>• Minimum deposit: {selectedChain.minDeposit}</li>
                  <li>
                    • Requires {selectedChain.confirmations} network
                    confirmations
                  </li>
                  <li>
                    • Funds will be credited automatically after confirmation
                  </li>
                </ul>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={goBack}
                  className="flex-1 border-slate-600 text-white hover:bg-slate-700"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
                <Button
                  onClick={onSuccess}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  Done
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    );
  }

  return null;
};

export default CCPaymentDepositStep;
