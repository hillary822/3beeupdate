import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ArrowUpRight,
  Calendar,
  CreditCard,
  Clock,
  CheckCircle,
  XCircle,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import CCPaymentWithdrawalStep from "./withdrawal/CCPaymentWithdrawalStep";

interface Withdrawal {
  id: string;
  amount: number;
  address: string;
  status: string;
  created_at: string;
  transaction_id?: string;
  admin_note?: string;
}

const WithdrawalsTab = () => {
  const { toast } = useToast();
  const { user, profile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [showWithdrawalModal, setShowWithdrawalModal] = useState(false);

  useEffect(() => {
    if (user) {
      fetchWithdrawals();
    }
  }, [user]);

  const fetchWithdrawals = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("withdrawals")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setWithdrawals(data || []);
    } catch (error) {
      console.error("Error fetching withdrawals:", error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-primary";
      case "pending":
        return "bg-yellow-600";
      case "rejected":
        return "bg-red-600";
      default:
        return "bg-gray-600";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-3 w-3" />;
      case "rejected":
        return <XCircle className="h-3 w-3" />;
      default:
        return <Clock className="h-3 w-3" />;
    }
  };

  const handleWithdrawalSuccess = () => {
    setShowWithdrawalModal(false);
    fetchWithdrawals(); // Refresh the withdrawals list
    toast({
      title: "Withdrawal Initiated",
      description: "Your withdrawal has been submitted and is being processed.",
    });
  };

  return (
    <div className="space-y-6">
      {/* Withdrawal Form */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Withdraw Funds</CardTitle>
          <CardDescription className="text-slate-400">
            Withdraw your funds to your USDT wallet address
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-slate-700 rounded-lg mb-4">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Available Balance:</span>
              <span className="text-white font-semibold text-lg">
                ${profile?.exchange_balance?.toFixed(2) || "0.00"}
              </span>
            </div>
          </div>

          <Button
            onClick={() => setShowWithdrawalModal(true)}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center gap-2"
            disabled={loading}
          >
            <ArrowUpRight className="h-4 w-4" />
            Withdraw Funds
          </Button>
        </CardContent>
      </Card>

      {/* Withdrawal History */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Withdrawal History</CardTitle>
          <CardDescription className="text-slate-400">
            View your past withdrawal transactions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {withdrawals.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <ArrowUpRight className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium mb-2">No withdrawals yet</p>
              <p className="text-sm">
                Your withdrawal history will appear here
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {withdrawals.map((withdrawal) => (
                <div
                  key={withdrawal.id}
                  className="bg-slate-700 rounded-lg p-4 border border-slate-600"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-600 rounded-lg">
                        <ArrowUpRight className="h-4 w-4 text-blue-500" />
                      </div>
                      <div>
                        <p className="text-white font-medium">
                          ${withdrawal.amount.toFixed(2)}
                        </p>
                        <p className="text-slate-400 text-sm">
                          USDT Withdrawal
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge
                        className={`${getStatusColor(
                          withdrawal.status
                        )} text-white flex items-center gap-1 mb-1`}
                      >
                        {getStatusIcon(withdrawal.status)}
                        {withdrawal.status}
                      </Badge>
                      <p className="text-slate-400 text-xs">
                        {new Date(withdrawal.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <div className="mt-3 p-2 bg-slate-600 rounded text-xs">
                    <p className="text-slate-300 mb-1">Wallet Address:</p>
                    <p className="text-slate-400 font-mono break-all">
                      {withdrawal.address}
                    </p>
                  </div>

                  {withdrawal.transaction_id && (
                    <div className="mt-3 p-2 bg-slate-600 rounded text-xs">
                      <p className="text-slate-300 mb-1">Transaction ID:</p>
                      <p className="text-slate-400 font-mono break-all">
                        {withdrawal.transaction_id}
                      </p>
                    </div>
                  )}

                  {withdrawal.admin_note && (
                    <div className="mt-3 p-2 bg-slate-600 rounded text-xs">
                      <p className="text-slate-300 mb-1">Note:</p>
                      <p className="text-slate-400">{withdrawal.admin_note}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showWithdrawalModal} onOpenChange={setShowWithdrawalModal}>
        <DialogContent className="bg-slate-800 border-slate-700 max-w-md">
          <CCPaymentWithdrawalStep
            onSuccess={handleWithdrawalSuccess}
            onCancel={() => setShowWithdrawalModal(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WithdrawalsTab;
