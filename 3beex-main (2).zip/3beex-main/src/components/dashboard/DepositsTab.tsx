import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Wallet,
  TrendingUp,
  Calendar,
  CreditCard,
  Bitcoin,
} from "lucide-react";
import CCPaymentDepositStep from "./deposit/CCPaymentDepositStep";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface Deposit {
  id: string;
  amount: number;
  method: string;
  payment_method_name: string;
  status: string;
  created_at: string;
  transaction_hash?: string;
  admin_note?: string;
}

interface DepositsTabProps {
  deposits: Deposit[];
  onDeposit: () => void;
  loading: boolean;
}

const DepositsTab = ({ deposits, onDeposit, loading }: DepositsTabProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [showDepositModal, setShowDepositModal] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-blue-600";
      case "pending":
        return "bg-yellow-600";
      case "rejected":
        return "bg-red-600";
      default:
        return "bg-gray-600";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <TrendingUp className="h-3 w-3" />;
      case "pending":
        return <Calendar className="h-3 w-3" />;
      default:
        return <CreditCard className="h-3 w-3" />;
    }
  };

  const handleDepositSuccess = () => {
    setShowDepositModal(false);
    onDeposit(); // Refresh the deposits list
    toast({
      title: "Deposit Initiated",
      description:
        "Your deposit has been submitted and will be processed shortly.",
    });
  };

  return (
    <>
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Deposit Funds</CardTitle>
          <CardDescription className="text-slate-400">
            Add funds to your trading account using USDT
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-3">
            <Button
              onClick={() => setShowDepositModal(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2"
              disabled={loading}
            >
              <Wallet className="h-4 w-4" />
              Deposit Funds
            </Button>
          </div>

          <div className="mt-6">
            <h3 className="text-white font-semibold mb-4">Deposit History</h3>

            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : deposits.length === 0 ? (
              <div className="text-center py-12 text-slate-400">
                <Wallet className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p className="text-lg font-medium mb-2">No deposits yet</p>
                <p className="text-sm">Your deposit history will appear here</p>
              </div>
            ) : (
              <div className="space-y-3">
                {deposits.map((deposit) => (
                  <div
                    key={deposit.id}
                    className="bg-slate-700 rounded-lg p-4 border border-slate-600"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-600 rounded-lg">
                          <Bitcoin className="h-4 w-4 text-yellow-500" />
                        </div>
                        <div>
                          <p className="text-white font-medium">
                            ${deposit.amount.toFixed(2)}
                          </p>
                          <p className="text-slate-400 text-sm">
                            {deposit.payment_method_name || deposit.method}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge
                          className={`${getStatusColor(
                            deposit.status
                          )} text-white flex items-center gap-1 mb-1`}
                        >
                          {getStatusIcon(deposit.status)}
                          {deposit.status}
                        </Badge>
                        <p className="text-slate-400 text-xs">
                          {new Date(deposit.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>

                    {deposit.transaction_hash && (
                      <div className="mt-3 p-2 bg-slate-600 rounded text-xs">
                        <p className="text-slate-300 mb-1">Transaction Hash:</p>
                        <p className="text-slate-400 font-mono break-all">
                          {deposit.transaction_hash}
                        </p>
                      </div>
                    )}

                    {deposit.admin_note && (
                      <div className="mt-3 p-2 bg-slate-600 rounded text-xs">
                        <p className="text-slate-300 mb-1">Note:</p>
                        <p className="text-slate-400">{deposit.admin_note}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={showDepositModal} onOpenChange={setShowDepositModal}>
        <DialogContent className="bg-slate-800 border-slate-700 max-w-md">
          <CCPaymentDepositStep
            onSuccess={handleDepositSuccess}
            onCancel={() => setShowDepositModal(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
};

export default DepositsTab;
