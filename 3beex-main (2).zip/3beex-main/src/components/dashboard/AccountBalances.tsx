
import { TrendingUp, BarChart3, RefreshCw, History } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import TransferHistoryModal from "./TransferHistoryModal";

interface AccountBalancesProps {
  accountBalances: {
    exchange: number;
    trade: number;
    perpetual: number;
  };
  onNavigate: (path: string) => void;
}

const AccountBalances = ({ accountBalances, onNavigate }: AccountBalancesProps) => {
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  return (
    <div className="space-y-4 w-full overflow-x-hidden">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white">My account</h3>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowHistoryModal(true)}
          className="text-white border-slate-600 hover:bg-slate-700"
        >
          <History className="h-4 w-4 mr-2" />
          History
        </Button>
      </div>
      
      <div className="space-y-3 md:space-y-0 md:grid md:grid-cols-3 md:gap-4 w-full">
        <div 
          className="flex items-center justify-between p-4 bg-slate-800 rounded-lg cursor-pointer hover:bg-slate-750"
          onClick={() => onNavigate("/exchange")}
        >
          <div>
            <div className="text-white font-medium">Exchange</div>
            <div className="text-2xl font-bold text-white">
              ${accountBalances.exchange.toFixed(2)}
            </div>
          </div>
          <TrendingUp className="h-5 w-5 text-slate-400" />
        </div>
        
        <div 
          className="flex items-center justify-between p-4 bg-slate-800 rounded-lg cursor-pointer hover:bg-slate-750"
          onClick={() => onNavigate("/perpetual")}
        >
          <div>
            <div className="text-white font-medium">Trade</div>
            <div className="text-2xl font-bold text-white">
              ${accountBalances.trade.toFixed(2)}
            </div>
          </div>
          <BarChart3 className="h-5 w-5 text-slate-400" />
        </div>

        <div 
          className="flex items-center justify-between p-4 bg-slate-800 rounded-lg cursor-pointer hover:bg-slate-750"
          onClick={() => onNavigate("/perpetual")}
        >
          <div>
            <div className="text-white font-medium">Perpetual</div>
            <div className="text-2xl font-bold text-white">
              ${accountBalances.perpetual.toFixed(2)}
            </div>
          </div>
          <RefreshCw className="h-5 w-5 text-slate-400" />
        </div>
      </div>
      
      <TransferHistoryModal 
        open={showHistoryModal}
        onOpenChange={setShowHistoryModal}
      />
    </div>
  );
};

export default AccountBalances;
