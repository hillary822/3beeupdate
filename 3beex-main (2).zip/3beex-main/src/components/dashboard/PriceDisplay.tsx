
import { TrendingUp, TrendingDown } from "lucide-react";

interface PriceDisplayProps {
  currentPrice: number;
  priceChange: number;
}

const PriceDisplay = ({ currentPrice, priceChange }: PriceDisplayProps) => {
  const priceChangePercent = currentPrice > 0 ? (priceChange / currentPrice) * 100 : 0;

  return (
    <div className="text-right">
      <div className="text-2xl font-bold text-white">
        ${currentPrice.toLocaleString(undefined, { 
          minimumFractionDigits: 2, 
          maximumFractionDigits: 2 
        })}
      </div>
      {priceChange !== 0 && (
        <div className={`flex items-center justify-end gap-1 text-sm ${priceChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
          {priceChange >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
          {priceChange >= 0 ? '+' : ''}{priceChange.toFixed(2)} ({priceChangePercent.toFixed(2)}%)
        </div>
      )}
    </div>
  );
};

export default PriceDisplay;
