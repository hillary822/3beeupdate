
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Edit, Save, X, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface PaymentMethod {
  id: string;
  name: string;
  display_name: string;
  wallet_address: string;
  is_active: boolean;
}

const PaymentMethodsTab = () => {
  const { toast } = useToast();
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editForm, setEditForm] = useState({
    display_name: '',
    wallet_address: '',
    is_active: true
  });
  const [addForm, setAddForm] = useState({
    name: '',
    display_name: '',
    wallet_address: '',
    is_active: true
  });

  useEffect(() => {
    fetchPaymentMethods();
  }, []);

  const fetchPaymentMethods = async () => {
    try {
      const { data, error } = await supabase
        .from('payment_methods')
        .select('*')
        .order('name');

      if (error) throw error;
      setPaymentMethods(data || []);
    } catch (error) {
      console.error('Error fetching payment methods:', error);
      toast({
        title: "Error",
        description: "Failed to load payment methods",
        variant: "destructive",
      });
    }
  };

  const startEdit = (method: PaymentMethod) => {
    setEditingId(method.id);
    setEditForm({
      display_name: method.display_name,
      wallet_address: method.wallet_address,
      is_active: method.is_active
    });
    setShowAddForm(false);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({
      display_name: '',
      wallet_address: '',
      is_active: true
    });
  };

  const saveEdit = async (id: string) => {
    if (!editForm.wallet_address.trim()) {
      toast({
        title: "Error",
        description: "Wallet address is required",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('payment_methods')
        .update({
          display_name: editForm.display_name,
          wallet_address: editForm.wallet_address,
          is_active: editForm.is_active,
          updated_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Payment method updated successfully",
      });

      setEditingId(null);
      fetchPaymentMethods();
    } catch (error) {
      console.error('Error updating payment method:', error);
      toast({
        title: "Error",
        description: "Failed to update payment method",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const startAdd = () => {
    setShowAddForm(true);
    setEditingId(null);
    setAddForm({
      name: '',
      display_name: '',
      wallet_address: '',
      is_active: true
    });
  };

  const cancelAdd = () => {
    setShowAddForm(false);
    setAddForm({
      name: '',
      display_name: '',
      wallet_address: '',
      is_active: true
    });
  };

  const saveAdd = async () => {
    if (!addForm.name.trim() || !addForm.display_name.trim() || !addForm.wallet_address.trim()) {
      toast({
        title: "Error",
        description: "All fields are required",
        variant: "destructive",
      });
      return;
    }

    // Check if name already exists
    const existingMethod = paymentMethods.find(
      method => method.name.toLowerCase() === addForm.name.toLowerCase()
    );
    
    if (existingMethod) {
      toast({
        title: "Error",
        description: `Payment method "${addForm.name}" already exists. Please use a different name.`,
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('payment_methods')
        .insert({
          name: addForm.name.toUpperCase(),
          display_name: addForm.display_name,
          wallet_address: addForm.wallet_address,
          is_active: addForm.is_active
        });

      if (error) {
        // Handle specific database errors
        if (error.code === '23505') { // Unique violation
          toast({
            title: "Error",
            description: `Payment method "${addForm.name}" already exists. Please use a different name.`,
            variant: "destructive",
          });
        } else {
          throw error;
        }
        return;
      }

      toast({
        title: "Success",
        description: "Payment method added successfully",
      });

      setShowAddForm(false);
      fetchPaymentMethods();
    } catch (error) {
      console.error('Error adding payment method:', error);
      toast({
        title: "Error",
        description: "Failed to add payment method. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white">Payment Methods</CardTitle>
            <CardDescription className="text-slate-400">
              Manage cryptocurrency payment methods for deposits
            </CardDescription>
          </div>
          <Button
            onClick={startAdd}
            className=""
            disabled={loading || showAddForm}
          >
            <Plus size={16} className="mr-2" />
            Add Method
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add New Payment Method Form */}
        {showAddForm && (
          <div className="bg-slate-700 rounded-lg p-4 space-y-3 border-2 border-primary">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-medium">Add New Payment Method</h3>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={saveAdd}
                  disabled={loading}
                  className=""
                >
                  <Save size={16} />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={cancelAdd}
                  className="border-slate-600"
                >
                  <X size={16} />
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <Label className="text-white text-sm">Name (e.g., BTC, ETH)</Label>
                <Input
                  value={addForm.name}
                  onChange={(e) => setAddForm({ ...addForm, name: e.target.value })}
                  placeholder="ETH"
                  className="bg-slate-600 border-slate-500 text-white mt-1"
                />
                <p className="text-xs text-slate-400 mt-1">
                  Existing: {paymentMethods.map(m => m.name).join(', ')}
                </p>
              </div>
              <div>
                <Label className="text-white text-sm">Display Name</Label>
                <Input
                  value={addForm.display_name}
                  onChange={(e) => setAddForm({ ...addForm, display_name: e.target.value })}
                  placeholder="Ethereum"
                  className="bg-slate-600 border-slate-500 text-white mt-1"
                />
              </div>
            </div>
            
            <div>
              <Label className="text-white text-sm">Wallet Address</Label>
              <Input
                value={addForm.wallet_address}
                onChange={(e) => setAddForm({ ...addForm, wallet_address: e.target.value })}
                placeholder="Enter wallet address"
                className="bg-slate-600 border-slate-500 text-white mt-1"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                checked={addForm.is_active}
                onCheckedChange={(checked) => setAddForm({ ...addForm, is_active: checked })}
              />
              <Label className="text-white text-sm">Active</Label>
            </div>
          </div>
        )}

        {/* Existing Payment Methods */}
        {paymentMethods.map((method) => (
          <div key={method.id} className="bg-slate-700 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center text-black font-bold">
                  {method.name === 'BTC' ? '₿' : method.name === 'USDT_TRC20' ? '₮' : method.name.charAt(0)}
                </div>
                <div>
                  <h3 className="text-white font-medium">{method.name}</h3>
                  <Badge variant={method.is_active ? "default" : "secondary"}>
                    {method.is_active ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </div>
              
              {editingId === method.id ? (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => saveEdit(method.id)}
                    disabled={loading}
                    className=""
                  >
                    <Save size={16} />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={cancelEdit}
                    className="border-slate-600"
                  >
                    <X size={16} />
                  </Button>
                </div>
              ) : (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => startEdit(method)}
                  className="border-slate-600 text-slate-300"
                >
                  <Edit size={16} />
                </Button>
              )}
            </div>

            {editingId === method.id ? (
              <div className="space-y-3">
                <div>
                  <Label className="text-white text-sm">Display Name</Label>
                  <Input
                    value={editForm.display_name}
                    onChange={(e) => setEditForm({ ...editForm, display_name: e.target.value })}
                    className="bg-slate-600 border-slate-500 text-white mt-1"
                  />
                </div>
                <div>
                  <Label className="text-white text-sm">Wallet Address</Label>
                  <Input
                    value={editForm.wallet_address}
                    onChange={(e) => setEditForm({ ...editForm, wallet_address: e.target.value })}
                    className="bg-slate-600 border-slate-500 text-white mt-1"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={editForm.is_active}
                    onCheckedChange={(checked) => setEditForm({ ...editForm, is_active: checked })}
                  />
                  <Label className="text-white text-sm">Active</Label>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div>
                  <Label className="text-slate-400 text-xs">Display Name</Label>
                  <p className="text-white text-sm">{method.display_name}</p>
                </div>
                <div>
                  <Label className="text-slate-400 text-xs">Wallet Address</Label>
                  <p className="text-white text-sm font-mono break-all">{method.wallet_address}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default PaymentMethodsTab;
