
import { Button } from "@/components/ui/button";
import { ArrowDownCircle, ArrowUpCircle, RefreshCw, ArrowLeftRight } from "lucide-react";

interface ActionButtonsProps {
  setActiveTab: (tab: string) => void;
  setShowTransferModal: (show: boolean) => void;
  onNavigate: (path: string) => void;
}

const ActionButtons = ({ setActiveTab, setShowTransferModal, onNavigate }: ActionButtonsProps) => {
  console.log("ActionButtons rendering");
  
  return (
    <div className="grid grid-cols-4 gap-2 sm:gap-4 mb-6 w-full max-w-full overflow-x-hidden">
      <div className="flex flex-col items-center">
        <button
          className="w-16 h-16 rounded-full bg-blue-600 hover:bg-blue-700 mb-2 flex items-center justify-center shadow-lg transition-colors"
          onClick={() => setActiveTab("deposits")}
        >
          <ArrowDownCircle size={24} color="white" strokeWidth={2} />
        </button>
        <span className="text-xs sm:text-sm text-foreground truncate">Deposit</span>
      </div>
      
      <div className="flex flex-col items-center">
        <button
          className="w-16 h-16 rounded-full bg-blue-600 hover:bg-blue-700 mb-2 flex items-center justify-center shadow-lg transition-colors"
          onClick={() => setActiveTab("withdrawals")}
        >
          <ArrowUpCircle size={24} color="white" strokeWidth={2} />
        </button>
        <span className="text-xs sm:text-sm text-foreground truncate">Withdrawal</span>
      </div>
      
      <div className="flex flex-col items-center">
        <button
          className="w-16 h-16 rounded-full bg-blue-600 hover:bg-blue-700 mb-2 flex items-center justify-center shadow-lg transition-colors"
          onClick={() => onNavigate("/exchange")}
        >
          <RefreshCw size={24} color="white" strokeWidth={2} />
        </button>
        <span className="text-xs sm:text-sm text-foreground truncate">Convert</span>
      </div>
      
      <div className="flex flex-col items-center">
        <button
          className="w-16 h-16 rounded-full bg-blue-600 hover:bg-blue-700 mb-2 flex items-center justify-center shadow-lg transition-colors"
          onClick={() => setShowTransferModal(true)}
        >
          <ArrowLeftRight size={24} color="white" strokeWidth={2} />
        </button>
        <span className="text-xs sm:text-sm text-foreground truncate">Transfer</span>
      </div>
    </div>
  );
};

export default ActionButtons;
