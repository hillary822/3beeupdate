
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { fetchCryptoPrices } from "@/services/cryptoService";

const PriceChart = () => {
  const { data: cryptoData, isLoading, error } = useQuery({
    queryKey: ['crypto-prices'],
    queryFn: fetchCryptoPrices,
    refetchInterval: 30000, // Refetch every 30 seconds
    staleTime: 25000, // Consider data stale after 25 seconds
  });

  // Take only the first 5 coins for display
  const displayData = cryptoData?.slice(0, 5) || [];

  if (isLoading) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white text-lg">Top 5 Cryptocurrencies</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {[...Array(5)].map((_, index) => (
              <div key={index} className="bg-slate-700 rounded-lg p-3 animate-pulse">
                <div className="flex items-center justify-between mb-1">
                  <div className="h-4 bg-slate-600 rounded w-8"></div>
                  <div className="h-3 bg-slate-600 rounded w-12"></div>
                </div>
                <div className="h-6 bg-slate-600 rounded w-20 mb-1"></div>
                <div className="h-3 bg-slate-600 rounded w-16"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white text-lg">Top 5 Cryptocurrencies</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-slate-400 py-8">
            <p>Unable to load market data</p>
            <p className="text-sm">Please try again later</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-lg">Top 5 Cryptocurrencies</CardTitle>
        <p className="text-slate-400 text-sm">Live prices updated every 30 seconds</p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {displayData.map((crypto) => {
            const symbol = crypto.symbol.replace('-USDT', '');
            const symbolName = getSymbolName(symbol);
            
            return (
              <div key={crypto.symbol} className="bg-slate-700 rounded-lg p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-300 text-sm font-medium">{symbol}</span>
                  <span 
                    className={`text-xs font-semibold ${crypto.change >= 0 ? 'text-green-400' : 'text-red-400'}`}
                  >
                    {crypto.change >= 0 ? '+' : ''}{crypto.change.toFixed(2)}%
                  </span>
                </div>
                <div className="text-white font-bold text-lg">
                  ${crypto.price.toLocaleString(undefined, { 
                    minimumFractionDigits: crypto.price < 1 ? 4 : 2,
                    maximumFractionDigits: crypto.price < 1 ? 4 : 2 
                  })}
                </div>
                <div className="text-slate-400 text-xs">{symbolName}</div>
                <div className="text-slate-500 text-xs mt-1">Vol: {crypto.volume}</div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

const getSymbolName = (symbol: string): string => {
  const names: { [key: string]: string } = {
    'BTC': 'Bitcoin',
    'ETH': 'Ethereum', 
    'SOL': 'Solana',
    'ADA': 'Cardano',
    'DOT': 'Polkadot',
    'MATIC': 'Polygon',
    'AVAX': 'Avalanche',
    'LINK': 'Chainlink'
  };
  return names[symbol] || symbol;
};

export default PriceChart;
