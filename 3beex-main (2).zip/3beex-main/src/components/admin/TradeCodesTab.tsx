
import { useState, useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Copy, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface TradeCodesTabProps {
  tradeCodes: any[];
  onTradeCodeGenerated: () => void;
}

const TradeCodesTab = ({ tradeCodes, onTradeCodeGenerated }: TradeCodesTabProps) => {
  const { toast } = useToast();
  const [newTradeCode, setNewTradeCode] = useState("");
  const [signalType, setSignalType] = useState("BUY");
  const [asset, setAsset] = useState("BTC");
  const [profitPercentage, setProfitPercentage] = useState(1);
  const [duration, setDuration] = useState(15);
  const [isPremium, setIsPremium] = useState(false);
  const [isVip, setIsVip] = useState(false);
  const [isPermanentSignal, setIsPermanentSignal] = useState(false);
  const [minimumBalance, setMinimumBalance] = useState(50);
  const [winOrLoss, setWinOrLoss] = useState("WIN");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredTradeCodes = useMemo(() => {
    if (!searchTerm) return tradeCodes;
    
    return tradeCodes.filter(code =>
      code.code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      code.asset?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      code.profit_percentage?.toString().includes(searchTerm) ||
      (code.is_used ? "used" : "available").includes(searchTerm.toLowerCase())
    );
  }, [tradeCodes, searchTerm]);

  const sendCodeToUsers = async (tradeCodeId: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('send_code_to_users', {
        trade_code_id_input: tradeCodeId
      });

      if (error) {
        console.error('Error sending code:', error);
        toast({
          title: "Error",
          description: "Failed to send code to users. Please try again.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Code Sent Successfully",
        description: (data as any).message,
      });
    } catch (error) {
      console.error('Error sending code:', error);
      toast({
        title: "Error",
        description: "Failed to send code to users. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const generateTradeCode = async () => {
    if (!newTradeCode) {
      toast({
        title: "Error",
        description: "Please enter a trade code",
        variant: "destructive",
      });
      return;
    }
    
    setLoading(true);
    try {
      console.log('Generating trade code:', {
        code: newTradeCode,
        asset: asset,
        profit_percentage: profitPercentage,
        duration_minutes: duration
      });

      const { error } = await supabase
        .from('trade_codes')
        .insert({
          code: newTradeCode,
          asset: asset,
          profit_percentage: profitPercentage,
          duration_minutes: duration,
          is_premium: isPremium,
          is_vip: isVip,
          is_permanent_signal: isPermanentSignal,
          minimum_balance: minimumBalance,
          win_or_loss: winOrLoss,
          note: note || null,
          created_by: 'admin',
          signal_type: signalType
        });

      if (error) {
        console.error('Error generating trade code:', error);
        if (error.code === '23505') {
          toast({
            title: "Error",
            description: "This trade code already exists. Please use a different code.",
            variant: "destructive",
          });
        } else {
          throw error;
        }
        return;
      }

      toast({
        title: "Trade Code Generated",
        description: `Code "${newTradeCode}" has been generated successfully and is now available for users.`,
      });
      
      setNewTradeCode("");
      setSignalType("BUY");
      setAsset("BTC");
      setProfitPercentage(1);
      setDuration(15);
      setIsPremium(false);
      setIsVip(false);
      setIsPermanentSignal(false);
      setMinimumBalance(50);
      setWinOrLoss("WIN");
      setNote("");
      
      onTradeCodeGenerated();
    } catch (error) {
      console.error('Error generating trade code:', error);
      toast({
        title: "Error",
        description: "Failed to generate trade code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Generate Trade Code</CardTitle>
          <CardDescription className="text-slate-400">
            Create new trading signals for users
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white">Trade Code</Label>
              <Input
                placeholder="Enter trade code (e.g., BUY_SIGNAL_003)"
                value={newTradeCode}
                onChange={(e) => setNewTradeCode(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-white">Signal Type</Label>
              <Select value={signalType} onValueChange={setSignalType}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BUY">BUY Signal</SelectItem>
                  <SelectItem value="SELL">SELL Signal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-white">Asset</Label>
              <Select value={asset} onValueChange={setAsset}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                  <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                  <SelectItem value="ADA">Cardano (ADA)</SelectItem>
                  <SelectItem value="SOL">Solana (SOL)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-white">Trade Percentage</Label>
              <Input
                type="number"
                placeholder="10.00"
                value={profitPercentage || ""}
                onChange={(e) => setProfitPercentage(e.target.value === "" ? 0 : Number(e.target.value))}
                className="bg-slate-700 border-slate-600 text-white"
                step="0.01"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-white">Minimum Balance Required</Label>
              <Input
                type="number"
                placeholder="50.00"
                value={minimumBalance || ""}
                onChange={(e) => setMinimumBalance(e.target.value === "" ? 0 : Number(e.target.value))}
                className="bg-slate-700 border-slate-600 text-white h-10"
                step="0.01"
                min="0"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-white">Duration (minutes)</Label>
              <Input
                type="number"
                placeholder="15"
                value={duration || ""}
                onChange={(e) => setDuration(e.target.value === "" ? 0 : Number(e.target.value))}
                className="bg-slate-700 border-slate-600 text-white h-10"
                min="1"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-white">Trade Result</Label>
              <Select value={winOrLoss} onValueChange={setWinOrLoss}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="WIN">WIN (100% profit returned)</SelectItem>
                  <SelectItem value="LOSS">LOSS (trade amount lost)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2 col-span-2">
            <Label className="text-white">Note (Optional)</Label>
            <textarea
              placeholder="Add a note about this trade code (visible to users)"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-slate-700 border-slate-600 text-white rounded-md p-2 h-20 resize-none"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-white">Code Type</Label>
            <Select value={
              isPermanentSignal ? "permanent" : 
              isPremium ? "premium" : 
              isVip ? "vip" : 
              "normal"
            } onValueChange={(value) => {
              setIsPremium(value === "premium");
              setIsVip(value === "vip");
              setIsPermanentSignal(value === "permanent");
            }}>
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue />
              </SelectTrigger>
               <SelectContent>
                 <SelectItem value="normal">Normal Code (Everyone can use)</SelectItem>
                 <SelectItem value="premium">Extra Signal (Inviters & New Members Only)</SelectItem>
                 <SelectItem value="vip">VIP Code (VIP Users Only)</SelectItem>
                 <SelectItem value="permanent">Permanent Signal Code (Permanent Signal Users Only)</SelectItem>
               </SelectContent>
            </Select>
          </div>
          <Button 
            onClick={generateTradeCode} 
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            disabled={loading}
          >
            {loading ? "Generating..." : "Generate Trade Code"}
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Recent Trade Codes</CardTitle>
          <div className="mt-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
              <Input
                placeholder="Search by code, asset, profit %, or status..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-slate-700 border-slate-600 text-white"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left p-2 text-slate-400">Code</th>
                  <th className="text-left p-2 text-slate-400">Asset</th>
                  <th className="text-left p-2 text-slate-400">Trade %</th>
                  <th className="text-left p-2 text-slate-400">Duration</th>
                  <th className="text-left p-2 text-slate-400">Min Balance</th>
                  <th className="text-left p-2 text-slate-400">Result</th>
                  <th className="text-left p-2 text-slate-400">Note</th>
                  <th className="text-left p-2 text-slate-400">Type</th>
                  <th className="text-left p-2 text-slate-400">Status</th>
                  <th className="text-left p-2 text-slate-400">Actions</th>
                  <th className="text-left p-2 text-slate-400">Created</th>
                </tr>
              </thead>
              <tbody>
                {filteredTradeCodes.map((code) => {
                  const copyCode = () => {
                    navigator.clipboard.writeText(code.code);
                    toast({
                      title: "Copied!",
                      description: "Trade code copied to clipboard",
                    });
                  };

                  return (
                    <tr key={code.id} className="border-b border-slate-700">
                      <td className="p-2">
                        <div className="flex items-center gap-2">
                          <span className="text-white font-mono">{code.code}</span>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={copyCode}
                            className="h-6 w-6 p-0 hover:bg-slate-700"
                          >
                            <Copy className="h-3 w-3 text-slate-400 hover:text-white" />
                          </Button>
                        </div>
                      </td>
                      <td className="p-2 text-slate-300">{code.asset}</td>
                      <td className="p-2 text-slate-300">{Number(code.profit_percentage).toFixed(2)}%</td>
                      <td className="p-2 text-slate-300">{code.duration_minutes}m</td>
                      <td className="p-2 text-slate-300">${Number(code.minimum_balance || 0).toFixed(2)}</td>
                      <td className="p-2">
                        <Badge 
                          variant={code.win_or_loss === 'WIN' ? "default" : "destructive"}
                          className={code.win_or_loss === 'WIN' ? "bg-green-600 text-white" : "bg-red-600 text-white"}
                        >
                          {code.win_or_loss || 'WIN'}
                        </Badge>
                      </td>
                      <td className="p-2 text-slate-300 max-w-[150px] truncate" title={code.note}>
                        {code.note || "-"}
                      </td>
                      <td className="p-2">
                        <Badge 
                          variant={code.is_premium || code.is_vip || code.is_permanent_signal ? "secondary" : "outline"}
                          className={
                            code.is_vip 
                              ? "bg-gradient-to-r from-yellow-500 to-yellow-600 text-white" 
                              : code.is_premium 
                                ? "bg-purple-600 text-white" 
                                : code.is_permanent_signal
                                  ? "bg-green-600 text-white"
                                  : "border-slate-500 text-white"
                          }
                        >
                          {code.is_vip ? "VIP" : code.is_premium ? "Premium" : code.is_permanent_signal ? "Permanent Signal" : "Normal"}
                        </Badge>
                      </td>
                       <td className="p-2">
                        {(() => {
                          const createdTime = new Date(code.created_at);
                          const expiryTime = new Date(createdTime.getTime() + code.duration_minutes * 60000);
                          const now = new Date();
                          const isExpired = now > expiryTime;
                          
                          return (
                            <div className="space-y-1">
                              {code.sent_at && (
                                <Badge variant="secondary" className="bg-blue-600 text-white">
                                  Sent
                                </Badge>
                              )}
                              <Badge variant={isExpired ? "destructive" : "default"} className="text-xs">
                                {isExpired ? "Expired" : "Active"}
                              </Badge>
                            </div>
                          );
                        })()}
                      </td>
                      <td className="p-2">
                        {(() => {
                          const createdTime = new Date(code.created_at);
                          const expiryTime = new Date(createdTime.getTime() + code.duration_minutes * 60000);
                          const now = new Date();
                          const isExpired = now > expiryTime;
                          
                          if (!code.sent_at) {
                            return (
                              <Button
                                size="sm"
                                onClick={() => sendCodeToUsers(code.id)}
                                disabled={loading}
                                className="h-7 px-2 text-xs"
                              >
                                <Send className="h-3 w-3 mr-1" />
                                Send Code
                              </Button>
                            );
                          } else {
                            return (
                              <span className="text-slate-400 text-xs">
                                {isExpired ? "Code Expired" : `Expires in ${Math.ceil((expiryTime.getTime() - now.getTime()) / 60000)}m`}
                              </span>
                            );
                          }
                        })()}
                      </td>
                      <td className="p-2 text-slate-300">
                        {new Date(code.created_at).toLocaleDateString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filteredTradeCodes.length === 0 && tradeCodes.length > 0 && (
              <p className="text-slate-400 text-center py-8">No trade codes match your search</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TradeCodesTab;
