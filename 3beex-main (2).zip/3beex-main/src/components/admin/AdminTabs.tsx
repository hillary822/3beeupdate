import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import UserManagementTab from "./UserManagementTab";
import WithdrawalsTab from "./WithdrawalsTab";
import TradeCodesTab from "./TradeCodesTab";
import KYCManagementTab from "./KYCManagementTab";
import DepositsManagementTab from "./DepositsManagementTab";
import SettingsTab from "./SettingsTab";
import WalletManagementTab from "./WalletManagementTab";
import ReferralSettingsTab from "./ReferralSettingsTab";
import ManualDepositAddressesTab from "./ManualDepositAddressesTab";

interface AdminTabsProps {
  users: any[];
  withdrawals: any[];
  tradeCodes: any[];
  onUserUpdated: () => void;
  onManageBalance: (userId: string, amount: number, note: string) => Promise<void>;
  onTradeCodeGenerated: () => void;
  onWithdrawalUpdate: (withdrawalId: string, status: string, transactionId?: string) => Promise<void>;
}

const AdminTabs = ({
  users,
  withdrawals,
  tradeCodes,
  onUserUpdated,
  onManageBalance,
  onTradeCodeGenerated,
  onWithdrawalUpdate,
}: AdminTabsProps) => {
  const [activeTab, setActiveTab] = useState("users");

  const tabs = [
    { value: "users", label: "Users" },
    { value: "withdrawals", label: "Withdrawals" },
    { value: "deposits", label: "Deposits" },
    { value: "manual-deposits", label: "Manual Deposits" },
    // { value: "wallets", label: "Wallets" }, // Hidden temporarily
    { value: "trades", label: "Trade Codes" },
    { value: "kyc", label: "KYC" },
    { value: "referrals", label: "Referrals" },
    { value: "settings", label: "Settings" },
  ];

  // Create a simple callback for balance management refresh
  const handleBalanceManagementRefresh = () => {
    onUserUpdated();
  };

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
      {/* Desktop tabs */}
      <div className="hidden lg:block">
        <TabsList className="grid w-full grid-cols-8 bg-slate-800">
          {tabs.map((tab) => (
            <TabsTrigger
              key={tab.value}
              value={tab.value}
              className="text-white data-[state=active]:bg-slate-700 data-[state=active]:text-white"
            >
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>
      </div>

      {/* Mobile and tablet tabs - horizontal scroll */}
      <div className="lg:hidden">
        <div className="w-full overflow-x-auto">
          <div className="flex min-w-max bg-slate-800 rounded-md p-1">
            {tabs.map((tab) => (
              <button
                key={tab.value}
                onClick={() => setActiveTab(tab.value)}
                className={`
                  flex-shrink-0 px-4 py-2 text-sm font-medium rounded-sm transition-all
                  ${activeTab === tab.value 
                    ? 'bg-slate-700 text-white' 
                    : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                  }
                `}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <TabsContent value="users">
        <UserManagementTab 
          users={users} 
          onUserUpdated={onUserUpdated}
          onManageBalance={handleBalanceManagementRefresh}
        />
      </TabsContent>

      <TabsContent value="withdrawals">
        <WithdrawalsTab 
          withdrawals={withdrawals}
          onWithdrawalUpdate={onWithdrawalUpdate}
        />
      </TabsContent>

      <TabsContent value="deposits">
        <DepositsManagementTab />
      </TabsContent>

      <TabsContent value="manual-deposits">
        <ManualDepositAddressesTab />
      </TabsContent>

      {/* <TabsContent value="wallets">
        <WalletManagementTab />
      </TabsContent> */}

      <TabsContent value="trades">
        <TradeCodesTab 
          tradeCodes={tradeCodes} 
          onTradeCodeGenerated={onTradeCodeGenerated}
        />
      </TabsContent>

      <TabsContent value="kyc">
        <KYCManagementTab />
      </TabsContent>

      <TabsContent value="referrals">
        <ReferralSettingsTab />
      </TabsContent>

      <TabsContent value="settings">
        <SettingsTab />
      </TabsContent>
    </Tabs>
  );
};

export default AdminTabs;
