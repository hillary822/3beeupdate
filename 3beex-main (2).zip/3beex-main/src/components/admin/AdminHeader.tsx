import { Button } from "@/components/ui/button";
import LogoutButton from "@/components/LogoutButton";

const AdminHeader = () => {
  // Direct hardcoded logout using window.location
  const handleLogout = () => {
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = '/';
  };

  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 lg:mb-8 gap-4">
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-slate-400">Manage users, trades, and platform settings</p>
      </div>
      <Button 
        variant="default"
        onClick={handleLogout} 
        className="w-full sm:w-auto bg-gradient-primary hover:shadow-glow text-primary-foreground"
      >
        Logout
      </Button>
    </div>
  );
};

export default AdminHeader;