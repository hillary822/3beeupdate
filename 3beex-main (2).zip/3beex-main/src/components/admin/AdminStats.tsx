
import { Card, CardContent } from "@/components/ui/card";
import { Users, ShieldCheck, TrendingUp, CreditCard, FileText, Wallet } from "lucide-react";

interface AdminStatsProps {
  users: any[];
  withdrawals: any[];
  deposits: any[];
  kycVerifications: any[];
}

const AdminStats = ({ users, withdrawals, deposits, kycVerifications }: AdminStatsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-7 gap-4 mb-8">
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center">
            <Users className="h-6 w-6 text-blue-400" />
            <div className="ml-3">
              <p className="text-xs font-medium text-slate-400">Total Users</p>
              <p className="text-xl font-bold text-white">{users.length}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center">
            <ShieldCheck className="h-6 w-6 text-primary" />
            <div className="ml-3">
              <p className="text-xs font-medium text-slate-400">Verified Users</p>
              <p className="text-xl font-bold text-white">{users.filter(u => u.verified).length}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center">
            <TrendingUp className="h-6 w-6 text-purple-400" />
            <div className="ml-3">
              <p className="text-xs font-medium text-slate-400">VIP Users</p>
              <p className="text-xl font-bold text-white">{users.filter(u => u.vip).length}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center">
            <CreditCard className="h-6 w-6 text-yellow-400" />
            <div className="ml-3">
              <p className="text-xs font-medium text-slate-400">Pending Withdrawals</p>
              <p className="text-xl font-bold text-white">{withdrawals.filter(w => w.status === "pending").length}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center">
            <Wallet className="h-6 w-6 text-orange-400" />
            <div className="ml-3">
              <p className="text-xs font-medium text-slate-400">Pending Deposits</p>
              <p className="text-xl font-bold text-white">{deposits.filter(d => d.status === "pending").length}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center">
            <FileText className="h-6 w-6 text-green-400" />
            <div className="ml-3">
              <p className="text-xs font-medium text-slate-400">Basic Verification</p>
              <p className="text-xl font-bold text-white">{kycVerifications.filter(k => k.status === "pending" && k.verification_type === "basic").length}</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center">
            <FileText className="h-6 w-6 text-purple-400" />
            <div className="ml-3">
              <p className="text-xs font-medium text-slate-400">Advanced Verification</p>
              <p className="text-xl font-bold text-white">{kycVerifications.filter(k => k.status === "pending" && k.verification_type === "advanced").length}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminStats;
