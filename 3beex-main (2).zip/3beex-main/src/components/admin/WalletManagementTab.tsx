
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface WalletInsertResponse {
  success: boolean;
  message?: string;
  error?: string;
}

const WalletManagementTab = () => {
  const { toast } = useToast();
  const [walletsInput, setWalletsInput] = useState("");
  const [inserting, setInserting] = useState(false);
  const [walletStats, setWalletStats] = useState({ total: 0, assignments: 0 });
  const [loadingStats, setLoadingStats] = useState(false);

  const fetchWalletStats = async () => {
    setLoadingStats(true);
    try {
      const { count: totalCount } = await supabase
        .from('pre_generated_wallets')
        .select('*', { count: 'exact', head: true });

      // For now, we'll just show 0 assignments until the migration is applied
      setWalletStats({ 
        total: totalCount || 0, 
        assignments: 0 
      });
    } catch (error) {
      console.error('Error fetching wallet stats:', error);
    } finally {
      setLoadingStats(false);
    }
  };

  const insertWallets = async () => {
    if (!walletsInput.trim()) {
      toast({
        title: "Error",
        description: "Please enter wallet addresses",
        variant: "destructive",
      });
      return;
    }

    setInserting(true);
    try {
      // Parse wallet addresses from input (one per line)
      const addresses = walletsInput
        .split('\n')
        .map(addr => addr.trim())
        .filter(addr => addr.length > 0);

      if (addresses.length === 0) {
        throw new Error('No valid addresses found');
      }

      // Format for the database function
      const walletsData = addresses.map(address => ({
        address,
        currency: 'USDT'
      }));

      console.log('Inserting wallets:', walletsData);

      const { data, error } = await supabase.rpc('insert_pre_generated_wallets', {
        wallets_data: walletsData
      });

      if (error) throw error;

      // Type cast the response to our expected interface
      const response = data as unknown as WalletInsertResponse;

      if (response?.success) {
        toast({
          title: "Success",
          description: response.message || "Wallets inserted successfully",
        });
        setWalletsInput("");
        fetchWalletStats(); // Refresh stats
      } else {
        throw new Error(response?.error || 'Failed to insert wallets');
      }
    } catch (error) {
      console.error('Error inserting wallets:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to insert wallets",
        variant: "destructive",
      });
    } finally {
      setInserting(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Wallet Statistics</CardTitle>
          <CardDescription className="text-slate-400">
            Overview of pre-generated wallets and assignments
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-white">{walletStats.total}</div>
              <div className="text-sm text-slate-400">Total Wallets</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">{walletStats.assignments}</div>
              <div className="text-sm text-slate-400">User Assignments</div>
            </div>
          </div>
          <Button 
            onClick={fetchWalletStats} 
            disabled={loadingStats}
            className="w-full"
          >
            {loadingStats ? "Loading..." : "Refresh Stats"}
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Add Pre-Generated Wallets</CardTitle>
          <CardDescription className="text-slate-400">
            Insert USDT wallet addresses (one per line). Multiple users can share the same wallet.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Enter wallet addresses here, one per line:
TQn9Y2khEsLJW1ChVWFMSMeRDow5oNDMHh
TUEMDKXnJHjcZhtCZWjrH7W9p9bhiS7nJK
..."
            value={walletsInput}
            onChange={(e) => setWalletsInput(e.target.value)}
            className="bg-slate-700 border-slate-600 text-white min-h-[200px]"
            rows={10}
          />
          
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="border-green-500 text-green-500">
              Format: One address per line
            </Badge>
            <Badge variant="outline" className="border-blue-500 text-blue-500">
              Currency: USDT (Tron TRC20)
            </Badge>
            <Badge variant="outline" className="border-yellow-500 text-yellow-500">
              Shared: Multiple users per wallet
            </Badge>
          </div>

          <Button
            onClick={insertWallets}
            disabled={inserting || !walletsInput.trim()}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            {inserting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Inserting Wallets...
              </>
            ) : (
              "Insert Wallets"
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default WalletManagementTab;
