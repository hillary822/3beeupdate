import { useState, useMemo } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DollarSign, Settings, Search, TreePine } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ccPaymentSupabase } from "@/integrations/supabase/client";
import BalanceManagement from "./BalanceManagement";
import UserReferralTreeModal from "./UserReferralTreeModal";

interface UserManagementTabProps {
  users: any[];
  onUserUpdated: () => void;
  onManageBalance: () => void;
}

const UserManagementTab = ({
  users,
  onUserUpdated,
  onManageBalance,
}: UserManagementTabProps) => {
  const { toast } = useToast();
  const [editingUser, setEditingUser] = useState<any>(null);
  const [balanceUser, setBalanceUser] = useState<any>(null);
  const [referralTreeUser, setReferralTreeUser] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [userForm, setUserForm] = useState({
    username: "",
    email: "",
    newPassword: "",
  });

  const filteredUsers = useMemo(() => {
    if (!searchTerm) return users;

    const term = searchTerm.toLowerCase();

    return users.filter((user) => {
      // Basic search fields
      const basicMatch =
        user.user_id?.toString().includes(searchTerm) ||
        user.username?.toLowerCase().includes(term) ||
        user.email?.toLowerCase().includes(term);

      // Account type searches
      const isVipUser = user.vip_level && user.vip_level > 0;
      const isPremiumUser = user.premium;
      const isPermanentSignalUser = user.permanent_signal;
      const isVerifiedUser = user.verified;
      const isSuspendedUser = user.suspended;
      const isLockedUser = user.locked;

      const accountTypeMatch =
        (term.includes("vip") && isVipUser) ||
        (term.includes("extra signal") && isPremiumUser) ||
        (term.includes("premium") && isPremiumUser) ||
        (term.includes("permanent signal") && isPermanentSignalUser) ||
        (term.includes("verified") && isVerifiedUser) ||
        (term.includes("unverified") && !isVerifiedUser) ||
        (term.includes("suspended") && isSuspendedUser) ||
        (term.includes("locked") && isLockedUser);

      return basicMatch || accountTypeMatch;
    });
  }, [users, searchTerm]);

  const updateUserStatus = async (
    userId: string,
    field: string,
    value: any
  ) => {
    try {
      const { error } = await supabase
        .from("profiles")
        .update({ [field]: value, updated_at: new Date().toISOString() })
        .eq("id", userId);

      if (error) throw error;

      toast({
        title: "User Updated",
        description: `User ${field} has been updated successfully.`,
      });

      onUserUpdated();
    } catch (error) {
      console.error("Error updating user:", error);
      toast({
        title: "Error",
        description: "Failed to update user. Please try again.",
        variant: "destructive",
      });
    }
  };

  const updateVipLevel = async (userId: string, vipLevel: number) => {
    console.log(`Updating VIP level for user ${userId} to level ${vipLevel}`);
    try {
      const { data, error } = await supabase
        .from("profiles")
        .update({
          vip_level: vipLevel,
          vip: vipLevel > 0, // Keep the boolean for backward compatibility
          updated_at: new Date().toISOString(),
        })
        .eq("id", userId)
        .select();

      if (error) {
        console.error("Error updating VIP level:", error);
        throw error;
      }

      console.log("VIP level updated successfully:", data);

      toast({
        title: "VIP Level Updated",
        description: `User VIP level has been set to ${
          vipLevel === 0 ? "None" : `VIP ${vipLevel}`
        }.`,
      });

      onUserUpdated();
    } catch (error) {
      console.error("Error updating VIP level:", error);
      toast({
        title: "Error",
        description: "Failed to update VIP level. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleEditUser = (user: any) => {
    setEditingUser(user);
    setUserForm({
      username: user.username,
      email: user.email,
      newPassword: "",
    });
  };

  const handleManageBalance = (user: any) => {
    setBalanceUser(user);
  };

  const handleSaveUserDetails = async () => {
    try {
      // Update profile
      const { error: profileError } = await supabase
        .from("profiles")
        .update({
          username: userForm.username,
          email: userForm.email,
          updated_at: new Date().toISOString(),
        })
        .eq("id", editingUser.id);

      if (profileError) throw profileError;

      // Update auth user using Edge Function if password or email changed
      if (userForm.newPassword || userForm.email !== editingUser.email) {
        const {
          data: { session },
        } = await supabase.auth.getSession();

        if (!session) {
          throw new Error("No active session");
        }

        const updates: any = {};
        if (userForm.email !== editingUser.email) {
          updates.email = userForm.email;
        }
        if (userForm.newPassword) {
          updates.password = userForm.newPassword;
        }

        const { data, error } = await ccPaymentSupabase.functions.invoke(
          "admin-update-user",
          {
            body: {
              user_id: editingUser.id,
              updates: updates,
            },
          }
        );

        if (error) {
          throw new Error(
            error.message || "Failed to update user authentication"
          );
        }

        if (!data?.success) {
          throw new Error(
            data?.error || "Failed to update user authentication"
          );
        }
      }

      toast({
        title: "User Updated",
        description: "User details have been updated successfully.",
      });

      setEditingUser(null);
      onUserUpdated();
    } catch (error) {
      console.error("Error updating user details:", error);
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to update user details.",
        variant: "destructive",
      });
    }
  };

  const getVipBadge = (user: any) => {
    const vipLevel = user.vip_level || 0;
    if (vipLevel === 0) return null;

    return (
      <Badge
        variant="secondary"
        className="text-xs bg-gradient-to-r from-yellow-500 to-yellow-600 text-white"
      >
        VIP {vipLevel}
      </Badge>
    );
  };

  const getPremiumBadge = (user: any) => {
    if (!user.premium) return null;

    return (
      <Badge
        variant="secondary"
        className="text-xs bg-gradient-to-r from-purple-500 to-purple-600 text-white whitespace-nowrap"
      >
        Extra Signal
      </Badge>
    );
  };

  const getPermanentSignalBadge = (user: any) => {
    if (!user.permanent_signal) return null;

    return (
      <Badge
        variant="secondary"
        className="text-xs bg-gradient-to-r from-green-500 to-green-600 text-white whitespace-nowrap"
      >
        Permanent Signal
      </Badge>
    );
  };

  const getTotalBalance = (user: any) => {
    const exchange = Number(user.exchange_balance || 0);
    const trade = Number(user.trade_balance || 0);
    const perpetual = Number(user.perpetual_balance || 0);
    return exchange + trade + perpetual;
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">User Management</CardTitle>
        <CardDescription className="text-slate-400">
          Manage user accounts, verification, balances, and VIP levels
        </CardDescription>
        <div className="mt-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Search by User ID, username, email, or account type (VIP, Extra Signal, Permanent Signal, verified, etc.)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-700 border-slate-600 text-white"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[800px]">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left p-2 text-slate-400 w-20">User ID</th>
                <th className="text-left p-2 text-slate-400 w-32">Username</th>
                <th className="text-left p-2 text-slate-400 w-64 min-w-[200px]">
                  Email
                </th>
                <th className="text-left p-2 text-slate-400 w-32">
                  Referred By
                </th>
                <th className="text-left p-2 text-slate-400 w-32">
                  Total Balance
                </th>
                <th className="text-left p-2 text-slate-400 w-40">Status</th>
                <th className="text-left p-2 text-slate-400 w-32">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => (
                <tr key={user.id} className="border-b border-slate-700">
                  <td className="p-2 text-white font-mono w-20">
                    {user.user_id}
                  </td>
                  <td
                    className="p-2 text-slate-300 w-32 truncate"
                    title={user.username}
                  >
                    {user.username}
                  </td>
                  <td
                    className="p-2 text-slate-300 w-64 min-w-[200px] break-words"
                    title={user.email}
                  >
                    <div className="max-w-[200px] break-words">
                      {user.email}
                    </div>
                  </td>
                  <td className="p-2 text-slate-300">
                    {user.referrer_info ? (
                      <div className="text-xs">
                        <div className="text-white font-mono">
                          ID: {user.referrer_info.user_id}
                        </div>
                        <div>{user.referrer_info.referral_code}</div>
                      </div>
                    ) : (
                      "Direct"
                    )}
                  </td>
                  <td className="p-2 text-white">
                    ${getTotalBalance(user).toFixed(2)}
                  </td>
                  <td className="p-2">
                    <div className="flex gap-1 flex-wrap">
                      <Badge
                        variant={user.verified ? "default" : "destructive"}
                        className={`text-xs ${
                          user.verified
                            ? "bg-blue-600 hover:bg-blue-700 text-white"
                            : ""
                        }`}
                      >
                        {user.verified ? "Verified" : "Unverified"}
                      </Badge>
                      {getVipBadge(user)}
                      {getPremiumBadge(user)}
                      {getPermanentSignalBadge(user)}
                    </div>
                  </td>
                  <td className="p-2">
                    <div className="flex gap-1 flex-wrap">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-xs"
                          >
                            Manage
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-slate-800 border-slate-700 max-w-md">
                          <DialogHeader>
                            <DialogTitle className="text-white">
                              Manage User: {user.username}
                            </DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-2">
                              <Button
                                variant={
                                  user.verified ? "destructive" : "default"
                                }
                                onClick={() =>
                                  updateUserStatus(
                                    user.id,
                                    "verified",
                                    !user.verified
                                  )
                                }
                                size="sm"
                              >
                                {user.verified ? "Unverify" : "Verify"}
                              </Button>
                              <Button
                                variant={
                                  user.premium ? "destructive" : "default"
                                }
                                onClick={() =>
                                  updateUserStatus(
                                    user.id,
                                    "premium",
                                    !user.premium
                                  )
                                }
                                size="sm"
                              >
                                {user.premium
                                  ? "Remove Extra Signal"
                                  : "Add Extra Signal"}
                              </Button>
                              <Button
                                variant={
                                  user.suspended ? "default" : "destructive"
                                }
                                onClick={() =>
                                  updateUserStatus(
                                    user.id,
                                    "suspended",
                                    !user.suspended
                                  )
                                }
                                size="sm"
                              >
                                {user.suspended ? "Unsuspend" : "Suspend"}
                              </Button>
                              <Button
                                variant={user.locked ? "default" : "secondary"}
                                onClick={() =>
                                  updateUserStatus(
                                    user.id,
                                    "locked",
                                    !user.locked
                                  )
                                }
                                size="sm"
                              >
                                {user.locked ? "Unlock" : "Lock"}
                              </Button>
                              <Button
                                variant={
                                  user.permanent_signal
                                    ? "destructive"
                                    : "default"
                                }
                                onClick={() =>
                                  updateUserStatus(
                                    user.id,
                                    "permanent_signal",
                                    !user.permanent_signal
                                  )
                                }
                                size="sm"
                                className="col-span-2"
                              >
                                {user.permanent_signal
                                  ? "Remove Permanent Signal"
                                  : "Add Permanent Signal"}
                              </Button>
                            </div>
                            <div className="space-y-2">
                              <Label className="text-white text-xs">
                                VIP Level
                              </Label>
                              <Select
                                value={(user.vip_level || 0).toString()}
                                onValueChange={(value) =>
                                  updateVipLevel(user.id, parseInt(value))
                                }
                              >
                                <SelectTrigger className="bg-slate-700 border-slate-600 text-white h-8">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent className="bg-slate-800 border-slate-700">
                                  <SelectItem value="0" className="text-white">
                                    None
                                  </SelectItem>
                                  <SelectItem value="1" className="text-white">
                                    VIP 1
                                  </SelectItem>
                                  <SelectItem value="2" className="text-white">
                                    VIP 2
                                  </SelectItem>
                                  <SelectItem value="3" className="text-white">
                                    VIP 3
                                  </SelectItem>
                                  <SelectItem value="4" className="text-white">
                                    VIP 4
                                  </SelectItem>
                                  <SelectItem value="5" className="text-white">
                                    VIP 5
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <Button
                              variant="outline"
                              onClick={() => handleEditUser(user)}
                              className="w-full text-white border-slate-600 hover:bg-slate-700"
                              size="sm"
                            >
                              <Settings className="h-4 w-4 mr-2" />
                              Edit Details & Password
                            </Button>
                            <Button
                              variant="outline"
                              onClick={() => setReferralTreeUser(user)}
                              className="w-full text-white border-slate-600 hover:bg-slate-700"
                              size="sm"
                            >
                              <TreePine className="h-4 w-4 mr-2" />
                              View Referrals
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleManageBalance(user)}
                        className="text-xs"
                      >
                        <DollarSign className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>

      {/* Edit User Details Dialog */}
      {editingUser && (
        <Dialog
          open={!!editingUser}
          onOpenChange={(open) => !open && setEditingUser(null)}
        >
          <DialogContent className="bg-slate-800 border-slate-700">
            <DialogHeader>
              <DialogTitle className="text-white">
                Edit User Details
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-white">
                  Username
                </Label>
                <Input
                  id="username"
                  value={userForm.username}
                  onChange={(e) =>
                    setUserForm({ ...userForm, username: e.target.value })
                  }
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={userForm.email}
                  onChange={(e) =>
                    setUserForm({ ...userForm, email: e.target.value })
                  }
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="newPassword" className="text-white">
                  New Password (optional)
                </Label>
                <Input
                  id="newPassword"
                  type="password"
                  value={userForm.newPassword}
                  onChange={(e) =>
                    setUserForm({ ...userForm, newPassword: e.target.value })
                  }
                  className="bg-slate-700 border-slate-600 text-white"
                  placeholder="Leave empty to keep current password"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleSaveUserDetails} className="flex-1">
                  Save Changes
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setEditingUser(null)}
                  className="flex-1 text-white border-slate-600 hover:bg-slate-700"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Balance Management Dialog */}
      <BalanceManagement
        isOpen={!!balanceUser}
        onClose={() => setBalanceUser(null)}
        selectedUser={balanceUser}
        onBalanceUpdated={() => {
          onUserUpdated();
          onManageBalance();
        }}
      />

      {/* Referral Tree Modal */}
      <UserReferralTreeModal
        isOpen={!!referralTreeUser}
        onClose={() => setReferralTreeUser(null)}
        user={referralTreeUser}
      />
    </Card>
  );
};

export default UserManagementTab;
