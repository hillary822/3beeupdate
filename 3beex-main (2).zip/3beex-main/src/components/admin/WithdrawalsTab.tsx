import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import React, { useState, useMemo } from "react";
import { Search, Copy } from "lucide-react";
import RejectionDialog from "./RejectionDialog";
import { ccPaymentSupabase } from "@/integrations/supabase/client";

interface WithdrawalsTabProps {
  withdrawals: any[];
  onWithdrawalUpdate?: (
    withdrawalId: string,
    status: string,
    transactionId?: string
  ) => Promise<void>;
}

const WithdrawalsTab = ({
  withdrawals,
  onWithdrawalUpdate,
}: WithdrawalsTabProps) => {
  const { toast } = useToast();
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [rejectionDialog, setRejectionDialog] = useState<{
    open: boolean;
    withdrawalId: string | null;
  }>({
    open: false,
    withdrawalId: null,
  });

  const filteredWithdrawals = useMemo(() => {
    if (!searchTerm) return withdrawals;

    return withdrawals.filter(
      (withdrawal) =>
        withdrawal.user_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        withdrawal.profiles?.email
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        withdrawal.address?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        withdrawal.amount?.toString().includes(searchTerm) ||
        withdrawal.status?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [withdrawals, searchTerm]);

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied",
        description: "Address copied to clipboard",
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy address",
        variant: "destructive",
      });
    }
  };

  const handleStatusUpdate = async (
    withdrawalId: string,
    newStatus: string,
    adminNote?: string
  ) => {
    console.log(`Starting withdrawal ${newStatus}: ${withdrawalId}`);
    setLoadingId(withdrawalId);

    try {
      // Use the admin edge function that handles both approvals and rejections with proper refund logic
      const { data, error } = await ccPaymentSupabase.functions.invoke(
        "admin-update-withdrawal",
        {
          body: {
            withdrawal_id: withdrawalId,
            new_status: newStatus,
            admin_note: adminNote,
          },
        }
      );

      if (error) {
        console.error("Edge function error:", error);
        throw new Error(error.message || `Failed to ${newStatus} withdrawal`);
      }

      if (!data?.success) {
        throw new Error(data?.error || `Failed to ${newStatus} withdrawal`);
      }

      console.log(`Withdrawal ${newStatus} successfully:`, data);

      // Show appropriate success message
      let successMessage = `Withdrawal request has been ${newStatus}`;
      if (newStatus === "rejected" && data.refunded > 0) {
        successMessage += ` and $${data.refunded} has been refunded to the user's balance`;
      }

      toast({
        title: "Success",
        description: successMessage,
      });

      // Force immediate refresh of withdrawals data
      if (onWithdrawalUpdate) {
        console.log("Calling onWithdrawalUpdate for immediate refresh");
        await onWithdrawalUpdate(withdrawalId, newStatus);
      }
    } catch (error: any) {
      console.error("Error in handleStatusUpdate:", error);

      toast({
        title: "Error",
        description:
          error.message || "Failed to update withdrawal. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoadingId(null);
      setRejectionDialog({ open: false, withdrawalId: null });
    }
  };

  const openRejectionDialog = (withdrawalId: string) => {
    setRejectionDialog({ open: true, withdrawalId });
  };

  const getStatusBadge = (status: string) => {
    const statusColors = {
      pending: "bg-yellow-600",
      completed: "bg-blue-600",
      rejected: "bg-red-600",
    };

    return (
      <Badge
        className={`${
          statusColors[status as keyof typeof statusColors] || "bg-gray-600"
        } text-white`}
      >
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">Withdrawal Requests</CardTitle>
        <CardDescription className="text-slate-400">
          Review and approve user withdrawal requests
        </CardDescription>
        <div className="mt-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Search by User ID, email, address, amount, or status..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-700 border-slate-600 text-white"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1400px] table-fixed">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left p-3 text-slate-400 w-[120px]">
                  User ID
                </th>
                <th className="text-left p-3 text-slate-400 w-[220px]">
                  Email
                </th>
                <th className="text-left p-3 text-slate-400 w-[100px]">
                  Amount
                </th>
                <th className="text-left p-3 text-slate-400 w-[380px]">
                  Address
                </th>
                <th className="text-left p-3 text-slate-400 w-[100px]">
                  Status
                </th>
                <th className="text-left p-3 text-slate-400 w-[120px]">Date</th>
                <th className="text-left p-3 text-slate-400 w-[220px]">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredWithdrawals.map((withdrawal) => (
                <React.Fragment key={withdrawal.id}>
                  <tr className="border-b border-slate-700 hover:bg-slate-700/30">
                    <td className="p-3 text-slate-300 font-mono text-sm">
                      {withdrawal.profiles?.user_id}
                    </td>
                    <td className="p-3 text-slate-300 text-sm truncate">
                      {withdrawal.profiles?.email || "N/A"}
                    </td>
                    <td className="p-3 text-white font-semibold">
                      ${Number(withdrawal.amount).toFixed(2)}
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <div className="text-slate-300 font-mono text-sm truncate min-w-0 flex-1">
                          {withdrawal.address}
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(withdrawal.address)}
                          className="h-6 w-6 p-1 text-slate-400 hover:text-white hover:bg-slate-700 flex-shrink-0"
                          title="Copy address"
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    </td>
                    <td className="p-3">{getStatusBadge(withdrawal.status)}</td>
                    <td className="p-3 text-slate-300 text-sm">
                      {new Date(withdrawal.created_at).toLocaleDateString()}
                    </td>
                    <td className="p-3">
                      {withdrawal.status === "pending" && (
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() =>
                              handleStatusUpdate(withdrawal.id, "completed")
                            }
                            disabled={loadingId === withdrawal.id}
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                          >
                            {loadingId === withdrawal.id
                              ? "Processing..."
                              : "Approve"}
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => openRejectionDialog(withdrawal.id)}
                            disabled={loadingId === withdrawal.id}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            {loadingId === withdrawal.id
                              ? "Processing..."
                              : "Reject"}
                          </Button>
                        </div>
                      )}
                      {withdrawal.admin_note && (
                        <div className="mt-2 text-sm">
                          <span className="text-slate-400">Admin Note: </span>
                          <span className="text-red-300">
                            {withdrawal.admin_note}
                          </span>
                        </div>
                      )}
                    </td>
                  </tr>
                </React.Fragment>
              ))}
            </tbody>
          </table>
          {filteredWithdrawals.length === 0 && withdrawals.length > 0 && (
            <p className="text-slate-400 text-center py-8">
              No withdrawal requests match your search
            </p>
          )}
          {withdrawals.length === 0 && (
            <p className="text-slate-400 text-center py-8">
              No withdrawal requests
            </p>
          )}
        </div>

        <RejectionDialog
          open={rejectionDialog.open}
          onOpenChange={(open) =>
            setRejectionDialog({ open, withdrawalId: null })
          }
          onConfirm={(note) =>
            rejectionDialog.withdrawalId &&
            handleStatusUpdate(rejectionDialog.withdrawalId, "rejected", note)
          }
          title="Reject Withdrawal"
          description="Are you sure you want to reject this withdrawal request? The funds will be refunded to the user's balance. You can optionally provide a reason below."
          loading={loadingId === rejectionDialog.withdrawalId}
        />
      </CardContent>
    </Card>
  );
};

export default WithdrawalsTab;
