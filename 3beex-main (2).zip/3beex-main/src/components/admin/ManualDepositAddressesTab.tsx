import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Edit, Save, X } from "lucide-react";

interface DepositAddress {
  id: string;
  currency: string;
  network: string;
  address: string;
  is_active: boolean;
  updated_at: string;
}

const ManualDepositAddressesTab = () => {
  const { toast } = useToast();
  const [addresses, setAddresses] = useState<DepositAddress[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({ address: '', network: '' });

  useEffect(() => {
    fetchAddresses();
  }, []);

  const fetchAddresses = async () => {
    try {
      const { data, error } = await supabase
        .from('manual_deposit_addresses')
        .select('*')
        .order('currency');

      if (error) throw error;
      setAddresses(data || []);
    } catch (error) {
      console.error('Error fetching addresses:', error);
      toast({
        title: "Error",
        description: "Failed to load deposit addresses",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (address: DepositAddress) => {
    setEditingId(address.id);
    setEditForm({
      address: address.address,
      network: address.network
    });
  };

  const handleSave = async (id: string) => {
    try {
      const { error } = await supabase
        .from('manual_deposit_addresses')
        .update({
          address: editForm.address,
          network: editForm.network
        })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Address updated successfully",
      });

      await fetchAddresses();
      setEditingId(null);
      setEditForm({ address: '', network: '' });
    } catch (error) {
      console.error('Error updating address:', error);
      toast({
        title: "Error",
        description: "Failed to update address",
        variant: "destructive",
      });
    }
  };

  const handleCancel = () => {
    setEditingId(null);
    setEditForm({ address: '', network: '' });
  };

  const toggleActive = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('manual_deposit_addresses')
        .update({ is_active: !currentStatus })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Address ${!currentStatus ? 'activated' : 'deactivated'} successfully`,
      });

      await fetchAddresses();
    } catch (error) {
      console.error('Error toggling address status:', error);
      toast({
        title: "Error",
        description: "Failed to update address status",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-semibold">Manual Deposit Addresses</h2>
          <p className="text-slate-400 text-sm">Manage addresses for manual crypto deposits</p>
        </div>
      </div>

      <div className="grid gap-4">
        {addresses.map((address) => (
          <Card key={address.id} className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center space-x-3">
                  <span>{address.currency}</span>
                  <Badge variant={address.is_active ? "default" : "secondary"}>
                    {address.is_active ? "Active" : "Inactive"}
                  </Badge>
                </CardTitle>
                <div className="flex items-center space-x-2">
                  {editingId === address.id ? (
                    <>
                      <Button
                        size="sm"
                        onClick={() => handleSave(address.id)}
                        className="h-8 w-8 p-0"
                      >
                        <Save className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleCancel}
                        className="h-8 w-8 p-0"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </>
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(address)}
                      className="h-8 w-8 p-0"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant={address.is_active ? "destructive" : "default"}
                    onClick={() => toggleActive(address.id, address.is_active)}
                  >
                    {address.is_active ? "Deactivate" : "Activate"}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {editingId === address.id ? (
                <div className="space-y-3">
                  <div>
                    <Label htmlFor={`network-${address.id}`}>Network</Label>
                    <Input
                      id={`network-${address.id}`}
                      value={editForm.network}
                      onChange={(e) => setEditForm(prev => ({ ...prev, network: e.target.value }))}
                      placeholder="e.g., TRC20, ETH, BTC"
                    />
                  </div>
                  <div>
                    <Label htmlFor={`address-${address.id}`}>Wallet Address</Label>
                    <Input
                      id={`address-${address.id}`}
                      value={editForm.address}
                      onChange={(e) => setEditForm(prev => ({ ...prev, address: e.target.value }))}
                      placeholder="Enter wallet address"
                      className="font-mono text-sm"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <div>
                    <Label className="text-xs text-slate-400">Network</Label>
                    <p className="text-sm">{address.network}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-400">Address</Label>
                    <p className="text-sm font-mono break-all bg-slate-900 p-2 rounded">
                      {address.address}
                    </p>
                  </div>
                  <div>
                    <Label className="text-xs text-slate-400">Last Updated</Label>
                    <p className="text-sm">
                      {new Date(address.updated_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {addresses.length === 0 && (
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="text-center py-8">
            <p className="text-slate-400">No deposit addresses configured yet.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ManualDepositAddressesTab;