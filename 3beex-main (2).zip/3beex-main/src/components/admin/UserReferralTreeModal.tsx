import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import ReferralTreeView from "../dashboard/ReferralTreeView";

interface UserReferralTreeModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
}

const UserReferralTreeModal = ({ isOpen, onClose, user }: UserReferralTreeModalProps) => {
  if (!user) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-slate-800 border-slate-700 max-w-6xl max-h-[90vh] overflow-hidden">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-white">
            Referral Tree - {user.username} (ID: {user.user_id})
          </DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>
        <div className="overflow-y-auto max-h-[70vh]">
          <ReferralTreeView userId={user.id} isAdminView={true} />
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default UserReferralTreeModal;