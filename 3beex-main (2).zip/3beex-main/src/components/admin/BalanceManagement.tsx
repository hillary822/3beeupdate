import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ccPaymentSupabase } from "@/integrations/supabase/client";

interface BalanceManagementProps {
  isOpen: boolean;
  onClose: () => void;
  selectedUser: any;
  onBalanceUpdated: () => void;
}

const BalanceManagement = ({
  isOpen,
  onClose,
  selectedUser,
  onBalanceUpdated,
}: BalanceManagementProps) => {
  const { toast } = useToast();
  const [amount, setAmount] = useState("");
  const [balanceType, setBalanceType] = useState("exchange");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);

  const handleCreditBalance = async () => {
    if (!selectedUser || !amount) {
      toast({
        title: "Error",
        description: "Please enter an amount to credit",
        variant: "destructive",
      });
      return;
    }

    const creditAmount = parseFloat(amount);
    if (creditAmount === 0) {
      toast({
        title: "Error",
        description: "Please enter a non-zero amount",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      // Determine which balance column to update
      const balanceColumn = `${balanceType}_balance`;

      // Get current balance
      const { data: currentProfile, error: fetchError } = await supabase
        .from("profiles")
        .select(balanceColumn)
        .eq("id", selectedUser.id)
        .single();

      if (fetchError) throw fetchError;

      const currentBalance = currentProfile[balanceColumn] || 0;
      const newBalance = currentBalance + creditAmount;

      if (newBalance < 0) {
        toast({
          title: "Error",
          description: "Insufficient balance for this deduction",
          variant: "destructive",
        });
        return;
      }

      // Update the balance
      const { error: updateError } = await supabase
        .from("profiles")
        .update({
          [balanceColumn]: newBalance,
          updated_at: new Date().toISOString(),
        })
        .eq("id", selectedUser.id);

      if (updateError) throw updateError;

      // Create a deposit record for tracking if it's a credit
      if (creditAmount > 0) {
        const { data: depositData, error: depositError } =
          await ccPaymentSupabase
            .from("deposits")
            .insert({
              user_id: selectedUser.id,
              amount: creditAmount,
              method: "manual_deposit",
              status: "completed",
              payment_method_name: "Manual Admin Deposit",
              admin_notes: `Manual deposit by admin. Reason: ${
                note || "No reason provided"
              }`,
            })
            .select()
            .single();

        if (depositError) throw depositError;
      }

      toast({
        title: "Success",
        description: `${creditAmount > 0 ? "Credited" : "Deducted"} $${Math.abs(
          creditAmount
        ).toFixed(2)} ${creditAmount > 0 ? "to" : "from"} ${
          selectedUser.username
        }'s ${balanceType} balance`,
      });

      setAmount("");
      setNote("");
      onBalanceUpdated();
      onClose();
    } catch (error) {
      console.error("Error updating balance:", error);
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Failed to update balance. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-slate-800 border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-white">
            Manage Balance - {selectedUser?.username}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div className="bg-slate-700 p-3 rounded">
              <p className="text-slate-400">Exchange</p>
              <p className="text-white font-semibold">
                ${Number(selectedUser?.exchange_balance || 0).toFixed(2)}
              </p>
            </div>
            <div className="bg-slate-700 p-3 rounded">
              <p className="text-slate-400">Trade</p>
              <p className="text-white font-semibold">
                ${Number(selectedUser?.trade_balance || 0).toFixed(2)}
              </p>
            </div>
            <div className="bg-slate-700 p-3 rounded">
              <p className="text-slate-400">Perpetual</p>
              <p className="text-white font-semibold">
                ${Number(selectedUser?.perpetual_balance || 0).toFixed(2)}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="balanceType" className="text-white">
              Balance Type
            </Label>
            <Select value={balanceType} onValueChange={setBalanceType}>
              <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="exchange" className="text-white">
                  Exchange Balance
                </SelectItem>
                <SelectItem value="trade" className="text-white">
                  Trade Balance
                </SelectItem>
                <SelectItem value="perpetual" className="text-white">
                  Perpetual Balance
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount" className="text-white">
              Amount (positive to add, negative to subtract)
            </Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              placeholder="Enter amount (e.g., 100 or -50)"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="note" className="text-white">
              Note (Optional)
            </Label>
            <Textarea
              id="note"
              placeholder="Add a note for this balance change"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div className="flex gap-2">
            <Button
              onClick={handleCreditBalance}
              disabled={loading || !amount}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              {loading ? "Processing..." : "Update Balance"}
            </Button>
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1 border-slate-600 text-slate-300 hover:text-white"
            >
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BalanceManagement;
