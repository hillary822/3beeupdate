import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ccPaymentSupabase } from "@/integrations/supabase/client";
import { User, Lock, Mail, MessageCircle, Phone } from "lucide-react";

const SettingsTab = () => {
  const { toast } = useToast();
  const [minBalance, setMinBalance] = useState("");
  const [supportEmail, setSupportEmail] = useState("");
  const [supportWhatsapp, setSupportWhatsapp] = useState("");
  const [supportTelegram, setSupportTelegram] = useState("");
  const [isUpdating, setIsUpdating] = useState(false);
  const [isLoadingSettings, setIsLoadingSettings] = useState(true);
  const [adminProfile, setAdminProfile] = useState({
    email: "",
    newPassword: "",
    confirmPassword: "",
  });

  // Load current platform settings
  useEffect(() => {
    const loadPlatformSettings = async () => {
      try {
        const { data: minBalanceData, error: minBalanceError } = await supabase
          .from("platform_settings")
          .select("value")
          .eq("key", "minimum_trading_balance")
          .single();

        const { data: supportEmailData, error: supportEmailError } =
          await supabase
            .from("platform_settings")
            .select("value")
            .eq("key", "support_email")
            .single();

        const { data: supportWhatsappData, error: supportWhatsappError } =
          await supabase
            .from("platform_settings")
            .select("value")
            .eq("key", "support_whatsapp")
            .single();

        const { data: supportTelegramData, error: supportTelegramError } =
          await supabase
            .from("platform_settings")
            .select("value")
            .eq("key", "support_telegram")
            .single();

        if (minBalanceError && minBalanceError.code !== "PGRST116") {
          console.error(
            "Error loading minimum balance setting:",
            minBalanceError
          );
        } else if (minBalanceData) {
          setMinBalance(minBalanceData.value);
        }

        if (supportEmailError && supportEmailError.code !== "PGRST116") {
          console.error(
            "Error loading support email setting:",
            supportEmailError
          );
        } else if (supportEmailData) {
          setSupportEmail(supportEmailData.value);
        } else {
          setSupportEmail("support@3beetex.com");
        }

        if (supportWhatsappError && supportWhatsappError.code !== "PGRST116") {
          console.error(
            "Error loading support WhatsApp setting:",
            supportWhatsappError
          );
        } else if (supportWhatsappData) {
          setSupportWhatsapp(supportWhatsappData.value);
        } else {
          setSupportWhatsapp("+1234567890");
        }

        if (supportTelegramError && supportTelegramError.code !== "PGRST116") {
          console.error(
            "Error loading support Telegram setting:",
            supportTelegramError
          );
        } else if (supportTelegramData) {
          setSupportTelegram(supportTelegramData.value);
        } else {
          setSupportTelegram("@3beetex_support");
        }
      } catch (error) {
        console.error("Error loading platform settings:", error);
      } finally {
        setIsLoadingSettings(false);
      }
    };

    loadPlatformSettings();
  }, []);

  const updateAdminProfile = async () => {
    if (!adminProfile.email && !adminProfile.newPassword) {
      toast({
        title: "Error",
        description: "Please provide either email or password to update",
        variant: "destructive",
      });
      return;
    }

    if (
      adminProfile.newPassword &&
      adminProfile.newPassword !== adminProfile.confirmPassword
    ) {
      toast({
        title: "Error",
        description: "Passwords do not match",
        variant: "destructive",
      });
      return;
    }

    setIsUpdating(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) throw new Error("No authenticated user");

      const updates: any = {};
      if (adminProfile.email && adminProfile.email !== user.email) {
        updates.email = adminProfile.email;
      }
      if (adminProfile.newPassword) {
        updates.password = adminProfile.newPassword;
      }

      if (Object.keys(updates).length === 0) {
        toast({
          title: "No Changes",
          description: "No changes detected to update",
        });
        return;
      }

      const { data, error } = await ccPaymentSupabase.functions.invoke(
        "admin-update-user",
        {
          body: {
            user_id: user.id,
            updates: {
              is_admin: true, // Assuming admin update means making the user an admin
            },
          },
        }
      );

      if (error) throw error;

      if (!data?.success) {
        throw new Error(data?.error || "Failed to update profile");
      }

      toast({
        title: "Profile Updated",
        description: "Your admin profile has been updated successfully",
      });

      // Clear form
      setAdminProfile({
        email: "",
        newPassword: "",
        confirmPassword: "",
      });
    } catch (error) {
      console.error("Error updating admin profile:", error);
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to update profile",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const updateMinBalance = async () => {
    try {
      const balance = Number(minBalance) || 0;

      // First try to update existing record
      const { data: existingData } = await supabase
        .from("platform_settings")
        .select("id")
        .eq("key", "minimum_trading_balance")
        .single();

      let error;
      if (existingData) {
        // Update existing record
        ({ error } = await supabase
          .from("platform_settings")
          .update({ value: balance.toString() })
          .eq("key", "minimum_trading_balance"));
      } else {
        // Insert new record
        ({ error } = await supabase.from("platform_settings").insert({
          key: "minimum_trading_balance",
          value: balance.toString(),
        }));
      }

      if (error) throw error;

      toast({
        title: "Minimum Balance Updated",
        description: `Platform minimum trading balance set to $${balance}`,
      });
    } catch (error) {
      console.error("Error updating minimum balance:", error);
      toast({
        title: "Error",
        description: "Failed to update minimum balance",
        variant: "destructive",
      });
    }
  };

  const updateSupportEmail = async () => {
    try {
      if (!supportEmail || !supportEmail.includes("@")) {
        toast({
          title: "Error",
          description: "Please enter a valid email address",
          variant: "destructive",
        });
        return;
      }

      await updateSetting("support_email", supportEmail, "Support Email");
    } catch (error) {
      console.error("Error updating support email:", error);
    }
  };

  const updateSupportWhatsapp = async () => {
    try {
      if (!supportWhatsapp) {
        toast({
          title: "Error",
          description: "Please enter a WhatsApp number",
          variant: "destructive",
        });
        return;
      }

      await updateSetting(
        "support_whatsapp",
        supportWhatsapp,
        "Support WhatsApp"
      );
    } catch (error) {
      console.error("Error updating support WhatsApp:", error);
    }
  };

  const updateSupportTelegram = async () => {
    try {
      if (!supportTelegram) {
        toast({
          title: "Error",
          description: "Please enter a Telegram handle or link",
          variant: "destructive",
        });
        return;
      }

      await updateSetting(
        "support_telegram",
        supportTelegram,
        "Support Telegram"
      );
    } catch (error) {
      console.error("Error updating support Telegram:", error);
    }
  };

  const updateSetting = async (
    key: string,
    value: string,
    displayName: string
  ) => {
    try {
      // First try to update existing record
      const { data: existingData } = await supabase
        .from("platform_settings")
        .select("id")
        .eq("key", key)
        .single();

      let error;
      if (existingData) {
        // Update existing record
        ({ error } = await supabase
          .from("platform_settings")
          .update({ value })
          .eq("key", key));
      } else {
        // Insert new record
        ({ error } = await supabase
          .from("platform_settings")
          .insert({ key, value }));
      }

      if (error) throw error;

      toast({
        title: `${displayName} Updated`,
        description: `${displayName} set to ${value}`,
      });
    } catch (error) {
      console.error(`Error updating ${key}:`, error);
      toast({
        title: "Error",
        description: `Failed to update ${displayName}`,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Admin Profile Settings */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <User className="h-5 w-5" />
            Admin Profile Settings
          </CardTitle>
          <CardDescription className="text-slate-400">
            Update your admin email and password
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label className="text-white flex items-center gap-2">
              <Mail className="h-4 w-4" />
              New Email (optional)
            </Label>
            <Input
              type="email"
              placeholder="Enter new email address"
              value={adminProfile.email}
              onChange={(e) =>
                setAdminProfile((prev) => ({ ...prev, email: e.target.value }))
              }
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-white flex items-center gap-2">
              <Lock className="h-4 w-4" />
              New Password (optional)
            </Label>
            <Input
              type="password"
              placeholder="Enter new password"
              value={adminProfile.newPassword}
              onChange={(e) =>
                setAdminProfile((prev) => ({
                  ...prev,
                  newPassword: e.target.value,
                }))
              }
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-white">Confirm New Password</Label>
            <Input
              type="password"
              placeholder="Confirm new password"
              value={adminProfile.confirmPassword}
              onChange={(e) =>
                setAdminProfile((prev) => ({
                  ...prev,
                  confirmPassword: e.target.value,
                }))
              }
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <Button
            onClick={updateAdminProfile}
            disabled={isUpdating}
            className="w-full"
          >
            {isUpdating ? "Updating..." : "Update Profile"}
          </Button>
        </CardContent>
      </Card>

      {/* Platform Settings */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Platform Settings</CardTitle>
          <CardDescription className="text-slate-400">
            Configure trading platform parameters
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label className="text-white">Minimum Balance for Trading</Label>

            {/* Display current active value */}
            <div className="bg-slate-700 border border-slate-600 rounded-md p-3 mb-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-300 text-sm">
                  Current Active Setting:
                </span>
                <span className="text-primary font-semibold">
                  {isLoadingSettings
                    ? "Loading..."
                    : `$${Number(minBalance || 0).toFixed(2)}`}
                </span>
              </div>
            </div>

            <div className="flex gap-4 items-center">
              <Input
                type="number"
                placeholder="Enter minimum balance"
                value={minBalance}
                onChange={(e) => setMinBalance(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white w-32"
              />
              <span className="text-slate-400">USD</span>
              <Button onClick={updateMinBalance}>Update</Button>
            </div>
            <p className="text-sm text-slate-500">
              Users must have this minimum total balance across all accounts to
              participate in trading
            </p>
          </div>

          {/* Support Email */}
          <div className="space-y-2">
            <Label className="text-white flex items-center gap-2">
              <Mail className="h-4 w-4" />
              Customer Support Email
            </Label>

            <div className="bg-slate-700 border border-slate-600 rounded-md p-3 mb-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-300 text-sm">
                  Current Active Setting:
                </span>
                <span className="text-primary font-semibold">
                  {isLoadingSettings ? "Loading..." : supportEmail}
                </span>
              </div>
            </div>

            <div className="flex gap-4 items-center">
              <Input
                type="email"
                placeholder="Enter support email address"
                value={supportEmail}
                onChange={(e) => setSupportEmail(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white flex-1"
              />
              <Button onClick={updateSupportEmail}>Update</Button>
            </div>
            <p className="text-sm text-slate-500">
              This email address will be displayed to users when they access
              customer support
            </p>
          </div>

          {/* Support WhatsApp */}
          <div className="space-y-2">
            <Label className="text-white flex items-center gap-2">
              <Phone className="h-4 w-4" />
              Customer Support WhatsApp
            </Label>

            <div className="bg-slate-700 border border-slate-600 rounded-md p-3 mb-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-300 text-sm">
                  Current Active Setting:
                </span>
                <span className="text-primary font-semibold">
                  {isLoadingSettings ? "Loading..." : supportWhatsapp}
                </span>
              </div>
            </div>

            <div className="flex gap-4 items-center">
              <Input
                type="text"
                placeholder="Enter WhatsApp number (e.g., +1234567890)"
                value={supportWhatsapp}
                onChange={(e) => setSupportWhatsapp(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white flex-1"
              />
              <Button onClick={updateSupportWhatsapp}>Update</Button>
            </div>
            <p className="text-sm text-slate-500">
              WhatsApp number for customer support (include country code)
            </p>
          </div>

          {/* Support Telegram */}
          <div className="space-y-2">
            <Label className="text-white flex items-center gap-2">
              <MessageCircle className="h-4 w-4" />
              Customer Support Telegram
            </Label>

            <div className="bg-slate-700 border border-slate-600 rounded-md p-3 mb-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-300 text-sm">
                  Current Active Setting:
                </span>
                <span className="text-primary font-semibold">
                  {isLoadingSettings ? "Loading..." : supportTelegram}
                </span>
              </div>
            </div>

            <div className="flex gap-4 items-center">
              <Input
                type="text"
                placeholder="Enter Telegram handle or link (e.g., @support or t.me/username)"
                value={supportTelegram}
                onChange={(e) => setSupportTelegram(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white flex-1"
              />
              <Button onClick={updateSupportTelegram}>Update</Button>
            </div>
            <p className="text-sm text-slate-500">
              Telegram username or link for customer support
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SettingsTab;
