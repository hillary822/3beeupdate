import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Settings, Save, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const ReferralSettingsTab = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState({
    referral_bonus_levels: 3,
    referral_level_1_percentage: 5.0,
    referral_level_2_percentage: 2.5,
    referral_level_3_percentage: 1.0,
    referral_bonus_percentage: 5.0,
    registration_bonus_amount: 10.0
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('platform_settings')
        .select('key, value')
        .in('key', [
          'referral_bonus_levels',
          'referral_level_1_percentage',
          'referral_level_2_percentage', 
          'referral_level_3_percentage',
          'referral_bonus_percentage',
          'registration_bonus_amount'
        ]);

      if (error) throw error;

      const settingsMap: any = {};
      data?.forEach(setting => {
        settingsMap[setting.key] = parseFloat(setting.value) || 0;
      });

      setSettings(prev => ({ ...prev, ...settingsMap }));
    } catch (error) {
      console.error('Error fetching referral settings:', error);
      toast({
        title: "Error",
        description: "Failed to load referral settings",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const updates = Object.entries(settings).map(([key, value]) => ({
        key,
        value: value.toString()
      }));

      for (const update of updates) {
        const { error } = await supabase
          .from('platform_settings')
          .upsert(update, { onConflict: 'key' });

        if (error) throw error;
      }

      toast({
        title: "Settings Saved",
        description: "Referral bonus settings updated successfully"
      });
    } catch (error) {
      console.error('Error saving referral settings:', error);
      toast({
        title: "Error",
        description: "Failed to save referral settings",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const resetToDefaults = () => {
    setSettings({
      referral_bonus_levels: 3,
      referral_level_1_percentage: 5.0,
      referral_level_2_percentage: 2.5,
      referral_level_3_percentage: 1.0,
      referral_bonus_percentage: 5.0,
      registration_bonus_amount: 10.0
    });
  };

  const handleInputChange = (key: string, value: string) => {
    const numValue = parseFloat(value) || 0;
    setSettings(prev => ({ ...prev, [key]: numValue }));
  };

  if (loading) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Referral Bonus Settings
        </CardTitle>
        <CardDescription className="text-slate-400">
          Configure referral bonus percentages and levels for the referral system
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="bonus-levels" className="text-white">
                Maximum Referral Levels
              </Label>
              <Input
                id="bonus-levels"
                type="number"
                min="1"
                max="10"
                value={settings.referral_bonus_levels}
                onChange={(e) => handleInputChange('referral_bonus_levels', e.target.value)}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <p className="text-xs text-slate-400">
                How many levels deep referral bonuses should be paid (1-10)
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="registration-bonus" className="text-white">
                Registration Bonus Amount ($)
              </Label>
              <Input
                id="registration-bonus"
                type="number"
                step="0.01"
                min="0"
                max="1000"
                value={settings.registration_bonus_amount}
                onChange={(e) => handleInputChange('registration_bonus_amount', e.target.value)}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <p className="text-xs text-slate-400">
                Base bonus amount given to referrers when someone registers using their referral code
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="default-bonus" className="text-white">
                Default Bonus Percentage (%)
              </Label>
              <Input
                id="default-bonus"
                type="number"
                step="0.1"
                min="0"
                max="50"
                value={settings.referral_bonus_percentage}
                onChange={(e) => handleInputChange('referral_bonus_percentage', e.target.value)}
                className="bg-slate-700 border-slate-600 text-white"
              />
              <p className="text-xs text-slate-400">
                Fallback percentage when level-specific percentages aren't set
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-white font-medium">Level-Specific Percentages</h3>
            
            <div className="space-y-2">
              <Label htmlFor="level-1" className="text-white">
                Level 1 Percentage (%) - Direct Referrals
              </Label>
              <Input
                id="level-1"
                type="number"
                step="0.1"
                min="0"
                max="50"
                value={settings.referral_level_1_percentage}
                onChange={(e) => handleInputChange('referral_level_1_percentage', e.target.value)}
                className="bg-slate-700 border-slate-600 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="level-2" className="text-white">
                Level 2 Percentage (%) - Referrals of Referrals
              </Label>
              <Input
                id="level-2"
                type="number"
                step="0.1"
                min="0"
                max="50"
                value={settings.referral_level_2_percentage}
                onChange={(e) => handleInputChange('referral_level_2_percentage', e.target.value)}
                className="bg-slate-700 border-slate-600 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="level-3" className="text-white">
                Level 3 Percentage (%)
              </Label>
              <Input
                id="level-3"
                type="number"
                step="0.1"
                min="0"
                max="50"
                value={settings.referral_level_3_percentage}
                onChange={(e) => handleInputChange('referral_level_3_percentage', e.target.value)}
                className="bg-slate-700 border-slate-600 text-white"
              />
            </div>
          </div>
        </div>

        <Separator className="bg-slate-600" />

        <div className="bg-slate-700/50 p-4 rounded-lg">
          <h4 className="text-white font-medium mb-2">How Referral Bonuses Work:</h4>
          <ul className="text-sm text-slate-300 space-y-1">
            <li>• When someone registers using a referral code, their referrers receive immediate bonuses</li>
            <li>• Level 1 = Direct referrer (person who provided the referral code)</li>
            <li>• Level 2 = Person who referred the Level 1 referrer</li>
            <li>• Level 3 = Person who referred the Level 2 referrer, and so on</li>
            <li>• Bonuses are calculated from the base registration bonus amount</li>
            <li>• Bonuses are automatically credited to referrers' exchange balances</li>
            <li>• Each level receives a percentage of the base registration bonus</li>
          </ul>
        </div>

        <div className="flex gap-4">
          <Button
            onClick={saveSettings}
            disabled={saving}
            className="flex-1"
          >
            <Save className="h-4 w-4 mr-2" />
            {saving ? "Saving..." : "Save Settings"}
          </Button>
          <Button
            variant="outline"
            onClick={resetToDefaults}
            className="flex-1"
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset to Defaults
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ReferralSettingsTab;