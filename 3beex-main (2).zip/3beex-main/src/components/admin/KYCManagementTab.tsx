
import { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Download, Eye, Check, X, User, CreditCard, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface KYCVerification {
  id: string;
  user_id: string;
  verification_type: 'basic' | 'advanced';
  status: 'pending' | 'approved' | 'rejected';
  full_name?: string;
  country?: string;
  state?: string;
  id_card_number?: string;
  id_front_path?: string;
  id_back_path?: string;
  selfie_with_id_path?: string;
  submitted_at: string;
  admin_notes?: string;
  profiles: {
    username: string;
    email: string;
  } | null;
}

const KYCManagementTab = () => {
  const { toast } = useToast();
  const [verifications, setVerifications] = useState<KYCVerification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedVerification, setSelectedVerification] = useState<KYCVerification | null>(null);
  const [adminNotes, setAdminNotes] = useState('');
  const [activeTab, setActiveTab] = useState('basic');
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchVerifications();
  }, []);

  const fetchVerifications = async () => {
    try {
      const { data: verificationsData, error: verificationsError } = await supabase
        .from('kyc_verifications')
        .select('*')
        .order('submitted_at', { ascending: false });

      if (verificationsError) {
        console.error('Error fetching verifications:', verificationsError);
        throw verificationsError;
      }

      const verificationsWithProfiles: KYCVerification[] = [];
      
      if (verificationsData) {
        for (const verification of verificationsData) {
          const { data: profileData } = await supabase
            .from('profiles')
            .select('username, email')
            .eq('id', verification.user_id)
            .single();

          verificationsWithProfiles.push({
            ...verification,
            profiles: profileData || null
          });
        }
      }

      console.log('Fetched KYC verifications:', verificationsWithProfiles);
      setVerifications(verificationsWithProfiles);
    } catch (error) {
      console.error('Error fetching verifications:', error);
      toast({
        title: "Error",
        description: "Failed to load KYC verifications",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateStatus = async (verificationId: string, status: 'approved' | 'rejected', notes?: string) => {
    try {
      const { error } = await supabase
        .from('kyc_verifications')
        .update({ 
          status, 
          reviewed_at: new Date().toISOString(),
          admin_notes: notes
        })
        .eq('id', verificationId);

      if (error) throw error;

      // If approved, update user's verified status
      if (status === 'approved') {
        const verification = verifications.find(v => v.id === verificationId);
        if (verification) {
          const { error: profileError } = await supabase
            .from('profiles')
            .update({ verified: true })
            .eq('id', verification.user_id);

          if (profileError) throw profileError;
        }
      }

      toast({
        title: "Status Updated",
        description: `KYC verification ${status} successfully`,
      });

      fetchVerifications();
      setSelectedVerification(null);
      setAdminNotes('');
    } catch (error) {
      console.error('Error updating status:', error);
      toast({
        title: "Error",
        description: "Failed to update verification status",
        variant: "destructive",
      });
    }
  };

  const viewDocument = async (documentPath: string) => {
    try {
      console.log('Attempting to view document:', documentPath);
      const { data } = await supabase.storage
        .from('verification-documents')
        .getPublicUrl(documentPath);

      console.log('Got public URL:', data.publicUrl);
      setSelectedImage(data.publicUrl);
    } catch (error) {
      console.error('Error viewing document:', error);
      toast({
        title: "Error",
        description: "Failed to load document",
        variant: "destructive",
      });
    }
  };

  const downloadDocument = async (documentPath: string, filename: string) => {
    try {
      const { data, error } = await supabase.storage
        .from('verification-documents')
        .download(documentPath);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: "Download Failed",
        description: "Failed to download document",
        variant: "destructive",
      });
    }
  };

  const filteredVerifications = useMemo(() => {
    if (!searchTerm) return verifications;
    
    return verifications.filter(verification =>
      verification.profiles?.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      verification.profiles?.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      verification.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      verification.country?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      verification.status?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [verifications, searchTerm]);

  const basicVerifications = filteredVerifications.filter(v => v.verification_type === 'basic');
  const advancedVerifications = filteredVerifications.filter(v => v.verification_type === 'advanced');

  const renderBasicVerificationTable = (verifications: KYCVerification[]) => (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[600px]">
        <thead>
          <tr className="border-b border-slate-700">
            <th className="text-left p-2 text-slate-400">User</th>
            <th className="text-left p-2 text-slate-400">Full Name</th>
            <th className="text-left p-2 text-slate-400">Country</th>
            <th className="text-left p-2 text-slate-400">Status</th>
            <th className="text-left p-2 text-slate-400">Submitted</th>
            <th className="text-left p-2 text-slate-400">Actions</th>
          </tr>
        </thead>
        <tbody>
          {verifications.map((verification) => (
            <tr key={verification.id} className="border-b border-slate-700">
              <td className="p-2 text-white">{verification.profiles?.username || 'Unknown'}</td>
              <td className="p-2 text-slate-300">{verification.full_name || 'N/A'}</td>
              <td className="p-2 text-slate-300">{verification.country || 'N/A'}</td>
               <td className="p-2">
                 <Badge 
                   variant={
                     verification.status === 'approved' ? 'default' : 
                     verification.status === 'rejected' ? 'destructive' : 'secondary'
                   }
                    className={verification.status === 'approved' ? 'bg-blue-600 hover:bg-blue-700 text-white' : ''}
                 >
                   {verification.status}
                 </Badge>
               </td>
              <td className="p-2 text-slate-300">
                {new Date(verification.submitted_at).toLocaleDateString()}
              </td>
              <td className="p-2">
                <div className="flex gap-1 flex-wrap">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedVerification(verification);
                      setAdminNotes(verification.admin_notes || '');
                    }}
                    className="text-xs"
                  >
                    <Eye className="h-3 w-3" />
                  </Button>
                  {verification.status === 'pending' && (
                    <>
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => updateStatus(verification.id, 'approved')}
                        className="text-xs bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <Check className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => updateStatus(verification.id, 'rejected')}
                        className="text-xs"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      
      {verifications.length === 0 && (
        <div className="text-center py-8 text-slate-400">
          No basic verifications found
        </div>
      )}
    </div>
  );

  const renderAdvancedVerificationTable = (verifications: KYCVerification[]) => (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[600px]">
        <thead>
          <tr className="border-b border-slate-700">
            <th className="text-left p-2 text-slate-400">User</th>
            <th className="text-left p-2 text-slate-400">Email</th>
            <th className="text-left p-2 text-slate-400">Status</th>
            <th className="text-left p-2 text-slate-400">Submitted</th>
            <th className="text-left p-2 text-slate-400">Actions</th>
          </tr>
        </thead>
        <tbody>
          {verifications.map((verification) => (
            <tr key={verification.id} className="border-b border-slate-700">
              <td className="p-2 text-white">{verification.profiles?.username || 'Unknown'}</td>
              <td className="p-2 text-slate-300 break-all">{verification.profiles?.email || 'Unknown'}</td>
               <td className="p-2">
                 <Badge 
                   variant={
                     verification.status === 'approved' ? 'default' : 
                     verification.status === 'rejected' ? 'destructive' : 'secondary'
                   }
                   className={verification.status === 'approved' ? 'bg-blue-600 hover:bg-blue-700 text-white' : ''}
                 >
                   {verification.status}
                 </Badge>
               </td>
              <td className="p-2 text-slate-300">
                {new Date(verification.submitted_at).toLocaleDateString()}
              </td>
              <td className="p-2">
                <div className="flex gap-1 flex-wrap">
                  {verification.id_front_path && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewDocument(verification.id_front_path!)}
                      className="text-xs"
                      title="View ID Front"
                    >
                      <Eye className="h-3 w-3" />
                    </Button>
                  )}
                  {verification.id_back_path && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewDocument(verification.id_back_path!)}
                      className="text-xs"
                      title="View ID Back"
                    >
                      <Eye className="h-3 w-3" />
                    </Button>
                  )}
                  {verification.selfie_with_id_path && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => viewDocument(verification.selfie_with_id_path!)}
                      className="text-xs"
                      title="View Selfie"
                    >
                      <Eye className="h-3 w-3" />
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedVerification(verification);
                      setAdminNotes(verification.admin_notes || '');
                    }}
                    className="text-xs"
                    title="Review"
                  >
                    Review
                  </Button>
                  {verification.status === 'pending' && (
                    <>
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => updateStatus(verification.id, 'approved')}
                        className="text-xs bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <Check className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => updateStatus(verification.id, 'rejected')}
                        className="text-xs"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      
      {verifications.length === 0 && (
        <div className="text-center py-8 text-slate-400">
          No advanced verifications found
        </div>
      )}
    </div>
  );

  if (isLoading) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-6">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <div>Loading KYC verifications...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">KYC Verification Management</CardTitle>
        <CardDescription className="text-slate-400">
          Review and approve user verification submissions
        </CardDescription>
        <div className="mt-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Search by username, email, full name, country, or status..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-700 border-slate-600 text-white"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="overflow-x-auto">
            <TabsList className="bg-slate-700 mb-6 w-max min-w-full">
              <TabsTrigger value="basic" className="flex items-center gap-2 whitespace-nowrap">
                <User className="h-4 w-4" />
                <span className="hidden sm:inline">Basic Verification</span>
                <span className="sm:hidden">Basic</span>
                <span>({basicVerifications.length})</span>
              </TabsTrigger>
              <TabsTrigger value="advanced" className="flex items-center gap-2 whitespace-nowrap">
                <CreditCard className="h-4 w-4" />
                <span className="hidden sm:inline">Advanced Verification</span>
                <span className="sm:hidden">Advanced</span>
                <span>({advancedVerifications.length})</span>
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="basic">
            {renderBasicVerificationTable(basicVerifications)}
          </TabsContent>

          <TabsContent value="advanced">
            {renderAdvancedVerificationTable(advancedVerifications)}
          </TabsContent>
        </Tabs>

        {/* Image Preview Dialog */}
        <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
          <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-white">KYC Document</DialogTitle>
            </DialogHeader>
            {selectedImage && (
              <div className="max-h-96 overflow-auto">
                <img 
                  src={selectedImage} 
                  alt="KYC Document"
                  className="w-full h-auto rounded-lg"
                />
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Review Dialog */}
        <Dialog open={!!selectedVerification} onOpenChange={() => setSelectedVerification(null)}>
          <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-white">
                Review {selectedVerification?.verification_type} Verification
              </DialogTitle>
            </DialogHeader>
            {selectedVerification && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-slate-400">User:</span>
                    <span className="text-white ml-2">{selectedVerification.profiles?.username}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Email:</span>
                    <span className="text-white ml-2">{selectedVerification.profiles?.email}</span>
                  </div>
                  {selectedVerification.verification_type === 'basic' && (
                    <>
                      <div>
                        <span className="text-slate-400">Full Name:</span>
                        <span className="text-white ml-2">{selectedVerification.full_name}</span>
                      </div>
                      <div>
                        <span className="text-slate-400">Country:</span>
                        <span className="text-white ml-2">{selectedVerification.country}</span>
                      </div>
                      <div>
                        <span className="text-slate-400">State:</span>
                        <span className="text-white ml-2">{selectedVerification.state}</span>
                      </div>
                      <div>
                        <span className="text-slate-400">ID Number:</span>
                        <span className="text-white ml-2">{selectedVerification.id_card_number}</span>
                      </div>
                    </>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-white text-sm">Admin Notes</label>
                  <Textarea
                    value={adminNotes}
                    onChange={(e) => setAdminNotes(e.target.value)}
                    placeholder="Add notes for the user..."
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>

                {selectedVerification.status === 'pending' && (
                  <div className="flex gap-3">
                    <Button
                      onClick={() => updateStatus(selectedVerification.id, 'approved', adminNotes)}
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      Approve
                    </Button>
                    <Button
                      onClick={() => updateStatus(selectedVerification.id, 'rejected', adminNotes)}
                      variant="destructive"
                      className="flex-1"
                    >
                      Reject
                    </Button>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default KYCManagementTab;
