import { useState, useEffect, useMemo } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Check, X, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { ccPaymentSupabase } from "@/integrations/supabase/client";
import { approveDeposit, rejectDeposit } from "@/utils/depositUtils";
import RejectionDialog from "./RejectionDialog";

interface Deposit {
  id: string;
  amount: number;
  payment_method_name: string;
  wallet_address: string;
  transaction_hash: string | null;
  status: string;
  created_at: string;
  user_id: string;
  method: string;
  admin_note: string | null;
  profiles?: {
    username: string;
    email: string;
    user_id: number;
  };
}

const DepositsManagementTab = () => {
  const { toast } = useToast();
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [rejectionDialog, setRejectionDialog] = useState<{
    open: boolean;
    depositId: string | null;
  }>({
    open: false,
    depositId: null,
  });

  const filteredDeposits = useMemo(() => {
    if (!searchTerm) return deposits;

    return deposits.filter(
      (deposit) =>
        deposit.profiles?.user_id?.toString().includes(searchTerm) ||
        deposit.profiles?.username
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        deposit.profiles?.email
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        deposit.amount?.toString().includes(searchTerm) ||
        deposit.method?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        deposit.status?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [deposits, searchTerm]);

  useEffect(() => {
    fetchDeposits();
  }, []);

  const fetchDeposits = async () => {
    setLoading(true);
    try {
      const { data: deposits, error } = await ccPaymentSupabase
        .from("deposits")
        .select(
          `
          *,
          profiles!inner(username, email, user_id)
        `
        )
        .order("created_at", { ascending: false });

      if (error) throw error;
      setDeposits(deposits || []);
    } catch (error) {
      console.error("Error fetching deposits:", error);
      toast({
        title: "Error",
        description: "Failed to load deposits",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (depositId: string) => {
    setActionLoading(depositId);
    try {
      await approveDeposit(depositId);
      toast({
        title: "Success",
        description: "Deposit approved and user balance updated",
      });
      fetchDeposits();
    } catch (error) {
      console.error("Error approving deposit:", error);
      toast({
        title: "Error",
        description: "Failed to approve deposit",
        variant: "destructive",
      });
    } finally {
      setActionLoading(null);
    }
  };

  const handleReject = async (depositId: string, adminNote?: string) => {
    setActionLoading(depositId);
    try {
      await rejectDeposit(depositId, adminNote);
      toast({
        title: "Success",
        description: "Deposit rejected",
      });
      fetchDeposits();
    } catch (error) {
      console.error("Error rejecting deposit:", error);
      toast({
        title: "Error",
        description: "Failed to reject deposit",
        variant: "destructive",
      });
    } finally {
      setActionLoading(null);
      setRejectionDialog({ open: false, depositId: null });
    }
  };

  const openRejectionDialog = (depositId: string) => {
    setRejectionDialog({ open: true, depositId });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-blue-600 text-white";
      case "pending":
        return "bg-yellow-600";
      case "rejected":
        return "bg-red-600";
      default:
        return "bg-gray-600";
    }
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">Deposit Management</CardTitle>
        <CardDescription className="text-slate-400">
          Review and approve user deposit requests
        </CardDescription>
        <div className="mt-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Search by User ID, username, email, amount, method, or status..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-700 border-slate-600 text-white"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="text-center py-8 text-slate-400">
            Loading deposits...
          </div>
        ) : filteredDeposits.length === 0 && deposits.length > 0 ? (
          <div className="text-center py-8 text-slate-400">
            No deposits match your search
          </div>
        ) : deposits.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            No deposits found
          </div>
        ) : (
          <div className="space-y-4">
            {filteredDeposits.map((deposit) => (
              <div
                key={deposit.id}
                className="bg-slate-700 p-4 rounded-lg border border-slate-600"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="text-2xl font-bold text-white">
                      ${Number(deposit.amount).toFixed(2)}
                    </div>
                    <Badge className={getStatusColor(deposit.status)}>
                      {deposit.status === "completed"
                        ? deposit.method === "admin_credit"
                          ? "USDT CREDIT"
                          : "Completed"
                        : deposit.status}
                    </Badge>
                    <div className="text-lg font-semibold text-slate-300">
                      {deposit.profiles?.user_id}
                    </div>
                  </div>
                  {deposit.status === "pending" && (
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => handleApprove(deposit.id)}
                        disabled={actionLoading === deposit.id}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <Check size={16} />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => openRejectionDialog(deposit.id)}
                        disabled={actionLoading === deposit.id}
                        className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                      >
                        <X size={16} />
                      </Button>
                    </div>
                  )}
                </div>

                <div className="text-slate-300 mb-2">
                  <span className="font-medium">
                    {deposit.profiles?.username}
                  </span>{" "}
                  ({deposit.profiles?.email})
                </div>

                <div className="text-sm text-slate-400 mb-2">
                  {new Date(deposit.created_at).toLocaleString()}
                </div>

                <div className="space-y-1 text-sm">
                  <div className="text-slate-400">
                    <span className="text-slate-500">Method:</span>{" "}
                    {deposit.method || "N/A"}
                  </div>

                  {deposit.wallet_address && (
                    <div className="text-slate-400 break-all">
                      <span className="text-slate-500">Wallet:</span>{" "}
                      {deposit.wallet_address}
                    </div>
                  )}

                  {deposit.transaction_hash && (
                    <div className="text-slate-400 break-all">
                      <span className="text-blue-400">TX Hash:</span>{" "}
                      {deposit.transaction_hash}
                    </div>
                  )}

                  {deposit.admin_note && (
                    <div className="mt-2 text-sm">
                      <span className="text-slate-500">Admin Note:</span>
                      <span className="text-red-300 ml-1">
                        {deposit.admin_note}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        <RejectionDialog
          open={rejectionDialog.open}
          onOpenChange={(open) => setRejectionDialog({ open, depositId: null })}
          onConfirm={(note) =>
            rejectionDialog.depositId &&
            handleReject(rejectionDialog.depositId, note)
          }
          title="Reject Deposit"
          description="Are you sure you want to reject this deposit request? You can optionally provide a reason below."
          loading={actionLoading === rejectionDialog.depositId}
        />
      </CardContent>
    </Card>
  );
};

export default DepositsManagementTab;
