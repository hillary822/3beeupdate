import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Download, Eye, Check, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface VerificationSubmission {
  id: string;
  user_id: string;
  document_path: string;
  status: string;
  created_at: string;
  profiles: {
    username: string;
    email: string;
  } | null;
}

const VerificationTab = () => {
  const { toast } = useToast();
  const [submissions, setSubmissions] = useState<VerificationSubmission[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => {
    fetchSubmissions();
  }, []);

  const fetchSubmissions = async () => {
    try {
      // Fetch verification submissions first
      const { data: submissionsData, error: submissionsError } = await supabase
        .from('verification_submissions')
        .select('*')
        .order('created_at', { ascending: false });

      if (submissionsError) {
        console.error('Error fetching submissions:', submissionsError);
        throw submissionsError;
      }

      // Fetch profiles for each submission
      const submissionsWithProfiles: VerificationSubmission[] = [];
      
      if (submissionsData) {
        for (const submission of submissionsData) {
          const { data: profileData } = await supabase
            .from('profiles')
            .select('username, email')
            .eq('id', submission.user_id)
            .single();

          submissionsWithProfiles.push({
            ...submission,
            profiles: profileData || null
          });
        }
      }

      setSubmissions(submissionsWithProfiles);
    } catch (error) {
      console.error('Error fetching submissions:', error);
      toast({
        title: "Error",
        description: "Failed to load verification submissions",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateStatus = async (submissionId: string, status: 'approved' | 'rejected') => {
    try {
      const { error } = await supabase
        .from('verification_submissions')
        .update({ 
          status, 
          reviewed_at: new Date().toISOString() 
        })
        .eq('id', submissionId);

      if (error) throw error;

      // If approved, also update the user's profile
      if (status === 'approved') {
        const submission = submissions.find(s => s.id === submissionId);
        if (submission) {
          const { error: profileError } = await supabase
            .from('profiles')
            .update({ verified: true })
            .eq('id', submission.user_id);

          if (profileError) throw profileError;
        }
      }

      toast({
        title: "Status Updated",
        description: `Verification ${status} successfully`,
      });

      fetchSubmissions();
    } catch (error) {
      console.error('Error updating status:', error);
      toast({
        title: "Error",
        description: "Failed to update verification status",
        variant: "destructive",
      });
    }
  };

  const downloadDocument = async (documentPath: string, filename: string) => {
    try {
      const { data, error } = await supabase.storage
        .from('verification-documents')
        .download(documentPath);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: "Download Failed",
        description: "Failed to download document",
        variant: "destructive",
      });
    }
  };

  const viewDocument = async (documentPath: string) => {
    try {
      const { data } = await supabase.storage
        .from('verification-documents')
        .getPublicUrl(documentPath);

      setSelectedImage(data.publicUrl);
    } catch (error) {
      console.error('Error viewing document:', error);
      toast({
        title: "Error",
        description: "Failed to load document",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <Card className="bg-slate-800 border-slate-700">
        <CardContent className="p-6">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <div>Loading verification submissions...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">Identity Verification</CardTitle>
        <CardDescription className="text-slate-400">
          Review and approve user verification documents
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[600px]">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left p-2 text-slate-400">User</th>
                <th className="text-left p-2 text-slate-400">Email</th>
                <th className="text-left p-2 text-slate-400">Status</th>
                <th className="text-left p-2 text-slate-400">Submitted</th>
                <th className="text-left p-2 text-slate-400">Actions</th>
              </tr>
            </thead>
            <tbody>
              {submissions.map((submission) => (
                <tr key={submission.id} className="border-b border-slate-700">
                  <td className="p-2 text-white">{submission.profiles?.username || 'Unknown'}</td>
                  <td className="p-2 text-slate-300 break-all">{submission.profiles?.email || 'Unknown'}</td>
                  <td className="p-2">
                    <Badge 
                      variant={
                        submission.status === 'approved' ? 'default' : 
                        submission.status === 'rejected' ? 'destructive' : 'secondary'
                      }
                    >
                      {submission.status}
                    </Badge>
                  </td>
                  <td className="p-2 text-slate-300">
                    {new Date(submission.created_at).toLocaleDateString()}
                  </td>
                  <td className="p-2">
                    <div className="flex gap-1 flex-wrap">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => viewDocument(submission.document_path)}
                        className="text-xs"
                      >
                        <Eye className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => downloadDocument(submission.document_path, `${submission.profiles?.username || 'user'}_verification.jpg`)}
                        className="text-xs"
                      >
                        <Download className="h-3 w-3" />
                      </Button>
                      {submission.status === 'pending' && (
                        <>
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => updateStatus(submission.id, 'approved')}
                            className="text-xs bg-blue-600 hover:bg-blue-700 text-white"
                          >
                            <Check className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => updateStatus(submission.id, 'rejected')}
                            className="text-xs"
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {submissions.length === 0 && (
            <div className="text-center py-8 text-slate-400">
              No verification submissions found
            </div>
          )}
        </div>

        {/* Image Preview Dialog */}
        <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
          <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-white">Verification Document</DialogTitle>
            </DialogHeader>
            {selectedImage && (
              <div className="max-h-96 overflow-auto">
                <img 
                  src={selectedImage} 
                  alt="Verification Document"
                  className="w-full h-auto rounded-lg"
                />
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};

export default VerificationTab;
