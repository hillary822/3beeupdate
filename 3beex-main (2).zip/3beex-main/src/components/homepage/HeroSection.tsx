
import { Button } from "@/components/ui/button";
import { User } from "lucide-react";
import LanguageTranslator from "@/components/LanguageTranslator";
import btcHeroBanner from "@/assets/btc-hero-banner.jpg";
import CryptoPriceTicker from "./CryptoPriceTicker";

interface HeroSectionProps {
  onShowAuth: () => void;
}

const HeroSection = ({ onShowAuth }: HeroSectionProps) => {
  return (
    <div className="relative bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Crypto Price Ticker */}
      <CryptoPriceTicker />
      
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-slate-800/50 border-b border-slate-700/50">
        <div className="flex items-center gap-3">
          <img 
            src="/lovable-uploads/2071e00c-95d8-4fcc-ab70-7f3a3b4b85a7.png" 
            alt="3BEET Exchange" 
            className="h-10 w-auto"
          />
        </div>
        
        
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            className="p-2 h-10 w-10 rounded-full hover:bg-white/10"
            onClick={onShowAuth}
          >
            <User className="w-5 h-5 text-white" />
          </Button>
          <LanguageTranslator />
        </div>
      </div>

      {/* Hero Banner - Full Width */}
      <div className="relative w-full h-64 overflow-hidden">
        <img 
          src={btcHeroBanner} 
          alt="Bitcoin Trading Platform" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent"></div>
        <div className="absolute inset-0 flex items-center">
          <div className="px-4 max-w-md">
            <h2 className="text-2xl font-bold text-white mb-2">
              Trade Bitcoin & Crypto
            </h2>
            <p className="text-white/90 text-sm">
              Professional trading platform with advanced tools and real-time analytics
            </p>
          </div>
        </div>
      </div>

      {/* Hero Content */}
      <div className="px-4 py-6 text-center">
        
        <div className="space-y-4">
          <h1 className="text-2xl font-bold text-white">
            Start Trading with 3BEET
          </h1>
          <p className="text-slate-300 text-sm max-w-xs mx-auto">
            Professional cryptocurrency trading platform with copy trading and advanced features
          </p>
          
          <Button 
            onClick={onShowAuth}
            className="bg-gradient-primary hover:bg-primary/90 text-white px-8 py-3 rounded-full font-medium transform hover:scale-105 transition-all duration-300"
          >
            Get Started
          </Button>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
