import { useEffect, useState } from "react";

interface CryptoPrice {
  symbol: string;
  price: number;
  change: number;
}

const CryptoPriceTicker = () => {
  const [prices, setPrices] = useState<CryptoPrice[]>([
    { symbol: "BTC", price: 119299, change: 0.70 },
    { symbol: "ETH", price: 3701.9, change: -2.86 },
    { symbol: "SOL", price: 200.2, change: 4.91 },
    { symbol: "ADA", price: 0.88, change: -3.88 },
    { symbol: "DOT", price: 4.41, change: -3.90 },
    { symbol: "MATIC", price: 0.248, change: -3.86 },
    { symbol: "AVAX", price: 25.61, change: -1.56 },
    { symbol: "LINK", price: 19.18, change: -3.98 }
  ]);

  useEffect(() => {
    const fetchPrices = async () => {
      try {
        const response = await fetch(
          'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana,cardano,polkadot,matic-network,avalanche-2,chainlink&vs_currencies=usd&include_24hr_change=true'
        );
        const data = await response.json();
        
        const newPrices: CryptoPrice[] = [
          { symbol: "BTC", price: data.bitcoin?.usd || 119299, change: data.bitcoin?.usd_24h_change || 0.70 },
          { symbol: "ETH", price: data.ethereum?.usd || 3701.9, change: data.ethereum?.usd_24h_change || -2.86 },
          { symbol: "SOL", price: data.solana?.usd || 200.2, change: data.solana?.usd_24h_change || 4.91 },
          { symbol: "ADA", price: data.cardano?.usd || 0.88, change: data.cardano?.usd_24h_change || -3.88 },
          { symbol: "DOT", price: data.polkadot?.usd || 4.41, change: data.polkadot?.usd_24h_change || -3.90 },
          { symbol: "MATIC", price: data['matic-network']?.usd || 0.248, change: data['matic-network']?.usd_24h_change || -3.86 },
          { symbol: "AVAX", price: data['avalanche-2']?.usd || 25.61, change: data['avalanche-2']?.usd_24h_change || -1.56 },
          { symbol: "LINK", price: data.chainlink?.usd || 19.18, change: data.chainlink?.usd_24h_change || -3.98 }
        ];
        
        setPrices(newPrices);
      } catch (error) {
        console.error('Failed to fetch crypto prices:', error);
      }
    };

    fetchPrices();
    const interval = setInterval(fetchPrices, 30000);
    return () => clearInterval(interval);
  }, []);

  const formatPrice = (price: number) => {
    if (price < 1) {
      return `$${price.toFixed(3)}`;
    } else if (price < 100) {
      return `$${price.toFixed(2)}`;
    } else {
      return `$${price.toLocaleString()}`;
    }
  };

  return (
    <div className="bg-slate-800/50 border-b border-slate-700/50 overflow-hidden">
      <div className="relative flex">
        <div className="flex animate-scroll whitespace-nowrap py-2">
          {/* First set */}
          {prices.map((crypto, index) => (
            <div key={`first-${index}`} className="flex items-center px-6 text-sm">
              <span className="text-white font-medium">{crypto.symbol}</span>
              <span className="text-white ml-2">{formatPrice(crypto.price)}</span>
              <span className={`ml-2 ${crypto.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {crypto.change >= 0 ? '+' : ''}{crypto.change.toFixed(2)}%
              </span>
            </div>
          ))}
          {/* Second set for seamless loop */}
          {prices.map((crypto, index) => (
            <div key={`second-${index}`} className="flex items-center px-6 text-sm">
              <span className="text-white font-medium">{crypto.symbol}</span>
              <span className="text-white ml-2">{formatPrice(crypto.price)}</span>
              <span className={`ml-2 ${crypto.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {crypto.change >= 0 ? '+' : ''}{crypto.change.toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CryptoPriceTicker;