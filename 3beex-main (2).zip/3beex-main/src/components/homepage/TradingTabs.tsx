import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const TradingTabs = () => {
  const [activeTab, setActiveTab] = useState("Hot");

  const tabs = ["Hot", "Self Service", "Perp", "Seconds", "Options", "Spot"];

  return (
    <div className="px-4 py-2">
      <div className="flex gap-1 overflow-x-auto scrollbar-hide">
        {tabs.map((tab) => (
          <Button
            key={tab}
            variant={activeTab === tab ? "default" : "ghost"}
            size="sm"
            className={`whitespace-nowrap text-xs px-3 py-1 h-8 ${
              activeTab === tab 
                ? "bg-primary text-white" 
                : "text-slate-400 hover:text-white hover:bg-white/10"
            }`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </Button>
        ))}
      </div>
    </div>
  );
};

export default TradingTabs;