import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { 
  Wallet, 
  ArrowDownToLine, 
  ArrowUpFromLine, 
  RefreshCw, 
  Settings, 
  MoreHorizontal 
} from "lucide-react";

interface NavigationGridProps {
  onShowAuth: () => void;
}

const NavigationGrid = ({ onShowAuth }: NavigationGridProps) => {
  const navigationItems = [
    { icon: ArrowDownToLine, label: "Deposit", color: "text-blue-400" },
    { icon: ArrowUpFromLine, label: "Withdrawal", color: "text-red-400" },
    { icon: RefreshCw, label: "Convert", color: "text-cyan-400" },
    { icon: Settings, label: "Options", color: "text-purple-400" },
    { icon: MoreHorizontal, label: "More", color: "text-gray-400" },
  ];

  return (
    <div className="px-4 py-6">
      <div className="grid grid-cols-5 gap-3 max-w-md mx-auto">
        {navigationItems.map((item, index) => (
          <Button
            key={index}
            variant="ghost"
            className="flex flex-col items-center gap-2 h-auto py-4 px-2 hover:bg-white/10 transition-colors"
            onClick={onShowAuth}
          >
            <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center">
              <item.icon className={`w-6 h-6 ${item.color}`} />
            </div>
            <span className="text-xs text-white font-medium">{item.label}</span>
          </Button>
        ))}
      </div>
    </div>
  );
};

export default NavigationGrid;