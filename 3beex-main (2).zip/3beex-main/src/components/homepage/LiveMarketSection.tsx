import TradingPairsDisplay from "@/components/homepage/TradingPairsDisplay";

const LiveMarketSection = () => {
  return (
    <div className="px-4 py-4">
      <div className="max-w-md mx-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-white font-semibold">Crypto</h2>
          <div className="flex gap-4 text-sm">
            <span className="text-slate-400">Last Price</span>
            <span className="text-slate-400">24h %</span>
          </div>
        </div>
        
        <TradingPairsDisplay />
      </div>
    </div>
  );
};

export default LiveMarketSection;