import { useQuery } from "@tanstack/react-query";
import { fetchCryptoPrices } from "@/services/cryptoService";
import { TrendingUp, TrendingDown } from "lucide-react";

const TradingPairsDisplay = () => {
  const { data: cryptoData, isLoading, error } = useQuery({
    queryKey: ['crypto-prices'],
    queryFn: fetchCryptoPrices,
    refetchInterval: 30000,
    staleTime: 25000,
  });

  // Take top 7 coins for display
  const displayData = cryptoData?.slice(0, 7) || [];

  if (isLoading) {
    return (
      <div className="bg-slate-900/50 backdrop-blur-sm rounded-lg p-3 md:p-6">
        <div className="space-y-2">
          {[...Array(7)].map((_, index) => (
            <div key={index} className="bg-slate-800/50 rounded-lg animate-pulse">
              {/* Mobile Loading */}
              <div className="md:hidden p-3">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center gap-2">
                    <div className="h-4 bg-slate-600 rounded w-12"></div>
                    <div className="h-3 bg-slate-600 rounded w-16"></div>
                  </div>
                  <div className="h-6 bg-slate-600 rounded w-16"></div>
                </div>
                <div className="flex justify-between">
                  <div className="h-4 bg-slate-600 rounded w-20"></div>
                  <div className="h-3 bg-slate-600 rounded w-16"></div>
                </div>
              </div>
              
              {/* Desktop Loading */}
              <div className="hidden md:flex justify-between items-center p-4">
                <div className="flex items-center gap-4">
                  <div className="h-4 bg-slate-600 rounded w-16"></div>
                  <div className="h-3 bg-slate-600 rounded w-20"></div>
                </div>
                <div className="text-right">
                  <div className="h-5 bg-slate-600 rounded w-24 mb-1"></div>
                  <div className="h-4 bg-slate-600 rounded w-16"></div>
                </div>
                <div className="h-8 bg-slate-600 rounded w-16"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-slate-900/50 backdrop-blur-sm rounded-lg p-3 md:p-6">
        <div className="text-center text-slate-400 py-8">
          <p>Unable to load market data</p>
          <p className="text-sm">Please try again later</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-900/50 backdrop-blur-sm rounded-lg p-3 md:p-6">
      {/* Header - hidden on mobile */}
      <div className="hidden md:block mb-6">
        <div className="grid grid-cols-4 gap-4 text-sm text-slate-400 font-medium mb-4">
          <div>Trading Pairs / Vol</div>
          <div className="text-right">Price</div>
          <div className="text-right">24H Change</div>
          <div></div>
        </div>
      </div>
      
      <div className="space-y-2">
        {displayData.map((crypto) => {
          const symbol = crypto.symbol.replace('-USDT', '');
          const isPositive = crypto.change >= 0;
          
          return (
            <div key={crypto.symbol} className="bg-slate-800/30 rounded-lg hover:bg-slate-800/50 transition-colors">
              {/* Mobile Layout */}
              <div className="md:hidden p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-bold text-base">{symbol}</span>
                    <span className="text-slate-400 text-sm">/ USDT</span>
                    {isPositive ? (
                      <TrendingUp className="w-3 h-3 text-amber-500" />
                    ) : (
                      <TrendingDown className="w-3 h-3 text-amber-500" />
                    )}
                  </div>
                  <div className={`px-2 py-1 rounded-md font-bold text-xs ${
                    isPositive 
                      ? 'bg-green-500/20 text-green-400' 
                      : 'bg-red-500/20 text-red-400'
                  }`}>
                    {isPositive ? '+' : ''}{crypto.change.toFixed(2)}%
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-white font-bold text-sm">
                      ${formatPrice(crypto.price)}
                    </div>
                    <div className="text-xs text-slate-400">
                      Vol: {formatVolume(crypto.volume)}
                    </div>
                  </div>
                </div>
              </div>

              {/* Desktop Layout */}
              <div className="hidden md:flex items-center justify-between p-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-white font-semibold text-lg">{symbol}</span>
                    <span className="text-slate-400">/ USDT</span>
                    {isPositive ? (
                      <TrendingUp className="w-4 h-4 text-amber-500" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-amber-500" />
                    )}
                  </div>
                  <div className="text-sm text-slate-400">
                    {formatVolume(crypto.volume)} USDT
                  </div>
                </div>
                
                <div className="flex-1 text-right">
                  <div className="text-white font-semibold text-lg">
                    {formatPrice(crypto.price)}
                  </div>
                  <div className="text-sm text-slate-400">
                    {formatPrice(crypto.price)} USD
                  </div>
                </div>
                
                <div className="flex-1 flex justify-end">
                  <div className={`px-3 py-1 rounded-md font-semibold text-sm ${
                    isPositive 
                      ? 'bg-green-500/20 text-green-400' 
                      : 'bg-red-500/20 text-red-400'
                  }`}>
                    {isPositive ? '+' : ''}{crypto.change.toFixed(2)}%
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const formatPrice = (price: number): string => {
  if (price >= 1000) {
    return price.toLocaleString(undefined, { 
      minimumFractionDigits: 1,
      maximumFractionDigits: 1
    });
  } else if (price >= 1) {
    return price.toLocaleString(undefined, { 
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  } else {
    return price.toLocaleString(undefined, { 
      minimumFractionDigits: 4,
      maximumFractionDigits: 6
    });
  }
};

const formatVolume = (volume: string): string => {
  const num = parseFloat(volume);
  if (num >= 1000000000) {
    return (num / 1000000000).toFixed(2) + 'B';
  } else if (num >= 1000000) {
    return (num / 1000000).toFixed(0) + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(0) + 'K';
  }
  return volume;
};

export default TradingPairsDisplay;