
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";


interface AuthModalProps {
  onClose: () => void;
}

const AuthModal = ({ onClose }: AuthModalProps) => {
  const navigate = useNavigate();
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [registerForm, setRegisterForm] = useState({ 
    email: "", 
    phone: "",
    password: "", 
    confirmPassword: "",
    referralCode: "",
    loginMethod: "email",
    otp: ""
  });
  const [loading, setLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpLoading, setOtpLoading] = useState(false);
  const [canResend, setCanResend] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const { signIn, sendOtp, verifyOtp, resendOtp, signUp } = useAuth();
  const { toast } = useToast();

  const handleBackHome = () => {
    navigate('/');
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      await signIn(loginForm.email, loginForm.password);
    } catch (error: any) {
      // Error is already handled in the signIn function
    } finally {
      setLoading(false);
    }
  };

  const handleSendOtp = async () => {
    if (!registerForm.email || !registerForm.password || !registerForm.referralCode.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in email, password, and referral code first",
        variant: "destructive",
      });
      return;
    }

    if (registerForm.password !== registerForm.confirmPassword) {
      toast({
        title: "Password Mismatch",
        description: "Passwords do not match",
        variant: "destructive",
      });
      return;
    }

    setOtpLoading(true);
    try {
      const username = registerForm.email.split('@')[0];
      await sendOtp(registerForm.email, registerForm.password, username, registerForm.referralCode.trim());
      setOtpSent(true);
      setCanResend(false);
      
      // Start resend timer
      let timer = 60;
      setResendTimer(timer);
      const interval = setInterval(() => {
        timer--;
        setResendTimer(timer);
        if (timer <= 0) {
          clearInterval(interval);
          setCanResend(true);
        }
      }, 1000);
    } catch (error: any) {
      // Error handled in sendOtp
    } finally {
      setOtpLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (registerForm.loginMethod === "email") {
      // Email registration with OTP
      if (!otpSent) {
        await handleSendOtp();
        return;
      }

      // Verify OTP
      if (!registerForm.otp || registerForm.otp.length !== 6) {
        toast({
          title: "Invalid OTP",
          description: "Please enter the 6-digit verification code",
          variant: "destructive",
        });
        return;
      }

      setLoading(true);
      try {
        await verifyOtp(registerForm.email, registerForm.otp);
        // Account is created and verified at this point
      } catch (error: any) {
        // Error handled in verifyOtp
      } finally {
        setLoading(false);
      }
    } else {
      // Phone registration (direct)
      if (registerForm.password !== registerForm.confirmPassword) {
        toast({
          title: "Registration Failed",
          description: "Passwords do not match",
          variant: "destructive",
        });
        return;
      }
      
      if (!registerForm.referralCode.trim()) {
        toast({
          title: "Registration Failed",
          description: "Referral code is required for registration",
          variant: "destructive",
        });
        return;
      }

      setLoading(true);
      try {
        await signUp(
          registerForm.phone, 
          registerForm.password, 
          registerForm.referralCode.trim()
        );
      } catch (error: any) {
        // Error handled in signUp
      } finally {
        setLoading(false);
      }
    }
  };

  const handleResendOtp = async () => {
    if (!registerForm.email) return;
    
    setOtpLoading(true);
    try {
      await resendOtp(registerForm.email);
      setCanResend(false);
      
      // Restart timer
      let timer = 60;
      setResendTimer(timer);
      const interval = setInterval(() => {
        timer--;
        setResendTimer(timer);
        if (timer <= 0) {
          clearInterval(interval);
          setCanResend(true);
        }
      }, 1000);
    } catch (error: any) {
      // Error handled in resendOtp
    } finally {
      setOtpLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4 w-full overflow-x-hidden">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div 
            onClick={handleBackHome}
            className="cursor-pointer hover:opacity-80 transition-opacity"
          >
            <h1 className="text-4xl font-bold text-white mb-2">3BEET EXCHANGE</h1>
            <p className="text-slate-300">Professional Trading Platform</p>
          </div>
          <Badge variant="secondary" className="mt-2">Invite Only</Badge>
        </div>

        <Card className="backdrop-blur-sm bg-white/10 border-white/20">
          <CardHeader>
            <CardTitle className="text-white">Access Platform</CardTitle>
            <CardDescription className="text-slate-300">
              Login to your account or register with a referral code
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <Button 
                variant="outline" 
                onClick={handleBackHome}
                className="w-full bg-white/20 text-white border-white/40 hover:bg-white/30 hover:border-white/60 font-semibold py-3"
              >
                ← Back to Homepage
              </Button>
            </div>
            
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-white">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={loginForm.email}
                      onChange={(e) => setLoginForm({...loginForm, email: e.target.value})}
                      className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
                      placeholder="Enter your email"
                      required
                      disabled={loading}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-white">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      value={loginForm.password}
                      onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                      className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
                      placeholder="Enter your password"
                      required
                      disabled={loading}
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    disabled={loading}
                  >
                    {loading ? "Signing In..." : "Login"}
                  </Button>
                </form>
              </TabsContent>
              
              <TabsContent value="register">
                <form onSubmit={handleRegister} className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-white">Registration Method</Label>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant={registerForm.loginMethod === "email" ? "default" : "outline"}
                        onClick={() => setRegisterForm({...registerForm, loginMethod: "email"})}
                        className="flex-1"
                        disabled={loading}
                      >
                        Email
                      </Button>
                      <Button
                        type="button"
                        variant={registerForm.loginMethod === "phone" ? "default" : "outline"}
                        onClick={() => setRegisterForm({...registerForm, loginMethod: "phone"})}
                        className="flex-1"
                        disabled={loading}
                      >
                        Phone
                      </Button>
                    </div>
                  </div>

                  {registerForm.loginMethod === "email" ? (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="reg-email" className="text-white">Email</Label>
                        <div className="flex gap-2">
                          <Input
                            id="reg-email"
                            type="email"
                            value={registerForm.email}
                            onChange={(e) => setRegisterForm({...registerForm, email: e.target.value})}
                            className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 flex-1"
                            placeholder="Enter your email"
                            required
                            disabled={loading || otpSent}
                          />
                          {!otpSent && (
                            <Button
                              type="button"
                              onClick={handleSendOtp}
                              disabled={!registerForm.email || !registerForm.password || !registerForm.referralCode || otpLoading}
                              className="bg-blue-600 hover:bg-blue-700 whitespace-nowrap"
                              size="sm"
                            >
                              {otpLoading ? "Sending..." : "Send OTP"}
                            </Button>
                          )}
                        </div>
                      </div>
                      
                      {otpSent && (
                        <div className="space-y-2">
                          <Label htmlFor="reg-otp" className="text-white">Verification Code</Label>
                          <Input
                            id="reg-otp"
                            type="text"
                            maxLength={6}
                            value={registerForm.otp}
                            onChange={(e) => setRegisterForm({...registerForm, otp: e.target.value})}
                            className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
                            placeholder="Enter 6-digit code"
                            required
                          />
                          <div className="space-y-2">
                            <p className="text-xs text-green-400">
                              OTP sent to {registerForm.email}. Please check your email.
                            </p>
                            <div className="flex items-center justify-between">
                               <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={handleResendOtp}
                                disabled={!canResend || otpLoading}
                                className="text-blue-400 hover:text-blue-300 p-0 h-auto"
                              >
                                {!canResend && resendTimer > 0 
                                  ? `Resend in ${resendTimer}s`
                                  : otpLoading 
                                    ? "Sending..."
                                    : "Resend OTP"
                                }
                              </Button>
                            </div>
                          </div>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="space-y-2">
                      <Label htmlFor="reg-phone" className="text-white">Phone Number</Label>
                      <Input
                        id="reg-phone"
                        type="tel"
                        value={registerForm.phone}
                        onChange={(e) => setRegisterForm({...registerForm, phone: e.target.value})}
                        className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
                        placeholder="Enter your phone number"
                        required
                        disabled={loading}
                      />
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="reg-password" className="text-white">Password</Label>
                    <Input
                      id="reg-password"
                      type="password"
                      value={registerForm.password}
                      onChange={(e) => setRegisterForm({...registerForm, password: e.target.value})}
                      className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
                      placeholder="Create a password"
                      required
                      disabled={loading}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password" className="text-white">Confirm Password</Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      value={registerForm.confirmPassword}
                      onChange={(e) => setRegisterForm({...registerForm, confirmPassword: e.target.value})}
                      className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
                      placeholder="Confirm your password"
                      required
                      disabled={loading}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="referral" className="text-white">Referral Code *</Label>
                    <Input
                      id="referral"
                      type="text"
                      value={registerForm.referralCode}
                      onChange={(e) => setRegisterForm({...registerForm, referralCode: e.target.value})}
                      className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
                      placeholder="Enter referral code (required)"
                      required
                      disabled={loading}
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-green-600 hover:bg-green-700"
                    disabled={loading || (registerForm.loginMethod === "email" && otpSent && (!registerForm.otp || registerForm.otp.length !== 6))}
                  >
                    {loading ? "Creating Account..." : 
                     registerForm.loginMethod === "email" && !otpSent ? "Send Verification Code" :
                     registerForm.loginMethod === "email" && otpSent ? "Verify & Register" :
                     "Register"}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AuthModal;
