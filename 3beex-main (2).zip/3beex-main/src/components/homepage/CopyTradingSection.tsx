import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, Activity } from "lucide-react";

interface CopyTradingSectionProps {
  onShowAuth: () => void;
}

const CopyTradingSection = ({ onShowAuth }: CopyTradingSectionProps) => {
  return (
    <div className="px-4 py-4">
      <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
        <Card className="bg-white/10 border-white/20 p-4 hover:bg-white/15 transition-colors cursor-pointer" onClick={onShowAuth}>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <h3 className="text-white font-semibold text-sm">Copy Trading</h3>
              <p className="text-slate-400 text-xs">Copy Trading</p>
            </div>
          </div>
        </Card>

        <Card className="bg-white/10 border-white/20 p-4 hover:bg-white/15 transition-colors cursor-pointer" onClick={onShowAuth}>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-green-500/20 flex items-center justify-center">
              <Activity className="w-6 h-6 text-green-400" />
            </div>
            <div>
              <h3 className="text-white font-semibold text-sm">Activity</h3>
              <p className="text-slate-400 text-xs">Activity</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default CopyTradingSection;