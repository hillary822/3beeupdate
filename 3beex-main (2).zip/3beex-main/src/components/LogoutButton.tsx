import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";

interface LogoutButtonProps {
  className?: string;
  variant?: "default" | "ghost" | "outline";
  size?: "default" | "sm" | "lg" | "icon";
}

const LogoutButton = ({ 
  className = "", 
  variant = "ghost",
  size = "icon"
}: LogoutButtonProps) => {
  // This is a hard logout - completely bypassing any React state
  const handleHardLogout = () => {
    try {
      // 1. Clear all localStorage items
      localStorage.clear();
      
      // 2. Clear all sessionStorage items
      sessionStorage.clear();
      
      // 3. Force a page reload to the homepage
      window.location.href = '/';
    } catch (error) {
      console.error('Hard logout failed:', error);
      // Still force the redirect
      window.location.href = '/';
    }
  };

  return (
    <Button 
      variant={variant}
      size={size}
      onClick={handleHardLogout} 
      className={`${className}`}
    >
      <LogOut size={18} />
    </Button>
  );
};

export default LogoutButton;