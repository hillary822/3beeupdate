import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const LanguageTranslator = () => {
  const [currentLanguage, setCurrentLanguage] = useState("en");
  const [isTranslating, setIsTranslating] = useState(false);
  const [currentTranslations, setCurrentTranslations] = useState<Record<string, string>>({});
  const { toast } = useToast();

  const languages = [
    { code: "en", name: "English", flag: "🇺🇸" },
    { code: "es", name: "Español", flag: "🇪🇸" },
  ];

  useEffect(() => {
    // Load saved language preference
    const savedLanguage = localStorage.getItem('preferred-language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  // Monitor for dynamic content changes and re-translate
  useEffect(() => {
    if (currentLanguage === 'en' || Object.keys(currentTranslations).length === 0) return;

    const observer = new MutationObserver((mutations) => {
      let shouldRetranslate = false;
      
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              shouldRetranslate = true;
            }
          });
        }
      });

      if (shouldRetranslate) {
        console.log('Dynamic content detected, re-applying translations...');
        setTimeout(() => applyTranslations(currentTranslations), 100);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    return () => observer.disconnect();
  }, [currentLanguage, currentTranslations]);

  const translatePageContent = async (targetLanguage: string) => {
    if (targetLanguage === 'en') {
      // Restore original English content
      window.location.reload();
      return;
    }

    setIsTranslating(true);
    try {
      console.log(`Requesting translation to ${targetLanguage}`);
      
      // Call our translation edge function
      const { data, error } = await supabase.functions.invoke('translate-page', {
        body: {
          targetLanguage
        }
      });

      console.log('Full translation response:', { data, error });

      if (error) {
        console.error('Translation error:', error);
        throw error;
      }

      console.log('Translation response:', data);

      // Apply translations to the page and store them
      if (data?.success && data?.translations) {
        setCurrentTranslations(data.translations);
        applyTranslations(data.translations);
      } else {
        throw new Error('Invalid translation response');
      }

      toast({
        title: "Translation Complete",
        description: `Page translated to ${languages.find(l => l.code === targetLanguage)?.name}`,
      });
    } catch (error) {
      console.error('Translation error:', error);
      toast({
        title: "Translation Failed",
        description: "Unable to translate page. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsTranslating(false);
    }
  };

  const applyTranslations = (translations: Record<string, string>) => {
    console.log('🔄 Starting translation process...');
    console.log('📝 Available translations:', Object.keys(translations).length);
    
    // Count elements that will be translated
    let translatedCount = 0;
    
    // Function to recursively translate text nodes
    const translateTextNodes = (node: Node) => {
      if (node.nodeType === Node.TEXT_NODE) {
        const text = node.textContent?.trim();
        if (text && translations[text]) {
          console.log(`✅ Translating text node "${text}" → "${translations[text]}"`);
          node.textContent = translations[text];
          translatedCount++;
        }
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        const element = node as Element;
        
        // Skip script and style elements
        if (element.tagName === 'SCRIPT' || element.tagName === 'STYLE') {
          return;
        }
        
        // Handle direct text content for leaf elements
        if (element.children.length === 0) {
          const text = element.textContent?.trim();
          if (text && translations[text]) {
            console.log(`Translating leaf element "${text}" to "${translations[text]}"`);
            element.textContent = translations[text];
            return;
          }
        }
        
        // Recursively process child nodes
        Array.from(node.childNodes).forEach(translateTextNodes);
      }
    };

    // Start translation from document body
    console.log('Starting comprehensive text translation...');
    translateTextNodes(document.body);

    // Handle input placeholders
    const inputElements = document.querySelectorAll('input[placeholder], textarea[placeholder]');
    console.log(`Found ${inputElements.length} input elements with placeholders`);
    
    inputElements.forEach((element, index) => {
      const placeholder = element.getAttribute('placeholder');
      if (placeholder && translations[placeholder]) {
        console.log(`Translating placeholder "${placeholder}" to "${translations[placeholder]}" (input ${index + 1})`);
        element.setAttribute('placeholder', translations[placeholder]);
      }
    });

    // Handle aria-labels and titles for accessibility
    const elementsWithLabels = document.querySelectorAll('[aria-label], [title]');
    elementsWithLabels.forEach((element) => {
      const ariaLabel = element.getAttribute('aria-label');
      const title = element.getAttribute('title');
      
      if (ariaLabel && translations[ariaLabel]) {
        element.setAttribute('aria-label', translations[ariaLabel]);
      }
      
      if (title && translations[title]) {
        element.setAttribute('title', translations[title]);
      }
    });

    // Set language attribute for CSS targeting
    document.documentElement.setAttribute('data-language', currentLanguage);
    
    // Add click listeners to tab elements to re-translate when tabs change
    const tabElements = document.querySelectorAll('[role="tab"], [data-state], .tab-trigger, button[aria-selected]');
    tabElements.forEach(tab => {
      if (!tab.hasAttribute('data-translation-listener')) {
        tab.setAttribute('data-translation-listener', 'true');
        tab.addEventListener('click', () => {
          setTimeout(() => {
            console.log('Tab clicked, re-applying translations...');
            applyTranslations(currentTranslations);
          }, 200); // Small delay to let tab content render
        });
      }
    });
    
    console.log(`📊 Translation completed: ${translatedCount} elements translated`);
  };

  const handleLanguageChange = (languageCode: string) => {
    setCurrentLanguage(languageCode);
    
    const selectedLang = languages.find(lang => lang.code === languageCode);
    if (selectedLang) {
      // Store preference in localStorage
      localStorage.setItem('preferred-language', languageCode);
      
      // Translate the page content
      translatePageContent(languageCode);
      
      console.log(`Language changed to: ${selectedLang.name}`);
    }
  };

  const currentLang = languages.find(lang => lang.code === currentLanguage);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="h-10 w-10 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-600 text-lg"
          disabled={isTranslating}
        >
          {isTranslating ? "🔄" : "🌐"}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48 bg-slate-800 border-slate-700">
        {languages.map((language) => (
          <DropdownMenuItem
            key={language.code}
            onClick={() => handleLanguageChange(language.code)}
            className={`cursor-pointer text-white hover:bg-slate-700 ${
              currentLanguage === language.code ? "bg-slate-700" : ""
            }`}
            disabled={isTranslating}
          >
            <span className="mr-2">{language.flag}</span>
            {language.name}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default LanguageTranslator;