
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useTrading } from '@/hooks/useTrading';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

interface TradingFormProps {
  pair: string;
  currentPrice: number;
  type: 'spot' | 'perpetual';
  leverage?: number;
  onTradeCompleted?: () => Promise<void>;
}

const TradingForm = ({ pair, currentPrice, type, leverage = 1, onTradeCompleted }: TradingFormProps) => {
  const [code, setCode] = useState('');
  const { useTradeCode, loading } = useTrading();
  const { profile } = useAuth();
  const { toast } = useToast();

  const tradeBalance = Number(profile?.trade_balance) || 0;
  const hasInsufficientBalance = tradeBalance <= 0;

  const handleTradeCodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (hasInsufficientBalance) {
      toast({
        title: "Insufficient Trade Balance",
        description: "Please transfer funds to your Trade account before trading",
        variant: "destructive",
      });
      return;
    }

    if (!code.trim()) {
      toast({
        title: "Code Required",
        description: "Please enter a valid trade code",
        variant: "destructive",
      });
      return;
    }

    const result = await useTradeCode(code);
    if (result && onTradeCompleted) {
      await onTradeCompleted();
    }
    setCode('');
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center justify-between">
          <span>{type === 'perpetual' ? 'Perpetual Trading' : 'Spot Trading'}</span>
          {type === 'perpetual' && leverage && (
            <Badge variant="outline" className="text-yellow-400 border-yellow-400">
              {leverage}x
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {hasInsufficientBalance && (
          <div className="bg-red-900/20 border border-red-600/30 rounded-lg p-3">
            <p className="text-red-400 text-sm">
              Insufficient Trade balance. Please transfer funds to your Trade account to start trading.
            </p>
          </div>
        )}

        <div className="text-sm text-slate-400">
          Trade Balance: <span className="text-green-400">${tradeBalance.toFixed(2)}</span>
        </div>

        <form onSubmit={handleTradeCodeSubmit} className="space-y-4">
          <div>
            <Label htmlFor="trade-code" className="text-slate-300">Trade Code</Label>
            <Input
              id="trade-code"
              type="text"
              placeholder="Enter trade code..."
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white"
              disabled={loading || hasInsufficientBalance}
            />
          </div>
          <Button 
            type="submit" 
            className="w-full bg-gradient-primary hover:shadow-glow"
            disabled={loading || hasInsufficientBalance}
          >
            {loading ? 'Processing...' : 'Use Trade Code'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default TradingForm;
