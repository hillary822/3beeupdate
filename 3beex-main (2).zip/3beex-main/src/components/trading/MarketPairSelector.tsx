
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { TrendingUp, TrendingDown } from "lucide-react";
import { fetchCryptoPrices } from "@/services/cryptoService";

interface MarketPair {
  symbol: string;
  price: number;
  change: number;
  volume: string;
}

interface MarketPairSelectorProps {
  selectedPair: string;
  onPairSelect: (pair: string) => void;
  onPriceUpdate: (price: number) => void;
  type?: "spot" | "perpetual";
}

const MarketPairSelector = ({ selectedPair, onPairSelect, onPriceUpdate, type = "spot" }: MarketPairSelectorProps) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [marketData, setMarketData] = useState<MarketPair[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const filteredPairs = marketData.filter(pair => 
    pair.symbol.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Fetch initial prices
  useEffect(() => {
    const loadInitialPrices = async () => {
      setIsLoading(true);
      const prices = await fetchCryptoPrices();
      setMarketData(prices);
      setIsLoading(false);
    };

    loadInitialPrices();
  }, []);

  // Update prices periodically
  useEffect(() => {
    const interval = setInterval(async () => {
      const prices = await fetchCryptoPrices();
      setMarketData(prices);
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  // Update selected pair price
  useEffect(() => {
    const selectedPairData = marketData.find(pair => pair.symbol === selectedPair);
    if (selectedPairData) {
      onPriceUpdate(selectedPairData.price);
    }
  }, [marketData, selectedPair, onPriceUpdate]);

  return (
    <div className="bg-slate-800 rounded-lg p-2 md:p-4 h-full">
      <div className="mb-4">
        <h3 className="text-base md:text-lg font-semibold mb-2">
          {type === "perpetual" ? "Perpetual Futures" : "Spot Markets"}
        </h3>
        <Input
          placeholder="Search pairs..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="bg-slate-700 border-slate-600 text-sm"
        />
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-32">
          <div className="text-slate-400 text-sm">Loading market data...</div>
        </div>
      ) : (
        <div className="space-y-1 max-h-[60vh] lg:max-h-[calc(100vh-300px)] overflow-y-auto">
          {filteredPairs.map((pair) => (
            <div
              key={pair.symbol}
              onClick={() => onPairSelect(pair.symbol)}
              className={`p-2 md:p-3 rounded cursor-pointer transition-colors ${
                selectedPair === pair.symbol 
                  ? "bg-blue-600" 
                  : "hover:bg-slate-700"
              }`}
            >
              <div className="flex justify-between items-start mb-1">
                <span className="font-medium text-sm md:text-base">{pair.symbol}</span>
                <div className={`flex items-center gap-1 text-xs md:text-sm ${
                  pair.change >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                  {pair.change >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {pair.change.toFixed(2)}%
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs md:text-sm text-white">${pair.price.toLocaleString()}</span>
                <span className="text-xs text-slate-400">{pair.volume}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MarketPairSelector;
