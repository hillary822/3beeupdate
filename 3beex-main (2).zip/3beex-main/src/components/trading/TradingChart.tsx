
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import { useState, useEffect } from "react";

interface TradingChartProps {
  pair: string;
  currentPrice: number;
}

const TradingChart = ({ pair, currentPrice }: TradingChartProps) => {
  const [chartData, setChartData] = useState<any[]>([]);
  const [timeframe, setTimeframe] = useState("1H");

  // Generate initial chart data
  useEffect(() => {
    const generateData = () => {
      const data = [];
      const basePrice = currentPrice;
      
      for (let i = 100; i >= 0; i--) {
        const variance = (Math.random() - 0.5) * (basePrice * 0.05);
        data.push({
          time: new Date(Date.now() - i * 60000).toLocaleTimeString(),
          price: basePrice + variance,
          volume: Math.random() * 1000000
        });
      }
      return data;
    };

    setChartData(generateData());
  }, [pair]);

  // Update chart with new price data
  useEffect(() => {
    if (chartData.length > 0) {
      setChartData(prev => [
        ...prev.slice(1),
        {
          time: new Date().toLocaleTimeString(),
          price: currentPrice,
          volume: Math.random() * 1000000
        }
      ]);
    }
  }, [currentPrice]);

  return (
    <div className="bg-slate-800 rounded-lg p-2 md:p-4 h-full">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-base md:text-lg font-semibold">{pair}</h3>
        
        <div className="flex gap-1 md:gap-2">
          {["1M", "5M", "15M", "1H", "4H", "1D"].map(tf => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-2 md:px-3 py-1 text-xs rounded ${
                timeframe === tf 
                  ? "bg-blue-600 text-white" 
                  : "bg-slate-700 text-slate-300 hover:bg-slate-600"
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      <div className="h-[300px] md:h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData}>
            <XAxis 
              dataKey="time" 
              axisLine={false}
              tickLine={false}
              tick={{ fill: '#94a3b8', fontSize: 10 }}
              interval="preserveStartEnd"
            />
            <YAxis 
              domain={['dataMin - 100', 'dataMax + 100']}
              axisLine={false}
              tickLine={false}
              tick={{ fill: '#94a3b8', fontSize: 10 }}
              width={60}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1e293b', 
                border: '1px solid #475569',
                borderRadius: '8px',
                fontSize: '12px'
              }}
            />
            <Line 
              type="monotone" 
              dataKey="price" 
              stroke="#10b981" 
              strokeWidth={2}
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default TradingChart;
