
import { useState, useEffect } from "react";

interface OrderBookProps {
  currentPrice: number;
}

interface OrderBookEntry {
  price: number;
  size: number;
  total: number;
}

const OrderBook = ({ currentPrice }: OrderBookProps) => {
  const [bids, setBids] = useState<OrderBookEntry[]>([]);
  const [asks, setAsks] = useState<OrderBookEntry[]>([]);

  useEffect(() => {
    const generateOrderBook = () => {
      const newBids: OrderBookEntry[] = [];
      const newAsks: OrderBookEntry[] = [];

      // Generate bids (buy orders) below current price
      for (let i = 0; i < 10; i++) {
        const price = currentPrice - (i + 1) * (Math.random() * 50 + 10);
        const size = Math.random() * 5 + 0.1;
        newBids.push({
          price,
          size,
          total: newBids.reduce((sum, bid) => sum + bid.size, 0) + size
        });
      }

      // Generate asks (sell orders) above current price
      for (let i = 0; i < 10; i++) {
        const price = currentPrice + (i + 1) * (Math.random() * 50 + 10);
        const size = Math.random() * 5 + 0.1;
        newAsks.push({
          price,
          size,
          total: size
        });
      }

      // Calculate cumulative totals for asks
      for (let i = 1; i < newAsks.length; i++) {
        newAsks[i].total = newAsks[i-1].total + newAsks[i].size;
      }

      setBids(newBids);
      setAsks(newAsks.reverse()); // Reverse to show highest price first
    };

    generateOrderBook();
    const interval = setInterval(generateOrderBook, 5000);
    return () => clearInterval(interval);
  }, [currentPrice]);

  return (
    <div className="bg-slate-800 rounded-lg p-2 md:p-4">
      <h3 className="text-base md:text-lg font-semibold mb-4">Order Book</h3>
      
      <div className="text-xs text-slate-400 grid grid-cols-3 gap-2 mb-2">
        <span>Price</span>
        <span className="text-right">Size</span>
        <span className="text-right">Total</span>
      </div>

      {/* Asks (Sell Orders) */}
      <div className="space-y-1 mb-3">
        {asks.slice(0, 6).map((ask, index) => (
          <div key={index} className="grid grid-cols-3 gap-2 text-xs relative">
            <div 
              className="absolute inset-0 bg-red-500/10"
              style={{ width: `${(ask.total / Math.max(...asks.map(a => a.total))) * 100}%` }}
            />
            <span className="text-red-400 relative z-10">{ask.price.toFixed(2)}</span>
            <span className="text-right relative z-10">{ask.size.toFixed(4)}</span>
            <span className="text-right text-slate-400 relative z-10">{ask.total.toFixed(4)}</span>
          </div>
        ))}
      </div>

      {/* Current Price */}
      <div className="bg-slate-700 rounded p-2 mb-3 text-center">
        <span className="text-green-400 font-mono text-xs md:text-sm">
          ${currentPrice.toFixed(2)}
        </span>
      </div>

      {/* Bids (Buy Orders) */}
      <div className="space-y-1">
        {bids.slice(0, 6).map((bid, index) => (
          <div key={index} className="grid grid-cols-3 gap-2 text-xs relative">
            <div 
              className="absolute inset-0 bg-green-500/10"
              style={{ width: `${(bid.total / Math.max(...bids.map(b => b.total))) * 100}%` }}
            />
            <span className="text-green-400 relative z-10">{bid.price.toFixed(2)}</span>
            <span className="text-right relative z-10">{bid.size.toFixed(4)}</span>
            <span className="text-right text-slate-400 relative z-10">{bid.total.toFixed(4)}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OrderBook;
