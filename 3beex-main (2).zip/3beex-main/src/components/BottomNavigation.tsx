
import { Home, TrendingUp, PlusCircle, MinusCircle, Users, Settings, BarChart3, User } from "lucide-react";

interface TabConfig {
  id: string;
  label: string;
  icon: any;
}

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  tabs?: TabConfig[];
}

const BottomNavigation = ({ activeTab, onTabChange, tabs }: BottomNavigationProps) => {
  console.log("BottomNavigation rendering with activeTab:", activeTab);
  
  const defaultTabs = [
    { id: "assets", label: "Assets", icon: Home },
    { id: "trades", label: "Trades", icon: TrendingUp },
    { id: "deposits", label: "Deposit", icon: PlusCircle },
    { id: "withdrawals", label: "Withdraw", icon: MinusCircle },
    { id: "referrals", label: "Referrals", icon: Users },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  const tabsToShow = tabs || defaultTabs;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-slate-800 border-t border-slate-700 w-full h-16 z-50 safe-area-inset">
      <div className="flex w-full h-16 overflow-hidden">
        {tabsToShow.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex-1 flex flex-col items-center justify-center py-2 px-1 transition-colors min-w-0 ${
                activeTab === tab.id
                  ? "text-primary bg-slate-700"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Icon size={18} className="flex-shrink-0" />
              <span className="text-xs mt-1 truncate w-full text-center">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNavigation;
