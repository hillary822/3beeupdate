
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";

interface OtpVerificationFormProps {
  email: string;
  onVerify: (otp: string) => Promise<void>;
  onResend: () => Promise<void>;
  loading?: boolean;
}

export const OtpVerificationForm = ({ 
  email, 
  onVerify, 
  onResend, 
  loading = false 
}: OtpVerificationFormProps) => {
  const [otp, setOtp] = useState('');
  const [resendTimer, setResendTimer] = useState(60);
  const [canResend, setCanResend] = useState(false);

  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => {
        setResendTimer(resendTimer - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [resendTimer]);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length === 6) {
      await onVerify(otp);
    }
  };

  const handleResend = async () => {
    await onResend();
    setResendTimer(60);
    setCanResend(false);
    setOtp('');
  };

  return (
    <form onSubmit={handleVerify} className="space-y-4">
      <div className="text-center space-y-2">
        <h3 className="text-lg font-semibold text-white">Verify Your Email</h3>
        <p className="text-slate-300 text-sm">
          We've sent a 6-digit verification code to:
        </p>
        <p className="text-white font-medium">{email}</p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="otp" className="text-white text-center block">
          Enter Verification Code
        </Label>
        <div className="flex justify-center">
          <InputOTP
            value={otp}
            onChange={setOtp}
            maxLength={6}
            disabled={loading}
          >
            <InputOTPGroup>
              <InputOTPSlot index={0} />
              <InputOTPSlot index={1} />
              <InputOTPSlot index={2} />
              <InputOTPSlot index={3} />
              <InputOTPSlot index={4} />
              <InputOTPSlot index={5} />
            </InputOTPGroup>
          </InputOTP>
        </div>
      </div>

      <Button 
        type="submit" 
        className="w-full"
        disabled={loading || otp.length !== 6}
      >
        {loading ? "Verifying..." : "Verify Account"}
      </Button>

      <div className="text-center space-y-2">
        <p className="text-slate-400 text-sm">
          Didn't receive the code?
        </p>
        <Button
          type="button"
          variant="ghost"
          onClick={handleResend}
          disabled={!canResend || loading}
          className="text-blue-400 hover:text-blue-300 p-0 h-auto"
        >
          {canResend ? "Resend Code" : `Resend in ${resendTimer}s`}
        </Button>
      </div>
    </form>
  );
};
