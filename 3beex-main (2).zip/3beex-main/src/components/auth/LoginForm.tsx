
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface LoginFormProps {
  onSubmit: (identifier: string, password: string, method: string) => void;
}

export const LoginForm = ({ onSubmit }: LoginFormProps) => {
  const [loginForm, setLoginForm] = useState({ email: "", password: "", phone: "" });
  const [loginMethod, setLoginMethod] = useState("email");

  const handleBackToHomepage = () => {
    window.location.href = '/';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const identifier = loginMethod === "email" ? loginForm.email : loginForm.phone;
    
    // Call the parent's onSubmit with the actual form data
    onSubmit(identifier, loginForm.password, loginMethod);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="mb-4">
        <Button 
          type="button"
          variant="outline" 
          onClick={handleBackToHomepage}
          className="w-full bg-white/20 text-white border-white/40 hover:bg-white/30 hover:border-white/60 font-semibold py-3"
        >
          ← Back to Homepage
        </Button>
      </div>
      
      <div className="space-y-2">
        <Label className="text-white">Login Method</Label>
        <div className="flex gap-2">
          <Button
            type="button"
            variant={loginMethod === "email" ? "default" : "outline"}
            onClick={() => setLoginMethod("email")}
            className="flex-1"
          >
            Email
          </Button>
          <Button
            type="button"
            variant={loginMethod === "phone" ? "default" : "outline"}
            onClick={() => setLoginMethod("phone")}
            className="flex-1"
          >
            Phone
          </Button>
        </div>
      </div>

      {loginMethod === "email" ? (
        <div className="space-y-2">
          <Label htmlFor="email" className="text-white">Email</Label>
          <Input
            id="email"
            type="email"
            value={loginForm.email}
            onChange={(e) => setLoginForm({...loginForm, email: e.target.value})}
            className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
            placeholder="Enter your email"
            required
          />
        </div>
      ) : (
        <div className="space-y-2">
          <Label htmlFor="phone" className="text-white">Phone Number</Label>
          <Input
            id="phone"
            type="tel"
            value={loginForm.phone}
            onChange={(e) => setLoginForm({...loginForm, phone: e.target.value})}
            className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
            placeholder="Enter your phone number"
            required
          />
        </div>
      )}
      
      <div className="space-y-2">
        <Label htmlFor="password" className="text-white">Password</Label>
        <Input
          id="password"
          type="password"
          value={loginForm.password}
          onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
          className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
          placeholder="Enter your password"
          required
        />
      </div>
      <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
        Login
      </Button>
    </form>
  );
};
