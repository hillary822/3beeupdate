
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { countries } from "@/utils/countryData";

interface RegisterFormData {
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
  referralCode: string;
  loginMethod: string;
  countryCode?: string;
  otp?: string;
}

interface RegisterFormProps {
  registerForm: RegisterFormData;
  setRegisterForm: (form: RegisterFormData) => void;
  onSubmit: (e: React.FormEvent) => void;
  isValidatingReferral: boolean;
  onSendOtp?: () => Promise<void>;
  otpSent?: boolean;
  otpLoading?: boolean;
  onResendOtp?: () => Promise<void>;
  canResend?: boolean;
  resendTimer?: number;
}

export const RegisterForm = ({ 
  registerForm, 
  setRegisterForm, 
  onSubmit, 
  isValidatingReferral,
  onSendOtp,
  otpSent = false,
  otpLoading = false,
  onResendOtp,
  canResend = false,
  resendTimer = 0
}: RegisterFormProps) => {
  const [searchCountry, setSearchCountry] = useState("");

  const filteredCountries = countries.filter(country =>
    country.name.toLowerCase().includes(searchCountry.toLowerCase()) ||
    country.fullName.toLowerCase().includes(searchCountry.toLowerCase()) ||
    country.code.includes(searchCountry)
  );
  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label className="text-white">Registration Method</Label>
        <div className="flex gap-2">
          <Button
            type="button"
            variant={registerForm.loginMethod === "email" ? "default" : "outline"}
            onClick={() => setRegisterForm({...registerForm, loginMethod: "email"})}
            className="flex-1"
          >
            Email
          </Button>
          <Button
            type="button"
            variant={registerForm.loginMethod === "phone" ? "default" : "outline"}
            onClick={() => setRegisterForm({...registerForm, loginMethod: "phone"})}
            className="flex-1"
          >
            Phone
          </Button>
        </div>
      </div>

      {registerForm.loginMethod === "email" ? (
        <>
          <div className="space-y-2">
            <Label htmlFor="reg-email" className="text-white">Email</Label>
            <div className="flex gap-2">
              <Input
                id="reg-email"
                type="email"
                value={registerForm.email}
                onChange={(e) => setRegisterForm({...registerForm, email: e.target.value})}
                className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 flex-1"
                placeholder="Enter your email"
                required
              />
              {onSendOtp && (
                <Button
                  type="button"
                  onClick={onSendOtp}
                  disabled={!registerForm.email || otpLoading || otpSent}
                  className="bg-blue-600 hover:bg-blue-700 whitespace-nowrap"
                  size="sm"
                >
                  {otpLoading ? "Sending..." : otpSent ? "OTP Sent" : "Send OTP"}
                </Button>
              )}
            </div>
          </div>
          
          {onSendOtp && (
            <div className="space-y-2">
              <Label htmlFor="reg-otp" className="text-white">Verification Code</Label>
              <Input
                id="reg-otp"
                type="text"
                maxLength={6}
                value={registerForm.otp || ''}
                onChange={(e) => setRegisterForm({...registerForm, otp: e.target.value})}
                className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
                placeholder="Enter 6-digit code"
                required={otpSent}
                disabled={!otpSent}
              />
              {otpSent && (
                <div className="space-y-2">
                  <p className="text-xs text-green-400">
                    OTP sent to {registerForm.email}. Please check your email.
                  </p>
                  {onResendOtp && (
                    <div className="flex items-center justify-between">
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={onResendOtp}
                        disabled={!canResend || otpLoading}
                        className="text-blue-400 hover:text-blue-300 p-0 h-auto"
                      >
                        {!canResend && resendTimer > 0 
                          ? `Resend in ${resendTimer}s`
                          : otpLoading 
                            ? "Sending..."
                            : "Resend OTP"
                        }
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </>
      ) : (
        <div className="space-y-2">
          <Label htmlFor="reg-phone" className="text-white">Phone Number</Label>
          <div className="flex gap-2">
            <div className="w-24">
              <Select
                value={registerForm.countryCode || "+1"}
                onValueChange={(value) => setRegisterForm({...registerForm, countryCode: value})}
              >
                <SelectTrigger className="bg-white/10 border-white/20 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  <div className="p-2">
                    <Input
                      placeholder="Search country..."
                      value={searchCountry}
                      onChange={(e) => setSearchCountry(e.target.value)}
                      className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 mb-2"
                    />
                  </div>
                  {filteredCountries.map((country) => (
                    <SelectItem 
                      key={country.code} 
                      value={country.code}
                      className="text-white hover:bg-slate-700"
                    >
                      {country.name} {country.code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Input
              id="reg-phone"
              type="tel"
              value={registerForm.phone}
              onChange={(e) => setRegisterForm({...registerForm, phone: e.target.value})}
              className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 flex-1"
              placeholder="Enter your phone number"
              required
            />
          </div>
        </div>
      )}
      
      <div className="space-y-2">
        <Label htmlFor="reg-password" className="text-white">Password</Label>
        <Input
          id="reg-password"
          type="password"
          value={registerForm.password}
          onChange={(e) => setRegisterForm({...registerForm, password: e.target.value})}
          className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
          placeholder="Create a password"
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="confirm-password" className="text-white">Confirm Password</Label>
        <Input
          id="confirm-password"
          type="password"
          value={registerForm.confirmPassword}
          onChange={(e) => setRegisterForm({...registerForm, confirmPassword: e.target.value})}
          className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
          placeholder="Confirm your password"
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="referral" className="text-white">Referral Code *</Label>
        <Input
          id="referral"
          type="text"
          value={registerForm.referralCode}
          onChange={(e) => setRegisterForm({...registerForm, referralCode: e.target.value})}
          className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
          placeholder="Enter referral code"
          required
        />
      </div>
      
      <Button 
        type="submit" 
        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
        disabled={isValidatingReferral || (registerForm.loginMethod === "email" && onSendOtp && (!otpSent || !registerForm.otp || registerForm.otp.length !== 6))}
      >
        {isValidatingReferral ? "Validating..." : "Register"}
      </Button>
    </form>
  );
};
