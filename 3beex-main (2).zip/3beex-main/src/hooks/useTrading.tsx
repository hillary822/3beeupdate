
import { useState, useEffect } from 'react';
import { useAuth } from './useAuth';
import { useToast } from '@/hooks/use-toast';
import { TradeCodeResponse, CompleteTradeResponse } from '@/types/trading';
import {
  executeTrade,
  processTradeCode,
  completeTradeAfterDelay,
  processWithdrawal
} from '@/utils/tradingUtils';
import { supabase } from '@/integrations/supabase/client';

export const useTrading = () => {
  const { user, profile, refreshProfile } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  // Check for active trades that should be completed using the system function
  useEffect(() => {
    if (!user) return;

    const checkActiveTrades = async () => {
      try {
        // Use the system function to complete all overdue trades
        const { data: completeResult, error } = await supabase.rpc('complete_overdue_trades');

        if (error) {
          console.error('Error completing overdue trades:', error);
          return;
        }

        const result = completeResult as any;
        if (result?.completed_trades > 0) {
          console.log('Completed overdue trades:', result.completed_trades);
          toast({
            title: "Trades Completed",
            description: `${result.completed_trades} overdue trade(s) have been completed!`,
          });
          await refreshProfile();
        }

        // Also check for user's specific active trades for notifications
        const { data: activeTrades } = await supabase
          .from('trades')
          .select(`
            id,
            started_at,
            trade_code_id,
            trade_codes(duration_minutes)
          `)
          .eq('user_id', user.id)
          .eq('status', 'active');

        if (activeTrades && activeTrades.length > 0) {
          activeTrades.forEach((trade: any) => {
            const startTime = new Date(trade.started_at).getTime();
            const durationMs = (trade.trade_codes?.duration_minutes || 15) * 60 * 1000;
            const expectedCompletionTime = startTime + durationMs;
            const currentTime = Date.now();

            if (currentTime >= expectedCompletionTime) {
              console.log('Found overdue trade for current user:', trade.id);
            }
          });
        }
      } catch (error) {
        console.error('Error checking active trades:', error);
      }
    };

    // Check immediately and then every minute
    checkActiveTrades();
    const interval = setInterval(checkActiveTrades, 60000);

    return () => clearInterval(interval);
  }, [user, refreshProfile, toast]);

  const createTrade = async (type: 'BUY' | 'SELL', asset: string, amount: number) => {
    if (!user) return;
    
    setLoading(true);
    try {
      await executeTrade(user.id, type, asset, amount);

      toast({
        title: "Trade Executed",
        description: `${type} order for ${asset} has been placed successfully`,
      });

      await refreshProfile();
    } catch (error) {
      console.error('Error creating trade:', error);
      toast({
        title: "Trade Failed",
        description: "Unable to execute trade. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const useTradeCode = async (code: string) => {
    if (!user) {
      console.log('No user found');
      return null;
    }

    // Check if user is suspended
    if (profile?.suspended) {
      toast({
        title: "Account Suspended",
        description: "Your account has been suspended from trading. Please contact support.",
        variant: "destructive",
      });
      return null;
    }
    
    setLoading(true);
    try {
      // Check trade code details first
      const { data: tradeCodeData } = await supabase
        .from('trade_codes')
        .select('is_premium, minimum_balance')
        .eq('code', code)
        .eq('is_used', false)
        .single();

      if (tradeCodeData?.is_premium && !profile?.premium) {
        toast({
          title: "Extra Signal Code ⚠",
          description: "Extra signal code . Only inviters and newly invited members can use this code .",
          variant: "destructive",
        });
        return null;
      }

      // Check minimum balance requirement
      const userTradeBalance = profile?.trade_balance || 0;
      const requiredBalance = tradeCodeData?.minimum_balance || 0;
      
      if (userTradeBalance < requiredBalance) {
        toast({
          title: "Insufficient Balance",
          description: `You need at least $${requiredBalance.toFixed(2)} in your trade balance to use this code. Current balance: $${userTradeBalance.toFixed(2)}`,
          variant: "destructive",
        });
        return null;
      }

      const response = await processTradeCode(code, user.id);

      if (response && response.success) {
        // Refresh profile immediately to show deducted balance
        await refreshProfile();
        
        toast({
          title: "Copy Trading Successfully Started!",
          description: `${response.asset} trade started with $${(response.amount_invested || 100).toFixed(2)}. Duration: ${response.duration_minutes} minutes with ${response.profit_percentage}% profit target.`,
        });

        // Simulate trade completion after duration
        completeTradeAfterDelay(
          response.trade_id!,
          response.duration_minutes || 15,
          async (completeResponse: CompleteTradeResponse) => {
            if (completeResponse && completeResponse.success) {
              const profit = Number(completeResponse.profit) || 0;
              const totalReturn = Number(completeResponse.total_return) || (100 + profit);
              
              toast({
                title: "Trade Completed Successfully!",
                description: `Congratulations! You earned $${profit.toFixed(2)} profit. Total return: $${totalReturn.toFixed(2)}`,
              });
              await refreshProfile();
            }
          },
          (error) => {
            toast({
              title: "Trade Completion Error",
              description: "There was an issue completing your trade. Please contact support.",
              variant: "destructive",
            });
          }
        );

        return response;
      } else {
        console.log('Trade code response indicates failure:', response);
        toast({
          title: "Invalid Trade Code",
          description: response?.error || "This code is invalid or has already been used.",
          variant: "destructive",
        });
        return null;
      }
    } catch (error) {
      console.error('Error using trade code:', error);
      toast({
        title: "Trade Code Failed",
        description: "Unable to process trade code. Please try again.",
        variant: "destructive",
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const requestWithdrawal = async (amount: number, address: string) => {
    if (!user) return;
    
    setLoading(true);
    try {
      await processWithdrawal(user.id, amount, address);

      toast({
        title: "Withdrawal Requested",
        description: "Your withdrawal request has been submitted for review",
      });
    } catch (error) {
      console.error('Error requesting withdrawal:', error);
      toast({
        title: "Withdrawal Failed",
        description: "Unable to process withdrawal request. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return {
    createTrade,
    useTradeCode,
    requestWithdrawal,
    loading
  };
};
