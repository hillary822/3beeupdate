
import { useState, useEffect } from "react";
import { fetchCryptoPrices } from "@/services/cryptoService";

export interface ChartDataPoint {
  time: string;
  price: number;
  isPositive: boolean;
}

export const useLiveChartData = () => {
  const [chartData, setChartData] = useState<ChartDataPoint[]>([]);
  const [currentPrice, setCurrentPrice] = useState(0);
  const [priceChange, setPriceChange] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [lastRealPrice, setLastRealPrice] = useState(0);

  // Fetch real BTC price and generate initial chart data
  useEffect(() => {
    const initializeChart = async () => {
      try {
        const cryptoData = await fetchCryptoPrices();
        const btcData = cryptoData.find(crypto => crypto.symbol === 'BTC-USDT');
        
        if (btcData) {
          const realPrice = btcData.price;
          setCurrentPrice(realPrice);
          setLastRealPrice(realPrice);
          
          // Generate fewer historical data points (only 20 instead of 100)
          const data: ChartDataPoint[] = [];
          let previousPrice = realPrice;
          
          for (let i = 20; i >= 0; i--) {
            const variance = (Math.random() - 0.5) * (realPrice * 0.01); // Reduced variance
            const newPrice = Math.max(realPrice + variance, realPrice * 0.98); // Prevent extreme drops
            data.push({
              time: new Date(Date.now() - i * 180000).toLocaleTimeString('en-US', { 
                hour12: false, 
                hour: '2-digit', 
                minute: '2-digit' 
              }),
              price: newPrice,
              isPositive: newPrice >= previousPrice,
            });
            previousPrice = newPrice;
          }
          setChartData(data);
        }
      } catch (error) {
        console.error('Error fetching initial price:', error);
        setCurrentPrice(96240.50);
        setLastRealPrice(96240.50);
        generateFallbackData();
      } finally {
        setIsLoading(false);
      }
    };

    initializeChart();
  }, []);

  const generateFallbackData = () => {
    const data: ChartDataPoint[] = [];
    const basePrice = 96240.50;
    let previousPrice = basePrice;
    
    // Only generate 20 data points instead of 100
    for (let i = 20; i >= 0; i--) {
      const variance = (Math.random() - 0.5) * (basePrice * 0.01);
      const newPrice = Math.max(basePrice + variance, basePrice * 0.98);
      data.push({
        time: new Date(Date.now() - i * 180000).toLocaleTimeString('en-US', { 
          hour12: false, 
          hour: '2-digit', 
          minute: '2-digit' 
        }),
        price: newPrice,
        isPositive: newPrice >= previousPrice,
      });
      previousPrice = newPrice;
    }
    setChartData(data);
  };

  // Update chart with real price data every 30 seconds
  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const cryptoData = await fetchCryptoPrices();
        const btcData = cryptoData.find(crypto => crypto.symbol === 'BTC-USDT');
        
        if (btcData) {
          const newRealPrice = btcData.price;
          
          // Only update if there's a meaningful change to prevent fluctuation
          if (Math.abs(newRealPrice - lastRealPrice) > lastRealPrice * 0.001) { // 0.1% threshold
            const change = newRealPrice - currentPrice;
            
            setCurrentPrice(newRealPrice);
            setLastRealPrice(newRealPrice);
            setPriceChange(change);
            
            setChartData(prev => [
              ...prev.slice(1),
              {
                time: new Date().toLocaleTimeString('en-US', { 
                  hour12: false, 
                  hour: '2-digit', 
                  minute: '2-digit' 
                }),
                price: newRealPrice,
                isPositive: newRealPrice >= prev[prev.length - 1]?.price,
              }
            ]);
          }
        }
      } catch (error) {
        console.error('Error updating price:', error);
        // Minimal fallback with smaller variance
        const smallVariance = (Math.random() - 0.5) * (currentPrice * 0.002);
        const newPrice = currentPrice + smallVariance;
        const change = newPrice - currentPrice;
        
        setCurrentPrice(newPrice);
        setPriceChange(change);
        
        setChartData(prev => [
          ...prev.slice(1),
          {
            time: new Date().toLocaleTimeString('en-US', { 
              hour12: false, 
              hour: '2-digit', 
              minute: '2-digit' 
            }),
            price: newPrice,
            isPositive: newPrice >= prev[prev.length - 1]?.price,
          }
        ]);
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [currentPrice, lastRealPrice]);

  return {
    chartData,
    currentPrice,
    priceChange,
    isLoading,
  };
};
