import { useState, useCallback, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { supabase, ccPaymentSupabase } from "@/integrations/supabase/client";

export const useAdminData = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [users, setUsers] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [deposits, setDeposits] = useState<any[]>([]);
  const [tradeCodes, setTradeCodes] = useState<any[]>([]);
  const [kycVerifications, setKycVerifications] = useState<any[]>([]);

  useEffect(() => {
    checkAdminStatus();
  }, [user]);

  useEffect(() => {
    if (isAdmin) {
      fetchAdminData();
    }
  }, [isAdmin]);

  const checkAdminStatus = async () => {
    if (!user) {
      navigate("/");
      return;
    }

    try {
      const { data, error } = await supabase.rpc("is_admin_user");

      if (error) {
        console.error("Error checking admin status:", error);
        toast({
          title: "Access Denied",
          description: "You don't have permission to access this page.",
          variant: "destructive",
        });
        navigate("/");
        return;
      }

      if (!data) {
        toast({
          title: "Access Denied",
          description: "You don't have permission to access this page.",
          variant: "destructive",
        });
        navigate("/");
        return;
      }

      setIsAdmin(true);
    } catch (error) {
      console.error("Error checking admin status:", error);
      navigate("/");
    } finally {
      setIsLoading(false);
    }
  };

  const fetchAdminData = async () => {
    console.log("fetchAdminData - Starting to fetch admin data");
    try {
      // Fetch users
      const { data: usersData, error: usersError } = await supabase
        .from("profiles")
        .select(
          `
          *,
          referrer_info:referred_by(referral_code, username, user_id)
        `
        )
        .order("created_at", { ascending: false });

      if (usersError) {
        console.error("Error fetching users:", usersError);
      } else {
        console.log("Users fetched:", usersData?.length || 0);
        setUsers(usersData || []);
      }

      // Fetch withdrawals using CCPayment Supabase
      const { data: withdrawalsData, error: withdrawalsError } =
        await ccPaymentSupabase
          .from("withdrawals")
          .select(
            `
          *,
          profiles!inner(username, email, user_id)
        `
          )
          .order("created_at", { ascending: false });

      if (withdrawalsError) {
        console.error("Error fetching withdrawals:", withdrawalsError);
      } else {
        console.log(
          "Withdrawals fetched:",
          withdrawalsData?.length || 0,
          withdrawalsData
        );
        setWithdrawals(withdrawalsData || []);
      }

      // Fetch deposits using CCPayment Supabase
      const { data: depositsData, error: depositsError } =
        await ccPaymentSupabase
          .from("deposits")
          .select(
            `
          *,
          profiles!inner(username, email, user_id)
        `
          )
          .order("created_at", { ascending: false });

      if (depositsError) {
        console.error("Error fetching deposits:", depositsError);
      } else {
        console.log("Deposits fetched:", depositsData?.length || 0);
        setDeposits(depositsData || []);
      }

      // Fetch trade codes
      const { data: tradeCodesData, error: tradeCodesError } = await supabase
        .from("trade_codes")
        .select("*")
        .order("created_at", { ascending: false });

      if (tradeCodesError) {
        console.error("Error fetching trade codes:", tradeCodesError);
      } else {
        console.log("Trade codes fetched:", tradeCodesData?.length || 0);
        setTradeCodes(tradeCodesData || []);
      }

      // Fetch KYC verifications
      const { data: kycData, error: kycError } = await supabase
        .from("kyc_verifications")
        .select("*")
        .order("created_at", { ascending: false });

      if (kycError) {
        console.error("Error fetching KYC verifications:", kycError);
      } else {
        console.log("KYC verifications fetched:", kycData?.length || 0);
        setKycVerifications(kycData || []);
      }
    } catch (error) {
      console.error("Error fetching admin data:", error);
    }
  };

  const refreshWithdrawals = async () => {
    console.log("Refreshing withdrawals data...");
    try {
      const { data: withdrawalsData, error: withdrawalsError } = await supabase
        .from("withdrawals")
        .select(
          `
          *,
          profiles!inner(username, email, user_id)
        `
        )
        .order("created_at", { ascending: false });

      if (withdrawalsError) {
        console.error("Error refreshing withdrawals:", withdrawalsError);
      } else {
        console.log(
          "Withdrawals refreshed:",
          withdrawalsData?.length || 0,
          withdrawalsData
        );
        setWithdrawals(withdrawalsData || []);
      }
    } catch (error) {
      console.error("Error refreshing withdrawals:", error);
    }
  };

  const handleUserUpdated = async () => {
    console.log("handleUserUpdated - Refreshing admin data");
    await fetchAdminData();
  };

  const handleManageBalance = async () => {
    console.log("handleManageBalance - Refreshing admin data");
    await fetchAdminData();
  };

  const handleTradeCodeGenerated = async () => {
    console.log("handleTradeCodeGenerated - Refreshing admin data");
    await fetchAdminData();
  };

  const handleWithdrawalUpdate = async (
    withdrawalId: string,
    status: string,
    transactionId?: string
  ) => {
    console.log(
      "handleWithdrawalUpdate - Refreshing withdrawals after status change:",
      withdrawalId,
      status
    );
    await refreshWithdrawals();
  };

  return {
    isLoading,
    isAdmin,
    users,
    withdrawals,
    deposits,
    tradeCodes,
    kycVerifications,
    handleUserUpdated,
    handleManageBalance,
    handleTradeCodeGenerated,
    handleWithdrawalUpdate,
  };
};
