import { useState, useEffect, useCallback, useMemo } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { supabase, ccPaymentSupabase } from "@/integrations/supabase/client";

export const useDashboardData = () => {
  const { user, profile, refreshProfile } = useAuth();
  const { toast } = useToast();
  const [trades, setTrades] = useState<any[]>([]);
  const [deposits, setDeposits] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [referralCount, setReferralCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  // Account balances from profile
  const [accountBalances, setAccountBalances] = useState({
    exchange: 0,
    trade: 0,
    perpetual: 0,
  });

  const fetchUserData = useCallback(async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      console.log("Fetching trades for user:", user.id);
      const { data: tradesData, error: tradesError } = await supabase
        .from("trades")
        .select(
          `
          *,
          trade_codes(
            profit_percentage,
            duration_minutes,
            note
          )
        `
        )
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (tradesError) {
        console.error("Error fetching trades:", tradesError);
      } else {
        console.log("Trades fetched:", tradesData?.length || 0);
        setTrades(tradesData || []);
      }

      // Fetch deposits using CCPayment Supabase
      const { data: depositsData } = await ccPaymentSupabase
        .from("deposits")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      setDeposits(depositsData || []);

      // Fetch withdrawals using CCPayment Supabase
      const { data: withdrawalsData } = await ccPaymentSupabase
        .from("withdrawals")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      setWithdrawals(withdrawalsData || []);

      // Fetch referral count
      const { data: referralsData } = await supabase
        .from("referrals")
        .select("id")
        .eq("referrer_id", user.id);
      setReferralCount(referralsData?.length || 0);
    } catch (error) {
      console.error("Error in fetchUserData:", error);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      fetchUserData();
    }
  }, [user, fetchUserData]);

  useEffect(() => {
    if (profile) {
      // Use actual database balances
      setAccountBalances({
        exchange: Number(profile.balance) || 0, // Use 'balance' instead of 'exchange_balance'
        trade: Number(profile.trade_balance) || 0,
        perpetual: Number(profile.perpetual_balance) || 0,
      });
    }
  }, [profile]);

  const checkTransferFee = useCallback(
    async (fromAccount: string, toAccount: string, amount: number) => {
      if (!user) return null;

      try {
        const { data, error } = await (supabase as any).rpc(
          "check_transfer_fee",
          {
            user_id_input: user.id,
            from_account: fromAccount,
            to_account: toAccount,
            amount_input: amount,
          }
        );

        if (error) throw error;

        return data as {
          success: boolean;
          will_apply_fee: boolean;
          fee_amount: number;
          final_amount: number;
          original_amount: number;
          error?: string;
        };
      } catch (error) {
        console.error("Fee check error:", error);
        return null;
      }
    },
    [user]
  );

  const handleTransfer = useCallback(
    async (fromAccount: string, toAccount: string, amount: number) => {
      if (!user) return;

      try {
        console.log("Transfer attempt:", {
          fromAccount,
          toAccount,
          amount,
          user_id: user.id,
        });

        // Use type assertion for the custom RPC function
        const { data, error } = await (supabase as any).rpc(
          "transfer_between_accounts",
          {
            user_id_input: user.id,
            from_account: fromAccount,
            to_account: toAccount,
            amount_input: amount,
          }
        );

        console.log("Transfer response:", { data, error });

        if (error) {
          console.error("Supabase RPC error:", error);
          throw error;
        }

        // Type assertion for the response since it's not in generated types
        const response = data as {
          success: boolean;
          error?: string;
          message?: string;
          fee_applied?: number;
          amount_transferred?: number;
          original_amount?: number;
        };

        if (response && response.success) {
          let description = `Transferred $${amount.toFixed(
            2
          )} from ${fromAccount} to ${toAccount}`;

          // Show fee information if a fee was applied
          if (response.fee_applied && response.fee_applied > 0) {
            description = `Transferred $${response.original_amount?.toFixed(
              2
            )} from ${fromAccount} to ${toAccount}. Fee of $${response.fee_applied.toFixed(
              2
            )} (25%) was applied. Net amount: $${response.amount_transferred?.toFixed(
              2
            )}`;
          }

          toast({
            title: "Transfer Successful",
            description,
          });

          // Refresh the profile to get updated balances
          await refreshProfile();
        } else {
          throw new Error(response?.error || "Transfer failed");
        }
      } catch (error) {
        console.error("Transfer error:", error);
        toast({
          title: "Transfer Failed",
          description:
            error instanceof Error
              ? error.message
              : "Unable to complete transfer",
          variant: "destructive",
        });
      }
    },
    [user, toast, refreshProfile]
  );

  const getTotalBalance = useCallback(() => {
    return (
      accountBalances.exchange +
      accountBalances.trade +
      accountBalances.perpetual
    );
  }, [accountBalances]);

  const getWinRate = useCallback(() => {
    const completedTrades =
      trades?.filter((trade) => trade.status === "completed") || [];
    if (completedTrades.length === 0) return 0;
    const winningTrades = completedTrades.filter(
      (trade) => (Number(trade.profit) || 0) > 0
    );
    return (winningTrades.length / completedTrades.length) * 100;
  }, [trades]);

  return {
    trades,
    deposits,
    withdrawals,
    referralCount,
    isLoading,
    accountBalances,
    fetchUserData,
    handleTransfer,
    checkTransferFee,
    getTotalBalance,
    getWinRate,
  };
};
