import { useState } from "react";
import { ccPaymentSupabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export const useWithdrawal = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const createWithdrawal = async (
    userId: string,
    amount: number,
    address: string,
    currency: string = "USDT"
  ) => {
    setLoading(true);

    try {
      console.log("Creating CCPayment withdrawal...");

      const { data, error } = await ccPaymentSupabase.functions.invoke(
        "ccpayment-create-withdrawal",
        {
          body: {
            user_id: userId,
            amount,
            wallet_address: address,
            currency,
          },
        }
      );

      if (error) {
        console.error("CCPayment withdrawal error:", error);
        throw error;
      }

      console.log("CCPayment withdrawal created:", data);

      if (data.success) {
        toast({
          title: "Withdrawal Request Created",
          description: `Your withdrawal of $${amount} ${currency} is being processed`,
        });

        return data.data;
      } else {
        throw new Error(data.error || "Failed to create withdrawal");
      }
    } catch (error) {
      console.error("Error creating withdrawal:", error);
      toast({
        title: "Withdrawal Failed",
        description: error.message || "Failed to create withdrawal request",
        variant: "destructive",
      });
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return {
    createWithdrawal,
    loading,
  };
};
