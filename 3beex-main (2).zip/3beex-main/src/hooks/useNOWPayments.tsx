import { useState } from "react";
import { ccPaymentSupabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface CreatePaymentRequest {
  amount: number;
  currency?: string;
  pay_currency?: string;
}

interface CreatePaymentResponse {
  success: boolean;
  payment_url?: string;
  payment_id?: string;
  pay_address?: string;
  pay_amount?: number;
  pay_currency?: string;
  order_id?: string;
  error?: string;
}

export const useNOWPayments = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const createPayment = async ({
    amount,
    currency = "usd",
    pay_currency = "btc",
  }: CreatePaymentRequest): Promise<CreatePaymentResponse | null> => {
    setLoading(true);

    try {
      console.log("Creating NOWPayments payment...");

      const { data, error } = await ccPaymentSupabase.functions.invoke(
        "nowpayments-create-payment",
        {
          body: {
            amount,
            currency,
            pay_currency,
          },
        }
      );

      if (error) {
        console.error("NOWPayments payment error:", error);
        throw error;
      }

      console.log("NOWPayments payment created:", data);

      if (data.success) {
        toast({
          title: "Payment Created",
          description: `Your crypto payment of $${amount} has been created`,
        });

        return data;
      } else {
        throw new Error(data.error || "Failed to create payment");
      }
    } catch (error) {
      console.error("Error creating NOWPayments payment:", error);
      toast({
        title: "Payment Failed",
        description: error.message || "Failed to create crypto payment",
        variant: "destructive",
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const getSupportedCurrencies = () => {
    return [
      { code: "usdttrc20", name: "USDT (TRC20)", symbol: "₮" },
      { code: "usdterc20", name: "USDT (ERC-20)", symbol: "₮" },
    ];
  };

  return {
    createPayment,
    getSupportedCurrencies,
    loading,
  };
};
