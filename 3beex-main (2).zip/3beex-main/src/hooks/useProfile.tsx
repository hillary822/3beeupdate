
import { useState, useCallback } from 'react';
import { User } from '@supabase/supabase-js';
import { Profile } from '@/types/auth';
import { createProfile, fetchProfile } from '@/utils/profileUtils';

export const useProfile = () => {
  const [profile, setProfile] = useState<Profile | null>(null);

  const refreshProfile = useCallback(async (user: User | null) => {
    if (user) {
      console.log("refreshProfile - Refreshing for user:", user.id);
      const profileData = await fetchProfile(user.id);
      setProfile(profileData);
    } else {
      setProfile(null);
    }
  }, []);

  const initializeProfile = useCallback(async (user: User) => {
    try {
      console.log("initializeProfile - Fetching profile for user:", user.id);
      
      // Since the database trigger automatically creates profiles,
      // we just need to fetch the existing profile
      let profileData = await fetchProfile(user.id);
      
      // If still no profile found after trigger should have created it,
      // wait a bit longer and try multiple times
      let retryCount = 0;
      while (!profileData && retryCount < 5) {
        console.log(`initializeProfile - No profile found, retry ${retryCount + 1}/5...`);
        await new Promise(resolve => setTimeout(resolve, 1000 * (retryCount + 1)));
        profileData = await fetchProfile(user.id);
        retryCount++;
      }
      
      if (!profileData) {
        console.log("initializeProfile - Still no profile after retries, creating one...");
        // If profile still doesn't exist, create it manually
        try {
          profileData = await createProfile(user);
        } catch (createError) {
          console.error("initializeProfile - Error creating profile:", createError);
        }
      }
      
      setProfile(profileData);
      console.log("initializeProfile - Profile set:", profileData?.username || 'none');
      return profileData;
    } catch (error) {
      console.error("initializeProfile - Error handling profile:", error);
      setProfile(null);
      return null;
    }
  }, []);

  const clearProfile = useCallback(() => {
    setProfile(null);
  }, []);

  return {
    profile,
    refreshProfile,
    initializeProfile,
    clearProfile
  };
};
