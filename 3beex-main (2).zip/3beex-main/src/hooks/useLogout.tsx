import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { useToast } from './use-toast';

export const useLogout = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const logout = async () => {
    try {
      // First, clear all auth storage
      if (typeof window !== 'undefined') {
        localStorage.removeItem('supabase.auth.token');
        localStorage.removeItem('supabase.auth.expires_at');
        localStorage.removeItem('supabase.auth.refresh_token');
        Object.keys(localStorage).forEach(key => {
          if (key.startsWith('supabase.auth.')) {
            localStorage.removeItem(key);
          }
        });
      }

      // Then sign out from Supabase
      await supabase.auth.signOut();

      // Remove any cached data
      sessionStorage.clear();
      
      // Show success message
      toast({
        title: "Signed out",
        description: "You have been signed out successfully.",
      });

      // Navigate to home page
      navigate('/', { replace: true });

    } catch (error) {
      console.error('Logout error:', error);
      toast({
        variant: "destructive",
        title: "Error signing out",
        description: "Failed to logout properly. Please try again.",
      });
      // Force navigation even on error
      navigate('/', { replace: true });
    }
  };

  return { logout };
};