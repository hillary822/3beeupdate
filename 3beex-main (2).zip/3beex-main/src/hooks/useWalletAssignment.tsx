
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

interface AssignedWallet {
  id: string;
  address: string;
  currency: string;
  assigned_at: string;
}

interface WalletAssignResponse {
  success: boolean;
  message?: string;
  error?: string;
  wallet?: AssignedWallet;
}

export const useWalletAssignment = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [assignedWallet, setAssignedWallet] = useState<AssignedWallet | null>(null);
  const [loading, setLoading] = useState(true);
  const [assigning, setAssigning] = useState(false);

  const fetchAssignedWallet = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('pre_generated_wallets')
        .select('*')
        .eq('assigned_to_user_id', user?.id)
        .eq('currency', 'USDT')
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setAssignedWallet({
          id: data.id,
          address: data.address,
          currency: data.currency,
          assigned_at: data.assigned_at || new Date().toISOString()
        });
      } else {
        await assignWallet();
      }
    } catch (error) {
      console.error('Error fetching assigned wallet:', error);
      toast({
        title: "Error",
        description: "Failed to fetch deposit address",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const assignWallet = async () => {
    setAssigning(true);
    try {
      const { data, error } = await supabase.rpc('assign_wallet_to_user', {
        user_id_input: user?.id,
        currency_input: 'USDT'
      });

      if (error) throw error;

      const response = data as unknown as WalletAssignResponse;

      if (response?.success) {
        setAssignedWallet(response.wallet!);
        
        toast({
          title: "Deposit Address Assigned",
          description: "Your USDT deposit address has been assigned successfully",
        });
      } else {
        throw new Error(response?.error || 'Failed to assign wallet');
      }
    } catch (error) {
      console.error('Error assigning wallet:', error);
      toast({
        title: "Error",
        description: "Failed to assign deposit address",
        variant: "destructive",
      });
    } finally {
      setAssigning(false);
    }
  };

  return {
    assignedWallet,
    loading,
    assigning,
    fetchAssignedWallet,
    assignWallet
  };
};
