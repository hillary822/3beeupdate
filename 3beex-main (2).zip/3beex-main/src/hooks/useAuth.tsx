
import { useState, useEffect, createContext, useContext, ReactNode, useCallback, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { User } from '@supabase/supabase-js';
import { useAuthActions } from './useAuthActions';
import { useProfile } from './useProfile';

interface AuthContextType {
  user: User | null;
  profile: any;
  loading: boolean;
  signIn: (identifier: string, password: string) => Promise<void>;
  signUp: (identifier: string, password: string, referralCode?: string) => Promise<any>;
  sendOtp: (email: string, password: string, username: string, referralCode: string) => Promise<any>;
  verifyOtp: (email: string, otp: string) => Promise<any>;
  resendOtp: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const { signIn, signUp, sendOtp, verifyOtp, resendOtp, signOut } = useAuthActions();
  const { profile, refreshProfile: profileRefresh, initializeProfile, clearProfile } = useProfile();

  useEffect(() => {
    let mounted = true;

    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (!mounted) return;
      
      console.log('Auth state changed:', event, session?.user?.email || 'no user');
      
      if (event === 'SIGNED_OUT') {
        setUser(null);
        clearProfile();
        setLoading(false);
        console.log('User signed out, clearing state');
      } else if (session?.user) {
        setUser(session.user);
        console.log('User signed in, user set');
        // Initialize profile for signed in user
        setTimeout(() => {
          initializeProfile(session.user);
        }, 0);
        setLoading(false);
      } else {
        setUser(null);
        clearProfile();
        setLoading(false);
      }
    });

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!mounted) return;
      
      if (session?.user) {
        setUser(session.user);
        console.log('Existing session found, user set');
        // Initialize profile for existing session
        setTimeout(() => {
          initializeProfile(session.user);
        }, 0);
      } else {
        setUser(null);
        clearProfile();
      }
      setLoading(false);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [clearProfile, initializeProfile]);

  const refreshProfile = useCallback(async () => {
    if (user) {
      await profileRefresh(user);
    }
  }, [user, profileRefresh]);

  const handleSignOut = useCallback(async () => {
    setLoading(true);
    try {
      await signOut();
      // State will be cleared by the auth state change listener
    } catch (error) {
      console.error('Sign out error:', error);
    } finally {
      setLoading(false);
    }
  }, [signOut]);

  const contextValue = useMemo(() => ({
    user,
    profile,
    loading,
    signIn,
    signUp,
    sendOtp,
    verifyOtp,
    resendOtp,
    signOut: handleSignOut,
    refreshProfile,
  }), [
    user,
    profile,
    loading,
    signIn,
    signUp,
    sendOtp,
    verifyOtp,
    resendOtp,
    handleSignOut,
    refreshProfile,
  ]);

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
