import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export const useAuthActions = () => {
  const { toast } = useToast();

  const signIn = async (identifier: string, password: string) => {
    try {
      const isEmail = identifier.includes("@");
      const authData = isEmail
        ? { email: identifier, password }
        : { phone: identifier, password };

      const { data, error } = await supabase.auth.signInWithPassword(authData);
      if (error) throw error;

      // Check if user account is locked
      if (data.user) {
        const { data: profile, error: profileError } = await supabase
          .from("profiles")
          .select("locked, suspended")
          .eq("id", data.user.id)
          .single();

        if (profileError) {
          console.error("Error fetching profile:", profileError);
        } else if (profile?.locked) {
          // Sign the user out immediately
          await supabase.auth.signOut();
          throw new Error("Account locked, contact admin");
        }
      }

      toast({
        title: "Login Successful",
        description: "Welcome back to 3BEET EXCHANGE",
      });
    } catch (error: any) {
      let errorMessage = error.message;

      if (error.message?.includes("Account locked, contact admin")) {
        errorMessage = "Account locked, contact admin";
      }

      toast({
        variant: "destructive",
        title: "Error signing in",
        description: errorMessage,
      });
      throw error;
    }
  };

  const sendOtp = async (
    email: string,
    password: string,
    username: string,
    referralCode: string
  ) => {
    try {
      // Validate referral code first
      if (!referralCode || !referralCode.trim()) {
        throw new Error("Referral code is required");
      }

      console.log("Validating referral code:", referralCode.trim());

      const { data: validationResult, error: referralError } =
        await supabase.rpc("send_registration_otp", {
          user_email: email,
          referral_code_input: referralCode.trim(),
        });

      if (referralError || !(validationResult as any)?.success) {
        throw new Error(
          (validationResult as any)?.error || "Invalid referral code provided"
        );
      }

      // Now send OTP for signup using Supabase Auth
      const { error } = await supabase.auth.signUp({
        email: email,
        password: password,
        options: {
          data: {
            username,
            referral_code: referralCode.trim(),
          },
          emailRedirectTo: `${window.location.origin}/`,
        },
      });

      if (error) {
        console.error("Send OTP error:", error);
        throw error;
      }

      toast({
        title: "Verification Code Sent",
        description:
          "Please check your email for the verification code to activate your account.",
      });

      return { success: true, email, password, username, referralCode };
    } catch (error: any) {
      console.error("Send OTP failed:", error);
      toast({
        variant: "destructive",
        title: "Failed to Send OTP",
        description:
          error.message ||
          "Could not send verification code. Please try again.",
      });
      throw error;
    }
  };

  const signUp = async (
    identifier: string,
    password: string,
    referralCode?: string
  ) => {
    try {
      const isEmail = identifier.includes("@");

      // Auto-generate username from email or phone
      const username = isEmail
        ? identifier.split("@")[0]
        : identifier.replace(/[^a-zA-Z0-9]/g, "").substring(0, 15);

      // Validate referral code (now required)
      if (!referralCode || !referralCode.trim()) {
        throw new Error("Referral code is required");
      }

      console.log("Validating referral code:", referralCode.trim());

      let isValid = false;

      try {
        // Try using the security definer function first (bypasses RLS)
        const { data: functionResult, error: referralError } =
          await supabase.rpc("validate_referral_code_public", {
            ref_code: referralCode.trim(),
          });

        console.log("Referral validation result:", {
          functionResult,
          referralError,
        });

        if (referralError) {
          console.error("Referral validation error:", referralError);

          // If function doesn't exist, fall back to direct table query
          if (
            referralError.message?.includes(
              "function public.validate_referral_code_public"
            )
          ) {
            console.log(
              "Function not found, using fallback validation method..."
            );

            // Fallback: Check if there are any users first (bootstrap scenario)
            const { count: userCount, error: countError } = await supabase
              .from("profiles")
              .select("*", { count: "exact", head: true });

            if (countError) {
              console.error("Error counting users:", countError);
              throw new Error(
                "Error validating referral code. Please try again."
              );
            }

            // If no users exist, allow registration (bootstrap scenario)
            if (userCount === 0) {
              console.log(
                "No users exist yet, allowing registration without referral validation"
              );
              isValid = true;
            } else {
              // Check if referral code exists
              const { data: referrerData, error: referrerError } =
                await supabase
                  .from("profiles")
                  .select("id, referral_code")
                  .eq("referral_code", referralCode.trim())
                  .maybeSingle();

              if (referrerError) {
                console.error("Error checking referral code:", referrerError);
                throw new Error(
                  "Error validating referral code. Please try again."
                );
              }

              isValid = !!referrerData;
            }
          } else {
            throw new Error(
              "Error validating referral code. Please try again."
            );
          }
        } else {
          isValid = functionResult;
        }
      } catch (error) {
        console.error("Referral validation failed:", error);
        throw new Error("Error validating referral code. Please try again.");
      }

      if (!isValid) {
        console.log("Invalid referral code:", referralCode.trim());
        throw new Error(
          "Invalid referral code provided. Please check and try again."
        );
      }

      console.log("Referral code validation passed!");

      console.log("Starting signup process with:", {
        identifier,
        username,
        referralCode: referralCode?.trim(),
        isEmail,
      });

      if (isEmail) {
        // For email signup, create the account
        const { data, error } = await supabase.auth.signUp({
          email: identifier,
          password,
          options: {
            data: {
              username,
              referral_code: referralCode?.trim(),
            },
            emailRedirectTo: `${window.location.origin}/`,
          },
        });

        if (error) {
          console.error("SignUp error:", error);
          throw error;
        }

        console.log("Signup response:", data);

        if (data.user) {
          toast({
            title: "Registration Successful",
            description: "Your account has been created successfully.",
          });
          return { user: data.user, session: data.session };
        }
      } else {
        // Phone signup
        const { data, error } = await supabase.auth.signUp({
          phone: identifier,
          password,
          options: {
            data: {
              username,
              referral_code: referralCode?.trim(),
            },
          },
        });

        if (error) {
          console.error("SignUp error:", error);
          throw error;
        }

        console.log("Phone signup response:", data);

        if (data.user) {
          toast({
            title: "Registration Successful",
            description: "Your account has been created successfully.",
          });
          return { user: data.user, session: data.session };
        }
      }

      throw new Error("User creation failed - unexpected response");
    } catch (error: any) {
      console.error("SignUp final error:", error);

      // Handle specific error cases
      if (error.message?.includes("User already registered")) {
        toast({
          variant: "destructive",
          title: "Account Already Exists",
          description:
            "An account with this email already exists. Please try logging in instead.",
        });
      } else if (error.message?.includes("Invalid referral code")) {
        toast({
          variant: "destructive",
          title: "Invalid Referral Code",
          description:
            "The referral code you entered is not valid. Please check and try again.",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Registration Failed",
          description:
            error.message ||
            "An error occurred during registration. Please try again.",
        });
      }
      throw error;
    }
  };

  const verifyOtp = async (email: string, otp: string) => {
    try {
      console.log("Verifying OTP for:", email, "with code:", otp);

      const { data, error } = await supabase.auth.verifyOtp({
        email,
        token: otp,
        type: "signup",
      });

      if (error) {
        console.error("OTP verification error:", error);
        throw error;
      }

      console.log("OTP verification successful:", data);

      toast({
        title: "Account Created Successfully",
        description:
          "Your account has been created and verified. Welcome to 3BEET EXCHANGE!",
      });

      return { data };
    } catch (error: any) {
      console.error("OTP verification failed:", error);
      toast({
        variant: "destructive",
        title: "Verification Failed",
        description:
          error.message || "Invalid verification code. Please try again.",
      });
      throw error;
    }
  };

  const resendOtp = async (email: string) => {
    try {
      console.log("Resending OTP to:", email);

      const { error } = await supabase.auth.resend({
        type: "signup",
        email: email,
      });

      if (error) {
        console.error("Resend OTP error:", error);
        throw error;
      }

      toast({
        title: "Code Resent",
        description: "A new verification code has been sent to your email.",
      });
    } catch (error: any) {
      console.error("Resend OTP failed:", error);
      toast({
        variant: "destructive",
        title: "Resend Failed",
        description:
          error.message ||
          "Failed to resend verification code. Please try again.",
      });
      throw error;
    }
  };

  const signOut = async () => {
    try {
      console.log("Signing out user...");

      // First clear auth storage
      if (typeof window !== "undefined" && window.localStorage) {
        Object.keys(localStorage).forEach((key) => {
          if (key.startsWith("supabase.auth.")) {
            localStorage.removeItem(key);
          }
        });
      }

      // Then try to sign out from Supabase
      await supabase.auth
        .signOut()
        .catch((err) => console.log("Supabase signout error:", err));

      // Always redirect to home
      window.location.href = "/";

      toast({
        title: "Signed out",
        description: "You have been signed out successfully.",
      });
    } catch (error: any) {
      console.error("Sign out error:", error);
      toast({
        variant: "destructive",
        title: "Error signing out",
        description: "An error occurred during sign out.",
      });
      // Still redirect even on error
      window.location.href = "/";
    }
  };

  return { signIn, signUp, sendOtp, verifyOtp, resendOtp, signOut };
};
