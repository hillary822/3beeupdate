
import { User } from '@supabase/supabase-js';

export interface Profile {
  id: string;
  username: string;
  email: string;
  balance: number;
  exchange_balance: number;
  trade_balance: number;
  perpetual_balance: number;
  verified: boolean;
  vip: boolean;
  vip_level: number;
  premium: boolean;
  suspended: boolean;
  referral_code: string;
  referred_by?: string;
  user_id: number;
}

export interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, username: string, referralCode?: string) => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}
