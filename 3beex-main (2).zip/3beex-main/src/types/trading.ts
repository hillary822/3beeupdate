
export interface TradeCodeResponse {
  success: boolean;
  trade_id?: string;
  duration_minutes?: number;
  asset?: string;
  profit_percentage?: number;
  amount_invested?: number;
  error?: string;
}

export interface CompleteTradeResponse {
  success: boolean;
  profit?: number;
  total_return?: number;
  trade_id?: string;
  error?: string;
}

export interface TradeOperations {
  createTrade: (type: 'BUY' | 'SELL', asset: string, amount: number) => Promise<void>;
  useTradeCode: (code: string) => Promise<TradeCodeResponse | null>;
  requestWithdrawal: (amount: number, address: string) => Promise<void>;
  makeDeposit: (amount: number, method: string) => Promise<void>;
  loading: boolean;
}
