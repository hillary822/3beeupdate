export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      deposits: {
        Row: {
          admin_note: string | null
          amount: number
          created_at: string | null
          id: string
          method: string
          payment_method_id: string | null
          payment_method_name: string | null
          status: string | null
          transaction_hash: string | null
          transaction_id: string | null
          updated_at: string | null
          user_id: string
          wallet_address: string | null
        }
        Insert: {
          admin_note?: string | null
          amount: number
          created_at?: string | null
          id?: string
          method: string
          payment_method_id?: string | null
          payment_method_name?: string | null
          status?: string | null
          transaction_hash?: string | null
          transaction_id?: string | null
          updated_at?: string | null
          user_id: string
          wallet_address?: string | null
        }
        Update: {
          admin_note?: string | null
          amount?: number
          created_at?: string | null
          id?: string
          method?: string
          payment_method_id?: string | null
          payment_method_name?: string | null
          status?: string | null
          transaction_hash?: string | null
          transaction_id?: string | null
          updated_at?: string | null
          user_id?: string
          wallet_address?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "deposits_payment_method_id_fkey"
            columns: ["payment_method_id"]
            isOneToOne: false
            referencedRelation: "payment_methods"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deposits_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      kyc_verifications: {
        Row: {
          admin_notes: string | null
          country: string | null
          created_at: string
          full_name: string | null
          id: string
          id_back_path: string | null
          id_card_number: string | null
          id_front_path: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          selfie_with_id_path: string | null
          state: string | null
          status: Database["public"]["Enums"]["verification_status"]
          submitted_at: string
          updated_at: string
          user_id: string
          verification_type: Database["public"]["Enums"]["verification_type"]
        }
        Insert: {
          admin_notes?: string | null
          country?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          id_back_path?: string | null
          id_card_number?: string | null
          id_front_path?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          selfie_with_id_path?: string | null
          state?: string | null
          status?: Database["public"]["Enums"]["verification_status"]
          submitted_at?: string
          updated_at?: string
          user_id: string
          verification_type: Database["public"]["Enums"]["verification_type"]
        }
        Update: {
          admin_notes?: string | null
          country?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          id_back_path?: string | null
          id_card_number?: string | null
          id_front_path?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          selfie_with_id_path?: string | null
          state?: string | null
          status?: Database["public"]["Enums"]["verification_status"]
          submitted_at?: string
          updated_at?: string
          user_id?: string
          verification_type?: Database["public"]["Enums"]["verification_type"]
        }
        Relationships: [
          {
            foreignKeyName: "kyc_verifications_reviewed_by_fkey"
            columns: ["reviewed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kyc_verifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      manual_deposit_addresses: {
        Row: {
          address: string
          created_at: string
          currency: string
          id: string
          is_active: boolean
          network: string
          updated_at: string
        }
        Insert: {
          address: string
          created_at?: string
          currency: string
          id?: string
          is_active?: boolean
          network: string
          updated_at?: string
        }
        Update: {
          address?: string
          created_at?: string
          currency?: string
          id?: string
          is_active?: boolean
          network?: string
          updated_at?: string
        }
        Relationships: []
      }
      payment_methods: {
        Row: {
          created_at: string
          display_name: string
          id: string
          is_active: boolean
          name: string
          updated_at: string
          wallet_address: string
        }
        Insert: {
          created_at?: string
          display_name: string
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
          wallet_address: string
        }
        Update: {
          created_at?: string
          display_name?: string
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
          wallet_address?: string
        }
        Relationships: []
      }
      platform_settings: {
        Row: {
          created_at: string | null
          id: string
          key: string
          updated_at: string | null
          value: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          key: string
          updated_at?: string | null
          value: string
        }
        Update: {
          created_at?: string | null
          id?: string
          key?: string
          updated_at?: string | null
          value?: string
        }
        Relationships: []
      }
      pre_generated_wallets: {
        Row: {
          address: string
          assigned_at: string | null
          assigned_to_user_id: string | null
          created_at: string | null
          currency: string
          id: string
          is_assigned: boolean | null
          updated_at: string | null
        }
        Insert: {
          address: string
          assigned_at?: string | null
          assigned_to_user_id?: string | null
          created_at?: string | null
          currency?: string
          id?: string
          is_assigned?: boolean | null
          updated_at?: string | null
        }
        Update: {
          address?: string
          assigned_at?: string | null
          assigned_to_user_id?: string | null
          created_at?: string | null
          currency?: string
          id?: string
          is_assigned?: boolean | null
          updated_at?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          balance: number | null
          created_at: string | null
          email: string
          exchange_balance: number | null
          id: string
          locked: boolean
          permanent_signal: boolean
          perpetual_balance: number | null
          premium: boolean | null
          referral_code: string
          referred_by: string | null
          suspended: boolean
          trade_account_deposits: number | null
          trade_balance: number | null
          updated_at: string | null
          user_id: number
          username: string
          verified: boolean | null
          vip: boolean | null
          vip_level: number | null
        }
        Insert: {
          balance?: number | null
          created_at?: string | null
          email: string
          exchange_balance?: number | null
          id: string
          locked?: boolean
          permanent_signal?: boolean
          perpetual_balance?: number | null
          premium?: boolean | null
          referral_code: string
          referred_by?: string | null
          suspended?: boolean
          trade_account_deposits?: number | null
          trade_balance?: number | null
          updated_at?: string | null
          user_id: number
          username: string
          verified?: boolean | null
          vip?: boolean | null
          vip_level?: number | null
        }
        Update: {
          balance?: number | null
          created_at?: string | null
          email?: string
          exchange_balance?: number | null
          id?: string
          locked?: boolean
          permanent_signal?: boolean
          perpetual_balance?: number | null
          premium?: boolean | null
          referral_code?: string
          referred_by?: string | null
          suspended?: boolean
          trade_account_deposits?: number | null
          trade_balance?: number | null
          updated_at?: string | null
          user_id?: number
          username?: string
          verified?: boolean | null
          vip?: boolean | null
          vip_level?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_referred_by_fkey"
            columns: ["referred_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      referrals: {
        Row: {
          created_at: string | null
          earnings: number | null
          id: string
          referred_id: string
          referrer_id: string
        }
        Insert: {
          created_at?: string | null
          earnings?: number | null
          id?: string
          referred_id: string
          referrer_id: string
        }
        Update: {
          created_at?: string | null
          earnings?: number | null
          id?: string
          referred_id?: string
          referrer_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "referrals_referred_id_fkey"
            columns: ["referred_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referrals_referrer_id_fkey"
            columns: ["referrer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      trade_codes: {
        Row: {
          asset: string
          code: string
          created_at: string | null
          created_by: string | null
          duration_minutes: number
          id: string
          is_permanent_signal: boolean
          is_premium: boolean
          is_used: boolean | null
          is_vip: boolean
          minimum_balance: number | null
          note: string | null
          profit_percentage: number
          sent_at: string | null
          signal_type: string | null
          used_at: string | null
          used_by: string | null
          win_or_loss: string
        }
        Insert: {
          asset?: string
          code: string
          created_at?: string | null
          created_by?: string | null
          duration_minutes?: number
          id?: string
          is_permanent_signal?: boolean
          is_premium?: boolean
          is_used?: boolean | null
          is_vip?: boolean
          minimum_balance?: number | null
          note?: string | null
          profit_percentage?: number
          sent_at?: string | null
          signal_type?: string | null
          used_at?: string | null
          used_by?: string | null
          win_or_loss?: string
        }
        Update: {
          asset?: string
          code?: string
          created_at?: string | null
          created_by?: string | null
          duration_minutes?: number
          id?: string
          is_permanent_signal?: boolean
          is_premium?: boolean
          is_used?: boolean | null
          is_vip?: boolean
          minimum_balance?: number | null
          note?: string | null
          profit_percentage?: number
          sent_at?: string | null
          signal_type?: string | null
          used_at?: string | null
          used_by?: string | null
          win_or_loss?: string
        }
        Relationships: [
          {
            foreignKeyName: "trade_codes_used_by_fkey"
            columns: ["used_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      trade_deposits: {
        Row: {
          amount: number
          available_for_withdrawal: number | null
          created_at: string
          doubled_amount: number
          fee_paid_amount: number | null
          id: string
          is_fully_doubled: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          available_for_withdrawal?: number | null
          created_at?: string
          doubled_amount?: number
          fee_paid_amount?: number | null
          id?: string
          is_fully_doubled?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          available_for_withdrawal?: number | null
          created_at?: string
          doubled_amount?: number
          fee_paid_amount?: number | null
          id?: string
          is_fully_doubled?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      trades: {
        Row: {
          amount: number
          asset: string
          completed_at: string | null
          created_at: string | null
          id: string
          profit: number | null
          started_at: string | null
          status: string | null
          trade_code: string
          trade_code_id: string | null
          type: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          amount: number
          asset: string
          completed_at?: string | null
          created_at?: string | null
          id?: string
          profit?: number | null
          started_at?: string | null
          status?: string | null
          trade_code: string
          trade_code_id?: string | null
          type: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          asset?: string
          completed_at?: string | null
          created_at?: string | null
          id?: string
          profit?: number | null
          started_at?: string | null
          status?: string | null
          trade_code?: string
          trade_code_id?: string | null
          type?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "trades_trade_code_id_fkey"
            columns: ["trade_code_id"]
            isOneToOne: false
            referencedRelation: "trade_codes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "trades_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      transfer_history: {
        Row: {
          amount: number
          created_at: string
          fee_amount: number | null
          from_account: string
          id: string
          status: string
          to_account: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          fee_amount?: number | null
          from_account: string
          id?: string
          status?: string
          to_account: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          fee_amount?: number | null
          from_account?: string
          id?: string
          status?: string
          to_account?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_codes: {
        Row: {
          code: string
          created_at: string | null
          id: string
          is_used: boolean | null
          sent_at: string | null
          trade_code_id: string
          updated_at: string | null
          used_at: string | null
          user_id: string
        }
        Insert: {
          code: string
          created_at?: string | null
          id?: string
          is_used?: boolean | null
          sent_at?: string | null
          trade_code_id: string
          updated_at?: string | null
          used_at?: string | null
          user_id: string
        }
        Update: {
          code?: string
          created_at?: string | null
          id?: string
          is_used?: boolean | null
          sent_at?: string | null
          trade_code_id?: string
          updated_at?: string | null
          used_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      verification_submissions: {
        Row: {
          created_at: string
          document_path: string
          id: string
          reviewed_at: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          document_path: string
          id?: string
          reviewed_at?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          document_path?: string
          id?: string
          reviewed_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "verification_submissions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      wallet_transactions: {
        Row: {
          amount: number
          ccpayment_transaction_id: string | null
          created_at: string | null
          fee: number | null
          from_address: string | null
          id: string
          status: string | null
          to_address: string | null
          transaction_hash: string | null
          transaction_type: string
          updated_at: string | null
          user_id: string
          wallet_id: string
        }
        Insert: {
          amount: number
          ccpayment_transaction_id?: string | null
          created_at?: string | null
          fee?: number | null
          from_address?: string | null
          id?: string
          status?: string | null
          to_address?: string | null
          transaction_hash?: string | null
          transaction_type: string
          updated_at?: string | null
          user_id: string
          wallet_id: string
        }
        Update: {
          amount?: number
          ccpayment_transaction_id?: string | null
          created_at?: string | null
          fee?: number | null
          from_address?: string | null
          id?: string
          status?: string | null
          to_address?: string | null
          transaction_hash?: string | null
          transaction_type?: string
          updated_at?: string | null
          user_id?: string
          wallet_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wallet_transactions_wallet_id_fkey"
            columns: ["wallet_id"]
            isOneToOne: false
            referencedRelation: "wallets"
            referencedColumns: ["id"]
          },
        ]
      }
      wallets: {
        Row: {
          address: string
          balance: number | null
          ccpayment_wallet_id: string | null
          created_at: string | null
          currency: string
          id: string
          is_active: boolean | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          address: string
          balance?: number | null
          ccpayment_wallet_id?: string | null
          created_at?: string | null
          currency?: string
          id?: string
          is_active?: boolean | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          address?: string
          balance?: number | null
          ccpayment_wallet_id?: string | null
          created_at?: string | null
          currency?: string
          id?: string
          is_active?: boolean | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      withdrawals: {
        Row: {
          address: string
          admin_note: string | null
          amount: number
          created_at: string | null
          id: string
          status: string | null
          transaction_id: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          address: string
          admin_note?: string | null
          amount: number
          created_at?: string | null
          id?: string
          status?: string | null
          transaction_id?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          address?: string
          admin_note?: string | null
          amount?: number
          created_at?: string | null
          id?: string
          status?: string | null
          transaction_id?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "withdrawals_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_credit_balance: {
        Args: {
          target_user_id: string
          credit_amount: number
          admin_note?: string
        }
        Returns: Json
      }
      admin_mark_trade_code_used: {
        Args: { code_input: string }
        Returns: Json
      }
      apply_retroactive_referral_bonuses: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      assign_wallet_to_user: {
        Args: { user_id_input: string; currency_input?: string }
        Returns: Json
      }
      can_view_referral: {
        Args: { referral_referrer_id: string; referral_referred_id: string }
        Returns: boolean
      }
      check_transfer_fee: {
        Args: {
          user_id_input: string
          from_account: string
          to_account: string
          amount_input: number
        }
        Returns: Json
      }
      complete_overdue_trades: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      complete_trade: {
        Args: { trade_id_input: string }
        Returns: Json
      }
      generate_trade_code: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_support_email: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      insert_pre_generated_wallets: {
        Args: { wallets_data: Json }
        Returns: Json
      }
      is_admin: {
        Args: { user_id: string }
        Returns: boolean
      }
      is_admin_user: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      mark_deposits_doubled: {
        Args: { user_id_input: string; profit_amount: number }
        Returns: undefined
      }
      process_referral_bonus: {
        Args: { user_id_input: string; trade_profit: number }
        Returns: Json
      }
      process_registration_bonus: {
        Args: { new_user_id: string; referrer_id: string }
        Returns: Json
      }
      send_code_to_users: {
        Args: { trade_code_id_input: string }
        Returns: Json
      }
      send_registration_otp: {
        Args: { user_email: string; referral_code_input: string }
        Returns: Json
      }
      transfer_between_accounts: {
        Args: {
          user_id_input: string
          from_account: string
          to_account: string
          amount_input: number
        }
        Returns: Json
      }
      update_user_balance: {
        Args: { target_user_id: string; balance_amount: number }
        Returns: undefined
      }
      use_trade_code: {
        Args: { code_input: string; user_id_input: string }
        Returns: Json
      }
      validate_referral_code: {
        Args: { ref_code: string }
        Returns: boolean
      }
      validate_referral_code_public: {
        Args: { ref_code: string }
        Returns: boolean
      }
    }
    Enums: {
      verification_status: "pending" | "approved" | "rejected"
      verification_type: "basic" | "advanced"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      verification_status: ["pending", "approved", "rejected"],
      verification_type: ["basic", "advanced"],
    },
  },
} as const
