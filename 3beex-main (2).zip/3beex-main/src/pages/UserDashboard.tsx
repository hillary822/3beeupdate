
import { useState, useEffect, useCallback, useMemo } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { forceLogout } from "@/utils/authUtils";
import BottomNavigation from "@/components/BottomNavigation";
import TransferModal from "@/components/dashboard/TransferModal";
import LiveChart from "@/components/dashboard/LiveChart";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import DashboardMobileContent from "@/components/dashboard/DashboardMobileContent";
import DashboardDesktopContent from "@/components/dashboard/DashboardDesktopContent";
import { useDashboardData } from "@/hooks/useDashboardData";

const UserDashboard = () => {
  const { user, profile, signOut } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("assets");
  const [showBalance, setShowBalance] = useState(true);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [settingsInitialTab, setSettingsInitialTab] = useState("account");

  const {
    trades,
    deposits,
    withdrawals,
    referralCount,
    isLoading,
    accountBalances,
    fetchUserData,
    handleTransfer,
    checkTransferFee,
    getTotalBalance,
    getWinRate,
  } = useDashboardData();


  const handleLogout = useCallback(async () => {
    try {
      toast({
        title: "Signing out",
        description: "Logging you out...",
      });
      
      // Use our robust force logout utility
      await forceLogout();
    } catch (error) {
      console.error('Logout error:', error);
      toast({
        title: "Error",
        description: "Failed to logout. Please try again.",
        variant: "destructive",
      });
      // Still force a redirect on error
      window.location.href = '/';
    }
  }, [toast]);

  const handleDeposit = useCallback(async () => {
    await fetchUserData();
  }, [fetchUserData]);

  const handleWithdraw = useCallback(async () => {
    await fetchUserData();
  }, [fetchUserData]);

  const handleCopyReferralCode = useCallback(() => {
    if (profile?.referral_code) {
      navigator.clipboard.writeText(profile.referral_code);
      toast({
        title: "Copied!",
        description: "Referral code copied to clipboard",
      });
    }
  }, [profile?.referral_code, toast]);

  const handleNavigateToVerification = useCallback(() => {
    setSettingsInitialTab("verification");
    setActiveTab("settings");
  }, []);

  const handleNavigateToSettings = useCallback(() => {
    setSettingsInitialTab("account");
    setActiveTab("settings");
  }, []);

  const handleTabChange = useCallback((tab: string) => {
    setActiveTab(tab);
  }, []);

  const handleToggleBalance = useCallback(() => {
    setShowBalance(prev => !prev);
  }, []);

  const handleShowTransferModal = useCallback(() => {
    setShowTransferModal(true);
  }, []);

  const handleCloseTransferModal = useCallback(() => {
    setShowTransferModal(false);
  }, []);

  // Memoize computed values
  const totalBalance = useMemo(() => getTotalBalance(), [getTotalBalance]);
  const winRate = useMemo(() => getWinRate(), [getWinRate]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <div>Loading dashboard...</div>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div>Loading profile...</div>
        </div>
      </div>
    );
  }

  // Check if chart should be visible (only on assets and trades tabs)
  const shouldShowChart = activeTab === "assets" || activeTab === "trades";

  return (
    <div className="min-h-screen bg-slate-900 text-white w-full overflow-x-hidden pb-16">
      <div className="p-2 sm:p-4 lg:p-6 w-full overflow-x-hidden max-w-full">
        <div className="max-w-7xl mx-auto w-full max-w-full overflow-x-hidden">
          <DashboardHeader onLogout={handleLogout} profile={profile} activeTab={activeTab} />

          {/* Mobile-first content */}
          <DashboardMobileContent
            activeTab={activeTab}
            profile={profile}
            totalBalance={totalBalance}
            winRate={winRate}
            showBalance={showBalance}
            setShowBalance={handleToggleBalance}
            setActiveTab={handleTabChange}
            setShowTransferModal={handleShowTransferModal}
            accountBalances={accountBalances}
            trades={trades}
            deposits={deposits}
            withdrawals={withdrawals}
            referralCount={referralCount}
            isLoading={isLoading}
            onNavigate={navigate}
            onTradeCompleted={fetchUserData}
            onDeposit={handleDeposit}
            onWithdraw={handleWithdraw}
            onCopyReferralCode={handleCopyReferralCode}
            onLogout={handleLogout}
            onNavigateToVerification={handleNavigateToVerification}
            onNavigateToSettings={handleNavigateToSettings}
            settingsInitialTab={settingsInitialTab}
          />

          {/* Desktop content */}
          <DashboardDesktopContent
            profile={profile}
            totalBalance={totalBalance}
            winRate={winRate}
            showBalance={showBalance}
            setShowBalance={handleToggleBalance}
            setActiveTab={handleTabChange}
            setShowTransferModal={handleShowTransferModal}
            accountBalances={accountBalances}
            trades={trades}
            deposits={deposits}
            withdrawals={withdrawals}
            referralCount={referralCount}
            isLoading={isLoading}
            onNavigate={navigate}
            onTradeCompleted={fetchUserData}
            onDeposit={handleDeposit}
            onWithdraw={handleWithdraw}
            onCopyReferralCode={handleCopyReferralCode}
            onNavigateToVerification={handleNavigateToVerification}
            onNavigateToSettings={handleNavigateToSettings}
            settingsInitialTab={settingsInitialTab}
          />

          {/* Live Chart Section - only show on assets and trades tabs */}
          {shouldShowChart && (
            <div className="mt-6">
              <LiveChart />
            </div>
          )}
        </div>
      </div>

      {/* Transfer Modal */}
      <TransferModal
        isOpen={showTransferModal}
        onClose={handleCloseTransferModal}
        accountBalances={accountBalances}
        onTransfer={handleTransfer}
        checkTransferFee={checkTransferFee}
      />

      {/* Bottom Navigation for Mobile - Fixed positioned */}
      <BottomNavigation activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  );
};

export default UserDashboard;
