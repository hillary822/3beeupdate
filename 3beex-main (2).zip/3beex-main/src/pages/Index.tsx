import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { LoginForm } from "@/components/auth/LoginForm";
import { RegisterForm } from "@/components/auth/RegisterForm";
import { OtpVerificationForm } from "@/components/auth/OtpVerificationForm";
import HeroSection from "@/components/homepage/HeroSection";
import LiveMarketSection from "@/components/homepage/LiveMarketSection";
import BottomNavigation from "@/components/BottomNavigation";
import RealisticTradingChart from "@/components/dashboard/RealisticTradingChart";
import CryptoPriceTicker from "@/components/homepage/CryptoPriceTicker";
import { Home, BarChart3, TrendingUp, User } from "lucide-react";

interface RegisterFormData {
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
  referralCode: string;
  loginMethod: string;
  countryCode?: string;
  otp?: string;
}

const Index = () => {
  const [registerForm, setRegisterForm] = useState<RegisterFormData>({ 
    email: "", 
    phone: "",
    password: "", 
    confirmPassword: "",
    referralCode: "",
    loginMethod: "email",
    countryCode: "+1",
    otp: ""
  });

  const updateRegisterForm = (form: RegisterFormData) => {
    setRegisterForm(form);
  };
  const [otpSent, setOtpSent] = useState(false);
  const [otpLoading, setOtpLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const [canResend, setCanResend] = useState(false);

  const startResendTimer = () => {
    setCanResend(false);
    setResendTimer(30);
    const timer = setInterval(() => {
      setResendTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanResend(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };
  const [activeTab, setActiveTab] = useState("login");
  const [bottomNavTab, setBottomNavTab] = useState("assets");

  // Homepage-specific bottom navigation tabs
  const homepageTabs = [
    { id: "assets", label: "Assets", icon: Home },
    { id: "spot", label: "Spot", icon: BarChart3 },
    { id: "future", label: "Future", icon: TrendingUp },
    { id: "account", label: "Account", icon: User },
  ];
  const [showAuthForm, setShowAuthForm] = useState(false);
  const [showOtpVerification, setShowOtpVerification] = useState(false);
  const [pendingVerificationEmail, setPendingVerificationEmail] = useState("");
  const { signIn, signUp, verifyOtp, resendOtp, user, loading } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  console.log("Index component - loading:", loading, "user:", user?.email || 'none');

  // Check for referral code and tab parameter in URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const refCode = urlParams.get('ref');
    const tabParam = urlParams.get('tab');
    
    if (refCode) {
      console.log('Found referral code in URL:', refCode);
      setRegisterForm(prev => ({ ...prev, referralCode: refCode }));
      setActiveTab("register");
      setShowAuthForm(true);
      
      toast({
        title: "Referral Code Applied",
        description: `Using referral code: ${refCode}`,
      });
    } else if (tabParam) {
      setActiveTab(tabParam === 'register' ? 'register' : 'login');
      setShowAuthForm(true);
    }
  }, [toast]);

  useEffect(() => {
    if (user && !loading) {
      console.log("Redirecting user:", user.email);
      if (user.email === 'admin@3beetex.com') {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    }
  }, [user, loading, navigate]);

  const handleLogin = async (identifier: string, password: string, method: string) => {
    console.log("handleLogin called with:", { identifier, method });
    
    try {
      await signIn(identifier, password);
    } catch (error: any) {
      console.error("Login error:", error);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (registerForm.password !== registerForm.confirmPassword) {
      toast({
        title: "Registration Failed",
        description: "Passwords do not match",
        variant: "destructive",
      });
      return;
    }

    if (registerForm.loginMethod === "email" && !registerForm.email.trim()) {
      toast({
        title: "Registration Failed",
        description: "Email is required",
        variant: "destructive",
      });
      return;
    }

    // Check if OTP is required for email registration
    if (registerForm.loginMethod === "email" && otpSent && (!registerForm.otp || registerForm.otp.length !== 6)) {
      toast({
        title: "Registration Failed",
        description: "Please enter the 6-digit verification code sent to your email",
        variant: "destructive",
      });
      return;
    }

    if (registerForm.loginMethod === "phone" && !registerForm.phone.trim()) {
      toast({
        title: "Registration Failed",
        description: "Phone number is required",
        variant: "destructive",
      });
      return;
    }

    if (!registerForm.referralCode.trim()) {
      toast({
        title: "Registration Failed",
        description: "Referral code is required for registration",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const identifier = registerForm.loginMethod === "email" ? registerForm.email : registerForm.phone;
      
      // If it's email registration with inline OTP, verify OTP first
      if (registerForm.loginMethod === "email" && otpSent && registerForm.otp) {
        await verifyOtp(registerForm.email, registerForm.otp);
        // User will be redirected automatically by the useEffect when auth state changes
        return;
      }
      
      const result = await signUp(
        identifier, 
        registerForm.password, 
        registerForm.referralCode.trim()
      );
      
      // If email signup requires verification and we haven't implemented inline OTP, show OTP form
      if (result?.needsVerification && registerForm.loginMethod === "email" && !otpSent) {
        setPendingVerificationEmail(registerForm.email);
        setShowOtpVerification(true);
        setShowAuthForm(false);
      }
      // For phone signup, user should be logged in automatically
      
    } catch (error: any) {
      console.error("Registration error in handleRegister:", error);
      
      // If it's a "user already exists" error for email, suggest they might need to verify
      if (error.message?.includes('User already registered') && registerForm.loginMethod === "email") {
        toast({
          title: "Account Needs Verification",
          description: "This email might need verification. Try entering your email to resend the verification code.",
          variant: "default",
        });
        
        // Show OTP form to allow verification attempt
        setPendingVerificationEmail(registerForm.email);
        setShowOtpVerification(true);
        setShowAuthForm(false);
      }
    }
  };

  const handleOtpVerify = async (otp: string) => {
    try {
      await verifyOtp(pendingVerificationEmail, otp);
      setShowOtpVerification(false);
      setPendingVerificationEmail("");
      // User will be redirected automatically by the useEffect when auth state changes
    } catch (error: any) {
      console.error("OTP verification error:", error);
    }
  };

  const handleResendOtp = async () => {
    try {
      await resendOtp(pendingVerificationEmail);
    } catch (error: any) {
      console.error("Resend OTP error:", error);
    }
  };

  const handleSendOtp = async () => {
    if (!registerForm.email) {
      toast({
        title: "Email Required",
        description: "Please enter your email address",
        variant: "destructive",
      });
      return;
    }

    if (!registerForm.password) {
      toast({
        title: "Password Required",
        description: "Please enter your password first",
        variant: "destructive",
      });
      return;
    }

    setOtpLoading(true);
    try {
      // First try to signup to trigger OTP
      try {
        await signUp(registerForm.email, registerForm.password, registerForm.referralCode || "");
      } catch (signupError: any) {
        // If user already exists, just resend OTP
        if (signupError.message?.includes('User already registered')) {
          await resendOtp(registerForm.email);
        } else {
          throw signupError;
        }
      }
      
      setOtpSent(true);
      startResendTimer();
      toast({
        title: "OTP Sent",
        description: "Please check your email for the verification code",
      });
    } catch (error: any) {
      console.error("Send OTP error:", error);
      toast({
        title: "Failed to Send OTP",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    } finally {
      setOtpLoading(false);
    }
  };

  const handleResendOtpInline = async () => {
    if (!registerForm.email || !canResend) return;
    
    setOtpLoading(true);
    try {
      await resendOtp(registerForm.email);
      startResendTimer();
      toast({
        title: "OTP Resent",
        description: "A new verification code has been sent to your email.",
      });
    } catch (error) {
      console.error("Failed to resend OTP:", error);
    } finally {
      setOtpLoading(false);
    }
  };

  const handleShowAuth = () => {
    setShowAuthForm(true);
  };

  const handleBottomNavChange = (tab: string) => {
    setBottomNavTab(tab);
    if (tab === "account") {
      setShowAuthForm(true);
    }
  };

  const handleBackToAuth = () => {
    setShowOtpVerification(false);
    setPendingVerificationEmail("");
    setActiveTab("register");
    setShowAuthForm(true);
  };

  // Show loading screen only during initial auth check
  if (loading) {
    console.log("Showing loading screen");
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-white">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p>Loading authentication...</p>
          <p className="text-sm text-slate-400 mt-2">If this takes too long, try refreshing the page</p>
        </div>
      </div>
    );
  }

  // Don't show login form if user is authenticated (they'll be redirected)
  if (user) {
    console.log("User authenticated, redirecting...");
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-white">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p>Redirecting to dashboard...</p>
        </div>
      </div>
    );
  }

  // Show OTP verification form
  if (showOtpVerification) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">3BEET EXCHANGE</h1>
            <p className="text-slate-300">Professional Trading Platform</p>
            <Badge variant="secondary" className="mt-2">Invite Only</Badge>
          </div>

          <Card className="backdrop-blur-sm bg-white/10 border-white/20">
            <CardHeader>
              <CardTitle className="text-white">Verify Your Account</CardTitle>
              <CardDescription className="text-slate-300">
                Complete your registration by verifying your email
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Button 
                  variant="ghost" 
                  onClick={handleBackToAuth}
                  className="text-slate-300 hover:text-white"
                >
                  ← Back to Registration
                </Button>
              </div>
              
              <OtpVerificationForm
                email={pendingVerificationEmail}
                onVerify={handleOtpVerify}
                onResend={handleResendOtp}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Show auth form if requested
  if (showAuthForm) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">3BEET EXCHANGE</h1>
            <p className="text-slate-300">Professional Trading Platform</p>
            <Badge variant="secondary" className="mt-2">Invite Only</Badge>
          </div>

          <Card className="backdrop-blur-sm bg-white/10 border-white/20">
            <CardHeader>
              <CardTitle className="text-white">Access Platform</CardTitle>
              <CardDescription className="text-slate-300">
                Login to your account or register with a referral code
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="login">Login</TabsTrigger>
                  <TabsTrigger value="register">Register</TabsTrigger>
                </TabsList>
                
                <TabsContent value="login">
                  <LoginForm onSubmit={handleLogin} />
                </TabsContent>
                
                <TabsContent value="register">
                  <RegisterForm 
                    registerForm={registerForm}
                    setRegisterForm={updateRegisterForm}
                    onSubmit={handleRegister}
                    isValidatingReferral={false}
                    onSendOtp={handleSendOtp}
                    otpSent={otpSent}
                    otpLoading={otpLoading}
                    onResendOtp={handleResendOtpInline}
                    canResend={canResend}
                    resendTimer={resendTimer}
                  />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Show homepage by default
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 pb-20">
      <HeroSection onShowAuth={handleShowAuth} />
      
      {/* Content based on bottom nav tab */}
      {bottomNavTab === "assets" && <LiveMarketSection />}
      {(bottomNavTab === "spot" || bottomNavTab === "future") && (
        <div className="px-4 py-6">
          <div className="text-center mb-4">
            <h2 className="text-2xl font-bold text-white">
              {bottomNavTab === "spot" ? "Spot Trading" : "Futures Trading"}
            </h2>
            <p className="text-slate-300">
              {bottomNavTab === "spot" ? "Trade cryptocurrencies instantly" : "Trade with leverage and futures contracts"}
            </p>
          </div>
          <RealisticTradingChart />
        </div>
      )}
      
      {/* Footer */}
      <footer className="mt-8 mb-4">
        <CryptoPriceTicker />
        <div className="px-4 py-2">
          <p className="text-slate-300 text-sm leading-relaxed text-center">
            3BEET EXCHANGE Is A Long Term Investment/Crypto Currency Exchange With Win-Win Corporation And Advanced Trading Technology
          </p>
        </div>
      </footer>
      
      <BottomNavigation activeTab={bottomNavTab} onTabChange={handleBottomNavChange} tabs={homepageTabs} />
    </div>
  );
};

export default Index;
