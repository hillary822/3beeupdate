
import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import HeroSection from "@/components/homepage/HeroSection";
import AuthModal from "@/components/homepage/AuthModal";
import NavigationGrid from "@/components/homepage/NavigationGrid";
import CopyTradingSection from "@/components/homepage/CopyTradingSection";
import TradingTabs from "@/components/homepage/TradingTabs";
import LiveMarketSection from "@/components/homepage/LiveMarketSection";
import BottomNavigation from "@/components/BottomNavigation";

const Homepage = () => {
  const [showAuth, setShowAuth] = useState(false);
  const [activeTab, setActiveTab] = useState("assets");
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user && !loading) {
      if (user.email === 'admin@3beetex.com') {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    }
  }, [user, loading, navigate]);

  // Check for referral code and redirect to main registration page
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const refCode = urlParams.get('ref');
    if (refCode) {
      console.log('Referral code found on homepage, redirecting to registration:', refCode);
      // Redirect to the main index page with referral code
      navigate(`/?ref=${refCode}`);
    }
  }, [navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-white">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  if (user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-white">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p>Redirecting to dashboard...</p>
        </div>
      </div>
    );
  }

  if (showAuth) {
    return <AuthModal onClose={() => setShowAuth(false)} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex flex-col w-full overflow-x-hidden">
      <div className="flex-1 pb-16 overflow-x-hidden">
        <HeroSection onShowAuth={() => setShowAuth(true)} />
        <NavigationGrid onShowAuth={() => setShowAuth(true)} />
        <CopyTradingSection onShowAuth={() => setShowAuth(true)} />
        <TradingTabs />
        <LiveMarketSection />
      </div>
      <div className="flex-shrink-0">
        <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
      </div>
    </div>
  );
};

export default Homepage;
