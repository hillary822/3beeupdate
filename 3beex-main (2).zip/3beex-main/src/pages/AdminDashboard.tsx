
import { useEffect } from "react";
import { useAdminData } from "@/hooks/useAdminData";
import AdminStats from "@/components/admin/AdminStats";
import AdminHeader from "@/components/admin/AdminHeader";
import AdminTabs from "@/components/admin/AdminTabs";
import LanguageTranslator from "@/components/LanguageTranslator";

const AdminDashboard = () => {

  const {
    isLoading,
    isAdmin,
    users,
    withdrawals,
    deposits,
    tradeCodes,
    kycVerifications,
    handleUserUpdated,
    handleManageBalance,
    handleTradeCodeGenerated,
    handleWithdrawalUpdate,
  } = useAdminData();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <div>Loading admin dashboard...</div>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen w-full bg-slate-900 text-white overflow-x-hidden">
      {/* Language Translator in top right */}
      <div className="absolute top-4 right-4 z-20">
        <LanguageTranslator />
      </div>
      
      <div className="w-full p-4 lg:p-6">
        <div className="w-full max-w-full">
          <AdminHeader />
          <AdminStats users={users} withdrawals={withdrawals} deposits={deposits} kycVerifications={kycVerifications} />
          <AdminTabs
            users={users}
            withdrawals={withdrawals}
            tradeCodes={tradeCodes}
            onUserUpdated={handleUserUpdated}
            onManageBalance={handleManageBalance}
            onTradeCodeGenerated={handleTradeCodeGenerated}
            onWithdrawalUpdate={handleWithdrawalUpdate}
          />
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
