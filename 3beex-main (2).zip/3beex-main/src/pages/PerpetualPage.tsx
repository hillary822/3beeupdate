
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, TrendingUp, TrendingDown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import MarketPairSelector from "@/components/trading/MarketPairSelector";
import TradingChart from "@/components/trading/TradingChart";
import OrderBook from "@/components/trading/OrderBook";
import TradingForm from "@/components/trading/TradingForm";

const PerpetualPage = () => {
  const navigate = useNavigate();
  const [selectedPair, setSelectedPair] = useState("BTC-USDT");
  const [currentPrice, setCurrentPrice] = useState(0);
  const [priceChange, setPriceChange] = useState(0);
  const [leverage, setLeverage] = useState(10);

  // Calculate price change percentage for display
  const priceChangePercent = currentPrice > 0 ? (priceChange / currentPrice) * 100 : 0;

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Header */}
      <div className="border-b border-slate-800 p-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              onClick={() => navigate("/dashboard")}
              className="text-slate-400 hover:text-white"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-lg md:text-xl font-semibold">Perpetual Futures</h1>
          </div>
          
          <div className="flex flex-col md:flex-row items-end md:items-center gap-2 md:gap-6">
            <div className="flex items-center gap-2 md:gap-4">
              <div className="text-xs md:text-sm text-slate-400">
                Leverage: <span className="text-yellow-400">{leverage}x</span>
              </div>
              <div className="flex gap-1 md:gap-2">
                {[5, 10, 20, 50, 100].map(lev => (
                  <Button
                    key={lev}
                    variant={leverage === lev ? "default" : "outline"}
                    size="sm"
                    onClick={() => setLeverage(lev)}
                    className="text-xs px-2 py-1"
                  >
                    {lev}x
                  </Button>
                ))}
              </div>
            </div>
            
            <div className="text-right">
              <div className="text-lg md:text-2xl font-bold">
                {currentPrice > 0 ? `$${currentPrice.toLocaleString()}` : 'Loading...'}
              </div>
              {currentPrice > 0 && (
                <div className={`flex items-center gap-1 text-xs md:text-sm ${priceChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {priceChange >= 0 ? <TrendingUp className="h-3 w-3 md:h-4 md:w-4" /> : <TrendingDown className="h-3 w-3 md:h-4 md:w-4" />}
                  {priceChange >= 0 ? '+' : ''}{priceChange.toFixed(2)} ({priceChangePercent.toFixed(2)}%)
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-2 md:p-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-2 md:gap-4 min-h-[calc(100vh-120px)]">
          {/* Market Pairs - Full width on mobile, left column on desktop */}
          <div className="lg:col-span-3 order-1">
            <MarketPairSelector 
              selectedPair={selectedPair} 
              onPairSelect={setSelectedPair}
              onPriceUpdate={(price) => {
                setCurrentPrice(price);
                setPriceChange((Math.random() - 0.5) * (price * 0.03)); // More volatile for futures
              }}
              type="perpetual"
            />
          </div>

          {/* Chart - Full width on mobile, center column on desktop */}
          <div className="lg:col-span-6 order-2">
            <TradingChart pair={selectedPair} currentPrice={currentPrice} />
          </div>

          {/* Trading Panel - Full width on mobile, right column on desktop */}
          <div className="lg:col-span-3 order-3 space-y-2 md:space-y-4">
            <TradingForm 
              pair={selectedPair} 
              currentPrice={currentPrice} 
              type="perpetual"
              leverage={leverage}
            />
            <OrderBook currentPrice={currentPrice} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerpetualPage;
