import { supabase } from '@/integrations/supabase/client';

export const signIn = async (identifier: string, password: string): Promise<void> => {
  console.log("signIn - Attempting sign in for:", identifier);
  
  try {
    // Check if identifier is email or phone
    const isEmail = identifier.includes('@');
    
    const authData = isEmail 
      ? { email: identifier, password }
      : { phone: identifier, password };
    
    const { error } = await supabase.auth.signInWithPassword(authData);
    if (error) {
      console.error("signIn - Error:", error);
      throw error;
    }
    console.log("signIn - Success");
  } catch (error) {
    console.error("signIn - Failed:", error);
    throw error;
  }
};

export const signUp = async (identifier: string, password: string, username: string, referralCode?: string): Promise<void> => {
  console.log("signUp - Attempting sign up for:", identifier);
  
  try {
    const isEmail = identifier.includes('@');
    const redirectUrl = `${window.location.origin}/`;
    
    const authData = isEmail 
      ? {
          email: identifier,
          password,
          options: {
            data: {
              username,
              referral_code: referralCode
            },
            emailRedirectTo: redirectUrl
          }
        }
      : {
          phone: identifier,
          password,
          options: {
            data: {
              username,
              referral_code: referralCode
            }
          }
        };
    
    const { data, error } = await supabase.auth.signUp(authData);
    
    if (error) {
      console.error("signUp - Error:", error);
      
      // Handle specific case where user already exists
      if (error.message.includes('User already registered') || error.message.includes('already been registered')) {
        // Try to sign them in instead
        console.log("signUp - User exists, attempting sign in instead");
        await signIn(identifier, password);
        return;
      }
      
      throw error;
    }
    
    // If user was created successfully, they should be automatically signed in
    console.log("signUp - Success, user should be logged in automatically");
  } catch (error) {
    console.error("signUp - Failed:", error);
    throw error;
  }
};

export const signOut = async (): Promise<void> => {
  console.log("signOut - Attempting sign out");
  
  try {
    // First, clear local storage of all Supabase auth items
    if (typeof window !== 'undefined' && window.localStorage) {
      console.log("signOut - Clearing localStorage auth items");
      Object.keys(localStorage).forEach(key => {
        if (key.startsWith('supabase.auth.')) {
          localStorage.removeItem(key);
        }
      });
    }

    // Then sign out from Supabase
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error("signOut - Error:", error);
      throw error;
    }
    
    // Force redirect to home page
    window.location.href = '/';
    
    console.log("signOut - Success");
  } catch (error) {
    console.error("signOut - Error:", error);
    
    // Even on error, redirect to home page
    window.location.href = '/';
    
    throw error;
  }
};

// Robust forced logout that works even when session is missing
export const forceLogout = async (): Promise<void> => {
  try {
    console.log("forceLogout - Forcing logout");
    
    // Clear localStorage first
    if (typeof window !== 'undefined' && window.localStorage) {
      console.log("forceLogout - Clearing localStorage auth items");
      Object.keys(localStorage).forEach(key => {
        if (key.startsWith('supabase.auth.')) {
          localStorage.removeItem(key);
        }
      });
    }
    
    // Try standard logout (may fail if no session)
    try {
      await supabase.auth.signOut();
      console.log("forceLogout - Standard signOut succeeded");
    } catch (err) {
      console.error("forceLogout - Standard signOut failed:", err);
      // Continue anyway
    }
    
    // Force redirect regardless of auth API result
    console.log("forceLogout - Redirecting to home page");
    window.location.href = '/';
  } catch (error) {
    console.error("forceLogout - Error:", error);
    // Force redirect even on error
    window.location.href = '/';
  }
};