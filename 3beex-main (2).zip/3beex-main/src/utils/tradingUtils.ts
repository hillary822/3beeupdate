
import { supabase } from '@/integrations/supabase/client';
import { TradeCodeResponse, CompleteTradeResponse } from '@/types/trading';

export const executeTrade = async (
  userId: string,
  type: 'BUY' | 'SELL',
  asset: string,
  amount: number
) => {
  // Generate trade code
  const { data: tradeCodeData } = await supabase.rpc('generate_trade_code');
  
  const { error } = await supabase
    .from('trades')
    .insert({
      user_id: userId,
      trade_code: tradeCodeData,
      type,
      asset,
      amount,
      status: 'completed',
      profit: (Math.random() - 0.4) * amount * 0.1 // Random profit/loss
    });

  if (error) throw error;
};

export const processTradeCode = async (
  code: string,
  userId: string
): Promise<TradeCodeResponse> => {
  console.log('Using trade code:', code, 'for user:', userId);

  const { data, error } = await supabase.rpc('use_trade_code', {
    code_input: code,
    user_id_input: userId
  });

  if (error) {
    console.error('RPC error:', error);
    throw error;
  }

  console.log('Trade code response:', data);
  return data as unknown as TradeCodeResponse;
};

export const completeTradeAfterDelay = async (
  tradeId: string,
  durationMinutes: number,
  onComplete: (response: CompleteTradeResponse) => void,
  onError: (error: any) => void
) => {
  const durationMs = durationMinutes * 60 * 1000;
  
  console.log(`Setting up trade completion for ${tradeId} in ${durationMinutes} minutes`);
  
  // Schedule the trade completion
  const completeTradeFunction = async () => {
    try {
      console.log('Attempting to complete trade:', tradeId);
      const { data: completeData, error: completeError } = await supabase.rpc('complete_trade', {
        trade_id_input: tradeId
      });

      if (completeError) {
        console.error('Complete trade error:', completeError);
        throw completeError;
      }

      console.log('Trade completion response:', completeData);
      const completeResponse = completeData as unknown as CompleteTradeResponse;
      onComplete(completeResponse);
    } catch (error) {
      console.error('Error completing trade:', error);
      onError(error);
    }
  };

  // Primary timer
  setTimeout(completeTradeFunction, durationMs);
  
  // Backup periodic check every minute after the expected completion time
  setTimeout(() => {
    const checkInterval = setInterval(async () => {
      try {
        // Check if trade is still active
        const { data: tradeData } = await supabase
          .from('trades')
          .select('status')
          .eq('id', tradeId)
          .single();

        if (tradeData?.status === 'active') {
          console.log('Trade still active, attempting completion...');
          await completeTradeFunction();
          clearInterval(checkInterval);
        } else {
          // Trade is no longer active, stop checking
          clearInterval(checkInterval);
        }
      } catch (error) {
        console.error('Error in backup check:', error);
      }
    }, 60000); // Check every minute

    // Stop checking after 10 minutes
    setTimeout(() => clearInterval(checkInterval), 600000);
  }, durationMs + 60000); // Start checking 1 minute after expected completion
};

export const processWithdrawal = async (
  userId: string,
  amount: number,
  address: string
) => {
  const { error } = await supabase
    .from('withdrawals')
    .insert({
      user_id: userId,
      amount,
      address,
      status: 'pending'
    });

  if (error) throw error;
};
