
import { supabase } from '@/integrations/supabase/client';
import { User } from '@supabase/supabase-js';
import { Profile } from '@/types/auth';

export const generateReferralCode = (): string => {
  return Math.random().toString(36).substr(2, 8).toUpperCase();
};

export const createProfile = async (user: User): Promise<Profile | null> => {
  console.log("createProfile - Creating profile for user:", user.email);
  try {
    const newProfile = {
      id: user.id,
      username: user.user_metadata?.username || user.email?.split('@')[0] || 'user',
      email: user.email || '',
      balance: 0.00,
      exchange_balance: 0.00,
      trade_balance: 0.00,
      perpetual_balance: 0.00,
      verified: false,
      vip: false,
      vip_level: 0,
      referral_code: generateReferralCode(),
      referred_by: user.user_metadata?.referral_code ? null : undefined,
      user_id: 1001 // This will be overridden by the sequence in the database
    };

    console.log("createProfile - Attempting to insert:", newProfile);

    const { data, error } = await supabase
      .from('profiles')
      .insert(newProfile)
      .select()
      .single();

    if (error) {
      console.error('createProfile - Error:', error);
      // If profile already exists, try to fetch it
      if (error.code === '23505') {
        console.log('createProfile - Profile already exists, fetching...');
        return await fetchProfile(user.id);
      }
      return null;
    }

    console.log("createProfile - Profile created successfully:", data);
    return data;
  } catch (error) {
    console.error('createProfile - Exception:', error);
    return null;
  }
};

export const fetchProfile = async (userId: string): Promise<Profile | null> => {
  console.log("fetchProfile - Starting for user:", userId);
  try {
    // Add timeout to prevent hanging
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Profile fetch timeout')), 8000)
    );

    const fetchPromise = supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();

    const { data, error } = await Promise.race([fetchPromise, timeoutPromise]) as any;
    
    if (error) {
      console.error('fetchProfile - Error:', error);
      if (error.code === 'PGRST116') {
        console.log('fetchProfile - No profile found');
        return null;
      }
      return null;
    }
    
    console.log("fetchProfile - Success:", data);
    return data;
  } catch (error) {
    console.error('fetchProfile - Exception:', error);
    return null;
  }
};
