import { supabase } from '@/integrations/supabase/client';

/**
 * Force logout a user by clearing all auth state
 * Works even when there's no active session
 */
export const forceLogout = async (): Promise<void> => {
  try {
    // Try standard logout first
    await supabase.auth.signOut({
      scope: 'local' // Only clear local session
    }).catch(err => {
      console.log('Initial signout attempt failed:', err);
    });
    
    // Clear all local storage items related to auth
    if (typeof window !== 'undefined') {
      localStorage.removeItem('supabase.auth.token');
      localStorage.removeItem('supabase.auth.expires_at');
      localStorage.removeItem('supabase.auth.refresh_token');
      
      // Iterate through localStorage and remove any supabase auth items
      Object.keys(localStorage).forEach(key => {
        if (key.startsWith('supabase.auth.')) {
          localStorage.removeItem(key);
        }
      });
    }
    
    // Redirect to home page to complete logout
    window.location.href = '/';
    
  } catch (error) {
    console.error('Force logout error:', error);
    // Ensure redirect happens even if there's an error
    window.location.href = '/';
  }
};