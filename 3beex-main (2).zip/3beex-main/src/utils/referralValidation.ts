
import { supabase } from '@/integrations/supabase/client';

export const validateReferralCode = async (code: string): Promise<boolean> => {
  if (!code.trim()) return false; // Empty referral code is invalid (required)
  
  try {
    console.log('Validating referral code:', code);
    const { data, error } = await supabase
      .from('profiles')
      .select('id, username, referral_code')
      .eq('referral_code', code.trim())
      .maybeSingle();
    
    if (error) {
      console.error('Referral validation error:', error);
      return false;
    }
    
    console.log('Referral code validation result:', data);
    return !!data;
  } catch (error) {
    console.error('Error validating referral code:', error);
    return false;
  }
};

export const validateReferralCodeForSignup = async (referralCode: string): Promise<void> => {
  if (!referralCode.trim()) {
    throw new Error('Referral code is required'); // Now required
  }
  
  console.log('Validating referral code before signup:', referralCode);
  const { data: referrerData, error: referralError } = await supabase
    .from('profiles')
    .select('id, username, referral_code')
    .eq('referral_code', referralCode.trim())
    .maybeSingle();
  
  if (referralError) {
    console.error('Referral validation error:', referralError);
    throw new Error('Error validating referral code');
  }
  
  if (!referrerData) {
    console.log('No referrer found for code:', referralCode);
    throw new Error('Invalid referral code provided');
  }
  
  console.log('Referral code validated successfully:', referrerData);
};
