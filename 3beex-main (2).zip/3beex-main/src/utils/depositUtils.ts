
import { supabase } from '@/integrations/supabase/client';

export const createDeposit = async (
  userId: string,
  amount: number,
  paymentMethodId: string,
  paymentMethodName: string,
  walletAddress: string,
  transactionHash?: string
) => {
  console.log('Creating deposit with params:', {
    userId,
    amount,
    paymentMethodId,
    paymentMethodName,
    walletAddress,
    transactionHash
  });

  const { data, error } = await supabase
    .from('deposits')
    .insert({
      user_id: userId,
      amount,
      payment_method_id: paymentMethodId,
      payment_method_name: paymentMethodName,
      wallet_address: walletAddress,
      transaction_hash: transactionHash,
      method: 'crypto_deposit',
      status: 'pending'
    })
    .select()
    .single();

  if (error) {
    console.error('Error creating deposit:', error);
    throw error;
  }

  console.log('Deposit created successfully:', data);
  return data;
};

export const approveDeposit = async (depositId: string) => {
  try {
    // Try using the edge function first
    const { data, error } = await supabase.functions.invoke('admin-update-deposit', {
      body: {
        deposit_id: depositId,
        new_status: 'completed'
      }
    });

    if (error) {
      console.log('Edge function failed, falling back to direct DB operations:', error);
      
      // Fallback to direct database operations
      const { data: deposit, error: fetchError } = await supabase
        .from('deposits')
        .select('user_id, amount, status')
        .eq('id', depositId)
        .eq('status', 'pending')
        .single();

      if (fetchError || !deposit) {
        throw new Error('Deposit not found or already processed');
      }

      // Update deposit status to completed
      const { error: updateError } = await supabase
        .from('deposits')
        .update({ 
          status: 'completed',
          updated_at: new Date().toISOString()
        })
        .eq('id', depositId);

      if (updateError) throw updateError;

      // Update user balance
      const { error: balanceError } = await supabase.rpc('update_user_balance', {
        target_user_id: deposit.user_id,
        balance_amount: deposit.amount
      });

      if (balanceError) throw balanceError;
      
      return { success: true };
    }

    if (!data?.success) {
      throw new Error(data?.error || 'Failed to approve deposit');
    }

    return data;
  } catch (error) {
    console.error('Error in approveDeposit:', error);
    throw error;
  }
};

export const rejectDeposit = async (depositId: string, adminNote?: string) => {
  try {
    // Try using the edge function first
    const { data, error } = await supabase.functions.invoke('admin-update-deposit', {
      body: {
        deposit_id: depositId,
        new_status: 'rejected',
        admin_note: adminNote
      }
    });

    if (error) {
      console.log('Edge function failed, falling back to direct DB operations:', error);
      
      // Fallback to direct database operations
      const { error: updateError } = await supabase
        .from('deposits')
        .update({ 
          status: 'rejected',
          admin_note: adminNote,
          updated_at: new Date().toISOString()
        })
        .eq('id', depositId);

      if (updateError) throw updateError;
      
      return { success: true };
    }

    if (!data?.success) {
      throw new Error(data?.error || 'Failed to reject deposit');
    }

    return data;
  } catch (error) {
    console.error('Error in rejectDeposit:', error);
    throw error;
  }
};
