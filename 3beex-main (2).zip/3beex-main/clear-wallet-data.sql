-- Script to clear existing wallet data for testing
-- This will allow you to test the chain selection fix

-- Delete existing user wallet records
-- Replace 'your-user-id-here' with your actual user ID
DELETE FROM user_wallets 
WHERE user_id = 'your-user-id-here';

-- You can also delete all wallet records if testing with multiple users:
-- DELETE FROM user_wallets;

-- Verify deletion
SELECT user_id, currency, chain, address, created_at 
FROM user_wallets 
WHERE user_id = 'your-user-id-here'; 