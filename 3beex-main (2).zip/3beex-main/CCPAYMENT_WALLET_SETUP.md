# CCPayment Wallet System Setup

This guide explains how to set up the CCPayment wallet system that generates deposit addresses using CCPayment's API.

## Overview

The system consists of:

1. **CCPayment Proxy Server** (`ccpayment-proxy/server.js`) - Handles CCPayment API calls
2. **Supabase Edge Function** (`supabase/functions/assign-wallet/`) - Manages wallet assignment
3. **Database Table** (`user_wallets`) - Stores generated wallet addresses
4. **Frontend Integration** - Uses the wallet assignment system

## Setup Steps

### 1. Database Setup

Run the SQL script in your Supabase SQL Editor:

```sql
-- Copy and paste the contents of ccpayment-wallet-setup.sql
-- This creates the user_wallets table, policies, and functions
```

Or apply the migration:

```bash
# If using local Supabase development
supabase migration up
```

### 2. Environment Variables

Add these environment variables to your CCPayment proxy server:

```bash
# CCPayment API Credentials
CCPAYMENT_APP_ID=your_ccpayment_app_id
CCPAYMENT_APP_SECRET=your_ccpayment_app_secret

# Server Configuration
PORT=3000
```

Add this to your Supabase Edge Function environment:

```bash
# CCPayment Proxy URL
CCPAYMENT_PROXY_URL=https://your-proxy-domain.com
```

### 3. Deploy CCPayment Proxy Server

The proxy server needs to be deployed and accessible to your Supabase Edge Functions.

**Option A: Deploy to Render/Railway/Heroku**

1. Push the `ccpayment-proxy/` folder to your hosting service
2. Set the environment variables
3. Note the deployed URL

**Option B: Local Development**

```bash
cd ccpayment-proxy
npm install
npm start
```

### 4. Update Supabase Edge Function

The `assign-wallet` function has been updated to:

- Call the CCPayment proxy to generate addresses
- Store addresses in the `user_wallets` table
- Return existing addresses if already assigned

## API Usage

### Generate/Get Wallet Address

**Endpoint:** `POST /functions/v1/assign-wallet`

**Request:**

```json
{
  "userId": "user-uuid-here",
  "currency": "USDT",
  "chain": "BSC"
}
```

**Response:**

```json
{
  "success": true,
  "wallet": {
    "id": "wallet-uuid",
    "address": "0x1234567890abcdef...",
    "currency": "USDT",
    "chain": "BSC",
    "memo": "",
    "assigned_at": "2024-01-01T00:00:00Z"
  },
  "message": "New wallet assigned successfully"
}
```

### CCPayment Proxy Endpoint

**Endpoint:** `POST /generate-wallet`

**Request:**

```json
{
  "userId": "unique-user-id",
  "chain": "BSC"
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "address": "0x1234567890abcdef...",
    "memo": "",
    "chain": "BSC",
    "userId": "unique-user-id"
  },
  "message": "Wallet address generated successfully"
}
```

## Supported Chains

The system supports any chain that CCPayment supports. Common chains:

- BSC (Binance Smart Chain)
- ETH (Ethereum)
- TRX (Tron)
- MATIC (Polygon)

## Database Schema

### user_wallets Table

```sql
CREATE TABLE public.user_wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  address TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USDT',
  chain TEXT NOT NULL DEFAULT 'BSC',
  memo TEXT,
  provider TEXT NOT NULL DEFAULT 'ccpayment',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id, currency, chain)
);
```

## Security Features

1. **Row Level Security (RLS)** - Users can only see their own wallets
2. **Admin Access** - Admins can view all wallets
3. **System Insertion** - Only the system can create new wallet records
4. **Unique Constraints** - One wallet per user per currency/chain combination

## Troubleshooting

### Common Issues

1. **Function not found error**

   - Run the `ccpayment-wallet-setup.sql` script in Supabase

2. **CCPayment API errors**

   - Check your APP_ID and APP_SECRET
   - Verify the proxy server is running and accessible
   - Check CCPayment API limits (1000 addresses per APP_ID)

3. **CORS errors**
   - Ensure the proxy server is properly configured
   - Check that the CCPAYMENT_PROXY_URL is correct

### Logs

Check logs in:

- Supabase Edge Function logs
- CCPayment proxy server logs
- Browser network tab for frontend errors

## Migration from Old System

If you were using the old `pre_generated_wallets` system:

1. The new system will work alongside the old system
2. New wallet requests will use CCPayment
3. You can gradually migrate users to the new system
4. Old wallet assignments will continue to work

## Next Steps

1. Test the wallet generation in your development environment
2. Deploy the proxy server to production
3. Update your frontend to handle the new wallet format
4. Monitor CCPayment usage and limits
5. Set up webhook handling for payment notifications (separate setup)
