
-- Create enum for verification types
CREATE TYPE public.verification_type AS ENUM ('basic', 'advanced');

-- Create enum for verification statuses
CREATE TYPE public.verification_status AS ENUM ('pending', 'approved', 'rejected');

-- Create new KYC verification table
CREATE TABLE public.kyc_verifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  verification_type public.verification_type NOT NULL,
  status public.verification_status NOT NULL DEFAULT 'pending',
  
  -- Basic verification fields
  full_name TEXT,
  country TEXT,
  state TEXT,
  id_card_number TEXT,
  
  -- Advanced verification file paths
  id_front_path TEXT,
  id_back_path TEXT,
  selfie_with_id_path TEXT,
  
  -- Metadata
  submitted_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  reviewed_at TIMESTAMP WITH TIME ZONE,
  reviewed_by UUID REFERENCES public.profiles(id),
  admin_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Ensure one verification per type per user
  UNIQUE(user_id, verification_type)
);

-- Enable RLS on kyc_verifications table
ALTER TABLE public.kyc_verifications ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for kyc_verifications
CREATE POLICY "Users can view their own KYC verifications" 
  ON public.kyc_verifications 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own KYC verifications" 
  ON public.kyc_verifications 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own pending KYC verifications" 
  ON public.kyc_verifications 
  FOR UPDATE 
  USING (auth.uid() = user_id AND status = 'pending');

CREATE POLICY "Admins can manage all KYC verifications" 
  ON public.kyc_verifications 
  FOR ALL 
  USING (public.is_admin_user());

-- Update storage bucket for KYC documents (rename existing one)
UPDATE storage.buckets 
SET name = 'kyc-documents' 
WHERE name = 'verification-documents';

-- Update storage policies for the renamed bucket
DROP POLICY IF EXISTS "Users can upload their own verification documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can view their own verification documents" ON storage.objects;
DROP POLICY IF EXISTS "Admins can view all verification documents" ON storage.objects;

CREATE POLICY "Users can upload their own KYC documents"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'kyc-documents' 
    AND auth.uid() IS NOT NULL
  );

CREATE POLICY "Users can view their own KYC documents"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'kyc-documents' 
    AND auth.uid() IS NOT NULL
  );

CREATE POLICY "Admins can view all KYC documents"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'kyc-documents' 
    AND public.is_admin_user()
  );

-- Add indexes for performance
CREATE INDEX idx_kyc_verifications_user_type ON public.kyc_verifications(user_id, verification_type);
CREATE INDEX idx_kyc_verifications_status ON public.kyc_verifications(status);
