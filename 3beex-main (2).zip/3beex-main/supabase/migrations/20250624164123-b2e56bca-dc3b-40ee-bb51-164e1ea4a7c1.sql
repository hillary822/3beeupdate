
-- Create a deposits table if it doesn't exist with proper structure
CREATE TABLE IF NOT EXISTS public.deposits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount NUMERIC(12,2) NOT NULL,
  payment_method_id UUID,
  payment_method_name TEXT,
  wallet_address TEXT,
  transaction_hash TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'rejected')),
  method TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on deposits
ALTER TABLE public.deposits ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for deposits
DROP POLICY IF EXISTS "Users can view their own deposits" ON public.deposits;
CREATE POLICY "Users can view their own deposits" 
  ON public.deposits 
  FOR SELECT 
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can create their own deposits" ON public.deposits;
CREATE POLICY "Users can create their own deposits" 
  ON public.deposits 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can view all deposits" ON public.deposits;
CREATE POLICY "Admins can view all deposits" 
  ON public.deposits 
  FOR ALL 
  USING (public.is_admin_user());

-- Create a function to handle admin balance credits that creates deposit records
CREATE OR REPLACE FUNCTION public.admin_credit_balance(
  target_user_id UUID,
  credit_amount NUMERIC,
  admin_note TEXT DEFAULT 'Admin credit'
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result JSON;
BEGIN
  -- Check if the current user is admin
  IF NOT public.is_admin_user() THEN
    RETURN json_build_object('success', false, 'error', 'Unauthorized');
  END IF;

  -- Insert a deposit record for tracking
  INSERT INTO public.deposits (
    user_id, 
    amount, 
    payment_method_name, 
    method, 
    status,
    wallet_address
  ) VALUES (
    target_user_id,
    credit_amount,
    'Admin Credit',
    'admin_credit',
    'completed',
    admin_note
  );

  -- Update user balance
  UPDATE public.profiles 
  SET exchange_balance = exchange_balance + credit_amount,
      updated_at = NOW()
  WHERE id = target_user_id;

  RETURN json_build_object('success', true, 'message', 'Balance credited successfully');
END;
$$;

-- Update the update_user_balance function to also create deposit records
CREATE OR REPLACE FUNCTION public.update_user_balance(user_id uuid, amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Insert a deposit record for tracking when balance is added
  IF amount > 0 THEN
    INSERT INTO public.deposits (
      user_id, 
      amount, 
      payment_method_name, 
      method, 
      status
    ) VALUES (
      user_id,
      amount,
      'Admin Approval',
      'admin_approval',
      'completed'
    );
  END IF;

  UPDATE public.profiles 
  SET exchange_balance = exchange_balance + amount,
      updated_at = NOW()
  WHERE id = user_id;
END;
$$;
