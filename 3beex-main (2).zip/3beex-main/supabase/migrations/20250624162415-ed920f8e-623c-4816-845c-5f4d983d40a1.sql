
-- Add the new balance columns to the profiles table
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS exchange_balance NUMERIC(12,2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS trade_balance NUMERIC(12,2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS perpetual_balance NUMERIC(12,2) DEFAULT 0.00;

-- Update existing users to have their current balance moved to exchange_balance
UPDATE public.profiles 
SET exchange_balance = balance 
WHERE exchange_balance IS NULL OR exchange_balance = 0;

-- Create the transfer function
CREATE OR REPLACE FUNCTION public.transfer_between_accounts(
  user_id_input UUID,
  from_account TEXT,
  to_account TEXT,
  amount_input NUMERIC
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_balance NUMERIC(12,2);
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Perform the transfer
  IF from_account = 'exchange' AND to_account = 'trade' THEN
    UPDATE public.profiles 
    SET exchange_balance = exchange_balance - amount_input,
        trade_balance = trade_balance + amount_input,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSIF from_account = 'exchange' AND to_account = 'perpetual' THEN
    UPDATE public.profiles 
    SET exchange_balance = exchange_balance - amount_input,
        perpetual_balance = perpetual_balance + amount_input,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSIF from_account = 'trade' AND to_account = 'exchange' THEN
    UPDATE public.profiles 
    SET trade_balance = trade_balance - amount_input,
        exchange_balance = exchange_balance + amount_input,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSIF from_account = 'trade' AND to_account = 'perpetual' THEN
    UPDATE public.profiles 
    SET trade_balance = trade_balance - amount_input,
        perpetual_balance = perpetual_balance + amount_input,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' AND to_account = 'exchange' THEN
    UPDATE public.profiles 
    SET perpetual_balance = perpetual_balance - amount_input,
        exchange_balance = exchange_balance + amount_input,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' AND to_account = 'trade' THEN
    UPDATE public.profiles 
    SET perpetual_balance = perpetual_balance - amount_input,
        trade_balance = trade_balance + amount_input,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid account combination');
  END IF;

  RETURN json_build_object('success', true, 'message', 'Transfer completed successfully');
END;
$$;
