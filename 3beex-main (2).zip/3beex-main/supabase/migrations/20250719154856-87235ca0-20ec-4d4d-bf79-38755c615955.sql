-- Fix the withdrawal logic: when a deposit is doubled, user can withdraw 2x the original deposit amount
CREATE OR REPLACE FUNCTION public.transfer_between_accounts(
  user_id_input UUID,
  from_account TEXT,
  to_account TEXT,
  amount_input NUMERIC
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_balance NUMERIC(12,2);
  fee_amount NUMERIC(12,2) := 0;
  final_transfer_amount NUMERIC(12,2);
  remaining_withdrawal NUMERIC(12,2);
  deposit_record RECORD;
  withdrawable_amount NUMERIC(12,2);
  transfer_id UUID;
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Handle transfers TO trade account (track new deposits)
  IF to_account = 'trade' THEN
    -- Create new deposit record
    INSERT INTO public.trade_deposits (user_id, amount)
    VALUES (user_id_input, amount_input);
    
    -- Update balances
    IF from_account = 'exchange' THEN
      UPDATE public.profiles 
      SET exchange_balance = exchange_balance - amount_input,
          trade_balance = trade_balance + amount_input,
          trade_account_deposits = trade_account_deposits + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF from_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET perpetual_balance = perpetual_balance - amount_input,
          trade_balance = trade_balance + amount_input,
          trade_account_deposits = trade_account_deposits + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    END IF;
    
    -- Log the transfer
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, 0, 'completed')
    RETURNING id INTO transfer_id;
    
    RETURN json_build_object('success', true, 'message', 'Transfer completed successfully', 'transfer_id', transfer_id);
  END IF;

  -- Handle transfers FROM trade account (apply fee logic)
  IF from_account = 'trade' AND (to_account = 'exchange' OR to_account = 'perpetual') THEN
    remaining_withdrawal := amount_input;
    
    -- Check how much can be withdrawn without fee (from doubled deposits)
    FOR deposit_record IN 
      SELECT id, amount, doubled_amount, is_fully_doubled
      FROM public.trade_deposits 
      WHERE user_id = user_id_input 
      ORDER BY created_at ASC
    LOOP
      IF remaining_withdrawal <= 0 THEN
        EXIT;
      END IF;
      
      -- Calculate how much of this deposit can be withdrawn without fee
      -- If deposit is fully doubled, user can withdraw up to 2x the original deposit
      IF deposit_record.is_fully_doubled THEN
        withdrawable_amount := LEAST(remaining_withdrawal, (deposit_record.amount * 2) - deposit_record.doubled_amount);
      ELSE
        withdrawable_amount := 0;
      END IF;
      
      -- Update the deposit record
      IF withdrawable_amount > 0 THEN
        UPDATE public.trade_deposits 
        SET doubled_amount = doubled_amount + withdrawable_amount,
            updated_at = NOW()
        WHERE id = deposit_record.id;
        
        remaining_withdrawal := remaining_withdrawal - withdrawable_amount;
      END IF;
    END LOOP;
    
    -- Calculate fee on remaining amount
    fee_amount := remaining_withdrawal * 0.25;
    final_transfer_amount := amount_input - fee_amount;
    
    -- Update balances
    IF to_account = 'exchange' THEN
      UPDATE public.profiles 
      SET trade_balance = trade_balance - amount_input,
          exchange_balance = exchange_balance + final_transfer_amount,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF to_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET trade_balance = trade_balance - amount_input,
          perpetual_balance = perpetual_balance + final_transfer_amount,
          updated_at = NOW()
      WHERE id = user_id_input;
    END IF;
    
    -- Log the transfer with fee
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, fee_amount, 'completed')
    RETURNING id INTO transfer_id;
  ELSE
    -- Handle other transfers without fee
    final_transfer_amount := amount_input;
    
    IF from_account = 'exchange' AND to_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET exchange_balance = exchange_balance - amount_input,
          perpetual_balance = perpetual_balance + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF from_account = 'perpetual' AND to_account = 'exchange' THEN
      UPDATE public.profiles 
      SET perpetual_balance = perpetual_balance - amount_input,
          exchange_balance = exchange_balance + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSE
      RETURN json_build_object('success', false, 'error', 'Invalid account combination');
    END IF;
    
    -- Log the transfer
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, 0, 'completed')
    RETURNING id INTO transfer_id;
  END IF;

  -- Return success with fee information
  IF fee_amount > 0 THEN
    RETURN json_build_object(
      'success', true, 
      'message', 'Transfer completed with fee applied',
      'fee_applied', fee_amount,
      'amount_transferred', final_transfer_amount,
      'original_amount', amount_input,
      'transfer_id', transfer_id
    );
  ELSE
    RETURN json_build_object('success', true, 'message', 'Transfer completed successfully', 'transfer_id', transfer_id);
  END IF;
END;
$$;

-- Update check transfer fee function with the same corrected logic
CREATE OR REPLACE FUNCTION public.check_transfer_fee(
  user_id_input UUID,
  from_account TEXT,
  to_account TEXT,
  amount_input NUMERIC
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_balance NUMERIC(12,2);
  fee_amount NUMERIC(12,2) := 0;
  final_transfer_amount NUMERIC(12,2);
  remaining_withdrawal NUMERIC(12,2);
  deposit_record RECORD;
  withdrawable_amount NUMERIC(12,2);
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Only calculate fee for transfers FROM trade account
  IF from_account = 'trade' AND (to_account = 'exchange' OR to_account = 'perpetual') THEN
    remaining_withdrawal := amount_input;
    
    -- Check how much can be withdrawn without fee (from doubled deposits)
    FOR deposit_record IN 
      SELECT amount, doubled_amount, is_fully_doubled
      FROM public.trade_deposits 
      WHERE user_id = user_id_input 
      ORDER BY created_at ASC
    LOOP
      IF remaining_withdrawal <= 0 THEN
        EXIT;
      END IF;
      
      -- Calculate how much of this deposit can be withdrawn without fee
      -- If deposit is fully doubled, user can withdraw up to 2x the original deposit
      IF deposit_record.is_fully_doubled THEN
        withdrawable_amount := LEAST(remaining_withdrawal, (deposit_record.amount * 2) - deposit_record.doubled_amount);
      ELSE
        withdrawable_amount := 0;
      END IF;
      
      remaining_withdrawal := remaining_withdrawal - withdrawable_amount;
    END LOOP;
    
    -- Calculate fee on remaining amount
    fee_amount := remaining_withdrawal * 0.25;
    final_transfer_amount := amount_input - fee_amount;
  ELSE
    final_transfer_amount := amount_input;
  END IF;

  -- Return fee information
  RETURN json_build_object(
    'success', true,
    'will_apply_fee', fee_amount > 0,
    'fee_amount', fee_amount,
    'final_amount', final_transfer_amount,
    'original_amount', amount_input
  );
END;
$$;