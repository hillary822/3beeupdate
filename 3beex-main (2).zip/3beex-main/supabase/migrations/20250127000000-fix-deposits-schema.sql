-- Fix deposits table schema for CCPayment webhook compatibility
-- Add missing columns that are required by the webhook

-- Add missing columns to deposits table if they don't exist
ALTER TABLE public.deposits 
ADD COLUMN IF NOT EXISTS payment_method_name TEXT,
ADD COLUMN IF NOT EXISTS transaction_hash TEXT;

-- Ensure the method column exists (it should from earlier migrations)
ALTER TABLE public.deposits 
ADD COLUMN IF NOT EXISTS method TEXT;

-- Update the status check constraint to ensure it allows the values we need
ALTER TABLE public.deposits DROP CONSTRAINT IF EXISTS deposits_status_check;
ALTER TABLE public.deposits ADD CONSTRAINT deposits_status_check 
    CHECK (status IN ('pending', 'completed', 'rejected', 'failed'));

-- Set default status to pending if not already set
ALTER TABLE public.deposits ALTER COLUMN status SET DEFAULT 'pending';

-- Create index on transaction_id for better performance on webhook lookups
CREATE INDEX IF NOT EXISTS idx_deposits_transaction_id ON public.deposits(transaction_id);

-- Create index on payment_method_name for filtering
CREATE INDEX IF NOT EXISTS idx_deposits_payment_method_name ON public.deposits(payment_method_name);

-- Update withdrawals table to match deposits structure for consistency
ALTER TABLE public.withdrawals 
ADD COLUMN IF NOT EXISTS payment_method_name TEXT,
ADD COLUMN IF NOT EXISTS method TEXT;

-- Ensure withdrawals status constraint allows the same values
ALTER TABLE public.withdrawals DROP CONSTRAINT IF EXISTS withdrawals_status_check;
ALTER TABLE public.withdrawals ADD CONSTRAINT withdrawals_status_check 
    CHECK (status IN ('pending', 'completed', 'rejected', 'failed'));

-- Create indexes on withdrawals for consistency
CREATE INDEX IF NOT EXISTS idx_withdrawals_transaction_id ON public.withdrawals(transaction_id);
CREATE INDEX IF NOT EXISTS idx_withdrawals_payment_method_name ON public.withdrawals(payment_method_name); 