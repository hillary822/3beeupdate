-- Create proper storage policies for kyc-documents bucket uploads from edge functions

-- Allow service role to upload files to kyc-documents bucket
CREATE POLICY "Service role can upload to kyc-documents" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'kyc-documents');

-- Allow service role to update files in kyc-documents bucket  
CREATE POLICY "Service role can update kyc-documents" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'kyc-documents');

-- Allow service role to select files in kyc-documents bucket
CREATE POLICY "Service role can select kyc-documents" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'kyc-documents');

-- Allow admins to access files in kyc-documents bucket
CREATE POLICY "Admins can access kyc-documents" 
ON storage.objects 
FOR ALL 
USING (bucket_id = 'kyc-documents' AND is_admin_user());

-- Allow users to view their own kyc documents
CREATE POLICY "Users can view their own kyc documents" 
ON storage.objects 
FOR SELECT 
USING (
  bucket_id = 'kyc-documents' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);