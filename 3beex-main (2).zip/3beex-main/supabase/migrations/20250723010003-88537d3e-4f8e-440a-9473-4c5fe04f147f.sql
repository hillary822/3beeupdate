-- Create a policy to allow unauthenticated users to validate referral codes during registration
CREATE POLICY "Allow public referral code validation" 
ON public.profiles 
FOR SELECT 
TO public
USING (true);

-- However, this would be too permissive. Let's be more specific and create a function for referral validation instead.
-- First, let's drop the overly permissive policy we just created (if it exists)
DROP POLICY IF EXISTS "Allow public referral code validation" ON public.profiles;

-- Create the admin check function if it doesn't exist
CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM auth.users 
    WHERE id = auth.uid() 
    AND email = 'admin@3beetex.com'
  );
END;
$$;

-- Create a more secure function for referral code validation that bypasses RLS
-- This function includes an exception for when there are no users in the database yet (bootstrap scenario)
CREATE OR REPLACE FUNCTION public.validate_referral_code_public(ref_code text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  user_count INTEGER;
BEGIN
  -- Check if there are any users in the database
  SELECT COUNT(*) INTO user_count FROM public.profiles;
  
  -- If no users exist yet, allow registration without referral code validation
  -- This handles the bootstrap scenario where the first user needs to register
  IF user_count = 0 THEN
    RETURN true;
  END IF;
  
  -- If ref_code is null or empty, return false (referral code is required when users exist)
  IF ref_code IS NULL OR TRIM(ref_code) = '' THEN
    RETURN false;
  END IF;
  
  -- This function runs with elevated privileges and can read profiles
  RETURN EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE referral_code = TRIM(ref_code)
  );
END;
$$;

-- Create table to store user wallet addresses from CCPayment
CREATE TABLE IF NOT EXISTS public.user_wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  address TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USDT',
  chain TEXT NOT NULL DEFAULT 'BSC',
  memo TEXT,
  provider TEXT NOT NULL DEFAULT 'ccpayment',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id, currency, chain)
);

-- Enable RLS on user_wallets
ALTER TABLE public.user_wallets ENABLE ROW LEVEL SECURITY;

-- Create policies for user_wallets
CREATE POLICY "Users can view their own wallets" 
  ON public.user_wallets 
  FOR SELECT 
  USING (user_id = auth.uid());

CREATE POLICY "Admins can view all wallets" 
  ON public.user_wallets 
  FOR SELECT 
  USING (public.is_admin_user());

CREATE POLICY "System can insert wallets" 
  ON public.user_wallets 
  FOR INSERT 
  WITH CHECK (true);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_user_wallets_user_currency_chain 
  ON public.user_wallets(user_id, currency, chain);