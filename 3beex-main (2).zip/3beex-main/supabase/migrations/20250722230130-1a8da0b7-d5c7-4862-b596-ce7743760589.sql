-- Add admin_note column to deposits table
ALTER TABLE public.deposits ADD COLUMN IF NOT EXISTS admin_note TEXT;

-- Add admin_note column to withdrawals table  
ALTER TABLE public.withdrawals ADD COLUMN IF NOT EXISTS admin_note TEXT;