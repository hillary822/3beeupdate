-- Update storage policies for verification-documents bucket to allow admin viewing
CREATE POLICY "Admins can view verification documents" 
ON storage.objects 
FOR SELECT 
USING (
  bucket_id = 'verification-documents' 
  AND EXISTS (
    SELECT 1 FROM auth.users 
    WHERE auth.users.id = auth.uid() 
    AND auth.users.email = 'admin@3beetex.com'
  )
);

-- Make the bucket public for easier admin access
UPDATE storage.buckets 
SET public = true 
WHERE id = 'verification-documents';