
-- Add vip_level column to profiles table
ALTER TABLE public.profiles 
ADD COLUMN vip_level INTEGER DEFAULT 0;

-- Update existing VIP users to have vip_level = 1 if they currently have vip = true
UPDATE public.profiles 
SET vip_level = 1 
WHERE vip = true AND vip_level = 0;
