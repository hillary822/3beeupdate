-- Add registration bonus amount setting
INSERT INTO public.platform_settings (key, value) VALUES 
('registration_bonus_amount', '10.00')
ON CONFLICT (key) DO NOTHING;