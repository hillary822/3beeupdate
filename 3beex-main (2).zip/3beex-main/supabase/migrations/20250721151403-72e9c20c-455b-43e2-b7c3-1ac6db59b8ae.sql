-- Add note column to trade_codes table
ALTER TABLE public.trade_codes 
ADD COLUMN note TEXT;