
-- Create profile for manually created user
INSERT INTO public.profiles (id, username, email, referral_code)
SELECT 
  id,
  SPLIT_PART(email, '@', 1) as username,
  email,
  'REF' || UPPER(SUBSTRING(REPLACE(gen_random_uuid()::text, '-', ''), 1, 6)) as referral_code
FROM auth.users 
WHERE email = 'hillary822@gmail.com'
AND id NOT IN (SELECT id FROM public.profiles);
