-- Admin function to mark trade codes as used
CREATE OR REPLACE FUNCTION admin_mark_trade_code_used(code_input text)
RETURNS JSON AS $$
BEGIN
  -- Check if user is admin
  IF NOT is_admin_user() THEN
    RETURN json_build_object('success', false, 'error', 'Unauthorized');
  END IF;

  -- Mark the trade code as used
  UPDATE trade_codes 
  SET is_used = true, 
      used_at = NOW()
  WHERE code = code_input;

  RETURN json_build_object('success', true, 'message', 'Trade code marked as used');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;