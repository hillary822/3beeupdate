-- Drop the existing function and recreate it with different parameter names to avoid ambiguity
DROP FUNCTION IF EXISTS public.update_user_balance(uuid, numeric);

-- Create the function with renamed parameters to avoid any ambiguity
CREATE OR REPLACE FUNCTION public.update_user_balance(target_user_id uuid, balance_amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Update the user's exchange balance
  UPDATE public.profiles 
  SET exchange_balance = exchange_balance + balance_amount,
      updated_at = NOW()
  WHERE id = target_user_id;
END;
$$;