-- Create table to track individual trade deposits and their doubling status
CREATE TABLE public.trade_deposits (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  doubled_amount NUMERIC(12,2) NOT NULL DEFAULT 0.00,
  is_fully_doubled BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.trade_deposits ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own trade deposits" 
ON public.trade_deposits 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "System can manage trade deposits" 
ON public.trade_deposits 
FOR ALL 
USING (true);

-- Create index for performance
CREATE INDEX idx_trade_deposits_user_id ON public.trade_deposits(user_id);

-- Update transfer_between_accounts function to track individual deposits
CREATE OR REPLACE FUNCTION public.transfer_between_accounts(
  user_id_input UUID, 
  from_account TEXT, 
  to_account TEXT, 
  amount_input NUMERIC
)
RETURNS JSON AS $$
DECLARE
  current_balance NUMERIC(12,2);
  fee_amount NUMERIC(12,2) := 0;
  final_transfer_amount NUMERIC(12,2);
  remaining_withdrawal NUMERIC(12,2);
  deposit_record RECORD;
  withdrawable_amount NUMERIC(12,2);
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Handle transfers TO trade account (track new deposits)
  IF to_account = 'trade' THEN
    -- Create new deposit record
    INSERT INTO public.trade_deposits (user_id, amount)
    VALUES (user_id_input, amount_input);
    
    -- Update balances
    IF from_account = 'exchange' THEN
      UPDATE public.profiles 
      SET exchange_balance = exchange_balance - amount_input,
          trade_balance = trade_balance + amount_input,
          trade_account_deposits = trade_account_deposits + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF from_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET perpetual_balance = perpetual_balance - amount_input,
          trade_balance = trade_balance + amount_input,
          trade_account_deposits = trade_account_deposits + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    END IF;
    
    RETURN json_build_object('success', true, 'message', 'Transfer completed successfully');
  END IF;

  -- Handle transfers FROM trade account (apply fee logic)
  IF from_account = 'trade' AND (to_account = 'exchange' OR to_account = 'perpetual') THEN
    remaining_withdrawal := amount_input;
    
    -- Check how much can be withdrawn without fee (from doubled deposits)
    FOR deposit_record IN 
      SELECT id, amount, doubled_amount, is_fully_doubled
      FROM public.trade_deposits 
      WHERE user_id = user_id_input 
      ORDER BY created_at ASC
    LOOP
      IF remaining_withdrawal <= 0 THEN
        EXIT;
      END IF;
      
      -- Calculate how much of this deposit can be withdrawn without fee
      IF deposit_record.is_fully_doubled THEN
        withdrawable_amount := LEAST(remaining_withdrawal, deposit_record.amount - deposit_record.doubled_amount);
      ELSE
        withdrawable_amount := 0;
      END IF;
      
      -- Update the deposit record
      IF withdrawable_amount > 0 THEN
        UPDATE public.trade_deposits 
        SET doubled_amount = doubled_amount + withdrawable_amount,
            updated_at = NOW()
        WHERE id = deposit_record.id;
        
        remaining_withdrawal := remaining_withdrawal - withdrawable_amount;
      END IF;
    END LOOP;
    
    -- Calculate fee on remaining amount
    fee_amount := remaining_withdrawal * 0.25;
    final_transfer_amount := amount_input - fee_amount;
    
    -- Update balances
    IF to_account = 'exchange' THEN
      UPDATE public.profiles 
      SET trade_balance = trade_balance - amount_input,
          exchange_balance = exchange_balance + final_transfer_amount,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF to_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET trade_balance = trade_balance - amount_input,
          perpetual_balance = perpetual_balance + final_transfer_amount,
          updated_at = NOW()
      WHERE id = user_id_input;
    END IF;
  ELSE
    -- Handle other transfers without fee
    final_transfer_amount := amount_input;
    
    IF from_account = 'exchange' AND to_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET exchange_balance = exchange_balance - amount_input,
          perpetual_balance = perpetual_balance + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF from_account = 'perpetual' AND to_account = 'exchange' THEN
      UPDATE public.profiles 
      SET perpetual_balance = perpetual_balance - amount_input,
          exchange_balance = exchange_balance + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSE
      RETURN json_build_object('success', false, 'error', 'Invalid account combination');
    END IF;
  END IF;

  -- Return success with fee information
  IF fee_amount > 0 THEN
    RETURN json_build_object(
      'success', true, 
      'message', 'Transfer completed with fee applied',
      'fee_applied', fee_amount,
      'amount_transferred', final_transfer_amount,
      'original_amount', amount_input
    );
  ELSE
    RETURN json_build_object('success', true, 'message', 'Transfer completed successfully');
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update check_transfer_fee function to use new logic
CREATE OR REPLACE FUNCTION public.check_transfer_fee(
  user_id_input UUID,
  from_account TEXT,
  to_account TEXT,
  amount_input NUMERIC
)
RETURNS JSON AS $$
DECLARE
  current_balance NUMERIC(12,2);
  fee_amount NUMERIC(12,2) := 0;
  final_transfer_amount NUMERIC(12,2);
  remaining_withdrawal NUMERIC(12,2);
  deposit_record RECORD;
  withdrawable_amount NUMERIC(12,2);
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Only calculate fee for transfers FROM trade account
  IF from_account = 'trade' AND (to_account = 'exchange' OR to_account = 'perpetual') THEN
    remaining_withdrawal := amount_input;
    
    -- Check how much can be withdrawn without fee (from doubled deposits)
    FOR deposit_record IN 
      SELECT amount, doubled_amount, is_fully_doubled
      FROM public.trade_deposits 
      WHERE user_id = user_id_input 
      ORDER BY created_at ASC
    LOOP
      IF remaining_withdrawal <= 0 THEN
        EXIT;
      END IF;
      
      -- Calculate how much of this deposit can be withdrawn without fee
      IF deposit_record.is_fully_doubled THEN
        withdrawable_amount := LEAST(remaining_withdrawal, deposit_record.amount - deposit_record.doubled_amount);
      ELSE
        withdrawable_amount := 0;
      END IF;
      
      remaining_withdrawal := remaining_withdrawal - withdrawable_amount;
    END LOOP;
    
    -- Calculate fee on remaining amount
    fee_amount := remaining_withdrawal * 0.25;
    final_transfer_amount := amount_input - fee_amount;
  ELSE
    final_transfer_amount := amount_input;
  END IF;

  -- Return fee information
  RETURN json_build_object(
    'success', true,
    'will_apply_fee', fee_amount > 0,
    'fee_amount', fee_amount,
    'final_amount', final_transfer_amount,
    'original_amount', amount_input
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to mark deposits as doubled when trades are completed
CREATE OR REPLACE FUNCTION public.mark_deposits_doubled(
  user_id_input UUID,
  profit_amount NUMERIC
)
RETURNS VOID AS $$
DECLARE
  remaining_profit NUMERIC(12,2) := profit_amount;
  deposit_record RECORD;
  doubling_amount NUMERIC(12,2);
BEGIN
  -- Mark deposits as doubled based on profit earned
  FOR deposit_record IN 
    SELECT id, amount, doubled_amount, is_fully_doubled
    FROM public.trade_deposits 
    WHERE user_id = user_id_input AND is_fully_doubled = false
    ORDER BY created_at ASC
  LOOP
    IF remaining_profit <= 0 THEN
      EXIT;
    END IF;
    
    -- Calculate how much of this deposit can be marked as doubled
    doubling_amount := LEAST(remaining_profit, deposit_record.amount - deposit_record.doubled_amount);
    
    -- Update the deposit record
    UPDATE public.trade_deposits 
    SET doubled_amount = doubled_amount + doubling_amount,
        is_fully_doubled = (doubled_amount + doubling_amount >= amount),
        updated_at = NOW()
    WHERE id = deposit_record.id;
    
    remaining_profit := remaining_profit - doubling_amount;
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;