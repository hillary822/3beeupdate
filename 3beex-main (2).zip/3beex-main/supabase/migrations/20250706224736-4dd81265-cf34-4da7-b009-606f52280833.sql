
-- Create the missing validate_referral_code function
CREATE OR REPLACE FUNCTION validate_referral_code(ref_code TEXT)
RETURNS BOOLEAN AS $$
BEGIN
  -- Check if referral code exists and return true/false
  RETURN EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE referral_code = ref_code
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
