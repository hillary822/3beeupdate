-- Check current check constraints on withdrawals table  
SELECT 
    tc.constraint_name, 
    cc.check_clause,
    tc.constraint_type
FROM information_schema.table_constraints tc
JOIN information_schema.check_constraints cc ON tc.constraint_name = cc.constraint_name
WHERE tc.table_name = 'withdrawals' AND tc.constraint_type = 'CHECK';

-- Also check what the current status values are in the withdrawals table
SELECT DISTINCT status FROM public.withdrawals;