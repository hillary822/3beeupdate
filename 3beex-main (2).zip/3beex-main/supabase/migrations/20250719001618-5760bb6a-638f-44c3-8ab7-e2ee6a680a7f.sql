-- Allow users to view referrals made by anyone in their referral network
CREATE POLICY "Users can view referrals made by their network" 
ON public.referrals 
FOR SELECT 
USING (
  -- Allow viewing referrals made by anyone in the user's referral tree
  EXISTS (
    WITH RECURSIVE referral_tree AS (
      -- Base case: direct referrals
      SELECT referred_id as user_id, 1 as level
      FROM public.referrals 
      WHERE referrer_id = auth.uid()
      
      UNION ALL
      
      -- Recursive case: referrals of referrals (up to 10 levels)
      SELECT r.referred_id as user_id, rt.level + 1
      FROM public.referrals r
      INNER JOIN referral_tree rt ON r.referrer_id = rt.user_id
      WHERE rt.level < 10
    )
    SELECT 1 FROM referral_tree WHERE user_id = referrals.referrer_id
  )
);