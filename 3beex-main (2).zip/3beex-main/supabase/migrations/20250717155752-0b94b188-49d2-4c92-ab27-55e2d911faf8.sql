-- Update registration bonus function to use configurable amount
CREATE OR REPLACE FUNCTION public.process_registration_bonus(new_user_id uuid, referrer_id uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_referrer_id uuid;
  current_level integer := 1;
  max_levels integer;
  bonus_percentage numeric;
  bonus_amount numeric;
  base_bonus_amount numeric;
  total_bonuses_paid numeric := 0;
  result json;
BEGIN
  -- Get referral bonus settings
  SELECT value::integer INTO max_levels 
  FROM public.platform_settings 
  WHERE key = 'referral_bonus_levels';
  
  SELECT value::numeric INTO base_bonus_amount
  FROM public.platform_settings 
  WHERE key = 'registration_bonus_amount';
  
  IF max_levels IS NULL THEN
    max_levels := 3;
  END IF;
  
  IF base_bonus_amount IS NULL THEN
    base_bonus_amount := 10.00;
  END IF;
  
  -- Start with the direct referrer
  current_referrer_id := referrer_id;
  
  -- Process referral bonuses up to max levels
  WHILE current_referrer_id IS NOT NULL AND current_level <= max_levels LOOP
    -- Get bonus percentage for current level
    SELECT value::numeric INTO bonus_percentage 
    FROM public.platform_settings 
    WHERE key = 'referral_level_' || current_level || '_percentage';
    
    IF bonus_percentage IS NULL THEN
      -- Fallback to default percentage
      SELECT value::numeric INTO bonus_percentage 
      FROM public.platform_settings 
      WHERE key = 'referral_bonus_percentage';
      
      IF bonus_percentage IS NULL THEN
        bonus_percentage := 5.0;
      END IF;
      
      -- Reduce percentage for each level
      bonus_percentage := bonus_percentage / current_level;
    END IF;
    
    -- Calculate bonus amount based on configurable registration bonus
    bonus_amount := base_bonus_amount * (bonus_percentage / 100);
    
    -- Update referrer's earnings in referrals table
    UPDATE public.referrals 
    SET earnings = earnings + bonus_amount
    WHERE referrer_id = current_referrer_id 
    AND referred_id = new_user_id;
    
    -- If no referral record exists, create one (shouldn't happen but safety check)
    IF NOT FOUND THEN
      INSERT INTO public.referrals (referrer_id, referred_id, earnings)
      VALUES (current_referrer_id, new_user_id, bonus_amount);
    END IF;
    
    -- Credit referrer's exchange balance
    UPDATE public.profiles 
    SET exchange_balance = exchange_balance + bonus_amount,
        updated_at = NOW()
    WHERE id = current_referrer_id;
    
    total_bonuses_paid := total_bonuses_paid + bonus_amount;
    
    -- Move to next level (current referrer's referrer)
    SELECT referred_by INTO current_referrer_id 
    FROM public.profiles 
    WHERE id = current_referrer_id;
    
    current_level := current_level + 1;
  END LOOP;
  
  RETURN json_build_object(
    'success', true,
    'total_bonuses_paid', total_bonuses_paid,
    'levels_processed', current_level - 1,
    'base_bonus', base_bonus_amount
  );
END;
$$;