-- Add platform minimum balance setting
CREATE TABLE IF NOT EXISTS public.platform_settings (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key text NOT NULL UNIQUE,
  value text NOT NULL,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admins can manage platform settings" 
ON public.platform_settings 
FOR ALL 
USING (is_admin_user());

-- Insert default minimum trading balance
INSERT INTO public.platform_settings (key, value) 
VALUES ('minimum_trading_balance', '0.00')
ON CONFLICT (key) DO NOTHING;

-- Update use_trade_code function to use trade code amount and check platform minimum
CREATE OR REPLACE FUNCTION public.use_trade_code(code_input text, user_id_input uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  trade_code_record RECORD;
  new_trade_id UUID;
  user_trade_balance DECIMAL(12,2);
  platform_min_balance DECIMAL(12,2);
  user_total_balance DECIMAL(12,2);
BEGIN
  -- Check if trade code exists and is unused
  SELECT * INTO trade_code_record 
  FROM public.trade_codes 
  WHERE code = code_input AND is_used = FALSE;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Invalid or already used trade code');
  END IF;
  
  -- Get platform minimum balance setting
  SELECT COALESCE(value::DECIMAL(12,2), 0) INTO platform_min_balance
  FROM public.platform_settings 
  WHERE key = 'minimum_trading_balance';
  
  -- Check user's current balances
  SELECT trade_balance, (exchange_balance + trade_balance + perpetual_balance) 
  INTO user_trade_balance, user_total_balance 
  FROM public.profiles WHERE id = user_id_input;
  
  -- Check if user meets platform minimum balance requirement
  IF user_total_balance < platform_min_balance THEN
    RETURN json_build_object(
      'success', false, 
      'error', format('Platform requires a minimum total balance of $%s to trade', platform_min_balance)
    );
  END IF;
  
  -- Check if user meets the trade code's minimum balance requirement
  IF user_trade_balance < COALESCE(trade_code_record.minimum_balance, 0) THEN
    RETURN json_build_object(
      'success', false, 
      'error', format('This trade code requires a minimum trade balance of $%s', COALESCE(trade_code_record.minimum_balance, 0))
    );
  END IF;
  
  -- Use the trade code's minimum balance as the trade amount
  DECLARE
    trade_amount DECIMAL(12,2) := COALESCE(trade_code_record.minimum_balance, 100.00);
  BEGIN
    -- Deduct the trade amount from user's trade balance
    UPDATE public.profiles 
    SET trade_balance = trade_balance - trade_amount, updated_at = NOW()
    WHERE id = user_id_input;
    
    -- Mark trade code as used
    UPDATE public.trade_codes 
    SET is_used = TRUE, used_by = user_id_input, used_at = NOW()
    WHERE id = trade_code_record.id;
    
    -- Create new trade with proper status
    INSERT INTO public.trades (
      user_id, 
      trade_code, 
      trade_code_id,
      type, 
      asset, 
      amount, 
      profit,
      status,
      started_at
    ) VALUES (
      user_id_input,
      code_input,
      trade_code_record.id,
      'BUY',
      trade_code_record.asset,
      trade_amount,
      0.00, -- Will be updated when trade completes
      'active',
      NOW()
    ) RETURNING id INTO new_trade_id;
    
    RETURN json_build_object(
      'success', true, 
      'trade_id', new_trade_id,
      'duration_minutes', trade_code_record.duration_minutes,
      'asset', trade_code_record.asset,
      'profit_percentage', trade_code_record.profit_percentage,
      'amount_invested', trade_amount,
      'minimum_balance_required', COALESCE(trade_code_record.minimum_balance, 0)
    );
  END;
END;
$$;