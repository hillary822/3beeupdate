-- Update the assign_wallet_to_user function to reissue existing wallets when no free ones are available
CREATE OR REPLACE FUNCTION public.assign_wallet_to_user(user_id_input uuid, currency_input text DEFAULT 'USDT'::text)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  wallet_record RECORD;
BEGIN
  -- Check if user already has an assigned wallet for this currency
  SELECT * INTO wallet_record 
  FROM public.pre_generated_wallets 
  WHERE assigned_to_user_id = user_id_input 
  AND currency = currency_input;
  
  IF FOUND THEN
    RETURN json_build_object(
      'success', true, 
      'wallet', json_build_object(
        'id', wallet_record.id,
        'address', wallet_record.address,
        'currency', wallet_record.currency,
        'assigned_at', wallet_record.assigned_at
      ),
      'message', 'Existing wallet found'
    );
  END IF;
  
  -- Try to find and assign an unused wallet first
  UPDATE public.pre_generated_wallets 
  SET 
    is_assigned = TRUE,
    assigned_to_user_id = user_id_input,
    assigned_at = NOW(),
    updated_at = NOW()
  WHERE id = (
    SELECT id FROM public.pre_generated_wallets 
    WHERE is_assigned = FALSE 
    AND currency = currency_input 
    ORDER BY created_at ASC 
    LIMIT 1
  )
  RETURNING * INTO wallet_record;
  
  -- If no unused wallet found, reissue an existing one
  IF NOT FOUND THEN
    UPDATE public.pre_generated_wallets 
    SET 
      assigned_to_user_id = user_id_input,
      assigned_at = NOW(),
      updated_at = NOW()
    WHERE id = (
      SELECT id FROM public.pre_generated_wallets 
      WHERE currency = currency_input 
      ORDER BY created_at ASC 
      LIMIT 1
    )
    RETURNING * INTO wallet_record;
    
    IF NOT FOUND THEN
      RETURN json_build_object(
        'success', false, 
        'error', 'No wallets available for assignment'
      );
    END IF;
    
    RETURN json_build_object(
      'success', true, 
      'wallet', json_build_object(
        'id', wallet_record.id,
        'address', wallet_record.address,
        'currency', wallet_record.currency,
        'assigned_at', wallet_record.assigned_at
      ),
      'message', 'Reissued existing wallet'
    );
  END IF;
  
  RETURN json_build_object(
    'success', true, 
    'wallet', json_build_object(
      'id', wallet_record.id,
      'address', wallet_record.address,
      'currency', wallet_record.currency,
      'assigned_at', wallet_record.assigned_at
    ),
    'message', 'New wallet assigned successfully'
  );
END;
$function$;