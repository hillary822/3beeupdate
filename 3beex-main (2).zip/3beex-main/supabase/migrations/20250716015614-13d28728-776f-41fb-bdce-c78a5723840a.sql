-- Add is_vip column to trade_codes table for VIP-only trade codes
ALTER TABLE public.trade_codes 
ADD COLUMN is_vip boolean NOT NULL DEFAULT false;