-- Create table for admin-managed deposit addresses
CREATE TABLE public.manual_deposit_addresses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  currency TEXT NOT NULL UNIQUE,
  network TEXT NOT NULL,
  address TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.manual_deposit_addresses ENABLE ROW LEVEL SECURITY;

-- Admin can manage all addresses
CREATE POLICY "Admins can manage manual deposit addresses"
ON public.manual_deposit_addresses
FOR ALL
USING (is_admin_user());

-- Users can view active addresses
CREATE POLICY "Users can view active manual deposit addresses"
ON public.manual_deposit_addresses
FOR SELECT
USING (is_active = true);

-- Insert default addresses
INSERT INTO public.manual_deposit_addresses (currency, network, address) VALUES
('USDT', 'TRX', 'TBD-USDT-ADDRESS'),
('ETH', 'ETH', 'TBD-ETH-ADDRESS'),
('BTC', 'BTC', 'TBD-BTC-ADDRESS');

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION update_manual_deposit_addresses_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_manual_deposit_addresses_updated_at
  BEFORE UPDATE ON public.manual_deposit_addresses
  FOR EACH ROW
  EXECUTE FUNCTION update_manual_deposit_addresses_updated_at();