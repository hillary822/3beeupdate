-- Update use_trade_code function to properly check trade code minimum balance
CREATE OR REPLACE FUNCTION public.use_trade_code(code_input text, user_id_input uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  trade_code_record RECORD;
  new_trade_id UUID;
  user_trade_balance DECIMAL(12,2);
  trade_amount DECIMAL(12,2) := 100.00; -- Default trade amount
BEGIN
  -- Check if trade code exists and is unused
  SELECT * INTO trade_code_record 
  FROM public.trade_codes 
  WHERE code = code_input AND is_used = FALSE;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Invalid or already used trade code');
  END IF;
  
  -- Check user's current trade balance
  SELECT trade_balance INTO user_trade_balance FROM public.profiles WHERE id = user_id_input;
  
  -- Check if user meets the trade code's minimum balance requirement
  IF user_trade_balance < COALESCE(trade_code_record.minimum_balance, 0) THEN
    RETURN json_build_object(
      'success', false, 
      'error', format('Insufficient balance. This trade code requires a minimum balance of $%s', COALESCE(trade_code_record.minimum_balance, 0))
    );
  END IF;
  
  -- Check if user has enough balance for the trade amount
  IF user_trade_balance < trade_amount THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient trade balance for this trade');
  END IF;
  
  -- Deduct the trade amount from user's trade balance
  UPDATE public.profiles 
  SET trade_balance = trade_balance - trade_amount, updated_at = NOW()
  WHERE id = user_id_input;
  
  -- Mark trade code as used
  UPDATE public.trade_codes 
  SET is_used = TRUE, used_by = user_id_input, used_at = NOW()
  WHERE id = trade_code_record.id;
  
  -- Create new trade with proper status
  INSERT INTO public.trades (
    user_id, 
    trade_code, 
    trade_code_id,
    type, 
    asset, 
    amount, 
    profit,
    status,
    started_at
  ) VALUES (
    user_id_input,
    code_input,
    trade_code_record.id,
    'BUY',
    trade_code_record.asset,
    trade_amount,
    0.00, -- Will be updated when trade completes
    'active',
    NOW()
  ) RETURNING id INTO new_trade_id;
  
  RETURN json_build_object(
    'success', true, 
    'trade_id', new_trade_id,
    'duration_minutes', trade_code_record.duration_minutes,
    'asset', trade_code_record.asset,
    'profit_percentage', trade_code_record.profit_percentage,
    'amount_invested', trade_amount,
    'minimum_balance_required', COALESCE(trade_code_record.minimum_balance, 0)
  );
END;
$$;