-- Fix the send_code_to_users function to properly count VIP users
CREATE OR REPLACE FUNCTION public.send_code_to_users(trade_code_id_input uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  trade_code_record RECORD;
  user_record RECORD;
  total_inserted_count INTEGER := 0;
  current_insert_count INTEGER := 0;
BEGIN
  -- Check if user is admin
  IF NOT is_admin_user() THEN
    RETURN json_build_object('success', false, 'error', 'Unauthorized');
  END IF;

  -- Get trade code details
  SELECT * INTO trade_code_record 
  FROM public.trade_codes 
  WHERE id = trade_code_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Trade code not found');
  END IF;
  
  -- Check if code has already been sent
  IF trade_code_record.sent_at IS NOT NULL THEN
    RETURN json_build_object('success', false, 'error', 'This code has already been sent to users');
  END IF;

  -- Mark the code as sent
  UPDATE public.trade_codes 
  SET sent_at = NOW()
  WHERE id = trade_code_id_input;

  -- Send to appropriate users based on code type
  IF trade_code_record.is_vip THEN
    -- Send to VIP users only
    FOR user_record IN 
      SELECT id FROM public.profiles 
      WHERE vip_level > 0
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS current_insert_count = ROW_COUNT;
      total_inserted_count := total_inserted_count + current_insert_count;
    END LOOP;
  ELSIF trade_code_record.is_premium THEN
    -- Send to premium users and users who have referred someone
    FOR user_record IN 
      SELECT DISTINCT p.id FROM public.profiles p
      WHERE p.premium = true 
      OR EXISTS (SELECT 1 FROM public.referrals r WHERE r.referrer_id = p.id)
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS current_insert_count = ROW_COUNT;
      total_inserted_count := total_inserted_count + current_insert_count;
    END LOOP;
  ELSE
    -- Send to all users
    FOR user_record IN 
      SELECT id FROM public.profiles
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS current_insert_count = ROW_COUNT;
      total_inserted_count := total_inserted_count + current_insert_count;
    END LOOP;
  END IF;

  RETURN json_build_object(
    'success', true, 
    'message', format('Code sent to %s users and will expire in %s minutes', total_inserted_count, trade_code_record.duration_minutes),
    'users_count', total_inserted_count
  );
END;
$function$;