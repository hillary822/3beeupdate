
-- Fix the admin_credit_balance function to not create duplicate deposits
CREATE OR REPLACE FUNCTION public.admin_credit_balance(
  target_user_id UUID,
  credit_amount NUMERIC,
  admin_note TEXT DEFAULT 'Admin credit'
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result JSON;
BEGIN
  -- Check if the current user is admin
  IF NOT public.is_admin_user() THEN
    RETURN json_build_object('success', false, 'error', 'Unauthorized');
  END IF;

  -- Only update user balance, don't create deposit record
  -- (deposit record should be created separately when needed)
  UPDATE public.profiles 
  SET exchange_balance = exchange_balance + credit_amount,
      updated_at = NOW()
  WHERE id = target_user_id;

  RETURN json_build_object('success', true, 'message', 'Balance credited successfully');
END;
$$;

-- Fix the update_user_balance function to not create duplicate deposits
CREATE OR REPLACE FUNCTION public.update_user_balance(user_id uuid, amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Only update the balance, don't create deposit records
  -- Deposit records should be created by the calling code when appropriate
  UPDATE public.profiles 
  SET exchange_balance = exchange_balance + amount,
      updated_at = NOW()
  WHERE id = user_id;
END;
$$;
