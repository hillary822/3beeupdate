-- Drop the duplicate policies that are causing conflicts
DROP POLICY IF EXISTS "Users can view referred user basic info" ON public.profiles;

-- Drop the policy I just added and recreate it with a different name to avoid conflicts
DROP POLICY IF EXISTS "Users can view referral tree profiles" ON public.profiles;

-- Recreate the referral tree policy with proper naming
CREATE POLICY "Users can view profiles in referral network" 
ON public.profiles 
FOR SELECT 
USING (
  -- Allow viewing profiles of anyone in the user's referral network
  EXISTS (
    WITH RECURSIVE referral_tree AS (
      -- Base case: direct referrals
      SELECT referred_id as user_id, 1 as level
      FROM public.referrals 
      WHERE referrer_id = auth.uid()
      
      UNION ALL
      
      -- Recursive case: referrals of referrals (up to 10 levels)
      SELECT r.referred_id as user_id, rt.level + 1
      FROM public.referrals r
      INNER JOIN referral_tree rt ON r.referrer_id = rt.user_id
      WHERE rt.level < 10
    )
    SELECT 1 FROM referral_tree WHERE user_id = profiles.id
  )
);