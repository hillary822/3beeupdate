-- First, let's see the current table structure and any constraints
\d public.withdrawals

-- Drop any existing check constraint on status
ALTER TABLE public.withdrawals DROP CONSTRAINT IF EXISTS withdrawals_status_check;

-- Make sure the status column allows the values we need
ALTER TABLE public.withdrawals ALTER COLUMN status SET DEFAULT 'pending';

-- Add a proper check constraint that allows pending, completed, and rejected
ALTER TABLE public.withdrawals ADD CONSTRAINT withdrawals_status_check 
    CHECK (status IN ('pending', 'completed', 'rejected'));