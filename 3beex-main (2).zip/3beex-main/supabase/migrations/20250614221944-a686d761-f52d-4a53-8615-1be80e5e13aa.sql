
-- First, let's check what status values are allowed in the trades table
-- and update the constraint to allow 'active' status
ALTER TABLE public.trades DROP CONSTRAINT IF EXISTS trades_status_check;

-- Add a new constraint that allows the status values we need
ALTER TABLE public.trades ADD CONSTRAINT trades_status_check 
CHECK (status IN ('pending', 'active', 'completed', 'cancelled'));

-- Update the use_trade_code function to properly handle the trade creation
CREATE OR REPLACE FUNCTION public.use_trade_code(code_input TEXT, user_id_input UUID)
RETURNS JSON AS $$
DECLARE
  trade_code_record RECORD;
  new_trade_id UUID;
  result JSON;
BEGIN
  -- Check if trade code exists and is unused
  SELECT * INTO trade_code_record 
  FROM public.trade_codes 
  WHERE code = code_input AND is_used = FALSE;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Invalid or already used trade code');
  END IF;
  
  -- Mark trade code as used
  UPDATE public.trade_codes 
  SET is_used = TRUE, used_by = user_id_input, used_at = NOW()
  WHERE id = trade_code_record.id;
  
  -- Create new trade with proper status
  INSERT INTO public.trades (
    user_id, 
    trade_code, 
    trade_code_id,
    type, 
    asset, 
    amount, 
    profit,
    status,
    started_at
  ) VALUES (
    user_id_input,
    code_input,
    trade_code_record.id,
    'BUY',
    trade_code_record.asset,
    100.00, -- Default trade amount
    0.00, -- Will be updated when trade completes
    'active',
    NOW()
  ) RETURNING id INTO new_trade_id;
  
  RETURN json_build_object(
    'success', true, 
    'trade_id', new_trade_id,
    'duration_minutes', trade_code_record.duration_minutes,
    'asset', trade_code_record.asset,
    'profit_percentage', trade_code_record.profit_percentage
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
