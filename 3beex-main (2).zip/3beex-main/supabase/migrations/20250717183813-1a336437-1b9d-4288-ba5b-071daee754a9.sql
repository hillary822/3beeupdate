-- Fix the handle_new_user function to handle errors better and avoid exceptions during signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
AS $$
DECLARE
  ref_code TEXT;
  referrer_id UUID;
  bonus_result json;
BEGIN
  -- Generate unique referral code
  ref_code := 'REF' || UPPER(SUBSTRING(REPLACE(gen_random_uuid()::text, '-', ''), 1, 6));
  
  -- Check if user provided a referral code
  IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
    -- Find the referrer by their referral code directly
    SELECT id INTO referrer_id 
    FROM public.profiles 
    WHERE referral_code = NEW.raw_user_meta_data->>'referral_code';
    
    -- If no referrer found, log it but don't fail the signup
    IF referrer_id IS NULL THEN
      -- Just log the issue but continue with signup
      RAISE WARNING 'Invalid referral code provided: %, continuing without referrer', NEW.raw_user_meta_data->>'referral_code';
      referrer_id := NULL;
    END IF;
  END IF;
  
  -- Insert the new profile with sequential user_id
  INSERT INTO public.profiles (id, username, email, referral_code, referred_by, user_id)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', SPLIT_PART(COALESCE(NEW.email, NEW.phone), '@', 1)),
    COALESCE(NEW.email, NEW.phone),
    ref_code,
    referrer_id,
    nextval('public.user_id_sequence')
  );
  
  -- Create referral record and process bonuses if referrer exists
  IF referrer_id IS NOT NULL THEN
    INSERT INTO public.referrals (referrer_id, referred_id, earnings)
    VALUES (referrer_id, NEW.id, 0);
    
    -- Process registration bonuses for the referral chain
    SELECT public.process_registration_bonus(NEW.id, referrer_id) INTO bonus_result;
  END IF;
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log the error but don't fail the user creation
    RAISE WARNING 'Error in handle_new_user: %', SQLERRM;
    RETURN NEW;
END;
$$;