
-- Create a table to store pre-generated wallets
CREATE TABLE IF NOT EXISTS public.pre_generated_wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  address TEXT NOT NULL UNIQUE,
  currency TEXT NOT NULL DEFAULT 'USDT',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create a table to track wallet assignments (many users can share same wallet)
CREATE TABLE IF NOT EXISTS public.wallet_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  wallet_id UUID NOT NULL REFERENCES public.pre_generated_wallets(id) ON DELETE CASCADE,
  currency TEXT NOT NULL DEFAULT 'USDT',
  assigned_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id, currency)
);

-- Enable RLS
ALTER TABLE public.pre_generated_wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wallet_assignments ENABLE ROW LEVEL SECURITY;

-- Create policies for pre_generated_wallets
CREATE POLICY "Admins can manage pre-generated wallets" 
  ON public.pre_generated_wallets 
  FOR ALL 
  USING (public.is_admin_user());

-- Create policies for wallet_assignments
CREATE POLICY "Admins can view all wallet assignments" 
  ON public.wallet_assignments 
  FOR SELECT 
  USING (public.is_admin_user());

CREATE POLICY "Users can view their own wallet assignments" 
  ON public.wallet_assignments 
  FOR SELECT 
  USING (user_id = auth.uid());

CREATE POLICY "System can create wallet assignments" 
  ON public.wallet_assignments 
  FOR INSERT 
  WITH CHECK (true);

-- Create function to assign wallet to user (multiple users can share same wallet)
CREATE OR REPLACE FUNCTION public.assign_wallet_to_user(user_id_input UUID, currency_input TEXT DEFAULT 'USDT')
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  wallet_record RECORD;
  assignment_record RECORD;
BEGIN
  -- Check if user already has an assigned wallet for this currency
  SELECT wa.*, pgw.address 
  INTO assignment_record 
  FROM public.wallet_assignments wa
  JOIN public.pre_generated_wallets pgw ON wa.wallet_id = pgw.id
  WHERE wa.user_id = user_id_input 
  AND wa.currency = currency_input;
  
  IF FOUND THEN
    RETURN json_build_object(
      'success', true, 
      'wallet', json_build_object(
        'id', assignment_record.wallet_id,
        'address', assignment_record.address,
        'currency', assignment_record.currency,
        'assigned_at', assignment_record.assigned_at
      ),
      'message', 'Existing wallet found'
    );
  END IF;
  
  -- Get any available wallet (users can share wallets)
  SELECT * INTO wallet_record 
  FROM public.pre_generated_wallets 
  WHERE currency = currency_input 
  ORDER BY created_at ASC 
  LIMIT 1;
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false, 
      'error', 'No available wallets for assignment'
    );
  END IF;
  
  -- Create assignment record
  INSERT INTO public.wallet_assignments (user_id, wallet_id, currency)
  VALUES (user_id_input, wallet_record.id, currency_input);
  
  RETURN json_build_object(
    'success', true, 
    'wallet', json_build_object(
      'id', wallet_record.id,
      'address', wallet_record.address,
      'currency', wallet_record.currency,
      'assigned_at', NOW()
    ),
    'message', 'New wallet assigned successfully'
  );
END;
$$;

-- Create function to insert pre-generated wallets (for admin use)
CREATE OR REPLACE FUNCTION public.insert_pre_generated_wallets(wallets_data JSON)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  wallet JSON;
  inserted_count INTEGER := 0;
  total_count INTEGER := 0;
BEGIN
  -- Check if the current user is admin
  IF NOT public.is_admin_user() THEN
    RETURN json_build_object('success', false, 'error', 'Unauthorized');
  END IF;
  
  -- Count total wallets to insert
  SELECT json_array_length(wallets_data) INTO total_count;
  
  -- Insert each wallet
  FOR wallet IN SELECT * FROM json_array_elements(wallets_data)
  LOOP
    BEGIN
      INSERT INTO public.pre_generated_wallets (address, currency)
      VALUES (
        wallet->>'address',
        COALESCE(wallet->>'currency', 'USDT')
      );
      inserted_count := inserted_count + 1;
    EXCEPTION WHEN unique_violation THEN
      -- Skip duplicate addresses
      CONTINUE;
    END;
  END LOOP;
  
  RETURN json_build_object(
    'success', true, 
    'message', format('Successfully inserted %s out of %s wallets', inserted_count, total_count)
  );
END;
$$;
