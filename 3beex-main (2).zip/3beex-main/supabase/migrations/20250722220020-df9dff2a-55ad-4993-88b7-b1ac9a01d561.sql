-- Update the check_transfer_fee function to apply simple 25% fee on transfer amount
CREATE OR REPLACE FUNCTION public.check_transfer_fee(user_id_input uuid, from_account text, to_account text, amount_input numeric)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  current_balance NUMERIC(12,2);
  fee_amount NUMERIC(12,2) := 0;
  final_transfer_amount NUMERIC(12,2);
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Apply 25% fee for transfers FROM trade account to exchange or perpetual
  IF from_account = 'trade' AND (to_account = 'exchange' OR to_account = 'perpetual') THEN
    -- Simple 25% fee on the transfer amount
    fee_amount := amount_input * 0.25;
    final_transfer_amount := amount_input - fee_amount;
  ELSE
    -- No fee for other transfers
    final_transfer_amount := amount_input;
  END IF;

  -- Return fee information
  RETURN json_build_object(
    'success', true,
    'will_apply_fee', fee_amount > 0,
    'fee_amount', fee_amount,
    'final_amount', final_transfer_amount,
    'original_amount', amount_input
  );
END;
$function$;