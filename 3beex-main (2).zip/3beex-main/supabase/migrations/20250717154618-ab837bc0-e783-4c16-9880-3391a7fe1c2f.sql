-- Add referral bonus settings
INSERT INTO public.platform_settings (key, value) VALUES 
('referral_bonus_percentage', '5.0'),
('referral_bonus_levels', '3'),
('referral_level_1_percentage', '5.0'),
('referral_level_2_percentage', '2.5'),
('referral_level_3_percentage', '1.0')
ON CONFLICT (key) DO NOTHING;

-- Create function to process referral bonuses
CREATE OR REPLACE FUNCTION public.process_referral_bonus(user_id_input uuid, trade_profit numeric)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_referrer_id uuid;
  current_level integer := 1;
  max_levels integer;
  bonus_percentage numeric;
  bonus_amount numeric;
  total_bonuses_paid numeric := 0;
  result json;
BEGIN
  -- Get referral bonus settings
  SELECT value::integer INTO max_levels 
  FROM public.platform_settings 
  WHERE key = 'referral_bonus_levels';
  
  IF max_levels IS NULL THEN
    max_levels := 3;
  END IF;
  
  -- Start with the user's referrer
  SELECT referred_by INTO current_referrer_id 
  FROM public.profiles 
  WHERE id = user_id_input;
  
  -- Process referral bonuses up to max levels
  WHILE current_referrer_id IS NOT NULL AND current_level <= max_levels LOOP
    -- Get bonus percentage for current level
    SELECT value::numeric INTO bonus_percentage 
    FROM public.platform_settings 
    WHERE key = 'referral_level_' || current_level || '_percentage';
    
    IF bonus_percentage IS NULL THEN
      -- Fallback to default percentage
      SELECT value::numeric INTO bonus_percentage 
      FROM public.platform_settings 
      WHERE key = 'referral_bonus_percentage';
      
      IF bonus_percentage IS NULL THEN
        bonus_percentage := 5.0;
      END IF;
      
      -- Reduce percentage for each level
      bonus_percentage := bonus_percentage / current_level;
    END IF;
    
    -- Calculate bonus amount
    bonus_amount := trade_profit * (bonus_percentage / 100);
    
    -- Update referrer's earnings in referrals table
    UPDATE public.referrals 
    SET earnings = earnings + bonus_amount
    WHERE referrer_id = current_referrer_id 
    AND referred_id IN (
      SELECT id FROM public.profiles 
      WHERE id = user_id_input OR referred_by = current_referrer_id
    );
    
    -- Credit referrer's exchange balance
    UPDATE public.profiles 
    SET exchange_balance = exchange_balance + bonus_amount,
        updated_at = NOW()
    WHERE id = current_referrer_id;
    
    total_bonuses_paid := total_bonuses_paid + bonus_amount;
    
    -- Move to next level (current referrer's referrer)
    SELECT referred_by INTO current_referrer_id 
    FROM public.profiles 
    WHERE id = current_referrer_id;
    
    current_level := current_level + 1;
  END LOOP;
  
  RETURN json_build_object(
    'success', true,
    'total_bonuses_paid', total_bonuses_paid,
    'levels_processed', current_level - 1
  );
END;
$$;