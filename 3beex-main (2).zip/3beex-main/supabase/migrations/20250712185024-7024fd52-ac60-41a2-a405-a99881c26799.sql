-- Create function to check if fee will be applied for a transfer
CREATE OR REPLACE FUNCTION public.check_transfer_fee(
  user_id_input UUID,
  from_account TEXT,
  to_account TEXT,
  amount_input NUMERIC
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_balance NUMERIC(12,2);
  current_trade_deposits NUMERIC(12,2);
  fee_amount NUMERIC(12,2) := 0;
  final_transfer_amount NUMERIC(12,2);
  has_doubled_trade_balance BOOLEAN := false;
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance, trade_account_deposits INTO current_balance, current_trade_deposits 
    FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Check if transferring from trade account and fee will be applied
  IF from_account = 'trade' AND (to_account = 'exchange' OR to_account = 'perpetual') THEN
    -- Check if user has doubled their trade account deposits
    IF (current_balance + amount_input) >= (current_trade_deposits * 2) THEN
      has_doubled_trade_balance := true;
    END IF;
    
    -- If user hasn't doubled their money, calculate fee
    IF NOT has_doubled_trade_balance THEN
      fee_amount := amount_input * 0.25;
      final_transfer_amount := amount_input - fee_amount;
    ELSE
      final_transfer_amount := amount_input;
    END IF;
  ELSE
    final_transfer_amount := amount_input;
  END IF;

  -- Return fee information
  RETURN json_build_object(
    'success', true,
    'will_apply_fee', fee_amount > 0,
    'fee_amount', fee_amount,
    'final_amount', final_transfer_amount,
    'original_amount', amount_input
  );
END;
$$;