-- Restore the proper doubling logic for transfer fees
CREATE OR REPLACE FUNCTION public.check_transfer_fee(
  user_id_input UUID,
  from_account TEXT,
  to_account TEXT,
  amount_input NUMERIC
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_balance NUMERIC(12,2);
  total_withdrawable NUMERIC(12,2) := 0;
  remaining_transfer NUMERIC(12,2) := amount_input;
  fee_amount NUMERIC(12,2) := 0;
  deposit_record RECORD;
  withdrawable_from_deposit NUMERIC(12,2);
  fee_on_deposit NUMERIC(12,2);
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Only apply fee logic for transfers FROM trade account
  IF from_account = 'trade' AND (to_account = 'exchange' OR to_account = 'perpetual') THEN
    -- Calculate fee based on deposits that haven't been doubled
    FOR deposit_record IN 
      SELECT id, amount, doubled_amount, available_for_withdrawal
      FROM public.trade_deposits 
      WHERE user_id = user_id_input 
      ORDER BY created_at ASC
    LOOP
      IF remaining_transfer <= 0 THEN
        EXIT;
      END IF;
      
      -- How much can be withdrawn from this deposit without fee
      withdrawable_from_deposit := LEAST(deposit_record.available_for_withdrawal, remaining_transfer);
      
      -- Deduct the withdrawable amount
      remaining_transfer := remaining_transfer - withdrawable_from_deposit;
      total_withdrawable := total_withdrawable + withdrawable_from_deposit;
    END LOOP;
    
    -- Any remaining amount after using all available withdrawals gets 25% fee
    IF remaining_transfer > 0 THEN
      fee_amount := remaining_transfer * 0.25;
    END IF;
  END IF;

  -- Return fee information
  RETURN json_build_object(
    'success', true,
    'will_apply_fee', fee_amount > 0,
    'fee_amount', fee_amount,
    'final_amount', amount_input - fee_amount,
    'original_amount', amount_input,
    'withdrawable_without_fee', total_withdrawable,
    'amount_with_fee', remaining_transfer
  );
END;
$$;

-- Update the transfer function to use the proper doubling logic
CREATE OR REPLACE FUNCTION public.transfer_between_accounts(
  user_id_input UUID,
  from_account TEXT,
  to_account TEXT,
  amount_input NUMERIC
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_balance NUMERIC(12,2);
  fee_amount NUMERIC(12,2) := 0;
  final_transfer_amount NUMERIC(12,2);
  transfer_id UUID;
  remaining_transfer NUMERIC(12,2) := amount_input;
  deposit_record RECORD;
  withdrawable_from_deposit NUMERIC(12,2);
  fee_on_remaining NUMERIC(12,2);
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Handle transfers TO trade account (no fee)
  IF to_account = 'trade' THEN
    -- Create new deposit record
    INSERT INTO public.trade_deposits (user_id, amount, available_for_withdrawal)
    VALUES (user_id_input, amount_input, 0);
    
    -- Update balances
    IF from_account = 'exchange' THEN
      UPDATE public.profiles 
      SET exchange_balance = exchange_balance - amount_input,
          trade_balance = trade_balance + amount_input,
          trade_account_deposits = trade_account_deposits + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF from_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET perpetual_balance = perpetual_balance - amount_input,
          trade_balance = trade_balance + amount_input,
          trade_account_deposits = trade_account_deposits + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    END IF;
    
    -- Log the transfer
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, 0, 'completed')
    RETURNING id INTO transfer_id;
    
    RETURN json_build_object('success', true, 'message', 'Transfer completed successfully', 'transfer_id', transfer_id);
  END IF;

  -- Handle transfers FROM trade account (apply doubling logic)
  IF from_account = 'trade' AND (to_account = 'exchange' OR to_account = 'perpetual') THEN
    -- Process withdrawals using available amounts first (no fee)
    FOR deposit_record IN 
      SELECT id, amount, doubled_amount, available_for_withdrawal
      FROM public.trade_deposits 
      WHERE user_id = user_id_input 
      ORDER BY created_at ASC
    LOOP
      IF remaining_transfer <= 0 THEN
        EXIT;
      END IF;
      
      -- How much can be withdrawn from this deposit without fee
      withdrawable_from_deposit := LEAST(deposit_record.available_for_withdrawal, remaining_transfer);
      
      IF withdrawable_from_deposit > 0 THEN
        -- Update the deposit record
        UPDATE public.trade_deposits 
        SET available_for_withdrawal = available_for_withdrawal - withdrawable_from_deposit,
            updated_at = NOW()
        WHERE id = deposit_record.id;
        
        -- Deduct from remaining transfer
        remaining_transfer := remaining_transfer - withdrawable_from_deposit;
      END IF;
    END LOOP;
    
    -- Apply 25% fee to any remaining amount
    IF remaining_transfer > 0 THEN
      fee_amount := remaining_transfer * 0.25;
    END IF;
    
    final_transfer_amount := amount_input - fee_amount;
    
    -- Update balances
    IF to_account = 'exchange' THEN
      UPDATE public.profiles 
      SET trade_balance = trade_balance - amount_input,
          exchange_balance = exchange_balance + final_transfer_amount,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF to_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET trade_balance = trade_balance - amount_input,
          perpetual_balance = perpetual_balance + final_transfer_amount,
          updated_at = NOW()
      WHERE id = user_id_input;
    END IF;
    
    -- Log the transfer with fee
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, fee_amount, 'completed')
    RETURNING id INTO transfer_id;
  ELSE
    -- Handle other transfers without fee (exchange <-> perpetual)
    final_transfer_amount := amount_input;
    
    IF from_account = 'exchange' AND to_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET exchange_balance = exchange_balance - amount_input,
          perpetual_balance = perpetual_balance + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF from_account = 'perpetual' AND to_account = 'exchange' THEN
      UPDATE public.profiles 
      SET perpetual_balance = perpetual_balance - amount_input,
          exchange_balance = exchange_balance + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSE
      RETURN json_build_object('success', false, 'error', 'Invalid account combination');
    END IF;
    
    -- Log the transfer
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, 0, 'completed')
    RETURNING id INTO transfer_id;
  END IF;

  -- Return success with fee information
  IF fee_amount > 0 THEN
    RETURN json_build_object(
      'success', true, 
      'message', 'Transfer completed with fee applied',
      'fee_applied', fee_amount,
      'amount_transferred', final_transfer_amount,
      'original_amount', amount_input,
      'transfer_id', transfer_id
    );
  ELSE
    RETURN json_build_object('success', true, 'message', 'Transfer completed successfully', 'transfer_id', transfer_id);
  END IF;
END;
$$;