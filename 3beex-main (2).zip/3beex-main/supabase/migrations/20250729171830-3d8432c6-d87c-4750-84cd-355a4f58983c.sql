-- Fix the complete_trade function math error
CREATE OR REPLACE FUNCTION public.complete_trade(trade_id_input uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  trade_record RECORD;
  trade_code_record RECORD;
  correct_profit_amount DECIMAL(12,2);
  actual_credit_amount DECIMAL(12,2);
  total_return DECIMAL(12,2);
BEGIN
  -- Get trade details
  SELECT * INTO trade_record FROM public.trades WHERE id = trade_id_input AND status = 'active';
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Trade not found or already completed');
  END IF;
  
  -- Get trade code details
  SELECT * INTO trade_code_record FROM public.trade_codes WHERE id = trade_record.trade_code_id;
  
  -- FIXED: Calculate profit based on the TRADE AMOUNT, not user's full balance
  correct_profit_amount := trade_record.amount * (trade_code_record.profit_percentage / 100);
  
  -- FIXED: Credit the full profit amount (not half)
  actual_credit_amount := correct_profit_amount;
  
  -- Total return is original trade amount + correct profit
  total_return := trade_record.amount + actual_credit_amount;
  
  -- Update trade with CORRECT profit amount
  UPDATE public.trades 
  SET 
    profit = correct_profit_amount,
    status = 'completed',
    completed_at = NOW(),
    updated_at = NOW()
  WHERE id = trade_id_input;
  
  -- Add back original trade amount + correct profit to user's trade balance
  UPDATE public.profiles 
  SET trade_balance = trade_balance + total_return, updated_at = NOW()
  WHERE id = trade_record.user_id;
  
  -- Mark deposits as doubled based on the actual profit earned
  PERFORM public.mark_deposits_doubled(trade_record.user_id, actual_credit_amount);
  
  RETURN json_build_object(
    'success', true, 
    'profit', correct_profit_amount,
    'actual_credit', actual_credit_amount,
    'total_return', total_return,
    'trade_id', trade_id_input
  );
END;
$function$