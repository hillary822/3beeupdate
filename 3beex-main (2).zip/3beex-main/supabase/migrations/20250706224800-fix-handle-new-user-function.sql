
-- Update the handle_new_user function to fix the referral validation issue
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  ref_code TEXT;
  referrer_id UUID;
BEGIN
  -- Generate unique referral code
  ref_code := 'REF' || UPPER(SUBSTRING(REPLACE(gen_random_uuid()::text, '-', ''), 1, 6));
  
  -- Check if user provided a referral code
  IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
    -- Find the referrer by their referral code directly (instead of using the function)
    SELECT id INTO referrer_id 
    FROM public.profiles 
    WHERE referral_code = NEW.raw_user_meta_data->>'referral_code';
    
    -- If no referrer found, raise an exception
    IF referrer_id IS NULL THEN
      RAISE EXCEPTION 'Invalid referral code provided: %', NEW.raw_user_meta_data->>'referral_code';
    END IF;
  END IF;
  
  -- Insert the new profile
  INSERT INTO public.profiles (id, username, email, referral_code, referred_by)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', SPLIT_PART(COALESCE(NEW.email, NEW.phone), '@', 1)),
    COALESCE(NEW.email, NEW.phone),
    ref_code,
    referrer_id
  );
  
  -- Create referral record if referrer exists
  IF referrer_id IS NOT NULL THEN
    INSERT INTO public.referrals (referrer_id, referred_id)
    VALUES (referrer_id, NEW.id);
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
