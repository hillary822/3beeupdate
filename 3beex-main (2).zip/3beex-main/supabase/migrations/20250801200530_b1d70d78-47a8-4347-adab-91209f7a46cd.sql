-- Update the use_trade_code function to use trade percentage logic
CREATE OR REPLACE FUNCTION public.use_trade_code(code_input text, user_id_input uuid)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  trade_code_record RECORD;
  user_profile RECORD;
  result JSON;
  new_trade_id UUID;
  user_full_balance NUMERIC;
  trade_amount NUMERIC;
  user_code_record RECORD;
BEGIN
  -- Get the trade code details
  SELECT * INTO trade_code_record
  FROM trade_codes 
  WHERE code = code_input;

  -- Check if code exists
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Invalid trade code'
    );
  END IF;

  -- Get user-specific code record if it exists
  SELECT * INTO user_code_record
  FROM user_codes 
  WHERE trade_code_id = trade_code_record.id 
  AND user_id = user_id_input;

  -- Check if code has expired 
  -- For codes sent to users: check sent_at + duration
  -- For direct codes: check created_at + duration
  IF user_code_record.sent_at IS NOT NULL THEN
    IF (user_code_record.sent_at + (trade_code_record.duration_minutes || ' minutes')::INTERVAL) < NOW() THEN
      RETURN json_build_object(
        'success', false,
        'error', 'Trade code has expired'
      );
    END IF;
  ELSE
    -- For codes not sent to users, check if they've expired based on creation time
    -- Allow a longer expiration window (e.g., 24 hours) for direct codes
    IF (trade_code_record.created_at + INTERVAL '24 hours') < NOW() THEN
      RETURN json_build_object(
        'success', false,
        'error', 'Trade code has expired'
      );
    END IF;
  END IF;

  -- Check if this code was sent to users and if so, verify the user has access
  IF EXISTS(SELECT 1 FROM user_codes WHERE trade_code_id = trade_code_record.id) THEN
    -- Code was sent to specific users, check if this user is one of them
    IF user_code_record.id IS NULL THEN
      RETURN json_build_object(
        'success', false,
        'error', 'This trade code was not assigned to you'
      );
    END IF;
    
    -- Check if user has already used this code
    IF user_code_record.is_used THEN
      RETURN json_build_object(
        'success', false,
        'error', 'You have already used this trade code'
      );
    END IF;
  ELSE
    -- For direct codes, check if user has already used this specific code
    IF EXISTS(SELECT 1 FROM trades WHERE user_id = user_id_input AND trade_code_id = trade_code_record.id) THEN
      RETURN json_build_object(
        'success', false,
        'error', 'You have already used this trade code'
      );
    END IF;
  END IF;

  -- Get user profile
  SELECT * INTO user_profile FROM profiles WHERE id = user_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'User profile not found'
    );
  END IF;

  -- Check if user account is suspended or locked
  IF user_profile.suspended OR user_profile.locked THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Account is suspended or locked'
    );
  END IF;

  -- Check premium requirement
  IF trade_code_record.is_premium AND NOT user_profile.premium THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Premium account required for this trade code'
    );
  END IF;

  -- Check VIP requirement
  IF trade_code_record.is_vip AND NOT user_profile.vip THEN
    RETURN json_build_object(
      'success', false,
      'error', 'VIP account required for this trade code'
    );
  END IF;

  -- Get user's full trade balance
  user_full_balance := user_profile.trade_balance;

  -- Check minimum balance requirement
  IF user_full_balance < trade_code_record.minimum_balance THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Insufficient balance. Required: $' || trade_code_record.minimum_balance
    );
  END IF;

  -- NEW LOGIC: Calculate trade amount as percentage of user's balance
  -- profit_percentage is now actually trade_percentage
  trade_amount := user_full_balance * (trade_code_record.profit_percentage / 100);
  
  -- Ensure trade amount is reasonable (not zero)
  IF trade_amount <= 0 THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Trade amount too small'
    );
  END IF;

  -- Deduct the calculated trade amount from user's balance
  UPDATE public.profiles 
  SET trade_balance = trade_balance - trade_amount,
      updated_at = NOW()
  WHERE id = user_id_input;

  -- Create the trade with the calculated trade amount
  INSERT INTO trades (
    user_id,
    trade_code,
    trade_code_id,
    type,
    asset,
    amount,
    status,
    started_at
  ) VALUES (
    user_id_input,
    code_input,
    trade_code_record.id,
    trade_code_record.signal_type,
    trade_code_record.asset,
    trade_amount,
    'active',
    NOW()
  ) RETURNING id INTO new_trade_id;

  -- Mark user code as used if it exists (NOT the global trade code)
  IF user_code_record.id IS NOT NULL THEN
    UPDATE user_codes 
    SET is_used = true, 
        used_at = NOW()
    WHERE id = user_code_record.id;
  END IF;

  -- Return success response
  RETURN json_build_object(
    'success', true,
    'trade_id', new_trade_id,
    'duration_minutes', trade_code_record.duration_minutes,
    'asset', trade_code_record.asset,
    'trade_percentage', trade_code_record.profit_percentage,
    'amount_invested', trade_amount,
    'original_balance', user_full_balance
  );
END;
$function$;

-- Update the complete_trade function to always return 100% profit
CREATE OR REPLACE FUNCTION public.complete_trade(trade_id_input uuid)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  trade_record RECORD;
  trade_code_record RECORD;
  profit_amount DECIMAL(12,2);
  total_return DECIMAL(12,2);
BEGIN
  -- Get trade details
  SELECT * INTO trade_record FROM public.trades WHERE id = trade_id_input AND status = 'active';
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Trade not found or already completed');
  END IF;
  
  -- Get trade code details
  SELECT * INTO trade_code_record FROM public.trade_codes WHERE id = trade_record.trade_code_id;
  
  -- NEW LOGIC: All successful trades return 100% profit on the deducted amount
  profit_amount := trade_record.amount; -- 100% of the trade amount
  
  -- Total return is the original trade amount + profit (so 2x the trade amount)
  total_return := trade_record.amount + profit_amount;
  
  -- Update trade with calculated profit amount
  UPDATE public.trades 
  SET 
    profit = profit_amount,
    status = 'completed',
    completed_at = NOW(),
    updated_at = NOW()
  WHERE id = trade_id_input;
  
  -- Add back trade amount + profit to user's trade balance
  UPDATE public.profiles 
  SET trade_balance = trade_balance + total_return, updated_at = NOW()
  WHERE id = trade_record.user_id;
  
  -- Mark deposits as doubled based on the actual profit earned
  PERFORM public.mark_deposits_doubled(trade_record.user_id, profit_amount);
  
  RETURN json_build_object(
    'success', true, 
    'profit', profit_amount,
    'total_return', total_return,
    'trade_amount', trade_record.amount,
    'trade_id', trade_id_input
  );
END;
$function$;