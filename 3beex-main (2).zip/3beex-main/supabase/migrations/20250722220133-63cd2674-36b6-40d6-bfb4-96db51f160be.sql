-- Update the transfer_between_accounts function to apply simple 25% fee
CREATE OR REPLACE FUNCTION public.transfer_between_accounts(user_id_input uuid, from_account text, to_account text, amount_input numeric)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  current_balance NUMERIC(12,2);
  fee_amount NUMERIC(12,2) := 0;
  final_transfer_amount NUMERIC(12,2);
  transfer_id UUID;
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Handle transfers TO trade account (no fee)
  IF to_account = 'trade' THEN
    -- Create new deposit record
    INSERT INTO public.trade_deposits (user_id, amount, available_for_withdrawal)
    VALUES (user_id_input, amount_input, 0);
    
    -- Update balances
    IF from_account = 'exchange' THEN
      UPDATE public.profiles 
      SET exchange_balance = exchange_balance - amount_input,
          trade_balance = trade_balance + amount_input,
          trade_account_deposits = trade_account_deposits + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF from_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET perpetual_balance = perpetual_balance - amount_input,
          trade_balance = trade_balance + amount_input,
          trade_account_deposits = trade_account_deposits + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    END IF;
    
    -- Log the transfer
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, 0, 'completed')
    RETURNING id INTO transfer_id;
    
    RETURN json_build_object('success', true, 'message', 'Transfer completed successfully', 'transfer_id', transfer_id);
  END IF;

  -- Handle transfers FROM trade account (apply 25% fee)
  IF from_account = 'trade' AND (to_account = 'exchange' OR to_account = 'perpetual') THEN
    -- Simple 25% fee on the transfer amount
    fee_amount := amount_input * 0.25;
    final_transfer_amount := amount_input - fee_amount;
    
    -- Update balances
    IF to_account = 'exchange' THEN
      UPDATE public.profiles 
      SET trade_balance = trade_balance - amount_input,
          exchange_balance = exchange_balance + final_transfer_amount,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF to_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET trade_balance = trade_balance - amount_input,
          perpetual_balance = perpetual_balance + final_transfer_amount,
          updated_at = NOW()
      WHERE id = user_id_input;
    END IF;
    
    -- Log the transfer with fee
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, fee_amount, 'completed')
    RETURNING id INTO transfer_id;
  ELSE
    -- Handle other transfers without fee (exchange <-> perpetual)
    final_transfer_amount := amount_input;
    
    IF from_account = 'exchange' AND to_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET exchange_balance = exchange_balance - amount_input,
          perpetual_balance = perpetual_balance + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF from_account = 'perpetual' AND to_account = 'exchange' THEN
      UPDATE public.profiles 
      SET perpetual_balance = perpetual_balance - amount_input,
          exchange_balance = exchange_balance + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSE
      RETURN json_build_object('success', false, 'error', 'Invalid account combination');
    END IF;
    
    -- Log the transfer
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, 0, 'completed')
    RETURNING id INTO transfer_id;
  END IF;

  -- Return success with fee information
  IF fee_amount > 0 THEN
    RETURN json_build_object(
      'success', true, 
      'message', 'Transfer completed with fee applied',
      'fee_applied', fee_amount,
      'amount_transferred', final_transfer_amount,
      'original_amount', amount_input,
      'transfer_id', transfer_id
    );
  ELSE
    RETURN json_build_object('success', true, 'message', 'Transfer completed successfully', 'transfer_id', transfer_id);
  END IF;
END;
$function$;