-- Create table for sent codes to users
CREATE TABLE public.user_codes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  trade_code_id UUID NOT NULL,
  code TEXT NOT NULL,
  sent_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  used_at TIMESTAMP WITH TIME ZONE NULL,
  is_used BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies
ALTER TABLE public.user_codes ENABLE ROW LEVEL SECURITY;

-- Users can view their own codes
CREATE POLICY "Users can view their own codes"
ON public.user_codes 
FOR SELECT 
USING (auth.uid() = user_id);

-- Users can update their own codes (for marking as used)
CREATE POLICY "Users can update their own codes"
ON public.user_codes 
FOR UPDATE 
USING (auth.uid() = user_id);

-- System can insert user codes
CREATE POLICY "System can insert user codes"
ON public.user_codes 
FOR INSERT 
WITH CHECK (true);

-- Admins can view all user codes
CREATE POLICY "Admins can view all user codes"
ON public.user_codes 
FOR SELECT 
USING (is_admin_user());

-- Create edge function to send codes to users
CREATE OR REPLACE FUNCTION public.send_code_to_users(trade_code_id_input UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  trade_code_record RECORD;
  user_record RECORD;
  inserted_count INTEGER := 0;
BEGIN
  -- Check if user is admin
  IF NOT is_admin_user() THEN
    RETURN json_build_object('success', false, 'error', 'Unauthorized');
  END IF;

  -- Get trade code details
  SELECT * INTO trade_code_record 
  FROM public.trade_codes 
  WHERE id = trade_code_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Trade code not found');
  END IF;

  -- Send to appropriate users based on code type
  IF trade_code_record.is_vip THEN
    -- Send to VIP users only
    FOR user_record IN 
      SELECT id FROM public.profiles 
      WHERE vip_level > 0
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS inserted_count = ROW_COUNT;
      IF inserted_count > 0 THEN
        inserted_count := inserted_count + 1;
      END IF;
    END LOOP;
  ELSIF trade_code_record.is_premium THEN
    -- Send to premium users and users who have referred someone
    FOR user_record IN 
      SELECT DISTINCT p.id FROM public.profiles p
      WHERE p.premium = true 
      OR EXISTS (SELECT 1 FROM public.referrals r WHERE r.referrer_id = p.id)
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS inserted_count = ROW_COUNT;
      IF inserted_count > 0 THEN
        inserted_count := inserted_count + 1;
      END IF;
    END LOOP;
  ELSE
    -- Send to all users
    FOR user_record IN 
      SELECT id FROM public.profiles
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS inserted_count = ROW_COUNT;
      IF inserted_count > 0 THEN
        inserted_count := inserted_count + 1;
      END IF;
    END LOOP;
  END IF;

  RETURN json_build_object(
    'success', true, 
    'message', format('Code sent to %s users', inserted_count),
    'users_count', inserted_count
  );
END;
$$;

-- Add unique constraint to prevent duplicate codes per user
ALTER TABLE public.user_codes 
ADD CONSTRAINT unique_user_trade_code 
UNIQUE (user_id, trade_code_id);