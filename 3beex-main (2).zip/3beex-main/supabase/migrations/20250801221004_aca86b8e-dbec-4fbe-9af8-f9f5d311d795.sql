-- Update complete_trade function to apply 30% platform fee on profits
CREATE OR REPLACE FUNCTION public.complete_trade(trade_id_input uuid)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  trade_record RECORD;
  trade_code_record RECORD;
  profit_amount DECIMAL(12,2);
  platform_fee DECIMAL(12,2);
  user_profit DECIMAL(12,2);
  total_return DECIMAL(12,2);
BEGIN
  -- Get trade details
  SELECT * INTO trade_record FROM public.trades WHERE id = trade_id_input AND status = 'active';
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Trade not found or already completed');
  END IF;
  
  -- Get trade code details
  SELECT * INTO trade_code_record FROM public.trade_codes WHERE id = trade_record.trade_code_id;
  
  -- Calculate profit based on WIN/LOSS setting
  IF trade_code_record.win_or_loss = 'WIN' THEN
    -- Winning trade: 100% profit on the deducted amount
    profit_amount := trade_record.amount;
    
    -- Apply 30% platform fee on profit only
    platform_fee := profit_amount * 0.30;
    user_profit := profit_amount - platform_fee;
    
    -- Total return is original trade amount + user's share of profit
    total_return := trade_record.amount + user_profit;
  ELSE
    -- Losing trade: no profit, lose the trade amount
    profit_amount := -trade_record.amount; -- Negative to show loss
    platform_fee := 0; -- No fee on losses
    user_profit := profit_amount;
    total_return := 0; -- No return to balance
  END IF;
  
  -- Update trade with calculated profit amount (user's portion)
  UPDATE public.trades 
  SET 
    profit = user_profit,
    status = 'completed',
    completed_at = NOW(),
    updated_at = NOW()
  WHERE id = trade_id_input;
  
  -- Add back to user's trade balance only if winning
  IF trade_code_record.win_or_loss = 'WIN' THEN
    UPDATE public.profiles 
    SET trade_balance = trade_balance + total_return, updated_at = NOW()
    WHERE id = trade_record.user_id;
    
    -- Mark deposits as doubled based on the user's profit earned (after platform fee)
    PERFORM public.mark_deposits_doubled(trade_record.user_id, user_profit);
  END IF;
  
  RETURN json_build_object(
    'success', true, 
    'profit', user_profit,
    'platform_fee', platform_fee,
    'total_return', total_return,
    'trade_amount', trade_record.amount,
    'trade_id', trade_id_input,
    'result', trade_code_record.win_or_loss
  );
END;
$function$;