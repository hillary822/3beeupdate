-- Add admin policy for referrals table to allow admins to view all referrals
CREATE POLICY "Admins can view all referrals" 
ON public.referrals 
FOR SELECT 
USING (is_admin_user());

-- Add admin policy for profiles to ensure admins can see all profiles in referral trees
CREATE POLICY "Admins can view all profiles for referral trees" 
ON public.profiles 
FOR SELECT 
USING (is_admin_user());