-- Fix the update_user_balance function to avoid ambiguous column references
CREATE OR REPLACE FUNCTION public.update_user_balance(user_id uuid, amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Use fully qualified column names to avoid ambiguity
  UPDATE public.profiles 
  SET exchange_balance = public.profiles.exchange_balance + amount,
      updated_at = NOW()
  WHERE public.profiles.id = user_id;
END;
$$;