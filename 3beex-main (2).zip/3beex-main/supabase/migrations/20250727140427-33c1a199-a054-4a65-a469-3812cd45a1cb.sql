-- Create a function to get support email that users can call
CREATE OR REPLACE FUNCTION public.get_support_email()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  support_email_value text;
BEGIN
  -- Get support email from platform settings
  SELECT value INTO support_email_value
  FROM public.platform_settings 
  WHERE key = 'support_email';
  
  -- Return the email or default if not found
  RETURN COALESCE(support_email_value, 'support@3beetex.com');
END;
$$;