-- Drop existing policies to recreate them properly
DROP POLICY IF EXISTS "Admins can view all KYC documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload their own KYC documents" ON storage.objects;
DROP POLICY IF EXISTS "Service role can manage KYC documents" ON storage.objects;

-- Create proper policies for kyc-documents bucket
CREATE POLICY "Admins can view all KYC documents" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'kyc-documents' AND is_admin_user());

CREATE POLICY "Users can upload their own KYC documents" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'kyc-documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Service role can manage KYC documents" 
ON storage.objects 
FOR ALL 
USING (bucket_id = 'kyc-documents');