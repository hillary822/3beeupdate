-- Add permanent_signal field to profiles table
ALTER TABLE public.profiles 
ADD COLUMN permanent_signal boolean NOT NULL DEFAULT false;

-- Add win_or_loss field to trade_codes table  
ALTER TABLE public.trade_codes 
ADD COLUMN win_or_loss text NOT NULL DEFAULT 'WIN';

-- Add check constraint to ensure valid values
ALTER TABLE public.trade_codes 
ADD CONSTRAINT trade_codes_win_or_loss_check 
CHECK (win_or_loss IN ('WIN', 'LOSS'));

-- Update the use_trade_code function to:
-- 1. Check expiration based on created_at instead of sent_at
-- 2. Allow any eligible user to use the code
CREATE OR REPLACE FUNCTION public.use_trade_code(code_input text, user_id_input uuid)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  trade_code_record RECORD;
  user_profile RECORD;
  result JSON;
  new_trade_id UUID;
  user_full_balance NUMERIC;
  trade_amount NUMERIC;
  user_code_record RECORD;
BEGIN
  -- Get the trade code details
  SELECT * INTO trade_code_record
  FROM trade_codes 
  WHERE code = code_input;

  -- Check if code exists
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Invalid trade code'
    );
  END IF;

  -- Check if code has expired based on creation time + duration
  IF (trade_code_record.created_at + (trade_code_record.duration_minutes || ' minutes')::INTERVAL) < NOW() THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Trade code has expired'
    );
  END IF;

  -- Get user profile
  SELECT * INTO user_profile FROM profiles WHERE id = user_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'User profile not found'
    );
  END IF;

  -- Check if user account is suspended or locked
  IF user_profile.suspended OR user_profile.locked THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Account is suspended or locked'
    );
  END IF;

  -- Check eligibility based on code type
  IF trade_code_record.is_premium AND NOT user_profile.premium THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Premium account required for this trade code'
    );
  END IF;

  IF trade_code_record.is_vip AND NOT user_profile.vip THEN
    RETURN json_build_object(
      'success', false,
      'error', 'VIP account required for this trade code'
    );
  END IF;

  -- Check if user has already used this specific code
  IF EXISTS(SELECT 1 FROM trades WHERE user_id = user_id_input AND trade_code_id = trade_code_record.id) THEN
    RETURN json_build_object(
      'success', false,
      'error', 'You have already used this trade code'
    );
  END IF;

  -- Get user's full trade balance
  user_full_balance := user_profile.trade_balance;

  -- Check minimum balance requirement
  IF user_full_balance < trade_code_record.minimum_balance THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Insufficient balance. Required: $' || trade_code_record.minimum_balance
    );
  END IF;

  -- Calculate trade amount as percentage of user's balance
  trade_amount := user_full_balance * (trade_code_record.profit_percentage / 100);
  
  -- Ensure trade amount is reasonable (not zero)
  IF trade_amount <= 0 THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Trade amount too small'
    );
  END IF;

  -- Deduct the calculated trade amount from user's balance
  UPDATE public.profiles 
  SET trade_balance = trade_balance - trade_amount,
      updated_at = NOW()
  WHERE id = user_id_input;

  -- Create the trade with the calculated trade amount
  INSERT INTO trades (
    user_id,
    trade_code,
    trade_code_id,
    type,
    asset,
    amount,
    status,
    started_at
  ) VALUES (
    user_id_input,
    code_input,
    trade_code_record.id,
    trade_code_record.signal_type,
    trade_code_record.asset,
    trade_amount,
    'active',
    NOW()
  ) RETURNING id INTO new_trade_id;

  -- Mark user code as used if it exists (for users who were sent the code)
  UPDATE user_codes 
  SET is_used = true, 
      used_at = NOW()
  WHERE user_id = user_id_input AND trade_code_id = trade_code_record.id;

  -- Return success response
  RETURN json_build_object(
    'success', true,
    'trade_id', new_trade_id,
    'duration_minutes', trade_code_record.duration_minutes,
    'asset', trade_code_record.asset,
    'trade_percentage', trade_code_record.profit_percentage,
    'amount_invested', trade_amount,
    'original_balance', user_full_balance
  );
END;
$function$;

-- Update the complete_trade function to handle WIN/LOSS logic
CREATE OR REPLACE FUNCTION public.complete_trade(trade_id_input uuid)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  trade_record RECORD;
  trade_code_record RECORD;
  profit_amount DECIMAL(12,2);
  total_return DECIMAL(12,2);
BEGIN
  -- Get trade details
  SELECT * INTO trade_record FROM public.trades WHERE id = trade_id_input AND status = 'active';
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Trade not found or already completed');
  END IF;
  
  -- Get trade code details
  SELECT * INTO trade_code_record FROM public.trade_codes WHERE id = trade_record.trade_code_id;
  
  -- Calculate profit based on WIN/LOSS setting
  IF trade_code_record.win_or_loss = 'WIN' THEN
    -- Winning trade: 100% profit on the deducted amount
    profit_amount := trade_record.amount;
    total_return := trade_record.amount + profit_amount; -- Return original + profit
  ELSE
    -- Losing trade: no profit, lose the trade amount
    profit_amount := -trade_record.amount; -- Negative to show loss
    total_return := 0; -- No return to balance
  END IF;
  
  -- Update trade with calculated profit amount
  UPDATE public.trades 
  SET 
    profit = profit_amount,
    status = 'completed',
    completed_at = NOW(),
    updated_at = NOW()
  WHERE id = trade_id_input;
  
  -- Add back to user's trade balance only if winning
  IF trade_code_record.win_or_loss = 'WIN' THEN
    UPDATE public.profiles 
    SET trade_balance = trade_balance + total_return, updated_at = NOW()
    WHERE id = trade_record.user_id;
    
    -- Mark deposits as doubled based on the actual profit earned
    PERFORM public.mark_deposits_doubled(trade_record.user_id, profit_amount);
  END IF;
  
  RETURN json_build_object(
    'success', true, 
    'profit', profit_amount,
    'total_return', total_return,
    'trade_amount', trade_record.amount,
    'trade_id', trade_id_input,
    'result', trade_code_record.win_or_loss
  );
END;
$function$;

-- Update send_code_to_users function to include permanent signal users
CREATE OR REPLACE FUNCTION public.send_code_to_users(trade_code_id_input uuid)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  trade_code_record RECORD;
  user_record RECORD;
  total_inserted_count INTEGER := 0;
  current_insert_count INTEGER := 0;
BEGIN
  -- Check if user is admin
  IF NOT is_admin_user() THEN
    RETURN json_build_object('success', false, 'error', 'Unauthorized');
  END IF;

  -- Get trade code details
  SELECT * INTO trade_code_record 
  FROM public.trade_codes 
  WHERE id = trade_code_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Trade code not found');
  END IF;
  
  -- Check if code has already been sent
  IF trade_code_record.sent_at IS NOT NULL THEN
    RETURN json_build_object('success', false, 'error', 'This code has already been sent to users');
  END IF;

  -- Mark the code as sent
  UPDATE public.trade_codes 
  SET sent_at = NOW()
  WHERE id = trade_code_id_input;

  -- Send to appropriate users based on code type
  IF trade_code_record.is_vip THEN
    -- Send to VIP users and permanent signal users
    FOR user_record IN 
      SELECT id FROM public.profiles 
      WHERE vip_level > 0 OR permanent_signal = true
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS current_insert_count = ROW_COUNT;
      total_inserted_count := total_inserted_count + current_insert_count;
    END LOOP;
  ELSIF trade_code_record.is_premium THEN
    -- Send to premium users, users who have referred someone, and permanent signal users
    FOR user_record IN 
      SELECT DISTINCT p.id FROM public.profiles p
      WHERE p.premium = true 
      OR p.permanent_signal = true
      OR EXISTS (SELECT 1 FROM public.referrals r WHERE r.referrer_id = p.id)
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS current_insert_count = ROW_COUNT;
      total_inserted_count := total_inserted_count + current_insert_count;
    END LOOP;
  ELSE
    -- Send to all users
    FOR user_record IN 
      SELECT id FROM public.profiles
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS current_insert_count = ROW_COUNT;
      total_inserted_count := total_inserted_count + current_insert_count;
    END LOOP;
  END IF;

  RETURN json_build_object(
    'success', true, 
    'message', format('Code sent to %s users and will expire in %s minutes from creation time', total_inserted_count, trade_code_record.duration_minutes),
    'users_count', total_inserted_count
  );
END;
$function$;