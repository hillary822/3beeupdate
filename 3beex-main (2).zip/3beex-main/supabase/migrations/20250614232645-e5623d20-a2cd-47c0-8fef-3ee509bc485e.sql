
-- Create a table for payment methods (BTC, USDT, etc.)
CREATE TABLE public.payment_methods (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE, -- 'BTC', 'USDT_TRC20', etc.
  display_name TEXT NOT NULL, -- 'Bitcoin', 'USDT (TRC20)', etc.
  wallet_address TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Insert default payment methods
INSERT INTO public.payment_methods (name, display_name, wallet_address) VALUES 
('BTC', 'Bitcoin', 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh'),
('USDT_TRC20', 'USDT (TRC20)', 'TYDzsYUEpvnYmQk4zGV9sNrQTpQZqNhHyh');

-- Update deposits table to include payment method and make status default to pending
ALTER TABLE public.deposits 
ADD COLUMN IF NOT EXISTS payment_method_id UUID REFERENCES public.payment_methods(id),
ADD COLUMN IF NOT EXISTS payment_method_name TEXT,
ADD COLUMN IF NOT EXISTS wallet_address TEXT,
ADD COLUMN IF NOT EXISTS transaction_hash TEXT;

-- Only alter status default if it's not already set
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'deposits' 
    AND column_name = 'status' 
    AND column_default = '''pending''::text'
  ) THEN
    ALTER TABLE public.deposits ALTER COLUMN status SET DEFAULT 'pending';
  END IF;
END $$;

-- Add RLS policies for payment methods (read-only for users, full access for admins)
ALTER TABLE public.payment_methods ENABLE ROW LEVEL SECURITY;

-- Drop and recreate payment method policies to avoid conflicts
DROP POLICY IF EXISTS "Users can view active payment methods" ON public.payment_methods;
DROP POLICY IF EXISTS "Admins can manage payment methods" ON public.payment_methods;

-- Users can view active payment methods
CREATE POLICY "Users can view active payment methods" 
  ON public.payment_methods 
  FOR SELECT 
  USING (is_active = true);

-- Admins can do everything with payment methods
CREATE POLICY "Admins can manage payment methods" 
  ON public.payment_methods 
  FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM auth.users 
    WHERE auth.users.id = auth.uid() 
    AND auth.users.email = 'admin@admin.com'
  ));

-- Enable RLS on deposits if not already enabled
ALTER TABLE public.deposits ENABLE ROW LEVEL SECURITY;

-- Drop existing deposit policies and recreate them
DROP POLICY IF EXISTS "Users can view their own deposits" ON public.deposits;
DROP POLICY IF EXISTS "Users can create deposit requests" ON public.deposits;
DROP POLICY IF EXISTS "Admins can manage all deposits" ON public.deposits;

-- Users can view their own deposits
CREATE POLICY "Users can view their own deposits" 
  ON public.deposits 
  FOR SELECT 
  USING (auth.uid() = user_id);

-- Users can create their own deposit requests
CREATE POLICY "Users can create deposit requests" 
  ON public.deposits 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Admins can view and update all deposits
CREATE POLICY "Admins can manage all deposits" 
  ON public.deposits 
  FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM auth.users 
    WHERE auth.users.id = auth.uid() 
    AND auth.users.email = 'admin@admin.com'
  ));
