-- Fix the use_trade_code function to properly mark codes as used
-- and handle expiration for all codes, not just sent ones
CREATE OR REPLACE FUNCTION use_trade_code(
  code_input TEXT,
  user_id_input UUID
) RETURNS JSON AS $$
DECLARE
  trade_code_record RECORD;
  user_profile RECORD;
  result JSON;
  new_trade_id UUID;
  balance_to_use NUMERIC;
BEGIN
  -- Get the trade code details including join with user_codes for sent_at
  SELECT tc.*, uc.sent_at, uc.user_id as assigned_user_id
  INTO trade_code_record
  FROM trade_codes tc
  LEFT JOIN user_codes uc ON uc.trade_code_id = tc.id AND uc.code = code_input
  WHERE tc.code = code_input;

  -- Check if code exists
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Invalid trade code'
    );
  END IF;

  -- Check if code has already been used
  IF trade_code_record.is_used THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Trade code has already been used'
    );
  END IF;

  -- Check if code has expired 
  -- For codes sent to users: check sent_at + duration
  -- For direct codes: check created_at + duration
  IF trade_code_record.sent_at IS NOT NULL THEN
    IF (trade_code_record.sent_at + (trade_code_record.duration_minutes || ' minutes')::INTERVAL) < NOW() THEN
      -- Mark the code as used/expired
      UPDATE trade_codes 
      SET is_used = true, 
          used_at = NOW(),
          used_by = user_id_input
      WHERE id = trade_code_record.id;
      
      RETURN json_build_object(
        'success', false,
        'error', 'Trade code has expired'
      );
    END IF;
  ELSE
    -- For codes not sent to users, check if they've expired based on creation time
    -- Allow a longer expiration window (e.g., 24 hours) for direct codes
    IF (trade_code_record.created_at + INTERVAL '24 hours') < NOW() THEN
      -- Mark the code as used/expired
      UPDATE trade_codes 
      SET is_used = true, 
          used_at = NOW(),
          used_by = user_id_input
      WHERE id = trade_code_record.id;
      
      RETURN json_build_object(
        'success', false,
        'error', 'Trade code has expired'
      );
    END IF;
  END IF;

  -- Check if this code was assigned to a specific user and if so, verify it's the right user
  IF trade_code_record.assigned_user_id IS NOT NULL AND trade_code_record.assigned_user_id != user_id_input THEN
    RETURN json_build_object(
      'success', false,
      'error', 'This trade code was not assigned to you'
    );
  END IF;

  -- Get user profile
  SELECT * INTO user_profile FROM profiles WHERE id = user_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'User profile not found'
    );
  END IF;

  -- Check if user account is suspended or locked
  IF user_profile.suspended OR user_profile.locked THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Account is suspended or locked'
    );
  END IF;

  -- Check premium requirement
  IF trade_code_record.is_premium AND NOT user_profile.premium THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Premium account required for this trade code'
    );
  END IF;

  -- Check VIP requirement
  IF trade_code_record.is_vip AND NOT user_profile.vip THEN
    RETURN json_build_object(
      'success', false,
      'error', 'VIP account required for this trade code'
    );
  END IF;

  -- Determine which balance to use
  balance_to_use := user_profile.trade_balance;

  -- Check minimum balance requirement
  IF balance_to_use < trade_code_record.minimum_balance THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Insufficient balance. Minimum required: $' || trade_code_record.minimum_balance
    );
  END IF;

  -- Calculate investment amount (10% of trade balance)
  DECLARE
    investment_amount NUMERIC := balance_to_use * 0.1;
  BEGIN
    -- Create the trade
    INSERT INTO trades (
      user_id,
      trade_code,
      trade_code_id,
      type,
      asset,
      amount,
      status,
      started_at
    ) VALUES (
      user_id_input,
      code_input,
      trade_code_record.id,
      trade_code_record.signal_type,
      trade_code_record.asset,
      investment_amount,
      'active',
      NOW()
    ) RETURNING id INTO new_trade_id;

    -- IMPORTANT: Mark the trade code as used immediately after first use
    UPDATE trade_codes 
    SET is_used = true, 
        used_at = NOW(),
        used_by = user_id_input
    WHERE id = trade_code_record.id;

    -- Mark user code as used if it exists
    UPDATE user_codes 
    SET is_used = true, 
        used_at = NOW()
    WHERE trade_code_id = trade_code_record.id AND user_id = user_id_input;

    -- Return success response
    RETURN json_build_object(
      'success', true,
      'trade_id', new_trade_id,
      'duration_minutes', trade_code_record.duration_minutes,
      'asset', trade_code_record.asset,
      'profit_percentage', trade_code_record.profit_percentage,
      'amount_invested', investment_amount
    );
  END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a system function to complete all overdue trades
CREATE OR REPLACE FUNCTION complete_overdue_trades()
RETURNS JSON AS $$
DECLARE
  trade_record RECORD;
  completed_count INTEGER := 0;
  result_details JSON[] := '{}';
  completion_result JSON;
BEGIN
  -- Find all active trades that should have completed
  FOR trade_record IN 
    SELECT t.id, t.started_at, tc.duration_minutes
    FROM trades t
    JOIN trade_codes tc ON t.trade_code_id = tc.id
    WHERE t.status = 'active'
    AND (t.started_at + (tc.duration_minutes || ' minutes')::INTERVAL) < NOW()
  LOOP
    -- Complete each overdue trade
    SELECT complete_trade(trade_record.id) INTO completion_result;
    
    IF (completion_result->>'success')::boolean THEN
      completed_count := completed_count + 1;
      result_details := result_details || completion_result;
    END IF;
  END LOOP;
  
  RETURN json_build_object(
    'success', true,
    'completed_trades', completed_count,
    'details', result_details
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;