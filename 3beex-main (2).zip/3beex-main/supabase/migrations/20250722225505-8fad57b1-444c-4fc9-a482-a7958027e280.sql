-- Fix deposits status check constraint to allow rejected status
ALTER TABLE public.deposits DROP CONSTRAINT IF EXISTS deposits_status_check;

-- Add updated check constraint that includes rejected status
ALTER TABLE public.deposits ADD CONSTRAINT deposits_status_check 
    CHECK (status IN ('pending', 'completed', 'rejected', 'failed'));