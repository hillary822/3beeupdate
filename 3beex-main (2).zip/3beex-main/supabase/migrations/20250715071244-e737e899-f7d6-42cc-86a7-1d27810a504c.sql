-- Add premium field to profiles table
ALTER TABLE public.profiles 
ADD COLUMN premium boolean DEFAULT false;