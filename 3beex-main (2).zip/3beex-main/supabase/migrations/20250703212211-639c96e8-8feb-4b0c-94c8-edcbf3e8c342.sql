
-- Add a function to validate referral codes at the database level
CREATE OR REPLACE FUNCTION validate_referral_code(ref_code TEXT)
RETURNS BOOLEAN AS $$
BEGIN
  -- Check if referral code exists and return true/false
  RETURN EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE referral_code = ref_code
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update the handle_new_user function to validate referral codes
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  ref_code TEXT;
  referrer_id UUID;
  is_valid_ref BOOLEAN;
BEGIN
  -- Generate unique referral code
  ref_code := 'REF' || UPPER(SUBSTRING(REPLACE(gen_random_uuid()::text, '-', ''), 1, 6));
  
  -- Check if user provided a referral code
  IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
    -- Validate the referral code exists
    SELECT validate_referral_code(NEW.raw_user_meta_data->>'referral_code') INTO is_valid_ref;
    
    -- If referral code is invalid, raise an exception
    IF NOT is_valid_ref THEN
      RAISE EXCEPTION 'Invalid referral code provided: %', NEW.raw_user_meta_data->>'referral_code';
    END IF;
    
    -- Find the referrer by their referral code
    SELECT id INTO referrer_id 
    FROM public.profiles 
    WHERE referral_code = NEW.raw_user_meta_data->>'referral_code';
  END IF;
  
  -- Insert the new profile
  INSERT INTO public.profiles (id, username, email, referral_code, referred_by)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', SPLIT_PART(COALESCE(NEW.email, NEW.phone), '@', 1)),
    COALESCE(NEW.email, NEW.phone),
    ref_code,
    referrer_id
  );
  
  -- Create referral record if referrer exists
  IF referrer_id IS NOT NULL THEN
    INSERT INTO public.referrals (referrer_id, referred_id)
    VALUES (referrer_id, NEW.id);
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
