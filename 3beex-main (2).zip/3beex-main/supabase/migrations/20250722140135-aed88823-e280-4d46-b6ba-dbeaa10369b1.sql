-- Fix transfer fee logic to properly handle partial withdrawals with fees
-- Add columns to track fee-paid amounts in trade_deposits table

ALTER TABLE public.trade_deposits 
ADD COLUMN IF NOT EXISTS fee_paid_amount NUMERIC(12,2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS available_for_withdrawal NUMERIC(12,2) DEFAULT 0.00;

-- Update existing records to set available_for_withdrawal = doubled_amount
UPDATE public.trade_deposits 
SET available_for_withdrawal = doubled_amount 
WHERE available_for_withdrawal = 0;

-- Create improved transfer function that properly tracks fee-paid withdrawals
CREATE OR REPLACE FUNCTION public.transfer_between_accounts(
  user_id_input UUID,
  from_account TEXT,
  to_account TEXT,
  amount_input NUMERIC
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_balance NUMERIC(12,2);
  fee_amount NUMERIC(12,2) := 0;
  final_transfer_amount NUMERIC(12,2);
  remaining_withdrawal NUMERIC(12,2);
  deposit_record RECORD;
  withdrawable_amount NUMERIC(12,2);
  fee_paid_amount NUMERIC(12,2);
  transfer_id UUID;
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Handle transfers TO trade account (track new deposits)
  IF to_account = 'trade' THEN
    -- Create new deposit record
    INSERT INTO public.trade_deposits (user_id, amount, available_for_withdrawal)
    VALUES (user_id_input, amount_input, 0);
    
    -- Update balances
    IF from_account = 'exchange' THEN
      UPDATE public.profiles 
      SET exchange_balance = exchange_balance - amount_input,
          trade_balance = trade_balance + amount_input,
          trade_account_deposits = trade_account_deposits + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF from_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET perpetual_balance = perpetual_balance - amount_input,
          trade_balance = trade_balance + amount_input,
          trade_account_deposits = trade_account_deposits + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    END IF;
    
    -- Log the transfer
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, 0, 'completed')
    RETURNING id INTO transfer_id;
    
    RETURN json_build_object('success', true, 'message', 'Transfer completed successfully', 'transfer_id', transfer_id);
  END IF;

  -- Handle transfers FROM trade account (apply fee logic)
  IF from_account = 'trade' AND (to_account = 'exchange' OR to_account = 'perpetual') THEN
    remaining_withdrawal := amount_input;
    
    -- First, check how much can be withdrawn without fee from available_for_withdrawal
    FOR deposit_record IN 
      SELECT id, amount, doubled_amount, is_fully_doubled, available_for_withdrawal, fee_paid_amount
      FROM public.trade_deposits 
      WHERE user_id = user_id_input 
      ORDER BY created_at ASC
    LOOP
      IF remaining_withdrawal <= 0 THEN
        EXIT;
      END IF;
      
      -- Calculate how much can be withdrawn without fee from this deposit
      withdrawable_amount := LEAST(remaining_withdrawal, deposit_record.available_for_withdrawal);
      
      -- If no fee-free amount available but deposit is fully doubled, allow 2x withdrawal
      IF withdrawable_amount = 0 AND deposit_record.is_fully_doubled THEN
        withdrawable_amount := LEAST(remaining_withdrawal, (deposit_record.amount * 2) - deposit_record.doubled_amount);
      END IF;
      
      -- Update the deposit record if we're withdrawing fee-free amount
      IF withdrawable_amount > 0 THEN
        UPDATE public.trade_deposits 
        SET available_for_withdrawal = available_for_withdrawal - withdrawable_amount,
            doubled_amount = doubled_amount + withdrawable_amount,
            updated_at = NOW()
        WHERE id = deposit_record.id;
        
        remaining_withdrawal := remaining_withdrawal - withdrawable_amount;
      END IF;
    END LOOP;
    
    -- Calculate fee on remaining amount and track it
    IF remaining_withdrawal > 0 THEN
      fee_amount := remaining_withdrawal * 0.25;
      
      -- Track the fee-paid amount in deposits (mark this portion as fee-paid)
      FOR deposit_record IN 
        SELECT id, amount, fee_paid_amount
        FROM public.trade_deposits 
        WHERE user_id = user_id_input 
        ORDER BY created_at ASC
      LOOP
        IF remaining_withdrawal <= 0 THEN
          EXIT;
        END IF;
        
        -- Calculate how much of this deposit can be marked as fee-paid
        fee_paid_amount := LEAST(remaining_withdrawal, deposit_record.amount - deposit_record.fee_paid_amount);
        
        IF fee_paid_amount > 0 THEN
          UPDATE public.trade_deposits 
          SET fee_paid_amount = fee_paid_amount + fee_paid_amount,
              updated_at = NOW()
          WHERE id = deposit_record.id;
          
          remaining_withdrawal := remaining_withdrawal - fee_paid_amount;
        END IF;
      END LOOP;
    END IF;
    
    final_transfer_amount := amount_input - fee_amount;
    
    -- Update balances
    IF to_account = 'exchange' THEN
      UPDATE public.profiles 
      SET trade_balance = trade_balance - amount_input,
          exchange_balance = exchange_balance + final_transfer_amount,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF to_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET trade_balance = trade_balance - amount_input,
          perpetual_balance = perpetual_balance + final_transfer_amount,
          updated_at = NOW()
      WHERE id = user_id_input;
    END IF;
    
    -- Log the transfer with fee
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, fee_amount, 'completed')
    RETURNING id INTO transfer_id;
  ELSE
    -- Handle other transfers without fee
    final_transfer_amount := amount_input;
    
    IF from_account = 'exchange' AND to_account = 'perpetual' THEN
      UPDATE public.profiles 
      SET exchange_balance = exchange_balance - amount_input,
          perpetual_balance = perpetual_balance + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSIF from_account = 'perpetual' AND to_account = 'exchange' THEN
      UPDATE public.profiles 
      SET perpetual_balance = perpetual_balance - amount_input,
          exchange_balance = exchange_balance + amount_input,
          updated_at = NOW()
      WHERE id = user_id_input;
    ELSE
      RETURN json_build_object('success', false, 'error', 'Invalid account combination');
    END IF;
    
    -- Log the transfer
    INSERT INTO public.transfer_history (user_id, from_account, to_account, amount, fee_amount, status)
    VALUES (user_id_input, from_account, to_account, amount_input, 0, 'completed')
    RETURNING id INTO transfer_id;
  END IF;

  -- Return success with fee information
  IF fee_amount > 0 THEN
    RETURN json_build_object(
      'success', true, 
      'message', 'Transfer completed with fee applied',
      'fee_applied', fee_amount,
      'amount_transferred', final_transfer_amount,
      'original_amount', amount_input,
      'transfer_id', transfer_id
    );
  ELSE
    RETURN json_build_object('success', true, 'message', 'Transfer completed successfully', 'transfer_id', transfer_id);
  END IF;
END;
$$;

-- Update the mark_deposits_doubled function to properly credit available_for_withdrawal
CREATE OR REPLACE FUNCTION public.mark_deposits_doubled(user_id_input uuid, profit_amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  remaining_profit NUMERIC(12,2) := profit_amount;
  deposit_record RECORD;
  doubling_amount NUMERIC(12,2);
BEGIN
  -- Mark deposits as doubled based on profit earned and make them available for withdrawal
  FOR deposit_record IN 
    SELECT id, amount, doubled_amount, is_fully_doubled, available_for_withdrawal, fee_paid_amount
    FROM public.trade_deposits 
    WHERE user_id = user_id_input AND is_fully_doubled = false
    ORDER BY created_at ASC
  LOOP
    IF remaining_profit <= 0 THEN
      EXIT;
    END IF;
    
    -- Calculate how much of this deposit can be marked as doubled
    doubling_amount := LEAST(remaining_profit, deposit_record.amount - deposit_record.doubled_amount);
    
    -- Update the deposit record
    UPDATE public.trade_deposits 
    SET doubled_amount = doubled_amount + doubling_amount,
        available_for_withdrawal = available_for_withdrawal + doubling_amount,
        is_fully_doubled = (doubled_amount + doubling_amount >= amount),
        updated_at = NOW()
    WHERE id = deposit_record.id;
    
    remaining_profit := remaining_profit - doubling_amount;
  END LOOP;
END;
$$;

-- Update check_transfer_fee function with the new logic
CREATE OR REPLACE FUNCTION public.check_transfer_fee(
  user_id_input UUID,
  from_account TEXT,
  to_account TEXT,
  amount_input NUMERIC
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_balance NUMERIC(12,2);
  fee_amount NUMERIC(12,2) := 0;
  final_transfer_amount NUMERIC(12,2);
  remaining_withdrawal NUMERIC(12,2);
  deposit_record RECORD;
  withdrawable_amount NUMERIC(12,2);
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Only calculate fee for transfers FROM trade account
  IF from_account = 'trade' AND (to_account = 'exchange' OR to_account = 'perpetual') THEN
    remaining_withdrawal := amount_input;
    
    -- Check how much can be withdrawn without fee
    FOR deposit_record IN 
      SELECT amount, doubled_amount, is_fully_doubled, available_for_withdrawal
      FROM public.trade_deposits 
      WHERE user_id = user_id_input 
      ORDER BY created_at ASC
    LOOP
      IF remaining_withdrawal <= 0 THEN
        EXIT;
      END IF;
      
      -- Calculate how much can be withdrawn without fee from this deposit
      withdrawable_amount := LEAST(remaining_withdrawal, deposit_record.available_for_withdrawal);
      
      -- If no fee-free amount available but deposit is fully doubled, allow 2x withdrawal
      IF withdrawable_amount = 0 AND deposit_record.is_fully_doubled THEN
        withdrawable_amount := LEAST(remaining_withdrawal, (deposit_record.amount * 2) - deposit_record.doubled_amount);
      END IF;
      
      remaining_withdrawal := remaining_withdrawal - withdrawable_amount;
    END LOOP;
    
    -- Calculate fee on remaining amount
    fee_amount := remaining_withdrawal * 0.25;
    final_transfer_amount := amount_input - fee_amount;
  ELSE
    final_transfer_amount := amount_input;
  END IF;

  -- Return fee information
  RETURN json_build_object(
    'success', true,
    'will_apply_fee', fee_amount > 0,
    'fee_amount', fee_amount,
    'final_amount', final_transfer_amount,
    'original_amount', amount_input
  );
END;
$$;