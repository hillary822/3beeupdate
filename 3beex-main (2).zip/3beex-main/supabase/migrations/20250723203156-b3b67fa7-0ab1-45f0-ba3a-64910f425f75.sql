-- Create a function to send email OTP and handle registration
CREATE OR REPLACE FUNCTION public.handle_email_verification_signup()
RETURNS trigger AS $$
BEGIN
  -- This trigger will be called after a user signs up but before they're confirmed
  -- The user creation is handled by Supabase Auth, we just need to handle the profile creation
  -- when the user confirms their email
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a function to validate referral codes and send OTP
CREATE OR REPLACE FUNCTION public.send_registration_otp(
  user_email text,
  referral_code_input text
)
RETURNS json AS $$
DECLARE
  referrer_exists boolean;
BEGIN
  -- Validate referral code first
  IF referral_code_input IS NULL OR referral_code_input = '' THEN
    RETURN json_build_object('success', false, 'error', 'Referral code is required');
  END IF;
  
  -- Check if referral code exists
  SELECT EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE referral_code = referral_code_input
  ) INTO referrer_exists;
  
  IF NOT referrer_exists THEN
    RETURN json_build_object('success', false, 'error', 'Invalid referral code provided');
  END IF;
  
  -- If validation passes, return success (the actual OTP sending will be handled by the edge function)
  RETURN json_build_object('success', true, 'message', 'Referral code valid, ready to send OTP');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;