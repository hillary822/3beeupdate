
-- Clear all withdrawal history to start fresh
DELETE FROM public.withdrawals;
