-- Manually create the missing profile for the current user
INSERT INTO public.profiles (id, username, email, referral_code, user_id)
VALUES (
  '6f48f923-d993-4e07-ac0e-ef495aa0a260',
  'christiananelson3',
  'christiananelson3@gmail.com',
  'REF' || UPPER(SUBSTRING(REPLACE(gen_random_uuid()::text, '-', ''), 1, 6)),
  nextval('public.user_id_sequence')
);

-- Drop and recreate the trigger to ensure it works properly
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();