-- Drop the problematic policy that causes infinite recursion
DROP POLICY "Users can view referrals made by their network" ON public.referrals;

-- Create a security definer function to check if a user can view a referral
CREATE OR REPLACE FUNCTION public.can_view_referral(referral_referrer_id uuid, referral_referred_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
BEGIN
  -- Users can view referrals they made or were made for them
  IF auth.uid() = referral_referrer_id OR auth.uid() = referral_referred_id THEN
    RETURN true;
  END IF;
  
  -- Check if the referrer is in the user's referral network
  RETURN EXISTS (
    WITH RECURSIVE referral_tree AS (
      -- Base case: direct referrals
      SELECT referred_id as user_id, 1 as level
      FROM public.referrals 
      WHERE referrer_id = auth.uid()
      
      UNION ALL
      
      -- Recursive case: referrals of referrals (up to 10 levels)
      SELECT r.referred_id as user_id, rt.level + 1
      FROM public.referrals r
      INNER JOIN referral_tree rt ON r.referrer_id = rt.user_id
      WHERE rt.level < 10
    )
    SELECT 1 FROM referral_tree WHERE user_id = referral_referrer_id
  );
END;
$$;

-- Create new policy using the security definer function
CREATE POLICY "Users can view network referrals" 
ON public.referrals 
FOR SELECT 
USING (public.can_view_referral(referrer_id, referred_id));