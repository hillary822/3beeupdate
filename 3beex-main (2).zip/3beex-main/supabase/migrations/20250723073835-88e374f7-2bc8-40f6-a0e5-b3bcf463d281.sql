-- Create missing profile for the recent user who got stuck
INSERT INTO public.profiles (id, username, email, referral_code, referred_by, user_id)
SELECT 
  au.id,
  COALESCE(au.raw_user_meta_data->>'username', SPLIT_PART(au.email, '@', 1)) as username,
  au.email,
  'REF' || UPPER(SUBSTRING(REPLACE(gen_random_uuid()::text, '-', ''), 1, 6)) as referral_code,
  CASE 
    WHEN au.raw_user_meta_data->>'referral_code' IS NOT NULL 
    THEN (SELECT id FROM public.profiles WHERE referral_code = au.raw_user_meta_data->>'referral_code')
    ELSE NULL
  END as referred_by,
  nextval('public.user_id_sequence') as user_id
FROM auth.users au
WHERE au.id NOT IN (SELECT id FROM public.profiles)
  AND au.confirmed_at IS NOT NULL;