
-- Add separate balance columns for different account types
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS exchange_balance DECIMAL(12,2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS trade_balance DECIMAL(12,2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS perpetual_balance DECIMAL(12,2) DEFAULT 0.00;

-- Update existing users to distribute their current balance equally across accounts
UPDATE public.profiles 
SET 
  exchange_balance = balance / 3,
  trade_balance = balance / 3,
  perpetual_balance = balance / 3
WHERE exchange_balance IS NULL OR exchange_balance = 0;

-- Function to transfer between accounts
CREATE OR REPLACE FUNCTION public.transfer_between_accounts(
  user_id_input UUID,
  from_account TEXT,
  to_account TEXT,
  amount_input DECIMAL(12,2)
)
RETURNS JSON AS $$
DECLARE
  current_balance DECIMAL(12,2);
BEGIN
  -- Get current balance of source account
  CASE from_account
    WHEN 'exchange' THEN
      SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
    WHEN 'trade' THEN
      SELECT trade_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
    WHEN 'perpetual' THEN
      SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
    ELSE
      RETURN json_build_object('success', false, 'error', 'Invalid source account');
  END CASE;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Perform the transfer
  CASE from_account
    WHEN 'exchange' THEN
      UPDATE public.profiles SET exchange_balance = exchange_balance - amount_input WHERE id = user_id_input;
    WHEN 'trade' THEN
      UPDATE public.profiles SET trade_balance = trade_balance - amount_input WHERE id = user_id_input;
    WHEN 'perpetual' THEN
      UPDATE public.profiles SET perpetual_balance = perpetual_balance - amount_input WHERE id = user_id_input;
  END CASE;

  CASE to_account
    WHEN 'exchange' THEN
      UPDATE public.profiles SET exchange_balance = exchange_balance + amount_input WHERE id = user_id_input;
    WHEN 'trade' THEN
      UPDATE public.profiles SET trade_balance = trade_balance + amount_input WHERE id = user_id_input;
    WHEN 'perpetual' THEN
      UPDATE public.profiles SET perpetual_balance = perpetual_balance + amount_input WHERE id = user_id_input;
  END CASE;

  -- Update the updated_at timestamp
  UPDATE public.profiles SET updated_at = NOW() WHERE id = user_id_input;

  RETURN json_build_object('success', true, 'message', 'Transfer completed successfully');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update exchange balance when deposit is completed
CREATE OR REPLACE FUNCTION public.update_exchange_balance_on_deposit()
RETURNS TRIGGER AS $$
BEGIN
  -- Only update if deposit status changed to completed
  IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
    UPDATE public.profiles 
    SET exchange_balance = exchange_balance + NEW.amount,
        updated_at = NOW()
    WHERE id = NEW.user_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for deposit completion
DROP TRIGGER IF EXISTS update_exchange_balance_trigger ON public.deposits;
CREATE TRIGGER update_exchange_balance_trigger
  AFTER UPDATE ON public.deposits
  FOR EACH ROW
  EXECUTE FUNCTION public.update_exchange_balance_on_deposit();
