-- Drop any existing check constraint on status that might be causing issues
ALTER TABLE public.withdrawals DROP CONSTRAINT IF EXISTS withdrawals_status_check;

-- Add a proper check constraint that allows pending, completed, and rejected
ALTER TABLE public.withdrawals ADD CONSTRAINT withdrawals_status_check 
    CHECK (status IN ('pending', 'completed', 'rejected'));