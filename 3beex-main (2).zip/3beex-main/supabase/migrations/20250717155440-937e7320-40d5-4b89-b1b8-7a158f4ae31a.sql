-- Create function to process referral registration bonus
CREATE OR REPLACE FUNCTION public.process_registration_bonus(new_user_id uuid, referrer_id uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_referrer_id uuid;
  current_level integer := 1;
  max_levels integer;
  bonus_percentage numeric;
  bonus_amount numeric;
  base_bonus_amount numeric := 10.00; -- Base bonus amount for registration
  total_bonuses_paid numeric := 0;
  result json;
BEGIN
  -- Get referral bonus settings
  SELECT value::integer INTO max_levels 
  FROM public.platform_settings 
  WHERE key = 'referral_bonus_levels';
  
  IF max_levels IS NULL THEN
    max_levels := 3;
  END IF;
  
  -- Start with the direct referrer
  current_referrer_id := referrer_id;
  
  -- Process referral bonuses up to max levels
  WHILE current_referrer_id IS NOT NULL AND current_level <= max_levels LOOP
    -- Get bonus percentage for current level
    SELECT value::numeric INTO bonus_percentage 
    FROM public.platform_settings 
    WHERE key = 'referral_level_' || current_level || '_percentage';
    
    IF bonus_percentage IS NULL THEN
      -- Fallback to default percentage
      SELECT value::numeric INTO bonus_percentage 
      FROM public.platform_settings 
      WHERE key = 'referral_bonus_percentage';
      
      IF bonus_percentage IS NULL THEN
        bonus_percentage := 5.0;
      END IF;
      
      -- Reduce percentage for each level
      bonus_percentage := bonus_percentage / current_level;
    END IF;
    
    -- Calculate bonus amount based on base registration bonus
    bonus_amount := base_bonus_amount * (bonus_percentage / 100);
    
    -- Update referrer's earnings in referrals table
    UPDATE public.referrals 
    SET earnings = earnings + bonus_amount
    WHERE referrer_id = current_referrer_id 
    AND referred_id = new_user_id;
    
    -- If no referral record exists, create one (shouldn't happen but safety check)
    IF NOT FOUND THEN
      INSERT INTO public.referrals (referrer_id, referred_id, earnings)
      VALUES (current_referrer_id, new_user_id, bonus_amount);
    END IF;
    
    -- Credit referrer's exchange balance
    UPDATE public.profiles 
    SET exchange_balance = exchange_balance + bonus_amount,
        updated_at = NOW()
    WHERE id = current_referrer_id;
    
    total_bonuses_paid := total_bonuses_paid + bonus_amount;
    
    -- Move to next level (current referrer's referrer)
    SELECT referred_by INTO current_referrer_id 
    FROM public.profiles 
    WHERE id = current_referrer_id;
    
    current_level := current_level + 1;
  END LOOP;
  
  RETURN json_build_object(
    'success', true,
    'total_bonuses_paid', total_bonuses_paid,
    'levels_processed', current_level - 1,
    'base_bonus', base_bonus_amount
  );
END;
$$;

-- Update handle_new_user function to process registration bonuses
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  ref_code TEXT;
  referrer_id UUID;
  bonus_result json;
BEGIN
  -- Generate unique referral code
  ref_code := 'REF' || UPPER(SUBSTRING(REPLACE(gen_random_uuid()::text, '-', ''), 1, 6));
  
  -- Check if user provided a referral code
  IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
    -- Find the referrer by their referral code directly
    SELECT id INTO referrer_id 
    FROM public.profiles 
    WHERE referral_code = NEW.raw_user_meta_data->>'referral_code';
    
    -- If no referrer found, raise an exception
    IF referrer_id IS NULL THEN
      RAISE EXCEPTION 'Invalid referral code provided: %', NEW.raw_user_meta_data->>'referral_code';
    END IF;
  END IF;
  
  -- Insert the new profile with sequential user_id
  INSERT INTO public.profiles (id, username, email, referral_code, referred_by, user_id)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', SPLIT_PART(COALESCE(NEW.email, NEW.phone), '@', 1)),
    COALESCE(NEW.email, NEW.phone),
    ref_code,
    referrer_id,
    nextval('public.user_id_sequence')
  );
  
  -- Create referral record and process bonuses if referrer exists
  IF referrer_id IS NOT NULL THEN
    INSERT INTO public.referrals (referrer_id, referred_id, earnings)
    VALUES (referrer_id, NEW.id, 0);
    
    -- Process registration bonuses for the referral chain
    SELECT public.process_registration_bonus(NEW.id, referrer_id) INTO bonus_result;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Remove referral bonus processing from trade completion
CREATE OR REPLACE FUNCTION public.complete_trade(trade_id_input uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  trade_record RECORD;
  trade_code_record RECORD;
  user_balance_before_trade DECIMAL(12,2);
  display_profit_amount DECIMAL(12,2);
  actual_credit_amount DECIMAL(12,2);
  total_return DECIMAL(12,2);
BEGIN
  -- Get trade details
  SELECT * INTO trade_record FROM public.trades WHERE id = trade_id_input AND status = 'active';
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Trade not found or already completed');
  END IF;
  
  -- Get trade code details
  SELECT * INTO trade_code_record FROM public.trade_codes WHERE id = trade_record.trade_code_id;
  
  -- Get user's current trade balance and add back the trade amount to get balance before trade
  SELECT trade_balance + trade_record.amount INTO user_balance_before_trade 
  FROM public.profiles WHERE id = trade_record.user_id;
  
  -- Calculate display profit based on USER'S BALANCE BEFORE TRADE (full percentage for trade history)
  display_profit_amount := user_balance_before_trade * (trade_code_record.profit_percentage / 100);
  
  -- Calculate actual credit amount (half of the profit percentage based on user's balance before trade)
  actual_credit_amount := user_balance_before_trade * (trade_code_record.profit_percentage / 100 / 2);
  
  -- Total return is original trade amount + actual credit (half profit based on balance before trade)
  total_return := trade_record.amount + actual_credit_amount;
  
  -- Update trade with FULL profit amount for display in trade history (based on balance before trade)
  UPDATE public.trades 
  SET 
    profit = display_profit_amount,
    status = 'completed',
    completed_at = NOW(),
    updated_at = NOW()
  WHERE id = trade_id_input;
  
  -- Add back original trade amount + HALF profit (based on balance before trade) to user's trade balance
  UPDATE public.profiles 
  SET trade_balance = trade_balance + total_return, updated_at = NOW()
  WHERE id = trade_record.user_id;
  
  -- Mark deposits as doubled based on the actual profit earned
  PERFORM public.mark_deposits_doubled(trade_record.user_id, actual_credit_amount);
  
  RETURN json_build_object(
    'success', true, 
    'profit', display_profit_amount,
    'actual_credit', actual_credit_amount,
    'total_return', total_return,
    'trade_id', trade_id_input,
    'calculation_base', user_balance_before_trade
  );
END;
$$;