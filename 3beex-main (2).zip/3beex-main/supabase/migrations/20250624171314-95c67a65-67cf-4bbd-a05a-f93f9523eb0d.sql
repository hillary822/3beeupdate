
-- Enable RLS on deposits table if not already enabled
ALTER TABLE public.deposits ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for deposits table
DROP POLICY IF EXISTS "Users can view their own deposits" ON public.deposits;
CREATE POLICY "Users can view their own deposits" 
  ON public.deposits 
  FOR SELECT 
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can create their own deposits" ON public.deposits;
CREATE POLICY "Users can create their own deposits" 
  ON public.deposits 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update their own deposits" ON public.deposits;
CREATE POLICY "Users can update their own deposits" 
  ON public.deposits 
  FOR UPDATE 
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins can manage all deposits" ON public.deposits;
CREATE POLICY "Admins can manage all deposits" 
  ON public.deposits 
  FOR ALL 
  USING (public.is_admin_user());
