-- Clean up duplicate storage policies for kyc-documents bucket
DROP POLICY IF EXISTS "Service role can upload to kyc-documents" ON storage.objects;
DROP POLICY IF EXISTS "Service role can update kyc-documents" ON storage.objects;
DROP POLICY IF EXISTS "Service role can select kyc-documents" ON storage.objects;
DROP POLICY IF EXISTS "Admins can access kyc-documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can view their own kyc documents" ON storage.objects;

-- Create a single comprehensive policy for the service role (edge functions)
CREATE POLICY "Service role full access to kyc-documents"
ON storage.objects
FOR ALL
TO service_role
USING (bucket_id = 'kyc-documents');

-- Allow authenticated users to view their own documents
CREATE POLICY "Users can view own kyc docs"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'kyc-documents' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Allow admins to view all kyc documents
CREATE POLICY "Admins can view all kyc docs"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'kyc-documents' AND is_admin_user());