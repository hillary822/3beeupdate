-- Apply existing referral bonus settings to all existing referrals retroactively
CREATE OR REPLACE FUNCTION public.apply_retroactive_referral_bonuses()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  referral_record RECORD;
  current_referrer_id uuid;
  current_level integer;
  max_levels integer;
  bonus_percentage numeric;
  bonus_amount numeric;
  base_bonus_amount numeric;
  total_bonuses_applied numeric := 0;
  referrals_processed integer := 0;
BEGIN
  -- Get referral bonus settings
  SELECT value::integer INTO max_levels 
  FROM public.platform_settings 
  WHERE key = 'referral_bonus_levels';
  
  SELECT value::numeric INTO base_bonus_amount
  FROM public.platform_settings 
  WHERE key = 'registration_bonus_amount';
  
  IF max_levels IS NULL THEN
    max_levels := 3;
  END IF;
  
  IF base_bonus_amount IS NULL THEN
    base_bonus_amount := 10.00;
  END IF;
  
  -- Process each referral that currently has 0 earnings
  FOR referral_record IN 
    SELECT * FROM public.referrals 
    WHERE earnings = 0
    ORDER BY created_at ASC
  LOOP
    referrals_processed := referrals_processed + 1;
    current_referrer_id := referral_record.referrer_id;
    current_level := 1;
    
    -- Process referral bonuses up to max levels for this referral
    WHILE current_referrer_id IS NOT NULL AND current_level <= max_levels LOOP
      -- Get bonus percentage for current level
      SELECT value::numeric INTO bonus_percentage 
      FROM public.platform_settings 
      WHERE key = 'referral_level_' || current_level || '_percentage';
      
      IF bonus_percentage IS NULL THEN
        -- Fallback to default percentage
        SELECT value::numeric INTO bonus_percentage 
        FROM public.platform_settings 
        WHERE key = 'referral_bonus_percentage';
        
        IF bonus_percentage IS NULL THEN
          bonus_percentage := 5.0;
        END IF;
        
        -- Reduce percentage for each level
        bonus_percentage := bonus_percentage / current_level;
      END IF;
      
      -- Calculate bonus amount based on configurable registration bonus
      bonus_amount := base_bonus_amount * (bonus_percentage / 100);
      
      -- Only update if this is the direct referrer (level 1)
      IF current_level = 1 AND current_referrer_id = referral_record.referrer_id THEN
        -- Update referrer's earnings in referrals table
        UPDATE public.referrals 
        SET earnings = earnings + bonus_amount
        WHERE referrer_id = current_referrer_id 
        AND referred_id = referral_record.referred_id;
        
        -- Credit referrer's exchange balance
        UPDATE public.profiles 
        SET exchange_balance = exchange_balance + bonus_amount,
            updated_at = NOW()
        WHERE id = current_referrer_id;
        
        total_bonuses_applied := total_bonuses_applied + bonus_amount;
      END IF;
      
      -- Move to next level (current referrer's referrer) for multi-level processing
      SELECT referred_by INTO current_referrer_id 
      FROM public.profiles 
      WHERE id = current_referrer_id;
      
      current_level := current_level + 1;
    END LOOP;
  END LOOP;
  
  RETURN json_build_object(
    'success', true,
    'message', 'Retroactive referral bonuses applied successfully',
    'referrals_processed', referrals_processed,
    'total_bonuses_applied', total_bonuses_applied,
    'base_bonus_amount', base_bonus_amount,
    'max_levels', max_levels
  );
END;
$$;

-- Execute the function to apply retroactive bonuses
SELECT public.apply_retroactive_referral_bonuses();