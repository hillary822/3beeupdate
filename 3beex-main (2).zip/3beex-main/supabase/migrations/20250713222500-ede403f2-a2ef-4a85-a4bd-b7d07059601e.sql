-- Let's look at the table definition to see all constraints
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_name = 'withdrawals' 
    AND table_schema = 'public'
ORDER BY ordinal_position;

-- Check for any check constraints using pg_constraint
SELECT 
    conname as constraint_name,
    pg_get_constraintdef(oid) as constraint_definition
FROM pg_constraint 
WHERE conrelid = 'public.withdrawals'::regclass 
    AND contype = 'c';