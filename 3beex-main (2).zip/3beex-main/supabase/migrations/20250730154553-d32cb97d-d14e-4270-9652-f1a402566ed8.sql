-- Fix trade code usage logic - allow multiple users to use same code
-- Only mark individual user codes as used, not the global trade code

CREATE OR REPLACE FUNCTION public.use_trade_code(code_input text, user_id_input uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  trade_code_record RECORD;
  user_profile RECORD;
  result JSON;
  new_trade_id UUID;
  balance_to_use NUMERIC;
  trade_amount NUMERIC;
  user_code_record RECORD;
BEGIN
  -- Get the trade code details
  SELECT * INTO trade_code_record
  FROM trade_codes 
  WHERE code = code_input;

  -- Check if code exists
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Invalid trade code'
    );
  END IF;

  -- Get user-specific code record if it exists
  SELECT * INTO user_code_record
  FROM user_codes 
  WHERE trade_code_id = trade_code_record.id 
  AND user_id = user_id_input;

  -- Check if code has expired 
  -- For codes sent to users: check sent_at + duration
  -- For direct codes: check created_at + duration
  IF user_code_record.sent_at IS NOT NULL THEN
    IF (user_code_record.sent_at + (trade_code_record.duration_minutes || ' minutes')::INTERVAL) < NOW() THEN
      RETURN json_build_object(
        'success', false,
        'error', 'Trade code has expired'
      );
    END IF;
  ELSE
    -- For codes not sent to users, check if they've expired based on creation time
    -- Allow a longer expiration window (e.g., 24 hours) for direct codes
    IF (trade_code_record.created_at + INTERVAL '24 hours') < NOW() THEN
      RETURN json_build_object(
        'success', false,
        'error', 'Trade code has expired'
      );
    END IF;
  END IF;

  -- Check if this code was sent to users and if so, verify the user has access
  IF EXISTS(SELECT 1 FROM user_codes WHERE trade_code_id = trade_code_record.id) THEN
    -- Code was sent to specific users, check if this user is one of them
    IF user_code_record.id IS NULL THEN
      RETURN json_build_object(
        'success', false,
        'error', 'This trade code was not assigned to you'
      );
    END IF;
    
    -- Check if user has already used this code
    IF user_code_record.is_used THEN
      RETURN json_build_object(
        'success', false,
        'error', 'You have already used this trade code'
      );
    END IF;
  ELSE
    -- For direct codes, check if user has already used this specific code
    IF EXISTS(SELECT 1 FROM trades WHERE user_id = user_id_input AND trade_code_id = trade_code_record.id) THEN
      RETURN json_build_object(
        'success', false,
        'error', 'You have already used this trade code'
      );
    END IF;
  END IF;

  -- Get user profile
  SELECT * INTO user_profile FROM profiles WHERE id = user_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'User profile not found'
    );
  END IF;

  -- Check if user account is suspended or locked
  IF user_profile.suspended OR user_profile.locked THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Account is suspended or locked'
    );
  END IF;

  -- Check premium requirement
  IF trade_code_record.is_premium AND NOT user_profile.premium THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Premium account required for this trade code'
    );
  END IF;

  -- Check VIP requirement
  IF trade_code_record.is_vip AND NOT user_profile.vip THEN
    RETURN json_build_object(
      'success', false,
      'error', 'VIP account required for this trade code'
    );
  END IF;

  -- Use minimum_balance as the actual trade amount
  trade_amount := trade_code_record.minimum_balance;
  balance_to_use := user_profile.trade_balance;

  -- Check if user has sufficient balance for the trade
  IF balance_to_use < trade_amount THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Insufficient balance. Required: $' || trade_amount
    );
  END IF;

  -- Deduct the trade amount from user's balance when trade starts
  UPDATE public.profiles 
  SET trade_balance = trade_balance - trade_amount,
      updated_at = NOW()
  WHERE id = user_id_input;

  -- Create the trade with the correct amount
  INSERT INTO trades (
    user_id,
    trade_code,
    trade_code_id,
    type,
    asset,
    amount,
    status,
    started_at
  ) VALUES (
    user_id_input,
    code_input,
    trade_code_record.id,
    trade_code_record.signal_type,
    trade_code_record.asset,
    trade_amount,
    'active',
    NOW()
  ) RETURNING id INTO new_trade_id;

  -- Mark user code as used if it exists (NOT the global trade code)
  IF user_code_record.id IS NOT NULL THEN
    UPDATE user_codes 
    SET is_used = true, 
        used_at = NOW()
    WHERE id = user_code_record.id;
  END IF;

  -- Return success response
  RETURN json_build_object(
    'success', true,
    'trade_id', new_trade_id,
    'duration_minutes', trade_code_record.duration_minutes,
    'asset', trade_code_record.asset,
    'profit_percentage', trade_code_record.profit_percentage,
    'amount_invested', trade_amount
  );
END;
$function$;