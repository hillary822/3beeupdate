-- Add premium field to trade_codes table
ALTER TABLE public.trade_codes ADD COLUMN is_premium BOOLEAN NOT NULL DEFAULT FALSE;

-- Add suspended field to profiles table  
ALTER TABLE public.profiles ADD COLUMN suspended BOOLEAN NOT NULL DEFAULT FALSE;