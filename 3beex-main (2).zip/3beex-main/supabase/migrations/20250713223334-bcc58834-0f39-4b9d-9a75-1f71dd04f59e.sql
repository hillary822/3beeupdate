-- Let's see the current function definition 
SELECT proname, prosrc 
FROM pg_proc 
WHERE proname = 'update_user_balance';

-- Also check if there are multiple functions with the same name
SELECT proname, pronargs, proargtypes::regtype[] 
FROM pg_proc 
WHERE proname = 'update_user_balance';