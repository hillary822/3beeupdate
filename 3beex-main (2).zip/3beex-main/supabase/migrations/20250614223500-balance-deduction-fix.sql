
-- Update the complete_trade function to restore the original amount plus profit
CREATE OR REPLACE FUNCTION public.complete_trade(trade_id_input UUID)
RETURNS JSON AS $$
DECLARE
  trade_record RECORD;
  trade_code_record RECORD;
  profit_amount DECIMAL(12,2);
  total_return DECIMAL(12,2);
BEGIN
  -- Get trade details
  SELECT * INTO trade_record FROM public.trades WHERE id = trade_id_input AND status = 'active';
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Trade not found or already completed');
  END IF;
  
  -- Get trade code details
  SELECT * INTO trade_code_record FROM public.trade_codes WHERE id = trade_record.trade_code_id;
  
  -- Calculate profit (percentage of the invested amount)
  profit_amount := trade_record.amount * (trade_code_record.profit_percentage / 100);
  
  -- Total return is original amount + profit
  total_return := trade_record.amount + profit_amount;
  
  -- Update trade with profit and completion
  UPDATE public.trades 
  SET 
    profit = profit_amount,
    status = 'completed',
    completed_at = NOW(),
    updated_at = NOW()
  WHERE id = trade_id_input;
  
  -- Add back the original amount + profit to user balance
  UPDATE public.profiles 
  SET balance = balance + total_return, updated_at = NOW()
  WHERE id = trade_record.user_id;
  
  RETURN json_build_object(
    'success', true, 
    'profit', profit_amount,
    'total_return', total_return,
    'trade_id', trade_id_input
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update the use_trade_code function to deduct balance when starting a trade
CREATE OR REPLACE FUNCTION public.use_trade_code(code_input TEXT, user_id_input UUID)
RETURNS JSON AS $$
DECLARE
  trade_code_record RECORD;
  new_trade_id UUID;
  user_balance DECIMAL(12,2);
  trade_amount DECIMAL(12,2) := 100.00; -- Default trade amount
BEGIN
  -- Check if trade code exists and is unused
  SELECT * INTO trade_code_record 
  FROM public.trade_codes 
  WHERE code = code_input AND is_used = FALSE;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Invalid or already used trade code');
  END IF;
  
  -- Check user's current balance
  SELECT balance INTO user_balance FROM public.profiles WHERE id = user_id_input;
  
  IF user_balance < trade_amount THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance for this trade');
  END IF;
  
  -- Deduct the trade amount from user's balance
  UPDATE public.profiles 
  SET balance = balance - trade_amount, updated_at = NOW()
  WHERE id = user_id_input;
  
  -- Mark trade code as used
  UPDATE public.trade_codes 
  SET is_used = TRUE, used_by = user_id_input, used_at = NOW()
  WHERE id = trade_code_record.id;
  
  -- Create new trade with proper status
  INSERT INTO public.trades (
    user_id, 
    trade_code, 
    trade_code_id,
    type, 
    asset, 
    amount, 
    profit,
    status,
    started_at
  ) VALUES (
    user_id_input,
    code_input,
    trade_code_record.id,
    'BUY',
    trade_code_record.asset,
    trade_amount,
    0.00, -- Will be updated when trade completes
    'active',
    NOW()
  ) RETURNING id INTO new_trade_id;
  
  RETURN json_build_object(
    'success', true, 
    'trade_id', new_trade_id,
    'duration_minutes', trade_code_record.duration_minutes,
    'asset', trade_code_record.asset,
    'profit_percentage', trade_code_record.profit_percentage,
    'amount_invested', trade_amount
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
