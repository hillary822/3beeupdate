-- Update trade logic to use user's full trade balance for profit calculation
-- CRITICAL: This changes how trades work - profit now based on full balance, not fixed amount

CREATE OR REPLACE FUNCTION public.use_trade_code(code_input text, user_id_input uuid)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  trade_code_record RECORD;
  user_profile RECORD;
  result JSON;
  new_trade_id UUID;
  user_full_balance NUMERIC;
  user_code_record RECORD;
BEGIN
  -- Get the trade code details
  SELECT * INTO trade_code_record
  FROM trade_codes 
  WHERE code = code_input;

  -- Check if code exists
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Invalid trade code'
    );
  END IF;

  -- Get user-specific code record if it exists
  SELECT * INTO user_code_record
  FROM user_codes 
  WHERE trade_code_id = trade_code_record.id 
  AND user_id = user_id_input;

  -- Check if code has expired 
  -- For codes sent to users: check sent_at + duration
  -- For direct codes: check created_at + duration
  IF user_code_record.sent_at IS NOT NULL THEN
    IF (user_code_record.sent_at + (trade_code_record.duration_minutes || ' minutes')::INTERVAL) < NOW() THEN
      RETURN json_build_object(
        'success', false,
        'error', 'Trade code has expired'
      );
    END IF;
  ELSE
    -- For codes not sent to users, check if they've expired based on creation time
    -- Allow a longer expiration window (e.g., 24 hours) for direct codes
    IF (trade_code_record.created_at + INTERVAL '24 hours') < NOW() THEN
      RETURN json_build_object(
        'success', false,
        'error', 'Trade code has expired'
      );
    END IF;
  END IF;

  -- Check if this code was sent to users and if so, verify the user has access
  IF EXISTS(SELECT 1 FROM user_codes WHERE trade_code_id = trade_code_record.id) THEN
    -- Code was sent to specific users, check if this user is one of them
    IF user_code_record.id IS NULL THEN
      RETURN json_build_object(
        'success', false,
        'error', 'This trade code was not assigned to you'
      );
    END IF;
    
    -- Check if user has already used this code
    IF user_code_record.is_used THEN
      RETURN json_build_object(
        'success', false,
        'error', 'You have already used this trade code'
      );
    END IF;
  ELSE
    -- For direct codes, check if user has already used this specific code
    IF EXISTS(SELECT 1 FROM trades WHERE user_id = user_id_input AND trade_code_id = trade_code_record.id) THEN
      RETURN json_build_object(
        'success', false,
        'error', 'You have already used this trade code'
      );
    END IF;
  END IF;

  -- Get user profile
  SELECT * INTO user_profile FROM profiles WHERE id = user_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'User profile not found'
    );
  END IF;

  -- Check if user account is suspended or locked
  IF user_profile.suspended OR user_profile.locked THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Account is suspended or locked'
    );
  END IF;

  -- Check premium requirement
  IF trade_code_record.is_premium AND NOT user_profile.premium THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Premium account required for this trade code'
    );
  END IF;

  -- Check VIP requirement
  IF trade_code_record.is_vip AND NOT user_profile.vip THEN
    RETURN json_build_object(
      'success', false,
      'error', 'VIP account required for this trade code'
    );
  END IF;

  -- CHANGED: Get user's full trade balance
  user_full_balance := user_profile.trade_balance;

  -- CHANGED: Check minimum balance requirement (but don't use it as trade amount)
  IF user_full_balance < trade_code_record.minimum_balance THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Insufficient balance. Minimum required: $' || trade_code_record.minimum_balance
    );
  END IF;

  -- CHANGED: Deduct the user's FULL trade balance when trade starts
  UPDATE public.profiles 
  SET trade_balance = 0,
      updated_at = NOW()
  WHERE id = user_id_input;

  -- CHANGED: Create the trade with the user's FULL balance as the amount
  INSERT INTO trades (
    user_id,
    trade_code,
    trade_code_id,
    type,
    asset,
    amount,
    status,
    started_at
  ) VALUES (
    user_id_input,
    code_input,
    trade_code_record.id,
    trade_code_record.signal_type,
    trade_code_record.asset,
    user_full_balance,  -- CHANGED: Use full balance instead of minimum_balance
    'active',
    NOW()
  ) RETURNING id INTO new_trade_id;

  -- Mark user code as used if it exists (NOT the global trade code)
  IF user_code_record.id IS NOT NULL THEN
    UPDATE user_codes 
    SET is_used = true, 
        used_at = NOW()
    WHERE id = user_code_record.id;
  END IF;

  -- Return success response
  RETURN json_build_object(
    'success', true,
    'trade_id', new_trade_id,
    'duration_minutes', trade_code_record.duration_minutes,
    'asset', trade_code_record.asset,
    'profit_percentage', trade_code_record.profit_percentage,
    'amount_invested', user_full_balance  -- CHANGED: Show full balance invested
  );
END;
$function$;

-- Update complete_trade function to work with the new logic
-- (No changes needed here since it already calculates profit based on trade.amount)
-- The trade.amount now contains the user's full balance from the updated use_trade_code function

-- Verify the complete_trade function is still correct
CREATE OR REPLACE FUNCTION public.complete_trade(trade_id_input uuid)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  trade_record RECORD;
  trade_code_record RECORD;
  correct_profit_amount DECIMAL(12,2);
  actual_credit_amount DECIMAL(12,2);
  total_return DECIMAL(12,2);
BEGIN
  -- Get trade details
  SELECT * INTO trade_record FROM public.trades WHERE id = trade_id_input AND status = 'active';
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Trade not found or already completed');
  END IF;
  
  -- Get trade code details
  SELECT * INTO trade_code_record FROM public.trade_codes WHERE id = trade_record.trade_code_id;
  
  -- Calculate profit based on the TRADE AMOUNT (which is now user's full balance)
  correct_profit_amount := trade_record.amount * (trade_code_record.profit_percentage / 100);
  
  -- Credit the full profit amount
  actual_credit_amount := correct_profit_amount;
  
  -- Total return is original trade amount + profit
  total_return := trade_record.amount + actual_credit_amount;
  
  -- Update trade with correct profit amount
  UPDATE public.trades 
  SET 
    profit = correct_profit_amount,
    status = 'completed',
    completed_at = NOW(),
    updated_at = NOW()
  WHERE id = trade_id_input;
  
  -- Add back original trade amount + profit to user's trade balance
  UPDATE public.profiles 
  SET trade_balance = trade_balance + total_return, updated_at = NOW()
  WHERE id = trade_record.user_id;
  
  -- Mark deposits as doubled based on the actual profit earned
  PERFORM public.mark_deposits_doubled(trade_record.user_id, actual_credit_amount);
  
  RETURN json_build_object(
    'success', true, 
    'profit', correct_profit_amount,
    'actual_credit', actual_credit_amount,
    'total_return', total_return,
    'trade_id', trade_id_input
  );
END;
$function$;