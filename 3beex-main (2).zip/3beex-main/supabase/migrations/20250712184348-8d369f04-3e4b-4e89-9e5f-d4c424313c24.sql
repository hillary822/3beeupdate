-- Update the transfer_between_accounts function to include 25% fee for trade-to-exchange transfers
-- when user hasn't doubled their trade account balance

-- First, add a column to track total deposits into trade account
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS trade_account_deposits NUMERIC(12,2) DEFAULT 0.00;

-- Update existing users to set initial trade account deposits to current trade balance
UPDATE public.profiles 
SET trade_account_deposits = trade_balance 
WHERE trade_account_deposits = 0 AND trade_balance > 0;

-- Create the updated transfer function with fee logic
CREATE OR REPLACE FUNCTION public.transfer_between_accounts(
  user_id_input UUID,
  from_account TEXT,
  to_account TEXT,
  amount_input NUMERIC
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_balance NUMERIC(12,2);
  current_trade_deposits NUMERIC(12,2);
  fee_amount NUMERIC(12,2) := 0;
  final_transfer_amount NUMERIC(12,2);
  has_doubled_trade_balance BOOLEAN := false;
BEGIN
  -- Check current balance in from_account
  IF from_account = 'exchange' THEN
    SELECT exchange_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'trade' THEN
    SELECT trade_balance, trade_account_deposits INTO current_balance, current_trade_deposits 
    FROM public.profiles WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' THEN
    SELECT perpetual_balance INTO current_balance FROM public.profiles WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid from_account');
  END IF;

  -- Check if sufficient balance
  IF current_balance < amount_input THEN
    RETURN json_build_object('success', false, 'error', 'Insufficient balance');
  END IF;

  -- Check if transferring from trade to exchange and apply fee if needed
  IF from_account = 'trade' AND to_account = 'exchange' THEN
    -- Check if user has doubled their trade account deposits
    -- Current trade balance should be at least 2x the total deposits made to trade account
    IF (current_balance + amount_input) >= (current_trade_deposits * 2) THEN
      has_doubled_trade_balance := true;
    END IF;
    
    -- If user hasn't doubled their money, apply 25% fee
    IF NOT has_doubled_trade_balance THEN
      fee_amount := amount_input * 0.25;
      final_transfer_amount := amount_input - fee_amount;
    ELSE
      final_transfer_amount := amount_input;
    END IF;
  ELSE
    final_transfer_amount := amount_input;
  END IF;

  -- Perform the transfer based on account types
  IF from_account = 'exchange' AND to_account = 'trade' THEN
    -- Track deposits into trade account
    UPDATE public.profiles 
    SET exchange_balance = exchange_balance - amount_input,
        trade_balance = trade_balance + amount_input,
        trade_account_deposits = trade_account_deposits + amount_input,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSIF from_account = 'exchange' AND to_account = 'perpetual' THEN
    UPDATE public.profiles 
    SET exchange_balance = exchange_balance - amount_input,
        perpetual_balance = perpetual_balance + amount_input,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSIF from_account = 'trade' AND to_account = 'exchange' THEN
    -- Apply fee if applicable (final_transfer_amount already calculated)
    UPDATE public.profiles 
    SET trade_balance = trade_balance - amount_input,
        exchange_balance = exchange_balance + final_transfer_amount,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSIF from_account = 'trade' AND to_account = 'perpetual' THEN
    UPDATE public.profiles 
    SET trade_balance = trade_balance - amount_input,
        perpetual_balance = perpetual_balance + amount_input,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' AND to_account = 'exchange' THEN
    UPDATE public.profiles 
    SET perpetual_balance = perpetual_balance - amount_input,
        exchange_balance = exchange_balance + amount_input,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSIF from_account = 'perpetual' AND to_account = 'trade' THEN
    -- Track deposits into trade account
    UPDATE public.profiles 
    SET perpetual_balance = perpetual_balance - amount_input,
        trade_balance = trade_balance + amount_input,
        trade_account_deposits = trade_account_deposits + amount_input,
        updated_at = NOW()
    WHERE id = user_id_input;
  ELSE
    RETURN json_build_object('success', false, 'error', 'Invalid account combination');
  END IF;

  -- Return success with fee information
  IF fee_amount > 0 THEN
    RETURN json_build_object(
      'success', true, 
      'message', 'Transfer completed with fee applied',
      'fee_applied', fee_amount,
      'amount_transferred', final_transfer_amount,
      'original_amount', amount_input
    );
  ELSE
    RETURN json_build_object('success', true, 'message', 'Transfer completed successfully');
  END IF;
END;
$$;