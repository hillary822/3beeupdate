-- Update use_trade_code function to use signal_type from trade_codes
CREATE OR REPLACE FUNCTION public.use_trade_code(code_input text, user_id_input uuid)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  trade_code_record RECORD;
  new_trade_id UUID;
  user_trade_balance DECIMAL(12,2);
  platform_min_balance DECIMAL(12,2);
  user_total_balance DECIMAL(12,2);
  user_profile RECORD;
BEGIN
  -- Check if trade code exists and is unused
  SELECT * INTO trade_code_record 
  FROM public.trade_codes 
  WHERE code = code_input AND is_used = FALSE;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Invalid or already used trade code');
  END IF;
  
  -- Get user profile information
  SELECT * INTO user_profile
  FROM public.profiles 
  WHERE id = user_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'User profile not found');
  END IF;
  
  -- Check if user is eligible for this trade code type
  IF trade_code_record.is_premium AND NOT user_profile.premium THEN
    RETURN json_build_object('success', false, 'error', 'This is an Extra Signal code. Only premium users can use this code.');
  END IF;
  
  IF trade_code_record.is_vip AND (user_profile.vip_level IS NULL OR user_profile.vip_level = 0) THEN
    RETURN json_build_object('success', false, 'error', 'This is a VIP code. Only VIP users can use this code.');
  END IF;
  
  -- Get platform minimum balance setting
  SELECT COALESCE(value::DECIMAL(12,2), 0) INTO platform_min_balance
  FROM public.platform_settings 
  WHERE key = 'minimum_trading_balance';
  
  -- Check user's current balances
  SELECT user_profile.trade_balance, (user_profile.exchange_balance + user_profile.trade_balance + user_profile.perpetual_balance) 
  INTO user_trade_balance, user_total_balance;
  
  -- Check if user meets platform minimum balance requirement
  IF user_total_balance < platform_min_balance THEN
    RETURN json_build_object(
      'success', false, 
      'error', format('Platform requires a minimum total balance of $%s to trade', platform_min_balance)
    );
  END IF;
  
  -- Check if user meets the trade code's minimum balance requirement
  IF user_trade_balance < COALESCE(trade_code_record.minimum_balance, 0) THEN
    RETURN json_build_object(
      'success', false, 
      'error', format('This trade code requires a minimum trade balance of $%s', COALESCE(trade_code_record.minimum_balance, 0))
    );
  END IF;
  
  -- Use the trade code's minimum balance as the trade amount
  DECLARE
    trade_amount DECIMAL(12,2) := COALESCE(trade_code_record.minimum_balance, 100.00);
  BEGIN
    -- Deduct the trade amount from user's trade balance
    UPDATE public.profiles 
    SET trade_balance = trade_balance - trade_amount, updated_at = NOW()
    WHERE id = user_id_input;
    
    -- Mark trade code as used
    UPDATE public.trade_codes 
    SET is_used = TRUE, used_by = user_id_input, used_at = NOW()
    WHERE id = trade_code_record.id;
    
    -- Create new trade with proper status and signal type from trade code
    INSERT INTO public.trades (
      user_id, 
      trade_code, 
      trade_code_id,
      type, 
      asset, 
      amount, 
      profit,
      status,
      started_at
    ) VALUES (
      user_id_input,
      code_input,
      trade_code_record.id,
      COALESCE(trade_code_record.signal_type, 'BUY'),
      trade_code_record.asset,
      trade_amount,
      0.00, -- Will be updated when trade completes
      'active',
      NOW()
    ) RETURNING id INTO new_trade_id;
    
    RETURN json_build_object(
      'success', true, 
      'trade_id', new_trade_id,
      'duration_minutes', trade_code_record.duration_minutes,
      'asset', trade_code_record.asset,
      'profit_percentage', trade_code_record.profit_percentage,
      'amount_invested', trade_amount,
      'minimum_balance_required', COALESCE(trade_code_record.minimum_balance, 0),
      'code_type', CASE 
        WHEN trade_code_record.is_vip THEN 'VIP'
        WHEN trade_code_record.is_premium THEN 'Premium'
        ELSE 'Normal'
      END
    );
  END;
END;
$function$;