
-- Drop existing policies
DROP POLICY IF EXISTS "Users can view active payment methods" ON public.payment_methods;
DROP POLICY IF EXISTS "Admins can manage payment methods" ON public.payment_methods;

-- Create a function to check if current user is admin (more reliable)
CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM auth.users 
    WHERE id = auth.uid() 
    AND email = 'admin@admin.com'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Users can view active payment methods
CREATE POLICY "Users can view active payment methods" 
  ON public.payment_methods 
  FOR SELECT 
  USING (is_active = true OR public.is_admin_user());

-- Admins can manage all payment methods
CREATE POLICY "Admins can manage payment methods" 
  ON public.payment_methods 
  FOR ALL 
  USING (public.is_admin_user());
