
-- Fix RLS policies for payment_methods table
DROP POLICY IF EXISTS "Users can view active payment methods" ON public.payment_methods;
DROP POLICY IF EXISTS "Admins can manage payment methods" ON public.payment_methods;

-- Users can view active payment methods
CREATE POLICY "Users can view active payment methods" 
  ON public.payment_methods 
  FOR SELECT 
  USING (is_active = true);

-- Admins can do everything with payment methods
CREATE POLICY "Admins can manage payment methods" 
  ON public.payment_methods 
  FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM auth.users 
    WHERE auth.users.id = auth.uid() 
    AND auth.users.email = 'admin@admin.com'
  ));
