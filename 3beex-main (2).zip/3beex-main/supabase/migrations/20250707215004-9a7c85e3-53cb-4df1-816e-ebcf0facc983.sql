-- Add admin update policy for withdrawals table
CREATE POLICY "Admins can update withdrawals" 
ON public.withdrawals 
FOR UPDATE 
USING (public.is_admin_user());