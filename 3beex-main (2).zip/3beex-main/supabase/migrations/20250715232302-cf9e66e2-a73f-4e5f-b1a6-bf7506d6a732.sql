-- Add locked field to profiles table
ALTER TABLE public.profiles 
ADD COLUMN locked boolean NOT NULL DEFAULT false;