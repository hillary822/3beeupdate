-- Ensure the update_user_balance function has the correct signature
-- This function should match what the CCPayment webhook and admin functions expect

-- First, ensure the exchange_balance column exists
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS exchange_balance NUMERIC(12,2) DEFAULT 0.00;

-- Migrate existing balance data to exchange_balance if needed
UPDATE public.profiles 
SET exchange_balance = COALESCE(balance, 0.00) 
WHERE exchange_balance IS NULL OR exchange_balance = 0;

-- Drop any existing versions to avoid conflicts
DROP FUNCTION IF EXISTS public.update_user_balance(uuid, numeric);
DROP FUNCTION IF EXISTS public.update_user_balance(user_id uuid, amount numeric);
DROP FUNCTION IF EXISTS public.update_user_balance(target_user_id uuid, balance_amount numeric);

-- Create the function with the correct signature that matches the webhook calls
CREATE OR REPLACE FUNCTION public.update_user_balance(target_user_id uuid, balance_amount numeric)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Update the user's exchange balance
  UPDATE public.profiles 
  SET exchange_balance = COALESCE(exchange_balance, 0) + balance_amount,
      updated_at = NOW()
  WHERE id = target_user_id;
  
  -- Log the balance update for debugging
  RAISE NOTICE 'Updated balance for user % by amount %', target_user_id, balance_amount;
END;
$$; 