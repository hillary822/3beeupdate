-- Update use_trade_code function to handle permanent signal eligibility
CREATE OR REPLACE FUNCTION public.use_trade_code(code_input text, user_id_input uuid)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  trade_code_record RECORD;
  user_profile RECORD;
  result JSON;
  new_trade_id UUID;
  user_full_balance NUMERIC;
  trade_amount NUMERIC;
  user_code_record RECORD;
BEGIN
  -- Get the trade code details
  SELECT * INTO trade_code_record
  FROM trade_codes 
  WHERE code = code_input;

  -- Check if code exists
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Invalid trade code'
    );
  END IF;

  -- Check if code has expired based on creation time + duration
  IF (trade_code_record.created_at + (trade_code_record.duration_minutes || ' minutes')::INTERVAL) < NOW() THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Trade code has expired'
    );
  END IF;

  -- Get user profile
  SELECT * INTO user_profile FROM profiles WHERE id = user_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'User profile not found'
    );
  END IF;

  -- Check if user account is suspended or locked
  IF user_profile.suspended OR user_profile.locked THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Account is suspended or locked'
    );
  END IF;

  -- Check eligibility based on code type
  IF trade_code_record.is_permanent_signal AND NOT user_profile.permanent_signal THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Permanent Signal account required for this trade code'
    );
  END IF;

  IF trade_code_record.is_premium AND NOT user_profile.premium AND NOT user_profile.permanent_signal AND NOT EXISTS(SELECT 1 FROM referrals WHERE referrer_id = user_id_input) THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Premium account, Permanent Signal account, or referral activity required for this trade code'
    );
  END IF;

  IF trade_code_record.is_vip AND NOT user_profile.vip AND NOT user_profile.permanent_signal THEN
    RETURN json_build_object(
      'success', false,
      'error', 'VIP or Permanent Signal account required for this trade code'
    );
  END IF;

  -- Check if user has already used this specific code
  IF EXISTS(SELECT 1 FROM trades WHERE user_id = user_id_input AND trade_code_id = trade_code_record.id) THEN
    RETURN json_build_object(
      'success', false,
      'error', 'You have already used this trade code'
    );
  END IF;

  -- Get user's full trade balance
  user_full_balance := user_profile.trade_balance;

  -- Check minimum balance requirement
  IF user_full_balance < trade_code_record.minimum_balance THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Insufficient balance. Required: $' || trade_code_record.minimum_balance
    );
  END IF;

  -- Calculate trade amount as percentage of user's balance
  trade_amount := user_full_balance * (trade_code_record.profit_percentage / 100);
  
  -- Ensure trade amount is reasonable (not zero)
  IF trade_amount <= 0 THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Trade amount too small'
    );
  END IF;

  -- Deduct the calculated trade amount from user's balance
  UPDATE public.profiles 
  SET trade_balance = trade_balance - trade_amount,
      updated_at = NOW()
  WHERE id = user_id_input;

  -- Create the trade with the calculated trade amount
  INSERT INTO trades (
    user_id,
    trade_code,
    trade_code_id,
    type,
    asset,
    amount,
    status,
    started_at
  ) VALUES (
    user_id_input,
    code_input,
    trade_code_record.id,
    trade_code_record.signal_type,
    trade_code_record.asset,
    trade_amount,
    'active',
    NOW()
  ) RETURNING id INTO new_trade_id;

  -- Mark user code as used if it exists (for users who were sent the code)
  UPDATE user_codes 
  SET is_used = true, 
      used_at = NOW()
  WHERE user_id = user_id_input AND trade_code_id = trade_code_record.id;

  -- Return success response
  RETURN json_build_object(
    'success', true,
    'trade_id', new_trade_id,
    'duration_minutes', trade_code_record.duration_minutes,
    'asset', trade_code_record.asset,
    'trade_percentage', trade_code_record.profit_percentage,
    'amount_invested', trade_amount,
    'original_balance', user_full_balance
  );
END;
$function$;