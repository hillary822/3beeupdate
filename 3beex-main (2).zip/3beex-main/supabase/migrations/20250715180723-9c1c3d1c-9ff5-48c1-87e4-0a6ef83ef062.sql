-- Add minimum balance field to trade_codes table
ALTER TABLE public.trade_codes 
ADD COLUMN minimum_balance NUMERIC(12,2) DEFAULT 0.00;