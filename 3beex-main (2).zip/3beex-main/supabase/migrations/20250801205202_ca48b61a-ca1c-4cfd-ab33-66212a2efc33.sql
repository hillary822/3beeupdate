-- Add is_permanent_signal field to trade_codes table
ALTER TABLE public.trade_codes 
ADD COLUMN is_permanent_signal boolean NOT NULL DEFAULT false;