-- Create the verification-documents bucket that edge functions expect
INSERT INTO storage.buckets (id, name, public) 
VALUES ('verification-documents', 'verification-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Drop existing policies and create permissive ones
DROP POLICY IF EXISTS "Service role full access to kyc-documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can view own kyc docs" ON storage.objects;
DROP POLICY IF EXISTS "Admins can view all kyc docs" ON storage.objects;

-- Create very permissive policies for testing
CREATE POLICY "Allow all operations on verification-documents"
ON storage.objects
FOR ALL
USING (bucket_id = 'verification-documents');

CREATE POLICY "Allow all operations on kyc-documents" 
ON storage.objects
FOR ALL
USING (bucket_id = 'kyc-documents');