-- Add sent_at field to trade_codes table to track when codes are sent to users
ALTER TABLE public.trade_codes 
ADD COLUMN sent_at timestamp with time zone NULL;

-- Update the send_code_to_users function to mark codes as sent and prevent resending
CREATE OR REPLACE FUNCTION public.send_code_to_users(trade_code_id_input uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  trade_code_record RECORD;
  user_record RECORD;
  inserted_count INTEGER := 0;
BEGIN
  -- Check if user is admin
  IF NOT is_admin_user() THEN
    RETURN json_build_object('success', false, 'error', 'Unauthorized');
  END IF;

  -- Get trade code details
  SELECT * INTO trade_code_record 
  FROM public.trade_codes 
  WHERE id = trade_code_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Trade code not found');
  END IF;
  
  -- Check if code has already been sent
  IF trade_code_record.sent_at IS NOT NULL THEN
    RETURN json_build_object('success', false, 'error', 'This code has already been sent to users');
  END IF;

  -- Mark the code as sent
  UPDATE public.trade_codes 
  SET sent_at = NOW()
  WHERE id = trade_code_id_input;

  -- Send to appropriate users based on code type
  IF trade_code_record.is_vip THEN
    -- Send to VIP users only
    FOR user_record IN 
      SELECT id FROM public.profiles 
      WHERE vip_level > 0
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS inserted_count = ROW_COUNT;
      IF inserted_count > 0 THEN
        inserted_count := inserted_count + 1;
      END IF;
    END LOOP;
  ELSIF trade_code_record.is_premium THEN
    -- Send to premium users and users who have referred someone
    FOR user_record IN 
      SELECT DISTINCT p.id FROM public.profiles p
      WHERE p.premium = true 
      OR EXISTS (SELECT 1 FROM public.referrals r WHERE r.referrer_id = p.id)
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS inserted_count = ROW_COUNT;
      IF inserted_count > 0 THEN
        inserted_count := inserted_count + 1;
      END IF;
    END LOOP;
  ELSE
    -- Send to all users
    FOR user_record IN 
      SELECT id FROM public.profiles
    LOOP
      INSERT INTO public.user_codes (user_id, trade_code_id, code)
      VALUES (user_record.id, trade_code_id_input, trade_code_record.code)
      ON CONFLICT (user_id, trade_code_id) DO NOTHING;
      
      GET DIAGNOSTICS inserted_count = ROW_COUNT;
      IF inserted_count > 0 THEN
        inserted_count := inserted_count + 1;
      END IF;
    END LOOP;
  END IF;

  RETURN json_build_object(
    'success', true, 
    'message', format('Code sent to %s users and will expire in %s minutes', inserted_count, trade_code_record.duration_minutes),
    'users_count', inserted_count
  );
END;
$function$;

-- Update use_trade_code function to check for expiration
CREATE OR REPLACE FUNCTION public.use_trade_code(code_input text, user_id_input uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  trade_code_record RECORD;
  user_code_record RECORD;
  new_trade_id UUID;
  user_trade_balance DECIMAL(12,2);
  platform_min_balance DECIMAL(12,2);
  user_total_balance DECIMAL(12,2);
  user_profile RECORD;
BEGIN
  -- Check if trade code exists
  SELECT * INTO trade_code_record 
  FROM public.trade_codes 
  WHERE code = code_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'Invalid trade code');
  END IF;
  
  -- Check if code has expired (if it was sent)
  IF trade_code_record.sent_at IS NOT NULL THEN
    IF NOW() > (trade_code_record.sent_at + INTERVAL '1 minute' * trade_code_record.duration_minutes) THEN
      RETURN json_build_object('success', false, 'error', 'This trade code has expired');
    END IF;
  END IF;
  
  -- Check if THIS USER has already used this code
  SELECT * INTO user_code_record
  FROM public.user_codes 
  WHERE user_id = user_id_input 
  AND trade_code_id = trade_code_record.id 
  AND is_used = true;
  
  IF FOUND THEN
    RETURN json_build_object('success', false, 'error', 'You have already used this trade code');
  END IF;
  
  -- Get user profile information
  SELECT * INTO user_profile
  FROM public.profiles 
  WHERE id = user_id_input;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', false, 'error', 'User profile not found');
  END IF;
  
  -- Check if user is eligible for this trade code type
  IF trade_code_record.is_premium AND NOT user_profile.premium THEN
    RETURN json_build_object('success', false, 'error', 'This is an Extra Signal code. Only premium users can use this code.');
  END IF;
  
  IF trade_code_record.is_vip AND (user_profile.vip_level IS NULL OR user_profile.vip_level = 0) THEN
    RETURN json_build_object('success', false, 'error', 'This is a VIP code. Only VIP users can use this code.');
  END IF;
  
  -- Get platform minimum balance setting
  SELECT COALESCE(value::DECIMAL(12,2), 0) INTO platform_min_balance
  FROM public.platform_settings 
  WHERE key = 'minimum_trading_balance';
  
  -- Check user's current balances
  SELECT user_profile.trade_balance, (user_profile.exchange_balance + user_profile.trade_balance + user_profile.perpetual_balance) 
  INTO user_trade_balance, user_total_balance;
  
  -- Check if user meets platform minimum balance requirement
  IF user_total_balance < platform_min_balance THEN
    RETURN json_build_object(
      'success', false, 
      'error', format('Platform requires a minimum total balance of $%s to trade', platform_min_balance)
    );
  END IF;
  
  -- Check if user meets the trade code's minimum balance requirement
  IF user_trade_balance < COALESCE(trade_code_record.minimum_balance, 0) THEN
    RETURN json_build_object(
      'success', false, 
      'error', format('This trade code requires a minimum trade balance of $%s', COALESCE(trade_code_record.minimum_balance, 0))
    );
  END IF;
  
  -- Use the trade code's minimum balance as the trade amount
  DECLARE
    trade_amount DECIMAL(12,2) := COALESCE(trade_code_record.minimum_balance, 100.00);
  BEGIN
    -- Deduct the trade amount from user's trade balance
    UPDATE public.profiles 
    SET trade_balance = trade_balance - trade_amount, updated_at = NOW()
    WHERE id = user_id_input;
    
    -- Mark the user_code as used (not the global trade_code)
    UPDATE public.user_codes 
    SET is_used = TRUE, used_at = NOW()
    WHERE user_id = user_id_input AND trade_code_id = trade_code_record.id;
    
    -- If no user_code record exists, create one and mark it as used
    IF NOT FOUND THEN
      INSERT INTO public.user_codes (user_id, trade_code_id, code, is_used, used_at)
      VALUES (user_id_input, trade_code_record.id, code_input, TRUE, NOW());
    END IF;
    
    -- Create new trade with proper status and signal type from trade code
    INSERT INTO public.trades (
      user_id, 
      trade_code, 
      trade_code_id,
      type, 
      asset, 
      amount, 
      profit,
      status,
      started_at
    ) VALUES (
      user_id_input,
      code_input,
      trade_code_record.id,
      COALESCE(trade_code_record.signal_type, 'BUY'),
      trade_code_record.asset,
      trade_amount,
      0.00, -- Will be updated when trade completes
      'active',
      NOW()
    ) RETURNING id INTO new_trade_id;
    
    RETURN json_build_object(
      'success', true, 
      'trade_id', new_trade_id,
      'duration_minutes', trade_code_record.duration_minutes,
      'asset', trade_code_record.asset,
      'profit_percentage', trade_code_record.profit_percentage,
      'amount_invested', trade_amount,
      'minimum_balance_required', COALESCE(trade_code_record.minimum_balance, 0),
      'code_type', CASE 
        WHEN trade_code_record.is_vip THEN 'VIP'
        WHEN trade_code_record.is_premium THEN 'Premium'
        ELSE 'Normal'
      END
    );
  END;
END;
$function$;