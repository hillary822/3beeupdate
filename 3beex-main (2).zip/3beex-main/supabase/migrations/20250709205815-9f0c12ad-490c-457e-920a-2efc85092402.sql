-- Add sequential user_id to profiles table
ALTER TABLE public.profiles ADD COLUMN user_id INTEGER;

-- Create sequence for user IDs
CREATE SEQUENCE public.user_id_sequence START 1001;

-- Update existing profiles with sequential user IDs
UPDATE public.profiles 
SET user_id = nextval('public.user_id_sequence')
WHERE user_id IS NULL;

-- Make user_id NOT NULL and UNIQUE
ALTER TABLE public.profiles 
ALTER COLUMN user_id SET NOT NULL,
ADD CONSTRAINT profiles_user_id_unique UNIQUE (user_id);

-- Update the handle_new_user function to include user_id assignment
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  ref_code TEXT;
  referrer_id UUID;
BEGIN
  -- Generate unique referral code
  ref_code := 'REF' || UPPER(SUBSTRING(REPLACE(gen_random_uuid()::text, '-', ''), 1, 6));
  
  -- Check if user provided a referral code
  IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
    -- Find the referrer by their referral code directly
    SELECT id INTO referrer_id 
    FROM public.profiles 
    WHERE referral_code = NEW.raw_user_meta_data->>'referral_code';
    
    -- If no referrer found, raise an exception
    IF referrer_id IS NULL THEN
      RAISE EXCEPTION 'Invalid referral code provided: %', NEW.raw_user_meta_data->>'referral_code';
    END IF;
  END IF;
  
  -- Insert the new profile with sequential user_id
  INSERT INTO public.profiles (id, username, email, referral_code, referred_by, user_id)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', SPLIT_PART(COALESCE(NEW.email, NEW.phone), '@', 1)),
    COALESCE(NEW.email, NEW.phone),
    ref_code,
    referrer_id,
    nextval('public.user_id_sequence')
  );
  
  -- Create referral record if referrer exists
  IF referrer_id IS NOT NULL THEN
    INSERT INTO public.referrals (referrer_id, referred_id)
    VALUES (referrer_id, NEW.id);
  END IF;
  
  RETURN NEW;
END;
$function$;