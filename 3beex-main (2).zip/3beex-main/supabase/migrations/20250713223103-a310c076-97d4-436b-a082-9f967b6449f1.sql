-- Check the current update_user_balance function definition
SELECT pg_get_functiondef(oid) 
FROM pg_proc 
WHERE proname = 'update_user_balance';

-- Let's also see what tables have user_id columns that might be causing the ambiguity
SELECT table_name, column_name 
FROM information_schema.columns 
WHERE column_name = 'user_id' 
AND table_schema = 'public';