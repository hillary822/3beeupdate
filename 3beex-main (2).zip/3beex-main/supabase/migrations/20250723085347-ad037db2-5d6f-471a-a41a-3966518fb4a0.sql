-- First, create the missing profile for the recent user
INSERT INTO public.profiles (id, username, email, referral_code, user_id)
SELECT 
  au.id,
  COALESCE(au.raw_user_meta_data->>'username', SPLIT_PART(au.email, '@', 1)) as username,
  au.email,
  'REF' || UPPER(SUBSTRING(REPLACE(gen_random_uuid()::text, '-', ''), 1, 6)) as referral_code,
  nextval('public.user_id_sequence') as user_id
FROM auth.users au
WHERE au.id = '64045af3-6f25-47c2-9cc6-346dfa2f50db'
  AND au.id NOT IN (SELECT id FROM public.profiles);

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Recreate the trigger function with proper error handling
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
SET search_path = public
AS $$
DECLARE
  ref_code TEXT;
  referrer_user_id UUID;
BEGIN
  -- Generate unique referral code
  ref_code := 'REF' || UPPER(SUBSTRING(REPLACE(gen_random_uuid()::text, '-', ''), 1, 6));
  
  -- Check if user provided a referral code
  IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
    -- Find the referrer by their referral code
    SELECT id INTO referrer_user_id 
    FROM public.profiles 
    WHERE referral_code = NEW.raw_user_meta_data->>'referral_code';
  END IF;
  
  -- Insert the new profile with all required fields
  INSERT INTO public.profiles (
    id, 
    username, 
    email, 
    referral_code, 
    referred_by, 
    user_id,
    balance,
    exchange_balance,
    trade_balance,
    perpetual_balance,
    verified,
    vip,
    vip_level,
    premium,
    suspended
  )
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', SPLIT_PART(COALESCE(NEW.email, NEW.phone), '@', 1)),
    COALESCE(NEW.email, NEW.phone),
    ref_code,
    referrer_user_id,
    nextval('public.user_id_sequence'),
    0,
    0,
    0,
    0,
    false,
    false,
    0,
    false,
    false
  );
  
  -- Create referral record if referrer exists
  IF referrer_user_id IS NOT NULL THEN
    INSERT INTO public.referrals (referrer_id, referred_id, earnings)
    VALUES (referrer_user_id, NEW.id, 0);
  END IF;
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log the error but don't fail the user creation
    RAISE WARNING 'Error in handle_new_user for user %: %', NEW.id, SQLERRM;
    RETURN NEW;
END;
$$;

-- Create the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();