-- Create the platform_settings table
CREATE TABLE IF NOT EXISTS public.platform_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value text NOT NULL,
  inserted_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Allow authenticated users to read platform settings
-- This is necessary for users to see support contact information
-- CREATE POLICY "Authenticated users can read platform settings" 
-- ON public.platform_settings 
-- FOR SELECT 
-- TO authenticated 
-- USING (true);
