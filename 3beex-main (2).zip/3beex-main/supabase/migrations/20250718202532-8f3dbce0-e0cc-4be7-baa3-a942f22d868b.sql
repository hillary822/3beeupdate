-- Insert missing profile for user d9609628-a5be-4176-abe1-4c6b3224d347
INSERT INTO public.profiles (
  id, 
  username, 
  email, 
  referral_code, 
  referred_by, 
  user_id
) VALUES (
  'd9609628-a5be-4176-abe1-4c6b3224d347',
  '8120992481',
  '8120992481',
  'REF' || UPPER(SUBSTRING(REPLACE(gen_random_uuid()::text, '-', ''), 1, 6)),
  (SELECT id FROM public.profiles WHERE referral_code = 'REFC2FFC0'),
  nextval('public.user_id_sequence')
) ON CONFLICT (id) DO NOTHING;