
-- Fix RLS policies for verification_submissions table
-- Drop existing policies first
DROP POLICY IF EXISTS "Users can view their own verification submissions" ON public.verification_submissions;
DROP POLICY IF EXISTS "Users can insert their own verification submissions" ON public.verification_submissions;
DROP POLICY IF EXISTS "Admins can view all verification submissions" ON public.verification_submissions;
DROP POLICY IF EXISTS "Admins can update all verification submissions" ON public.verification_submissions;

-- Create corrected policies for verification_submissions
CREATE POLICY "Users can view their own verification submissions" 
  ON public.verification_submissions 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own verification submissions" 
  ON public.verification_submissions 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all verification submissions" 
  ON public.verification_submissions 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE id = auth.uid() 
      AND email = 'admin@admin.com'
    )
  );

CREATE POLICY "Admins can update all verification submissions" 
  ON public.verification_submissions 
  FOR UPDATE 
  USING (
    EXISTS (
      SELECT 1 FROM auth.users 
      WHERE id = auth.uid() 
      AND email = 'admin@admin.com'
    )
  );

-- Also fix storage policies for verification documents
-- Drop existing storage policies first
DROP POLICY IF EXISTS "Users can upload their own verification documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can view their own verification documents" ON storage.objects;
DROP POLICY IF EXISTS "Admins can view all verification documents" ON storage.objects;

-- Create corrected storage policies
CREATE POLICY "Users can upload their own verification documents"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'verification-documents' 
    AND auth.uid() IS NOT NULL
  );

CREATE POLICY "Users can view their own verification documents"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'verification-documents' 
    AND auth.uid() IS NOT NULL
  );

CREATE POLICY "Admins can view all verification documents"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'verification-documents' 
    AND EXISTS (
      SELECT 1 FROM auth.users 
      WHERE id = auth.uid() 
      AND email = 'admin@admin.com'
    )
  );
