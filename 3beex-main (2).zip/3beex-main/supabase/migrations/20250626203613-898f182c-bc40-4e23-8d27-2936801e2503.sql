
-- Create wallets table to store user wallet addresses
CREATE TABLE public.wallets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  address TEXT NOT NULL UNIQUE,
  currency TEXT NOT NULL DEFAULT 'USDT',
  balance NUMERIC(18,8) DEFAULT 0.00,
  ccpayment_wallet_id TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create wallet transactions table to track all wallet activity
CREATE TABLE public.wallet_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_id UUID REFERENCES public.wallets(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  transaction_type TEXT NOT NULL, -- 'deposit', 'withdrawal', 'transfer'
  amount NUMERIC(18,8) NOT NULL,
  fee NUMERIC(18,8) DEFAULT 0.00,
  status TEXT DEFAULT 'pending', -- 'pending', 'completed', 'failed', 'cancelled'
  transaction_hash TEXT,
  ccpayment_transaction_id TEXT,
  from_address TEXT,
  to_address TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on wallets table
ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;

-- Create policy for users to view their own wallets
CREATE POLICY "Users can view their own wallets" 
  ON public.wallets 
  FOR SELECT 
  USING (auth.uid() = user_id);

-- Create policy for users to update their own wallets
CREATE POLICY "Users can update their own wallets" 
  ON public.wallets 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Enable RLS on wallet_transactions table
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;

-- Create policy for users to view their own wallet transactions
CREATE POLICY "Users can view their own wallet transactions" 
  ON public.wallet_transactions 
  FOR SELECT 
  USING (auth.uid() = user_id);

-- Create policy for users to insert their own wallet transactions
CREATE POLICY "Users can create their own wallet transactions" 
  ON public.wallet_transactions 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX idx_wallets_user_id ON public.wallets(user_id);
CREATE INDEX idx_wallets_address ON public.wallets(address);
CREATE INDEX idx_wallet_transactions_wallet_id ON public.wallet_transactions(wallet_id);
CREATE INDEX idx_wallet_transactions_user_id ON public.wallet_transactions(user_id);
CREATE INDEX idx_wallet_transactions_status ON public.wallet_transactions(status);

-- Function to create wallet for new users
CREATE OR REPLACE FUNCTION public.create_user_wallet()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- The wallet creation will be handled by the edge function
  -- This trigger just ensures the profile is created first
  RETURN NEW;
END;
$$;
