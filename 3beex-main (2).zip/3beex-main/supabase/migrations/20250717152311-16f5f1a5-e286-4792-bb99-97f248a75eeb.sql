-- Add signal_type column to trade_codes table
ALTER TABLE public.trade_codes ADD COLUMN signal_type TEXT DEFAULT 'BUY';