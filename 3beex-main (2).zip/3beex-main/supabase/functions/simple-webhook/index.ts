import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("Simple webhook received");
    console.log("Method:", req.method);
    console.log("Headers:", Object.fromEntries(req.headers.entries()));

    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Get the request body
    const body = await req.text();
    console.log("Request body:", body);

    // Parse JSON if it's a POST request with data
    let data = null;
    if (body) {
      try {
        data = JSON.parse(body);
        console.log("Parsed data:", data);
      } catch (e) {
        console.log("Body is not JSON:", body);
      }
    }

    // Example: Log webhook to database (optional)
    const { error: logError } = await supabaseClient
      .from("platform_settings")
      .upsert({
        key: `webhook_log_${Date.now()}`,
        value: JSON.stringify({
          timestamp: new Date().toISOString(),
          method: req.method,
          body: body,
          headers: Object.fromEntries(req.headers.entries()),
        }),
      });

    if (logError) {
      console.error("Error logging webhook:", logError);
    }

    // Your custom webhook logic goes here
    // For example:
    if (data && data.action) {
      switch (data.action) {
        case "test":
          console.log("Test webhook received");
          break;

        case "update_user":
          if (data.user_id && data.updates) {
            const { error } = await supabaseClient
              .from("profiles")
              .update(data.updates)
              .eq("id", data.user_id);

            if (error) {
              console.error("Error updating user:", error);
              return new Response("Update failed", { status: 500 });
            }
          }
          break;

        default:
          console.log("Unknown action:", data.action);
      }
    }

    // Return success response
    return new Response(
      JSON.stringify({
        success: true,
        message: "Webhook processed successfully",
        timestamp: new Date().toISOString(),
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Webhook error:", error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
