import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface CCPaymentWebhook {
  type: string;
  msg: {
    recordId: string;
    coinId: number;
    coinSymbol: string;
    status: string;
    isFlaggedAsRisky: boolean;
    orderId?: string; // This should now contain our orderId with userId
    amount?: string;
    chain?: string;
    address?: string;
  };
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('CCPayment webhook received');

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const apiKey = Deno.env.get('CCPAYMENT_API_KEY');
    if (!apiKey) {
      console.error('CCPayment API key not configured');
      return new Response('API key not configured', { status: 500 });
    }

    // Get webhook signature headers
    const timestamp = req.headers.get('timestamp') || '';
    const nonce = req.headers.get('nonce') || '';
    const signature = req.headers.get('sign') || '';

    const body = await req.text();
    console.log('🔍 Raw webhook body:', body);
    console.log('📋 Webhook headers:', Object.fromEntries(req.headers.entries()));

    // Try to parse JSON with error handling
    let webhookData: any;
    try {
      webhookData = JSON.parse(body);
      console.log('✅ Parsed webhook data:', JSON.stringify(webhookData, null, 2));
    } catch (parseError) {
      console.error('❌ JSON parse error:', parseError);
      console.error('Raw body that failed to parse:', body);
      return new Response(JSON.stringify({ 
        msg: "error", 
        error: "Invalid JSON payload" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Check webhook type and status
    // /if (webhookData.type !== 'UserDeposit') {
    //   console.log('🔄 Not a user deposit webhook, type:', webhookData.type);
    //   return new Response(JSON.stringify({ msg: "success" }), { 
    //     status: 200, 
    //     headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    //   });
    // }

    const status = webhookData.msg?.status || '';
    console.log('🔍 Payment status:', status);
    
    if (status !== 'Success') {
      console.log('⏳ Payment not successful yet, status:', status);
      return new Response(JSON.stringify({ msg: "success" }), { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Extract orderId which should contain our userId
    const orderId = webhookData.msg?.orderId;
    const recordId = webhookData.msg?.recordId;
    
    console.log('🔍 Processing deposit with orderId:', orderId, 'recordId:', recordId);

    if (!orderId) {
      console.error('❌ No orderId found in webhook data');
      console.log('📋 Available webhook data:', JSON.stringify(webhookData, null, 2));
      return new Response(JSON.stringify({ 
        msg: "error", 
        error: "Missing orderId" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Extract userId from orderId (format: deposit_userId_timestamp)
    const orderIdParts = orderId.split('_');
    if (orderIdParts.length < 3 || orderIdParts[0] !== 'deposit') {
      console.error('❌ Invalid orderId format:', orderId);
      return new Response(JSON.stringify({ 
        msg: "error", 
        error: "Invalid orderId format" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const userId = orderIdParts[1];
    const amount = parseFloat(webhookData.msg?.amount || '1'); // Default to 1 if amount not provided
    
    console.log('📊 Extracted from webhook:', { userId, amount, orderId, recordId });

    // Process the deposit
    try {
      await processDeposit(supabaseClient, webhookData, userId, amount);
      console.log('✅ Deposit processed successfully for user:', userId, 'amount:', amount);
    } catch (error) {
      console.error('❌ Error processing deposit:', error);
      return new Response(JSON.stringify({ 
        msg: "error", 
        error: "Failed to process deposit" 
      }), { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({ msg: "success" }), { 
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('CCPayment webhook processing error:', error);
    return new Response(JSON.stringify({ msg: "error", error: "Internal server error" }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
})

// Function to get deposit details from CCPayment API
async function getDepositDetails(recordId: string) {
  try {
    const appId = Deno.env.get('CCPAYMENT_APP_ID');
    const appSecret = Deno.env.get('CCPAYMENT_APP_SECRET');
    
    if (!appId || !appSecret) {
      throw new Error('CCPayment credentials not configured');
    }

    // For now, we'll need to implement CCPayment's deposit details API
    // This is a placeholder - we need to find the correct CCPayment API endpoint
    console.log('🔍 Would fetch deposit details for recordId:', recordId);
    
    // Since we don't have the exact API endpoint, let's try a different approach
    // We can parse the recordId to extract userId if it follows our format
    // The recordId might contain encoded information about the deposit
    
    return null; // Placeholder
  } catch (error) {
    console.error('Error in getDepositDetails:', error);
    return null;
  }
}

// Function to handle deposit processing
async function processDeposit(supabaseClient: any, webhookData: any, userId: string, depositAmount: number) {
  console.log('Processing deposit for user:', userId, 'amount:', depositAmount);
  
  // Create deposit record directly from webhook (no pre-existing record needed)
  const { data: newDeposit, error: newDepositError } = await supabaseClient
    .from('deposits')
    .insert({
      user_id: userId,
      amount: depositAmount,
      payment_method_name: 'CCPayment',
      method: 'crypto_deposit',
      status: 'completed',
      transaction_id: webhookData.msg?.orderId || webhookData.msg?.recordId, // Use orderId as transaction_id
      transaction_hash: webhookData.msg?.recordId // CCPayment's recordId as hash
    })
    .select()
    .single();

  if (newDepositError) {
    console.error('Error creating deposit record:', newDepositError);
    throw new Error('Database error: ' + newDepositError.message);
  }
  
  console.log('Deposit record created:', newDeposit.id);

  // Update user balance (add to exchange_balance)
  const { error: balanceError } = await supabaseClient.rpc('update_user_balance', {
    target_user_id: userId,
    balance_amount: depositAmount
  });

  if (balanceError) {
    console.error('Error updating user balance:', balanceError);
    throw new Error('Balance update error: ' + balanceError.message);
  }
  
  console.log('User balance updated successfully for user:', userId, 'amount added:', depositAmount);
}

// Function to handle withdrawal processing
async function processWithdrawal(supabaseClient: any, webhookData: any, userId: string, withdrawalAmount: number) {
  // Update existing withdrawal record
  const { data: withdrawal, error: withdrawalError } = await supabaseClient
    .from('withdrawals')
    .update({
      status: 'completed',
      transaction_hash: webhookData.order_id,
      updated_at: new Date().toISOString()
    })
    .eq('transaction_id', webhookData.order_id)
    .select()
    .single();

  if (withdrawalError || !withdrawal) {
    console.error('Error updating withdrawal record:', withdrawalError);
    
    // If no existing withdrawal found, create a new one
    const { data: newWithdrawal, error: newWithdrawalError } = await supabaseClient
      .from('withdrawals')
      .insert({
        user_id: userId,
        amount: withdrawalAmount,
        payment_method_name: 'CCPayment',
        method: 'crypto_withdrawal',
        status: 'completed',
        transaction_id: webhookData.order_id,
        transaction_hash: webhookData.order_id
      })
      .select()
      .single();

    if (newWithdrawalError) {
      console.error('Error creating new withdrawal record:', newWithdrawalError);
      throw new Error('Database error');
    }
    
    console.log('New withdrawal record created:', newWithdrawal.id);
  } else {
    console.log('Withdrawal record updated:', withdrawal.id);
  }

  // Note: For withdrawals, we don't update the user balance here
  // The balance should have been deducted when the withdrawal was initiated
  // This webhook just confirms the withdrawal was processed successfully
}