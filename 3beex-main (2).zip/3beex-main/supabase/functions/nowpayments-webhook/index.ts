
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { createHmac } from 'https://deno.land/std@0.177.0/node/crypto.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface NOWPaymentsWebhook {
  payment_id: string;
  payment_status: string;
  pay_address: string;
  price_amount: number;
  price_currency: string;
  pay_amount: number;
  pay_currency: string;
  order_id: string;
  order_description: string;
  purchase_id: string;
  outcome_amount: number;
  outcome_currency: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('NOWPayments webhook received');

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const ipnSecret = Deno.env.get('NOWPAYMENTS_IPN_SECRET');
    if (!ipnSecret) {
      console.error('NOWPayments IPN secret not configured');
      return new Response('IPN secret not configured', { status: 500 });
    }

    // Verify webhook signature
    const signature = req.headers.get('x-nowpayments-sig');
    const body = await req.text();
    
    if (signature) {
      const hmac = createHmac('sha512', ipnSecret);
      hmac.update(body);
      const expectedSignature = hmac.digest('hex');
      
      if (signature !== expectedSignature) {
        console.error('Invalid webhook signature');
        return new Response('Invalid signature', { status: 401 });
      }
    }

    const webhookData: NOWPaymentsWebhook = JSON.parse(body);
    console.log('Webhook data:', webhookData);

    // Only process completed/confirmed payments
    if (webhookData.payment_status !== 'finished' && webhookData.payment_status !== 'confirmed') {
      console.log('Payment not completed yet, status:', webhookData.payment_status);
      return new Response('OK', { status: 200, headers: corsHeaders });
    }

    // Extract user ID from order_id (format: deposit_userId_timestamp)
    const orderIdParts = webhookData.order_id.split('_');
    if (orderIdParts.length < 2 || orderIdParts[0] !== 'deposit') {
      console.error('Invalid order ID format:', webhookData.order_id);
      return new Response('Invalid order ID', { status: 400 });
    }

    const userId = orderIdParts[1];
    console.log('Processing deposit for user:', userId);

    // Create deposit record
    const { data: deposit, error: depositError } = await supabaseClient
      .from('deposits')
      .insert({
        user_id: userId,
        amount: webhookData.outcome_amount,
        payment_method_name: 'Wallet Deposit',
        method: 'crypto_deposit',
        status: 'completed',
        transaction_hash: webhookData.payment_id,
        wallet_address: webhookData.pay_address
      })
      .select()
      .single();

    if (depositError) {
      console.error('Error creating deposit record:', depositError);
      return new Response('Database error', { status: 500 });
    }

    console.log('Deposit record created:', deposit.id);

    // Update user balance
    const { error: balanceError } = await supabaseClient.rpc('update_user_balance', {
      user_id: userId,
      amount: webhookData.outcome_amount
    });

    if (balanceError) {
      console.error('Error updating user balance:', balanceError);
      return new Response('Balance update error', { status: 500 });
    }

    // Update wallet balance
    const { error: walletError } = await supabaseClient
      .from('wallets')
      .update({ 
        balance: webhookData.outcome_amount,
        updated_at: new Date().toISOString()
      })
      .eq('user_id', userId)
      .eq('currency', webhookData.pay_currency.toUpperCase());

    if (walletError) {
      console.error('Error updating wallet balance:', walletError);
    }

    console.log('Deposit processed successfully for user:', userId, 'amount:', webhookData.outcome_amount);

    return new Response('OK', { 
      status: 200,
      headers: corsHeaders
    });

  } catch (error) {
    console.error('Webhook processing error:', error);
    return new Response('Internal server error', { 
      status: 500,
      headers: corsHeaders
    });
  }
});
