import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.50.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface KYCDocumentsRequest {
  user_id: string;
  user_email: string;
  username: string;
  verification_id: string;
  documents: {
    id_front: string; // base64 encoded
    id_back: string; // base64 encoded
    selfie_with_id: string; // base64 encoded
  };
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== KYC Document Processing Started ===');
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    console.log('Supabase client created successfully');

    let requestBody;
    try {
      requestBody = await req.json();
      console.log('Request body parsed:', Object.keys(requestBody));
    } catch (parseError) {
      console.error('Failed to parse request body:', parseError);
      throw new Error('Invalid JSON in request body');
    }

    const { user_id, user_email, username, verification_id, documents }: KYCDocumentsRequest = requestBody;

    console.log('Processing KYC documents for:', { user_id, username, verification_id });

    if (!user_id || !verification_id || !documents) {
      throw new Error('Missing required fields: user_id, verification_id, or documents');
    }

    if (!documents.id_front || !documents.id_back || !documents.selfie_with_id) {
      throw new Error('Missing document files: id_front, id_back, or selfie_with_id');
    }

    // Store documents in storage and get their paths
    const timestamp = Date.now();
    
    console.log('Starting file uploads...');

    // Upload ID front image
    console.log('Uploading ID front...');
    const idFrontBuffer = Uint8Array.from(atob(documents.id_front.includes(',') ? documents.id_front.split(',')[1] : documents.id_front), c => c.charCodeAt(0));
    const idFrontPath = `verification-documents/${user_id}/id_front_${timestamp}.jpg`;
    
    const { error: idFrontError } = await supabase.storage
      .from('verification-documents')
      .upload(idFrontPath, idFrontBuffer, {
        contentType: 'image/jpeg',
        upsert: true
      });

    if (idFrontError) {
      console.error('ID front upload failed:', idFrontError);
      throw new Error(`ID front upload failed: ${idFrontError.message}`);
    }
    console.log('ID front uploaded successfully');

    // Upload ID back image
    console.log('Uploading ID back...');
    const idBackBuffer = Uint8Array.from(atob(documents.id_back.includes(',') ? documents.id_back.split(',')[1] : documents.id_back), c => c.charCodeAt(0));
    const idBackPath = `verification-documents/${user_id}/id_back_${timestamp}.jpg`;
    
    const { error: idBackError } = await supabase.storage
      .from('verification-documents')
      .upload(idBackPath, idBackBuffer, {
        contentType: 'image/jpeg',
        upsert: true
      });

    if (idBackError) {
      console.error('ID back upload failed:', idBackError);
      throw new Error(`ID back upload failed: ${idBackError.message}`);
    }
    console.log('ID back uploaded successfully');

    // Upload selfie with ID image
    console.log('Uploading selfie...');
    const selfieBuffer = Uint8Array.from(atob(documents.selfie_with_id.includes(',') ? documents.selfie_with_id.split(',')[1] : documents.selfie_with_id), c => c.charCodeAt(0));
    const selfiePath = `verification-documents/${user_id}/selfie_with_id_${timestamp}.jpg`;
    
    const { error: selfieError } = await supabase.storage
      .from('verification-documents')
      .upload(selfiePath, selfieBuffer, {
        contentType: 'image/jpeg',
        upsert: true
      });

    if (selfieError) {
      console.error('Selfie upload failed:', selfieError);
      throw new Error(`Selfie upload failed: ${selfieError.message}`);
    }
    console.log('Selfie uploaded successfully');

    // Update KYC verification record with document paths
    console.log('Updating KYC verification record...');
    const { data: kycData, error: kycError } = await supabase
      .from('kyc_verifications')
      .update({
        id_front_path: idFrontPath,
        id_back_path: idBackPath,
        selfie_with_id_path: selfiePath,
        status: 'pending',
        submitted_at: new Date().toISOString()
      })
      .eq('id', verification_id)
      .select()
      .single();

    if (kycError) {
      console.error('KYC record update failed:', kycError);
      throw new Error(`KYC record update failed: ${kycError.message}`);
    }

    console.log('KYC verification updated successfully:', kycData);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Documents uploaded successfully for admin review',
        kyc_data: kycData
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );

  } catch (error: any) {
    console.error("=== ERROR in send-kyc-documents function ===");
    console.error("Error message:", error.message);
    console.error("Error stack:", error.stack);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Unknown error occurred'
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);