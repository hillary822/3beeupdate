import { createHmac } from "https://deno.land/std@0.177.0/node/crypto.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CCPaymentCoin {
  coinId: number;
  symbol: string;
  coinFullName: string;
  logoUrl: string;
  status: string;
  networks: {
    [key: string]: {
      chain: string;
      chainFullName: string;
      contract?: string;
      precision: number;
      canDeposit: boolean;
      canWithdraw: boolean;
      minimumDepositAmount: string;
      minimumWithdrawAmount: string;
      maximumWithdrawAmount: string;
      isSupportMemo: boolean;
    };
  };
}

interface CCPaymentResponse {
  code: number;
  msg: string;
  data: {
    coins: CCPaymentCoin[];
  };
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const appId = Deno.env.get('CCPAYMENT_MERCHANT_ID');
    const appSecret = Deno.env.get('CCPAYMENT_API_KEY');

    if (!appId || !appSecret) {
      console.error('CCPayment credentials not configured');
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'CCPayment credentials not configured' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // First, let's check what IP we're using
    console.log('Checking our outbound IP address...');
    let currentIP = 'unknown';
    try {
      const ipResponse = await fetch('https://api.ipify.org?format=json');
      if (ipResponse.ok) {
        const ipData = await ipResponse.json();
        currentIP = ipData.ip;
        console.log('Our current IP:', currentIP);
      }
    } catch (error) {
      console.log('Could not determine IP:', error.message);
    }

    // Get proxy URL from environment
    const proxyUrl = Deno.env.get('CCPAYMENT_PROXY_URL');
    console.log('CCPAYMENT_PROXY_URL environment variable:', proxyUrl);
    console.log('All environment variables containing CCPAYMENT:', 
      Object.fromEntries(
        Object.entries(Deno.env.toObject())
          .filter(([key]) => key.includes('CCPAYMENT'))
      )
    );
    
    if (!proxyUrl) {
      console.error('CCPAYMENT_PROXY_URL not configured - this will cause direct requests to CCPayment!');
      throw new Error('CCPAYMENT_PROXY_URL not configured');
    }
    
    console.log('Using proxy URL:', proxyUrl);
    
    const path = `${proxyUrl}/ccpayment/v2/getCoinList`;
    console.log('Full request path:', path);
    
    const args = "";
    const timestamp = Math.floor(Date.now() / 1000);
    
    let signText = appId + timestamp;
    if (args) {
      signText += args;
    }

    const sign = createHmac('sha256', appSecret)
      .update(signText)
      .digest('hex');

    console.log('Making request through PROXY to CCPayment');
    console.log('Request details:', {
      proxyUrl,
      fullPath: path,
      appId: appId.substring(0, 4) + '...',
      timestamp,
      signText: signText.substring(0, 20) + '...',
      sign: sign.substring(0, 10) + '...'
    });

    const response = await fetch(path, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Appid': appId,
        'Sign': sign,
        'Timestamp': timestamp.toString(),
      },
      body: args
    });

    console.log('CCPayment response status:', response.status);
    console.log('CCPayment response headers:', Object.fromEntries(response.headers.entries()));

    const responseText = await response.text();
    console.log('Raw CCPayment response body:', responseText);
    console.log('Response body length:', responseText.length);

    if (!response.ok) {
      console.error('HTTP error - CCPayment API returned non-200 status:', response.status);
      console.error('Error response body:', responseText);
      throw new Error(`CCPayment API HTTP error: ${response.status} - ${responseText}`);
    }

    let ccpaymentData: CCPaymentResponse;
    try {
      ccpaymentData = JSON.parse(responseText);
      console.log('Successfully parsed JSON response');
      console.log('CCPayment response structure:', {
        code: ccpaymentData.code,
        msg: ccpaymentData.msg,
        hasData: !!ccpaymentData.data,
        dataKeys: ccpaymentData.data ? Object.keys(ccpaymentData.data) : []
      });
    } catch (parseError) {
      console.error('JSON parsing failed:', parseError);
      console.error('Raw response that failed to parse:', responseText);
      throw new Error(`Invalid JSON response from CCPayment proxy: ${responseText}`);
    }
    
    console.log('CCPayment response code:', ccpaymentData.code, 'msg:', ccpaymentData.msg);

    if (ccpaymentData.code !== 10000) {
      console.error('CCPayment API returned error code:', ccpaymentData.code);
      console.error('CCPayment error message:', ccpaymentData.msg);
      console.error('This is the REAL error (not IP whitelist issue)');
      throw new Error(`CCPayment API error: ${ccpaymentData.msg}`);
    }

    // Transform CCPayment data to our frontend format - include ALL coins
    const transformedCoins = ccpaymentData.data.coins
      .filter(coin => coin.status === 'Normal') // Only include active coins
      .map(coin => {
        // Transform all networks/chains for this coin
        const chains = Object.entries(coin.networks)
          .filter(([_, network]) => network.canDeposit) // Only include chains that support deposits
          .map(([chainKey, network]) => ({
            name: chainKey,
            network: network.chainFullName,
            fee: network.minimumWithdrawAmount && parseFloat(network.minimumWithdrawAmount) > 0 
              ? `${network.minimumWithdrawAmount} ${coin.symbol}` 
              : 'Variable',
            minDeposit: network.minimumDepositAmount && parseFloat(network.minimumDepositAmount) > 0
              ? `${network.minimumDepositAmount} ${coin.symbol}`
              : `0 ${coin.symbol}`,
            confirmations: getConfirmationsForChain(chainKey),
            contract: network.contract,
            precision: network.precision,
            canWithdraw: network.canWithdraw,
            isSupportMemo: network.isSupportMemo,
            maximumWithdrawAmount: network.maximumWithdrawAmount
          }));

        return {
          symbol: coin.symbol,
          name: coin.coinFullName,
          logoUrl: coin.logoUrl, // Use CCPayment's actual logo URL
          coinId: coin.coinId,
          chains: chains
        };
      })
      .filter(coin => coin.chains.length > 0) // Only include coins with available deposit chains
      .sort((a, b) => {
        // Sort by priority: USDT, BTC, ETH first, then alphabetically
        const priority = ['USDT', 'BTC', 'ETH'];
        const aIndex = priority.indexOf(a.symbol);
        const bIndex = priority.indexOf(b.symbol);
        
        if (aIndex !== -1 && bIndex !== -1) return aIndex - bIndex;
        if (aIndex !== -1) return -1;
        if (bIndex !== -1) return 1;
        return a.symbol.localeCompare(b.symbol);
      });

    console.log(`Successfully fetched ${transformedCoins.length} coins from CCPayment`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        coins: transformedCoins,
        totalCoins: transformedCoins.length,
        requestIP: currentIP,
        debug: {
          appId: appId.substring(0, 4) + '...',
          timestamp,
          responseCode: ccpaymentData.code
        }
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('Error fetching CCPayment coin list:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Failed to fetch coin list'
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});

// Helper function to get typical confirmation counts for different chains
function getConfirmationsForChain(chain: string): number {
  const confirmations: { [key: string]: number } = {
    'BTC': 3,
    'ETH': 12,
    'BSC': 15,
    'TRON': 19,
    'TRC20': 19,
    'ERC20': 12,
    'BEP20': 15,
    'POLYGON': 10,
    'MATIC': 10,
    'AVAX': 10,
    'AVALANCHE': 10,
    'ARBITRUM': 1,
    'OPTIMISM': 1,
    'FANTOM': 5,
    'SOLANA': 1,
    'SOL': 1,
  };
  
  return confirmations[chain.toUpperCase()] || 6; // Default to 6 confirmations
} 