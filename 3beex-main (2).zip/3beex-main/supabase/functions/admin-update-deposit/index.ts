import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Verify admin status
    const authClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        auth: { persistSession: false },
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    )

    const { data: { user } } = await authClient.auth.getUser()
    if (!user || user.email !== 'admin@3beetex.com') {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { 
          status: 403, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    const { deposit_id, new_status, admin_note } = await req.json()

    console.log('Admin updating deposit:', { deposit_id, new_status })

    // Get deposit details first
    const { data: deposit, error: depositError } = await supabaseClient
      .from('deposits')
      .select('user_id, amount, status')
      .eq('id', deposit_id)
      .single()

    if (depositError || !deposit) {
      console.error('Deposit not found:', depositError)
      return new Response(
        JSON.stringify({ error: 'Deposit not found' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Update deposit status
    const { error: updateError } = await supabaseClient
      .from('deposits')
      .update({
        status: new_status,
        admin_note: admin_note || null,
        updated_at: new Date().toISOString()
      })
      .eq('id', deposit_id)

    if (updateError) {
      console.error('Database error:', updateError)
      throw updateError
    }

    // If approving, update user's exchange balance
    if (new_status === 'completed' && deposit.status === 'pending') {
      console.log(`Crediting ${deposit.amount} to user ${deposit.user_id}`)
      
      const { error: balanceError } = await supabaseClient.rpc('update_user_balance', {
        target_user_id: deposit.user_id,
        balance_amount: deposit.amount
      })

      if (balanceError) {
        console.error('Error updating user balance:', balanceError)
        return new Response(
          JSON.stringify({ error: 'Failed to update user balance' }),
          { 
            status: 500, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        )
      }

      console.log(`Successfully credited ${deposit.amount} to user ${deposit.user_id}`)
    }

    console.log(`Deposit ${deposit_id} updated to ${new_status}`)

    return new Response(
      JSON.stringify({ 
        success: true,
        message: `Deposit ${new_status} successfully`
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('Function error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})