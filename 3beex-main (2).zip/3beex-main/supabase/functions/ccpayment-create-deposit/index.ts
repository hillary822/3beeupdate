import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface CCPaymentDepositRequest {
  user_id: string
  amount: number
  currency: string
}

// Helper function to create HMAC SHA256 signature
async function createHmacSignature(message: string, secret: string): Promise<string> {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(secret);
  const messageData = encoder.encode(message);
  
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  
  const signature = await crypto.subtle.sign('HMAC', cryptoKey, messageData);
  const hashArray = Array.from(new Uint8Array(signature));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('CCPayment deposit creation request received');
    
    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Parse request body
    const { user_id, amount, currency }: CCPaymentDepositRequest = await req.json();
    
    console.log('Request details:', { user_id, amount, currency });

    // Validate input
    if (!user_id || !amount || amount <= 0) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Invalid input parameters' 
      }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // CCPayment credentials
    const appId = Deno.env.get('CCPAYMENT_MERCHANT_ID'); 
    const appSecret = Deno.env.get('CCPAYMENT_API_KEY');
    
    console.log('CCPayment credentials check:', { 
      appId: appId ? 'Set' : 'Missing', 
      appSecret: appSecret ? 'Set' : 'Missing' 
    });

    if (!appId || !appSecret) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'CCPayment credentials not configured' 
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Generate referenceId (unique order ID)
    const referenceId = `deposit_${user_id}_${Math.floor(Date.now() / 1000)}`;
    
    // Create payload following CCPayment's exact format
    const payloadData = {
      referenceId: referenceId,
      chain: "TRX", // Using TRX for TRON USDT
    };
    
    const payload = JSON.stringify(payloadData);
    console.log('CCPayment payload:', payload);

    // Generate timestamp (Unix timestamp)
    const timestamp = Math.floor(Date.now() / 1000);
    
    // Generate signature following CCPayment's exact method: appId + timestamp + payload
    const signText = appId + timestamp.toString() + payload;
    console.log('Sign text (first 50 chars):', signText.substring(0, 50) + '...');
    
    // Create HMAC SHA256 signature
    const signature = await createHmacSignature(signText, appSecret);
    console.log('Generated signature:', signature.substring(0, 10) + '...');

    // Get proxy URL from environment
    const proxyUrl = Deno.env.get('CCPAYMENT_PROXY_URL');
    if (!proxyUrl) {
      throw new Error('CCPAYMENT_PROXY_URL not configured');
    }
    
    // CCPayment API endpoint via proxy
    const apiEndpoint = `${proxyUrl}/ccpayment/v2/getOrCreateAppDepositAddress`;
    
    console.log('Making request to CCPayment API:', apiEndpoint);
    
    // Make request with correct headers
    const ccPaymentResponse = await fetch(apiEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Appid': appId,
        'Sign': signature,
        'Timestamp': timestamp.toString(),
      },
      body: payload
    });

    const responseText = await ccPaymentResponse.text();
    console.log('CCPayment raw response:', responseText);
    console.log('CCPayment response status:', ccPaymentResponse.status);

    let ccPaymentResult;
    try {
      ccPaymentResult = JSON.parse(responseText);
    } catch (parseError) {
      console.error('Failed to parse CCPayment response as JSON:', parseError);
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Invalid JSON response from CCPayment',
        debug_info: { raw_response: responseText }
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log('CCPayment parsed response:', ccPaymentResult);

    // Check for CCPayment success response
    if (ccPaymentResponse.status !== 200 || ccPaymentResult.code !== 10000 || !ccPaymentResult.data?.address) {
      console.error('CCPayment API error:', {
        status: ccPaymentResponse.status,
        statusText: ccPaymentResponse.statusText,
        response: ccPaymentResult
      });
      
      return new Response(JSON.stringify({ 
        success: false, 
        error: `CCPayment API error: Status ${ccPaymentResponse.status}, Code: ${ccPaymentResult.code || 'Unknown'}`,
        debug_info: {
          status: ccPaymentResponse.status,
          response: ccPaymentResult,
          endpoint: apiEndpoint,
          payload: payloadData
        }
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log('CCPayment API success, creating deposit record');

    // Create deposit record with the address from CCPayment response
    const depositAddress = ccPaymentResult.data.address;
    const memo = ccPaymentResult.data.memo || '';
    
    const { data: depositData, error: depositError } = await supabase
      .from('deposits')
      .insert({
        user_id,
        amount,
        method: 'crypto_deposit',
        status: 'pending',
        transaction_id: referenceId,
        payment_method_name: 'CCPayment',
        wallet_address: depositAddress
      })
      .select()
      .single();

    if (depositError) {
      console.error('Database error:', depositError);
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Failed to create deposit record',
        debug_info: depositError
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log('Deposit record created successfully:', depositData.id);

    // Return success response with the wallet address and memo
    return new Response(JSON.stringify({ 
      success: true, 
      data: {
        deposit_id: depositData.id,
        reference_id: referenceId,
        wallet_address: depositAddress,
        memo: memo,
        amount: amount.toString(),
        currency: currency,
        status: 'pending',
        ccpayment_response: ccPaymentResult
      }
    }), { 
      status: 200, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Function error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: error.message || 'Internal server error',
      stack: error.stack
    }), { 
      status: 500, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});