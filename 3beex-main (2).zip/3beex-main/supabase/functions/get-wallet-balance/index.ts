
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { walletId } = await req.json();
    console.log('Getting balance for wallet:', walletId);

    // Get wallet from database
    const { data: wallet, error } = await supabaseClient
      .from('wallets')
      .select('*')
      .eq('id', walletId)
      .single();

    if (error || !wallet) {
      throw new Error('Wallet not found');
    }

    console.log('Wallet found:', wallet.address);

    // Check balance using CCPayment v2 API
    const merchantId = Deno.env.get('CCPAYMENT_MERCHANT_ID');
    const apiKey = Deno.env.get('CCPAYMENT_API_KEY');

    if (!merchantId || !apiKey) {
      console.log('CCPayment credentials not configured, returning database balance');
      return new Response(
        JSON.stringify({ 
          success: true, 
          balance: wallet.balance 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const params = {
      address: wallet.address,
      currency: wallet.currency.toLowerCase()
    };

    const signature = await generateCCPaymentSignature(params);

    // Get proxy URL from environment
    const proxyUrl = Deno.env.get('CCPAYMENT_PROXY_URL');
    if (!proxyUrl) {
      throw new Error('CCPAYMENT_PROXY_URL not configured');
    }

    // Use CCPayment v2 API endpoints via proxy
    const v2Endpoints = [
      `${proxyUrl}/api/v2/wallet/balance`,
      `${proxyUrl}/ccpayment/api/v2/wallet/balance`
    ];

    let balanceData = null;
    let lastError = null;

    for (const endpoint of v2Endpoints) {
      try {
        console.log('Trying v2 balance endpoint:', endpoint);
        
        const ccpaymentResponse = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Appid': merchantId,
            'Sign': signature
          },
          body: JSON.stringify(params)
        });

        console.log('Balance response status:', ccpaymentResponse.status);
        
        if (ccpaymentResponse.status === 404) {
          console.log('404 - Balance endpoint not found, trying next...');
          continue;
        }

        const responseText = await ccpaymentResponse.text();
        console.log('Balance response text:', responseText);

        if (!responseText.trim()) {
          console.log('Empty balance response, trying next endpoint...');
          continue;
        }

        try {
          balanceData = JSON.parse(responseText);
          console.log('Successfully parsed balance response from:', endpoint);
          break;
        } catch (parseError) {
          console.error('Failed to parse balance response from', endpoint, ':', parseError);
          lastError = parseError;
          continue;
        }
      } catch (fetchError) {
        console.error('Balance fetch error for', endpoint, ':', fetchError);
        lastError = fetchError;
        continue;
      }
    }

    if (!balanceData) {
      console.log('All v2 balance endpoints failed, returning database balance. Last error:', lastError);
      return new Response(
        JSON.stringify({ 
          success: true, 
          balance: wallet.balance 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Balance data:', balanceData);

    if (balanceData.success && balanceData.data) {
      // Update wallet balance in database
      await supabaseClient
        .from('wallets')
        .update({ 
          balance: balanceData.data.balance,
          updated_at: new Date().toISOString()
        })
        .eq('id', walletId);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        balance: balanceData.data?.balance || wallet.balance 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error getting wallet balance:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Failed to get wallet balance'
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});

async function generateCCPaymentSignature(params: Record<string, any>): Promise<string> {
  const apiKey = Deno.env.get('CCPAYMENT_API_KEY') ?? '';
  const sortedParams = Object.keys(params)
    .sort()
    .map(key => `${key}=${params[key]}`)
    .join('&');
  
  const signString = sortedParams + apiKey;
  
  const encoder = new TextEncoder();
  const data = encoder.encode(signString);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  
  return hashHex;
}
