
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Verify admin status
    const authClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        auth: { persistSession: false },
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    )

    const { data: { user } } = await authClient.auth.getUser()
    if (!user || user.email !== 'admin@3beetex.com') {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { 
          status: 403, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    const { withdrawal_id, new_status, transaction_id, admin_note } = await req.json()

    console.log('Admin updating withdrawal:', { withdrawal_id, new_status, transaction_id })

    // Get withdrawal details first
    const { data: withdrawal, error: withdrawalError } = await supabaseClient
      .from('withdrawals')
      .select('user_id, amount, status')
      .eq('id', withdrawal_id)
      .single()

    if (withdrawalError || !withdrawal) {
      console.error('Withdrawal not found:', withdrawalError)
      return new Response(
        JSON.stringify({ error: 'Withdrawal not found' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // If rejecting a pending withdrawal, refund the user's balance
    if (new_status === 'rejected' && withdrawal.status === 'pending') {
      console.log(`Refunding ${withdrawal.amount} to user ${withdrawal.user_id}`)
      
      // Get user's current balance
      const { data: profile, error: profileError } = await supabaseClient
        .from('profiles')
        .select('exchange_balance')
        .eq('id', withdrawal.user_id)
        .single()

      if (profileError || !profile) {
        console.error('User not found for refund:', profileError)
        return new Response(
          JSON.stringify({ error: 'User not found for refund' }),
          { 
            status: 404, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        )
      }

      // Refund the amount to user's balance
      const { error: refundError } = await supabaseClient
        .from('profiles')
        .update({
          exchange_balance: profile.exchange_balance + withdrawal.amount,
          updated_at: new Date().toISOString()
        })
        .eq('id', withdrawal.user_id)

      if (refundError) {
        console.error('Error refunding user balance:', refundError)
        return new Response(
          JSON.stringify({ error: 'Failed to refund user balance' }),
          { 
            status: 500, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        )
      }

      console.log(`Successfully refunded ${withdrawal.amount} to user ${withdrawal.user_id}`)
    }

    // Update withdrawal status
    const updateData: any = {
      status: new_status,
      admin_note: admin_note || null,
      updated_at: new Date().toISOString()
    }

    if (transaction_id) {
      updateData.transaction_id = transaction_id
    }

    const { error } = await supabaseClient
      .from('withdrawals')
      .update(updateData)
      .eq('id', withdrawal_id)

    if (error) {
      console.error('Database error:', error)
      throw error
    }

    console.log(`Withdrawal ${withdrawal_id} updated to ${new_status}`)

    return new Response(
      JSON.stringify({ 
        success: true,
        refunded: new_status === 'rejected' && withdrawal.status === 'pending' ? withdrawal.amount : 0
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('Function error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})
