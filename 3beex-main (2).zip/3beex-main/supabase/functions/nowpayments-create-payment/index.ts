import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface CreatePaymentRequest {
  amount: number;
  currency?: string;
  pay_currency?: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('NOWPayments create payment request received');

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    )

    // Get authenticated user
    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;

    if (!user) {
      console.error('User not authenticated');
      return new Response('Unauthorized', { status: 401, headers: corsHeaders });
    }

    const { amount, currency = 'usd', pay_currency = 'btc' }: CreatePaymentRequest = await req.json();

    if (!amount || amount <= 0) {
      console.error('Invalid amount:', amount);
      return new Response('Invalid amount', { status: 400, headers: corsHeaders });
    }

    const apiKey = Deno.env.get('NOWPAYMENTS_API_KEY');
    if (!apiKey) {
      console.error('NOWPayments API key not configured');
      return new Response('Payment gateway not configured', { status: 500, headers: corsHeaders });
    }

    // Create unique order ID
    const orderId = `deposit_${user.id}_${Date.now()}`;

    // Create payment request to NOWPayments
    const paymentData = {
      price_amount: amount,
      price_currency: currency,
      pay_currency: pay_currency,
      order_id: orderId,
      order_description: `Crypto deposit for user ${user.email}`,
      ipn_callback_url: `${Deno.env.get('SUPABASE_URL')}/functions/v1/nowpayments-webhook`,
      success_url: `${req.headers.get('origin')}/dashboard?status=success`,
      cancel_url: `${req.headers.get('origin')}/dashboard?status=cancelled`
    };

    console.log('Creating NOWPayments invoice with data:', paymentData);

    const response = await fetch('https://api.nowpayments.io/v1/invoice', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
      body: JSON.stringify(paymentData),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('NOWPayments API error:', response.status, errorText);
      return new Response(JSON.stringify({ 
        success: false, 
        error: `Payment gateway error: ${errorText}` 
      }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      });
    }

    const invoiceData = await response.json();
    console.log('NOWPayments invoice created:', invoiceData);

    // Create pending deposit record
    const supabaseService = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { error: depositError } = await supabaseService
      .from('deposits')
      .insert({
        user_id: user.id,
        amount: amount,
        payment_method_name: 'NOWPayments',
        method: 'crypto_deposit',
        status: 'pending',
        transaction_hash: invoiceData.id,
        wallet_address: invoiceData.pay_address || ''
      });

    if (depositError) {
      console.error('Error creating deposit record:', depositError);
    }

    return new Response(JSON.stringify({
      success: true,
      payment_url: invoiceData.invoice_url,
      payment_id: invoiceData.id,
      pay_address: invoiceData.pay_address,
      pay_amount: invoiceData.pay_amount,
      pay_currency: invoiceData.pay_currency,
      order_id: orderId
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });

  } catch (error) {
    console.error('NOWPayments create payment error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Internal server error' 
    }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});