import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface CCPaymentWithdrawalRequest {
  user_id: string;
  amount: number;
  wallet_address: string;
  currency: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('CCPayment withdrawal request received');

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { user_id, amount, wallet_address, currency = 'USDT' }: CCPaymentWithdrawalRequest = await req.json();

    // Validate input
    if (!user_id || !amount || amount <= 0 || !wallet_address) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Invalid request parameters' 
      }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Check user balance and KYC status
    const { data: profile, error: profileError } = await supabaseClient
      .from('profiles')
      .select('exchange_balance, verified')
      .eq('id', user_id)
      .single();

    if (profileError || !profile) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'User not found' 
      }), { 
        status: 404, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Check if user is KYC verified
    if (!profile.verified) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'KYC verification required. Please complete your identity verification before making withdrawals.' 
      }), { 
        status: 403, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (profile.exchange_balance < amount) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Insufficient balance' 
      }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const merchantId = Deno.env.get('CCPAYMENT_MERCHANT_ID');
    const apiKey = Deno.env.get('CCPAYMENT_API_KEY');

    if (!merchantId || !apiKey) {
      console.error('CCPayment credentials not configured');
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Payment gateway not configured' 
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Generate unique withdrawal ID
    const withdrawalId = `withdraw_${user_id}_${Date.now()}`;
    
    // Create CCPayment withdrawal order
    const ccPaymentPayload = {
      merchant_order_id: withdrawalId,
      amount: amount.toString(),
      currency: currency,
      address: wallet_address,
      chain: 'TRX', // Tron network for USDT
    };

    // Generate signature for CCPayment
    const timestamp = Date.now().toString();
    const nonce = Math.random().toString(36).substring(2, 15);
    
    const signatureParams = {
      merchant_id: merchantId,
      timestamp,
      nonce,
      ...ccPaymentPayload
    };

    // Sort parameters and create signature string
    const sortedKeys = Object.keys(signatureParams).sort();
    const signatureString = sortedKeys
      .map(key => `${key}=${signatureParams[key as keyof typeof signatureParams]}`)
      .join('&') + `&key=${apiKey}`;

    // Create SHA256 hash
    const encoder = new TextEncoder();
    const data = encoder.encode(signatureString);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const signature = Array.from(new Uint8Array(hashBuffer))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');

    // Get proxy URL from environment
    const proxyUrl = Deno.env.get('CCPAYMENT_PROXY_URL');
    if (!proxyUrl) {
      throw new Error('CCPAYMENT_PROXY_URL not configured');
    }

    // Make request to CCPayment withdrawal API via proxy
    const ccPaymentResponse = await fetch(`${proxyUrl}/api/ccpayment/v1/withdraw/create`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Merchantid': merchantId,
        'Timestamp': timestamp,
        'Nonce': nonce,
        'Sign': signature,
      },
      body: JSON.stringify(ccPaymentPayload)
    });

    const ccPaymentResult = await ccPaymentResponse.json();
    console.log('CCPayment withdrawal API response:', ccPaymentResult);

    if (!ccPaymentResponse.ok || ccPaymentResult.code !== 10000) {
      console.error('CCPayment withdrawal API error:', ccPaymentResult);
      return new Response(JSON.stringify({ 
        success: false, 
        error: ccPaymentResult.message || 'Failed to create withdrawal order' 
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Deduct balance from user
    const { error: balanceError } = await supabaseClient
      .from('profiles')
      .update({
        exchange_balance: profile.exchange_balance - amount,
        updated_at: new Date().toISOString()
      })
      .eq('id', user_id);

    if (balanceError) {
      console.error('Error updating user balance:', balanceError);
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Failed to update balance' 
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Store withdrawal record
    const { data: withdrawal, error: withdrawalError } = await supabaseClient
      .from('withdrawals')
      .insert({
        user_id,
        amount,
        address: wallet_address,
        status: 'processing',
        transaction_id: ccPaymentResult.data.withdraw_id || withdrawalId
      })
      .select()
      .single();

    if (withdrawalError) {
      console.error('Error creating withdrawal record:', withdrawalError);
      
      // Refund the user's balance if withdrawal record creation fails
      await supabaseClient
        .from('profiles')
        .update({
          exchange_balance: profile.exchange_balance,
          updated_at: new Date().toISOString()
        })
        .eq('id', user_id);
      
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Database error' 
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log('Withdrawal request created:', withdrawal.id);

    return new Response(JSON.stringify({ 
      success: true,
      data: {
        withdrawal_id: withdrawal.id,
        transaction_id: ccPaymentResult.data.withdraw_id || withdrawalId,
        status: 'processing',
        estimated_completion: '5-30 minutes'
      }
    }), { 
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('CCPayment withdrawal creation error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Internal server error' 
    }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});