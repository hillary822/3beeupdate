
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface CreateWalletRequest {
  userId: string;
  currency?: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    let requestBody;
    try {
      requestBody = await req.json();
    } catch (error) {
      console.error('Invalid JSON in request body:', error);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Invalid request body' 
        }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const { userId, currency = 'BTC' }: CreateWalletRequest = requestBody;

    if (!userId) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'User ID is required' 
        }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    console.log('Creating wallet for user:', userId, 'currency:', currency);

    // Check if user already has a wallet for this currency
    const { data: existingWallet, error: walletCheckError } = await supabaseClient
      .from('wallets')
      .select('*')
      .eq('user_id', userId)
      .eq('currency', currency)
      .single();

    if (walletCheckError && walletCheckError.code !== 'PGRST116') {
      console.error('Database error checking existing wallet:', walletCheckError);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Database error' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    if (existingWallet) {
      console.log('Existing wallet found:', existingWallet.id);
      return new Response(
        JSON.stringify({ success: true, wallet: existingWallet }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get NOWPayments API key
    const apiKey = Deno.env.get('NOWPAYMENTS_API_KEY');
    
    if (!apiKey) {
      console.error('NOWPayments API key not found');
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Payment service configuration missing. Please contact support.' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Create NOWPayments invoice
    const nowPaymentsPayload = {
      price_amount: 1,
      price_currency: 'USD',
      pay_currency: currency.toLowerCase(),
      order_id: `wallet_${userId}_${Date.now()}`,
      order_description: `Wallet deposit for user ${userId}`,
      ipn_callback_url: `${Deno.env.get('SUPABASE_URL')}/functions/v1/nowpayments-webhook`,
      success_url: `${Deno.env.get('SUPABASE_URL')}/dashboard`,
      cancel_url: `${Deno.env.get('SUPABASE_URL')}/dashboard`
    };

    console.log('Creating NOWPayments invoice with payload:', nowPaymentsPayload);

    const nowPaymentsResponse = await fetch('https://api.nowpayments.io/v1/invoice', {
      method: 'POST',
      headers: {
        'x-api-key': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(nowPaymentsPayload)
    });

    console.log('NOWPayments response status:', nowPaymentsResponse.status);

    if (!nowPaymentsResponse.ok) {
      const errorText = await nowPaymentsResponse.text();
      console.error('NOWPayments API error:', errorText);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: `Payment service error: ${nowPaymentsResponse.status}` 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const nowPaymentsData = await nowPaymentsResponse.json();
    console.log('NOWPayments response data:', nowPaymentsData);

    // Store wallet in database with NOWPayments invoice URL
    const { data: newWallet, error: insertError } = await supabaseClient
      .from('wallets')
      .insert({
        user_id: userId,
        address: nowPaymentsData.invoice_url,
        currency: currency,
        balance: 0.00,
        is_active: true
      })
      .select()
      .single();

    if (insertError) {
      console.error('Database insert error:', insertError);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Failed to save wallet to database' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    console.log('Wallet saved to database successfully:', newWallet.id);

    return new Response(
      JSON.stringify({ 
        success: true, 
        wallet: newWallet,
        deposit_address: nowPaymentsData.invoice_url,
        method: 'nowpayments'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Unexpected error in create-wallet function:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: 'Internal server error. Please try again or contact support.' 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
