const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get IP address from multiple services
    const ipServices = [
      'https://api.ipify.org?format=json',
      'https://httpbin.org/ip',
      'https://ifconfig.me/ip',
      'https://api.my-ip.io/ip'
    ];

    const results = [];

    for (const service of ipServices) {
      try {
        const response = await fetch(service, {
          headers: {
            'User-Agent': 'Supabase-Edge-Function'
          }
        });
        
        if (response.ok) {
          const data = await response.text();
          results.push({
            service: service,
            ip: data.includes('{') ? JSON.parse(data) : data.trim(),
            success: true
          });
        } else {
          results.push({
            service: service,
            error: `HTTP ${response.status}`,
            success: false
          });
        }
      } catch (error) {
        results.push({
          service: service,
          error: error.message,
          success: false
        });
      }
    }

    // Get request headers for additional info
    const requestInfo = {
      headers: Object.fromEntries(req.headers.entries()),
      url: req.url,
      method: req.method
    };

    return new Response(
      JSON.stringify({ 
        success: true,
        ipResults: results,
        requestInfo: requestInfo,
        timestamp: new Date().toISOString()
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('Error getting IP:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
}); 