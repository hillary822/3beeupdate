import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface WithdrawalRequest {
  user_id: string;
  amount: number;
  address: string;
  currency?: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Withdrawal request received');

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { user_id, amount, address, currency = 'USDT' }: WithdrawalRequest = await req.json();

    // Validate input
    if (!user_id || !amount || amount <= 0 || !address) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Invalid request parameters' 
      }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Check user balance
    const { data: profile, error: profileError } = await supabaseClient
      .from('profiles')
      .select('exchange_balance, username')
      .eq('id', user_id)
      .single();

    if (profileError || !profile) {
      console.error('User not found:', profileError);
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'User not found' 
      }), { 
        status: 404, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (profile.exchange_balance < amount) {
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Insufficient balance' 
      }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Deduct balance from user immediately (will be refunded if admin rejects)
    const { error: balanceError } = await supabaseClient
      .from('profiles')
      .update({
        exchange_balance: profile.exchange_balance - amount,
        updated_at: new Date().toISOString()
      })
      .eq('id', user_id);

    if (balanceError) {
      console.error('Error updating user balance:', balanceError);
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Failed to update balance' 
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Create withdrawal record with pending status
    const { data: withdrawal, error: withdrawalError } = await supabaseClient
      .from('withdrawals')
      .insert({
        user_id,
        amount,
        address,
        status: 'pending',
        transaction_id: `WD_${user_id}_${Date.now()}`
      })
      .select()
      .single();

    if (withdrawalError) {
      console.error('Error creating withdrawal record:', withdrawalError);
      
      // Refund the user's balance if withdrawal record creation fails
      await supabaseClient
        .from('profiles')
        .update({
          exchange_balance: profile.exchange_balance,
          updated_at: new Date().toISOString()
        })
        .eq('id', user_id);
      
      return new Response(JSON.stringify({ 
        success: false, 
        error: 'Failed to create withdrawal request' 
      }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log('Withdrawal request created successfully:', withdrawal.id);

    return new Response(JSON.stringify({ 
      success: true,
      data: {
        withdrawal_id: withdrawal.id,
        transaction_id: withdrawal.transaction_id,
        status: 'pending',
        message: 'Withdrawal request submitted successfully. It will be reviewed by our team.'
      }
    }), { 
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Withdrawal request creation error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Internal server error' 
    }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});