import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { createHmac } from "https://deno.land/std@0.177.0/node/crypto.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// Define the expected webhook payload structure
interface CustomWebhookPayload {
  event_type: string;
  user_id: string;
  amount?: number;
  transaction_id?: string;
  status: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Only allow POST requests
  if (req.method !== "POST") {
    return new Response("Method not allowed", {
      status: 405,
      headers: corsHeaders,
    });
  }

  try {
    console.log("Custom webhook received");

    // Initialize Supabase client with service role key
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Get webhook secret for signature verification
    const webhookSecret = Deno.env.get("CUSTOM_WEBHOOK_SECRET");
    if (!webhookSecret) {
      console.error("Webhook secret not configured");
      return new Response("Webhook secret not configured", { status: 500 });
    }

    // Get request headers and body
    const signature = req.headers.get("x-webhook-signature");
    const timestamp = req.headers.get("x-webhook-timestamp");
    const body = await req.text();

    console.log("Webhook body:", body);

    // Verify webhook signature (recommended for security)
    if (signature && timestamp) {
      const signaturePayload = `${timestamp}.${body}`;
      const hmac = createHmac("sha256", webhookSecret);
      hmac.update(signaturePayload);
      const expectedSignature = `v1=${hmac.digest("hex")}`;

      if (signature !== expectedSignature) {
        console.error("Invalid webhook signature");
        return new Response("Invalid signature", { status: 401 });
      }
    }

    // Parse webhook data
    const webhookData: CustomWebhookPayload = JSON.parse(body);
    console.log("Parsed webhook data:", webhookData);

    // Validate required fields
    if (
      !webhookData.event_type ||
      !webhookData.user_id ||
      !webhookData.status
    ) {
      console.error("Missing required fields");
      return new Response("Missing required fields", { status: 400 });
    }

    // Process different event types
    switch (webhookData.event_type) {
      case "payment_completed":
        await handlePaymentCompleted(supabaseClient, webhookData);
        break;

      case "user_verified":
        await handleUserVerified(supabaseClient, webhookData);
        break;

      case "trade_executed":
        await handleTradeExecuted(supabaseClient, webhookData);
        break;

      default:
        console.log("Unknown event type:", webhookData.event_type);
        break;
    }

    console.log("Webhook processed successfully");

    return new Response("OK", {
      status: 200,
      headers: corsHeaders,
    });
  } catch (error) {
    console.error("Webhook processing error:", error);
    return new Response("Internal server error", {
      status: 500,
      headers: corsHeaders,
    });
  }
});

// Handler functions for different event types
async function handlePaymentCompleted(
  supabaseClient: any,
  data: CustomWebhookPayload
) {
  console.log("Processing payment completion for user:", data.user_id);

  if (!data.amount || !data.transaction_id) {
    throw new Error("Missing payment data");
  }

  // Create deposit record
  const { error: depositError } = await supabaseClient.from("deposits").insert({
    user_id: data.user_id,
    amount: data.amount,
    payment_method_name: "Custom Webhook",
    method: "webhook_deposit",
    status: "completed",
    transaction_id: data.transaction_id,
    transaction_hash: data.transaction_id,
  });

  if (depositError) {
    console.error("Error creating deposit:", depositError);
    throw depositError;
  }

  // Update user balance using the existing RPC function
  const { error: balanceError } = await supabaseClient.rpc(
    "update_user_balance",
    {
      target_user_id: data.user_id,
      balance_amount: data.amount,
    }
  );

  if (balanceError) {
    console.error("Error updating balance:", balanceError);
    throw balanceError;
  }

  console.log("Payment processed successfully");
}

async function handleUserVerified(
  supabaseClient: any,
  data: CustomWebhookPayload
) {
  console.log("Processing user verification for user:", data.user_id);

  // Update user profile verification status
  const { error } = await supabaseClient
    .from("profiles")
    .update({
      verified: true,
      updated_at: new Date().toISOString(),
    })
    .eq("id", data.user_id);

  if (error) {
    console.error("Error updating user verification:", error);
    throw error;
  }

  console.log("User verification updated successfully");
}

async function handleTradeExecuted(
  supabaseClient: any,
  data: CustomWebhookPayload
) {
  console.log("Processing trade execution for user:", data.user_id);

  // You can add custom trade processing logic here
  // For example, updating trade status, calculating profits, etc.

  console.log("Trade execution processed successfully");
}
