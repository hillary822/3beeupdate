
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface AssignWalletRequest {
  userId: string;
  currency?: string;
  chain?: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    let requestBody;
    try {
      requestBody = await req.json();
    } catch (error) {
      console.error('Invalid JSON in request body:', error);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Invalid request body' 
        }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const { userId, currency, chain }: AssignWalletRequest = requestBody;

    console.log('🔍 assign-wallet received request body:', JSON.stringify(requestBody, null, 2));
    console.log('📊 Parsed parameters:', { userId, currency, chain });

    if (!userId || !chain || !currency) {
      console.log('❌ Missing required parameters:', {
        hasUserId: !!userId,
        hasCurrency: !!currency,
        hasChain: !!chain
      });
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'User ID, chain, and currency are required' 
        }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    console.log('Assigning wallet for user:', userId, 'currency:', currency, 'chain:', chain);

    // Check if user already has a wallet assigned for this currency/chain
    const { data: existingWallet, error: checkError } = await supabaseClient
      .from('user_wallets')
      .select('*')
      .eq('user_id', userId)
      .eq('currency', currency)
      .eq('chain', chain)
      .maybeSingle();

    if (checkError && checkError.code !== 'PGRST116') { // PGRST116 = no rows found
      console.error('Error checking existing wallet:', checkError);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Database error checking existing wallet' 
        }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // if (existingWallet) {
    //   console.log('Existing wallet found:', existingWallet);
    //   return new Response(
    //     JSON.stringify({
    //       success: true,
    //       wallet: {
    //         id: existingWallet.id,
    //         address: existingWallet.address,
    //         currency: existingWallet.currency,
    //         chain: existingWallet.chain,
    //         memo: existingWallet.memo,
    //         assigned_at: existingWallet.created_at
    //       },
    //       message: 'Existing wallet found'
    //     }),
    //     { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    //   );
    // }

    // Generate new wallet address via CCPayment proxy
    const proxyUrl = Deno.env.get('CCPAYMENT_PROXY_URL') || 'http://localhost:3000';
    
    console.log('Chain:', chain);
    console.log('User ID:', userId);
    console.log('Generating new wallet via CCPayment proxy:', proxyUrl);
    
    const walletResponse = await fetch(`${proxyUrl}/generate-wallet`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId: userId,
        chain: chain,
        currency: currency
      })
    });

    if (!walletResponse.ok) {
      const errorData = await walletResponse.json();
      console.error('CCPayment proxy error:', errorData);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: errorData.error || 'Failed to generate wallet address' 
        }),
        { 
          status: walletResponse.status,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const walletData = await walletResponse.json();
    console.log('CCPayment wallet generated:', walletData);

    if (!walletData.success) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: walletData.error || 'Failed to generate wallet address' 
        }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Return the wallet data directly from CCPayment without saving to database
    console.log('Wallet generated successfully from CCPayment:', walletData.data);

    return new Response(
      JSON.stringify({
        success: true,
        wallet: {
          address: walletData.data.address,
          currency: currency,
          chain: chain,
          memo: walletData.data.memo || '',
          provider: 'ccpayment'
        },
        message: 'Wallet address generated successfully'
      }),
      { 
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Unexpected error in assign-wallet function:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: 'Internal server error. Please try again or contact support.' 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
