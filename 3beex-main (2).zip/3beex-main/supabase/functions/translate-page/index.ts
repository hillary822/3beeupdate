import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TranslationRequest {
  targetLanguage: string;
  content?: string; // Made optional since we're translating common UI elements
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { targetLanguage, content }: TranslationRequest = await req.json();
    
    console.log(`Starting translation to ${targetLanguage}`);

    // Hardcoded translations for reliability (since LibreTranslate public instance is unreliable)
    const translationDictionary: Record<string, Record<string, string>> = {
      'es': {
        'Dashboard': 'Panel de Control',
        'Assets': 'Activos',
        'Trades': 'Operaciones',
        'Deposits': 'Depósitos',
        'Withdrawals': 'Retiros',
        'Referrals': 'Referencias',
        'Settings': 'Configuración',
        'Balance': 'Saldo',
        'Copy Trading': 'Copy Trading',
        'Exchange': 'Intercambio',
        'Trade': 'Operar',
        'Perpetual': 'Perpetuo',
        'Total Balance': 'Saldo Total',
        'Win Rate': 'Tasa de Éxito',
        'Profile': 'Perfil',
        'Verification': 'Verificación',
        'Welcome back': 'Bienvenido de vuelta',
        'Login': 'Iniciar Sesión',
        'Register': 'Registrarse',
        'Email': 'Correo',
        'Password': 'Contraseña',
        'Username': 'Usuario',
        'Submit': 'Enviar',
        'Cancel': 'Cancelar',
        'Save': 'Guardar',
        'Delete': 'Eliminar',
        'Edit': 'Editar',
        'Amount': 'Cantidad',
        'Status': 'Estado',
        'Date': 'Fecha',
        'Transaction': 'Transacción',
        'Transfer': 'Transferir',
        'Wallet': 'Billetera',
        'Address': 'Dirección',
        'Pending': 'Pendiente',
        'Completed': 'Completado',
        'Failed': 'Fallido',
        'Approved': 'Aprobado',
        'Rejected': 'Rechazado',
        'Copy': 'Copiar',
        'Logout': 'Cerrar Sesión',
        // Admin specific terms
        'Admin Dashboard': 'Panel de Administración',
        'User Management': 'Gestión de Usuarios',
        'Total Users': 'Total de Usuarios',
        'Active Users': 'Usuarios Activos',
        'Verified Users': 'Usuarios Verificados',
        'VIP Users': 'Usuarios VIP',
        'Total Withdrawals': 'Total de Retiros',
        'Pending Withdrawals': 'Retiros Pendientes',
        'Completed Withdrawals': 'Retiros Completados',
        'Trade Codes': 'Códigos de Trading',
        'Wallet Management': 'Gestión de Billeteras',
        'KYC Management': 'Gestión de KYC',
        'Users': 'Usuarios',
        'View': 'Ver',
        'Manage': 'Gestionar',
        'Actions': 'Acciones',
        'Search': 'Buscar',
        'Filter': 'Filtrar',
        'Export': 'Exportar',
        'Import': 'Importar',
        'Update': 'Actualizar',
        'Create': 'Crear',
        'Remove': 'Eliminar',
        'Add': 'Añadir',
        'Details': 'Detalles',
        'Information': 'Información',
        'Statistics': 'Estadísticas',
        'Reports': 'Reportes',
        'Analytics': 'Analíticas',
        // Tab and navigation specific
        'Overview': 'Resumen',
        'History': 'Historial',
        'Account Settings': 'Configuración de Cuenta',
        'Payment Methods': 'Métodos de Pago',
        'KYC Verification': 'Verificación KYC',
        'All': 'Todos',
        'Active': 'Activo',
        'Inactive': 'Inactivo',
        'Recent': 'Reciente',
        'Previous': 'Anterior',
        'Next': 'Siguiente',
        'Back': 'Atrás',
        'Forward': 'Adelante',
        'Today': 'Hoy',
        'Yesterday': 'Ayer',
        'This Week': 'Esta Semana',
        'This Month': 'Este Mes',
        'Last Month': 'Mes Pasado',
        'Custom': 'Personalizado',
        'Show All': 'Mostrar Todo',
        'Show More': 'Mostrar Más',
        'Show Less': 'Mostrar Menos',
        'Expand': 'Expandir',
        'Collapse': 'Colapsar',
        'Open': 'Abrir',
        'Close': 'Cerrar',
        // Trading specific terms
        'Trading History': 'Historial de Trading',
        'Your executed trades and profits': 'Tus operaciones ejecutadas y ganancias',
        'No trades yet': 'Aún no hay operaciones',
        'Ongoing Trade': 'Operación en Curso',
        'Settled': 'Liquidado',
        'Order ID': 'ID de Orden',
        'Copy Code': 'Código de Copia',
        'Turnover': 'Volumen',
        'Profit/Loss': 'Ganancia/Pérdida',
        'Duration': 'Duración',
        'Expires At': 'Expira En',
        'BUY': 'COMPRAR',
        'SELL': 'VENDER',
        // Referrals and invite section
        'Invite Me': 'Invítame',
        'Referral Program': 'Programa de Referencias',
        'Invite friends and earn rewards': 'Invita amigos y gana recompensas',
        'Your Referral Link': 'Tu Enlace de Referencia',
        'Direct Referrals': 'Referencias Directas',
        'Referral Earnings': 'Ganancias por Referencias',
        'Network Tree': 'Árbol de Red',
        'Please log in to view your referrals': 'Por favor inicia sesión para ver tus referencias',
        'Copied!': '¡Copiado!',
        'Referral link copied to clipboard': 'Enlace de referencia copiado al portapapeles',
        'No referral data available': 'No hay datos de referencias disponibles',
        // Trading signals in invite section
        'Your Invitation Signals': 'Tus Señales de Invitación',
        'Click "Trade Code" to use any of these codes instantly': 'Haz clic en "Código de Trading" para usar cualquiera de estos códigos al instante',
        'New Signal': 'Nueva Señal',
        'Signal Code': 'Código de Señal',
        'Required Amount': 'Cantidad Requerida',
        'Expected Profit': 'Ganancia Esperada',
        'Expires': 'Expira',
        'Received': 'Recibido',
        'Click To Confirm Order': 'Haz Clic Para Confirmar Orden'
      },
      'fr': {
        'Dashboard': 'Tableau de Bord',
        'Assets': 'Actifs',
        'Trades': 'Transactions',
        'Deposits': 'Dépôts',
        'Withdrawals': 'Retraits',
        'Referrals': 'Parrainages',
        'Settings': 'Paramètres',
        'Balance': 'Solde',
        'Copy Trading': 'Copy Trading',
        'Exchange': 'Échange',
        'Trade': 'Négocier',
        'Perpetual': 'Perpétuel',
        'Total Balance': 'Solde Total',
        'Win Rate': 'Taux de Réussite',
        'Profile': 'Profil',
        'Verification': 'Vérification',
        'Welcome back': 'Bon retour',
        'Login': 'Se connecter',
        'Register': "S'inscrire",
        'Email': 'Email',
        'Password': 'Mot de passe',
        'Username': "Nom d'utilisateur",
        'Submit': 'Soumettre',
        'Cancel': 'Annuler',
        'Save': 'Sauvegarder',
        'Delete': 'Supprimer',
        'Edit': 'Modifier',
        'Amount': 'Montant',
        'Status': 'Statut',
        'Date': 'Date',
        'Transaction': 'Transaction',
        'Transfer': 'Transférer',
        'Wallet': 'Portefeuille',
        'Address': 'Adresse',
        'Pending': 'En attente',
        'Completed': 'Terminé',
        'Failed': 'Échoué',
        'Approved': 'Approuvé',
        'Rejected': 'Rejeté',
        'Copy': 'Copier',
        'Logout': 'Se déconnecter'
      },
      'de': {
        'Dashboard': 'Dashboard',
        'Assets': 'Vermögenswerte',
        'Trades': 'Handel',
        'Deposits': 'Einzahlungen',
        'Withdrawals': 'Abhebungen',
        'Referrals': 'Empfehlungen',
        'Settings': 'Einstellungen',
        'Balance': 'Guthaben',
        'Copy Trading': 'Copy Trading',
        'Exchange': 'Austausch',
        'Trade': 'Handeln',
        'Perpetual': 'Perpetual',
        'Total Balance': 'Gesamtguthaben',
        'Win Rate': 'Gewinnrate',
        'Profile': 'Profil',
        'Verification': 'Verifizierung',
        'Welcome back': 'Willkommen zurück',
        'Login': 'Anmelden',
        'Register': 'Registrieren',
        'Email': 'E-Mail',
        'Password': 'Passwort',
        'Username': 'Benutzername',
        'Submit': 'Senden',
        'Cancel': 'Abbrechen',
        'Save': 'Speichern',
        'Delete': 'Löschen',
        'Edit': 'Bearbeiten',
        'Amount': 'Betrag',
        'Status': 'Status',
        'Date': 'Datum',
        'Transaction': 'Transaktion',
        'Transfer': 'Übertragen',
        'Wallet': 'Wallet',
        'Address': 'Adresse',
        'Pending': 'Ausstehend',
        'Completed': 'Abgeschlossen',
        'Failed': 'Fehlgeschlagen',
        'Approved': 'Genehmigt',
        'Rejected': 'Abgelehnt',
        'Copy': 'Kopieren',
        'Logout': 'Abmelden'
      }
    };

    // Common UI texts for trading platform
    const commonTexts = [
      'Dashboard', 'Assets', 'Trades', 'Deposits', 'Withdrawals', 'Referrals', 'Settings',
      'Balance', 'Copy Trading', 'Exchange', 'Trade', 'Perpetual', 'Total Balance',
      'Win Rate', 'Profile', 'Verification', 'Welcome back', 'Login', 'Register',
      'Email', 'Password', 'Username', 'Submit', 'Cancel', 'Save', 'Delete', 'Edit',
      'Amount', 'Status', 'Date', 'Transaction', 'Transfer', 'Wallet', 'Address',
      'Pending', 'Completed', 'Failed', 'Approved', 'Rejected', 'Copy', 'Logout',
      // Admin specific terms
      'Admin Dashboard', 'User Management', 'Total Users', 'Active Users', 'Verified Users', 'VIP Users',
      'Total Withdrawals', 'Pending Withdrawals', 'Completed Withdrawals', 'Trade Codes',
      'Wallet Management', 'KYC Management', 'Users', 'View', 'Manage', 'Actions',
      'Search', 'Filter', 'Export', 'Import', 'Update', 'Create', 'Remove', 'Add',
      'Details', 'Information', 'Statistics', 'Reports', 'Analytics',
      // Tab and navigation specific
      'Overview', 'History', 'Account Settings', 'Payment Methods', 'KYC Verification',
      'All', 'Active', 'Inactive', 'Recent', 'Previous', 'Next', 'Back', 'Forward',
      'Today', 'Yesterday', 'This Week', 'This Month', 'Last Month', 'Custom',
      'Show All', 'Show More', 'Show Less', 'Expand', 'Collapse', 'Open', 'Close',
      // Trading specific terms
      'Trading History', 'Your executed trades and profits', 'No trades yet',
      'Ongoing Trade', 'Settled', 'Order ID', 'Copy Code', 'Turnover',
      'Profit/Loss', 'Duration', 'Expires At', 'BUY', 'SELL',
      // Referrals and invite section
      'Invite Me', 'Referral Program', 'Invite friends and earn rewards',
      'Your Referral Link', 'Direct Referrals', 'Referral Earnings', 'Network Tree',
      'Please log in to view your referrals', 'Copied!', 
      'Referral link copied to clipboard', 'No referral data available',
      // Trading signals in invite section
      'Your Invitation Signals', 'Click "Trade Code" to use any of these codes instantly',
      'New Signal', 'Signal Code', 'Required Amount', 'Expected Profit',
      'Expires', 'Received', 'Click To Confirm Order'
    ];

    const translations: Record<string, string> = {};

    // Use hardcoded translations if available
    if (translationDictionary[targetLanguage]) {
      const langDict = translationDictionary[targetLanguage];
      commonTexts.forEach(text => {
        translations[text] = langDict[text] || text;
      });
      
      console.log(`Applied ${Object.keys(translations).length} hardcoded translations for ${targetLanguage}`);
    } else {
      // Fallback: keep original text for unsupported languages
      commonTexts.forEach(text => {
        translations[text] = text;
      });
      
      console.log(`No translations available for ${targetLanguage}, keeping original text`);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        translations,
        targetLanguage,
        service: 'Hardcoded'
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );

  } catch (error: any) {
    console.error("Error in translate-page function:", error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);