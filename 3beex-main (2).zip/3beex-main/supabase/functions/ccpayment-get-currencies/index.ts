import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Helper function to create HMAC SHA256 signature
async function createHmacSignature(message: string, secret: string): Promise<string> {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(secret);
  const messageData = encoder.encode(message);
  
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  
  const signature = await crypto.subtle.sign('HMAC', cryptoKey, messageData);
  const hashArray = Array.from(new Uint8Array(signature));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('CCPayment get currencies request received');

    // CCPayment credentials
    const appId = Deno.env.get('CCPAYMENT_MERCHANT_ID');
    const appSecret = Deno.env.get('CCPAYMENT_API_KEY');

    if (!appId || !appSecret) {
      throw new Error('CCPayment credentials not configured');
    }

    // Prepare request parameters
    const timestamp = Math.floor(Date.now() / 1000).toString();
    const nonce = Math.random().toString(36).substring(2, 15);
    
    // Create signature for CCPayment API
    const signatureString = `appid=${appId}&timestamp=${timestamp}&nonce=${nonce}&key=${appSecret}`;
    const signature = await createHmacSignature(signatureString, appSecret);

    // Get proxy URL from environment
    const proxyUrl = Deno.env.get('CCPAYMENT_PROXY_URL');
    if (!proxyUrl) {
      throw new Error('CCPAYMENT_PROXY_URL not configured');
    }

    // Call CCPayment API to get supported currencies via proxy
    const ccPaymentResponse = await fetch(`${proxyUrl}/admin/ccpayment/v2/bill/supported-currencies`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Appid': appId,
        'Sign': signature,
        'Timestamp': timestamp,
        'Nonce': nonce,
      }
    });

    if (!ccPaymentResponse.ok) {
      const errorText = await ccPaymentResponse.text();
      console.error('CCPayment API error:', errorText);
      throw new Error(`CCPayment API error: ${ccPaymentResponse.status}`);
    }

    const ccPaymentData = await ccPaymentResponse.json();
    console.log('CCPayment currencies response:', ccPaymentData);

    // Transform CCPayment data into our format
    const transformedCurrencies = transformCCPaymentCurrencies(ccPaymentData);

    return new Response(
      JSON.stringify({
        success: true,
        currencies: transformedCurrencies
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('Error fetching CCPayment currencies:', error);
    
    // Return fallback currencies if API fails
    const fallbackCurrencies = getFallbackCurrencies();
    
    return new Response(
      JSON.stringify({
        success: true,
        currencies: fallbackCurrencies,
        fallback: true,
        error: error.message
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});

function transformCCPaymentCurrencies(ccPaymentData: any) {
  // Transform CCPayment response into our coin/chain format
  const currencies = [];
  
  if (ccPaymentData?.data && Array.isArray(ccPaymentData.data)) {
    for (const currency of ccPaymentData.data) {
      const chains = [];
      
      // Handle different networks for the same currency
      if (currency.networks && Array.isArray(currency.networks)) {
        for (const network of currency.networks) {
          chains.push({
            name: network.network || network.name,
            network: network.network || network.name,
            fee: network.fee || 'Variable',
            minDeposit: network.min_deposit || '1',
            confirmations: network.confirmations || 1
          });
        }
      } else {
        // Single network currency
        chains.push({
          name: currency.symbol,
          network: currency.symbol,
          fee: currency.fee || 'Variable',
          minDeposit: currency.min_deposit || '1',
          confirmations: currency.confirmations || 1
        });
      }

      currencies.push({
        symbol: currency.symbol,
        name: currency.name || currency.symbol,
        icon: getCurrencyIcon(currency.symbol),
        chains: chains
      });
    }
  }
  
  return currencies;
}

function getCurrencyIcon(symbol: string): string {
  const iconMap: { [key: string]: string } = {
    'USDT': '💰',
    'BTC': '₿',
    'ETH': 'Ξ',
    'BNB': '🟡',
    'USDC': '💙',
    'BUSD': '💛',
    'TRX': '🔴',
    'LTC': '🥈',
    'DOGE': '🐕',
    'ADA': '🔵',
    'DOT': '🟣',
    'LINK': '🔗',
    'XRP': '💧'
  };
  
  return iconMap[symbol] || '🪙';
}

function getFallbackCurrencies() {
  // Fallback currencies if CCPayment API fails
  return [
    {
      symbol: "USDT",
      name: "Tether",
      icon: "💰",
      chains: [
        {
          name: "TRC20",
          network: "TRON",
          fee: "1 USDT",
          minDeposit: "1 USDT",
          confirmations: 19,
        },
        {
          name: "ERC20",
          network: "Ethereum",
          fee: "5 USDT",
          minDeposit: "10 USDT",
          confirmations: 12,
        },
        {
          name: "BEP20",
          network: "BSC",
          fee: "1 USDT",
          minDeposit: "1 USDT",
          confirmations: 15,
        },
      ],
    },
    {
      symbol: "BTC",
      name: "Bitcoin",
      icon: "₿",
      chains: [
        {
          name: "Bitcoin",
          network: "Bitcoin",
          fee: "0.0005 BTC",
          minDeposit: "0.001 BTC",
          confirmations: 3,
        },
      ],
    },
    {
      symbol: "ETH",
      name: "Ethereum",
      icon: "Ξ",
      chains: [
        {
          name: "ERC20",
          network: "Ethereum",
          fee: "0.005 ETH",
          minDeposit: "0.01 ETH",
          confirmations: 12,
        },
      ],
    },
  ];
} 