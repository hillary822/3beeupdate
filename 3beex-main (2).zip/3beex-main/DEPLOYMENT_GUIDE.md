# Deployment Guide - Trading Platform

This guide will help you deploy and run the trading platform on your local machine and in production.

## Prerequisites

- Node.js 18+ installed
- Git installed
- A Supabase account
- API keys for payment providers (optional for local development)

## 1. Local Development Setup

### Step 1: Clone and Install Dependencies

```bash
git clone [your-repository-url]
cd [project-folder]
npm install
```

### Step 2: Environment Variables

Create a `.env.local` file in the root directory:

```env
VITE_SUPABASE_URL=https://kikzlslbehbxbuoirhvi.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVrenpoZGt6ZmZocG5ydGV3endpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk1ODk1OTgsImV4cCI6MjA2NTE2NTU5OH0.nSNVGffn1X2QCu_YiS36JfPUc-_p2kXyYuipm3vwZOI

# Optional - For payment processing (get your own keys)
CCPAYMENT_API_KEY=your_ccpayment_api_key
CCPAYMENT_MERCHANT_ID=your_merchant_id
CCPAYMENT_APPID=your_app_id
CCPAYMENT_APPSECRET=your_app_secret
NOWPAYMENTS_API_KEY=your_nowpayments_api_key
NOWPAYMENTS_PUBLIC_KEY=your_nowpayments_public_key
NOWPAYMENTS_IPN_SECRET=your_nowpayments_ipn_secret

# For email functionality
RESEND_API_KEY=your_resend_api_key
```

### Step 3: Update Supabase Client (Recommended)

For production use, modify `src/integrations/supabase/client.ts` to use environment variables:

```typescript
const SUPABASE_URL =
  import.meta.env.VITE_SUPABASE_URL ||
  "https://kikzlslbehbxbuoirhvi.supabase.co";
const SUPABASE_PUBLISHABLE_KEY =
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVrenpoZGt6ZmZocG5ydGV3endpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk1ODk1OTgsImV4cCI6MjA2NTE2NTU5OH0.nSNVGffn1X2QCu_YiS36JfPUc-_p2kXyYuipm3vwZOI";
```

### Step 4: Run Locally

```bash
npm run dev
```

The application will be available at `http://localhost:8080`

## 2. Setting Up Your Own Supabase Project (Recommended for Production)

### Step 1: Create New Supabase Project

1. Go to [supabase.com](https://supabase.com)
2. Create a new project
3. Note down your project URL and anon key

### Step 2: Import Database Schema

1. In your Supabase dashboard, go to SQL Editor
2. Run the migration files from `supabase/migrations/` in order
3. Or use the Supabase CLI:

```bash
npx supabase link --project-ref your-project-id
npx supabase db push
```

### Step 3: Configure Authentication

1. Go to Authentication > Settings
2. Set `Site URL` to your domain
3. Configure email templates as needed
4. Disable email confirmation for testing (enable for production)

### Step 4: Set Up Edge Functions

1. Install Supabase CLI: `npm install -g @supabase/cli`
2. Deploy functions:

```bash
npx supabase functions deploy --project-ref your-project-id
```

### Step 5: Configure Secrets

In your Supabase dashboard, go to Settings > Functions and add these secrets:

```
SUPABASE_URL=your-supabase-url
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
SUPABASE_DB_URL=your-db-url
RESEND_API_KEY=your-resend-key
CCPAYMENT_API_KEY=your-ccpayment-key
CCPAYMENT_MERCHANT_ID=your-merchant-id
CCPAYMENT_APPID=your-app-id
CCPAYMENT_APPSECRET=your-app-secret
NOWPAYMENTS_API_KEY=your-nowpayments-key
NOWPAYMENTS_PUBLIC_KEY=your-nowpayments-public-key
NOWPAYMENTS_IPN_SECRET=your-nowpayments-secret
```

## 3. Production Deployment

### Option 1: Vercel (Recommended)

1. Push your code to GitHub
2. Connect your GitHub repo to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy automatically

### Option 2: Netlify

1. Build the project: `npm run build`
2. Upload the `dist` folder to Netlify
3. Configure environment variables
4. Set up continuous deployment

### Option 3: Traditional VPS/Server

1. Install Node.js on your server
2. Clone the repository
3. Install dependencies: `npm install`
4. Build the project: `npm run build`
5. Serve the `dist` folder with nginx/apache
6. Configure environment variables

## 4. Required API Keys and Services

### Payment Processing

- **CCPayment**: Get API keys from [CCPayment dashboard](https://ccpayment.com)
- **NOWPayments**: Get API keys from [NOWPayments](https://nowpayments.io)

### Email Service

- **Resend**: Get API key from [Resend](https://resend.com/api-keys)
- Verify your domain in Resend dashboard

### Admin Access

- The admin panel is accessible with email: `admin@3beetex.com`
- You can change this in the database or create new admin users

## 5. Local Development Notes

**Yes, this can be run entirely on your local machine:**

1. ✅ Frontend runs locally on `localhost:8080`
2. ✅ Database can use the existing Supabase instance or your own
3. ✅ All features work locally including:
   - User authentication
   - Trading simulation
   - Admin panel
   - Payment processing (with proper API keys)
   - Email notifications

## 6. Security Considerations

1. **Never commit API keys to version control**
2. **Use different API keys for development/production**
3. **Enable Row Level Security (RLS) policies in Supabase**
4. **Configure CORS properly for your domain**
5. **Use HTTPS in production**

## 7. Troubleshooting

### Common Issues:

1. **"Invalid API key"**: Check your environment variables
2. **Database connection errors**: Verify Supabase URL and keys
3. **Email not sending**: Check Resend API key and domain verification
4. **Payment failures**: Verify payment provider API keys

### Getting Help:

1. Check browser console for errors
2. Check Supabase logs in dashboard
3. Check edge function logs in Supabase
4. Verify environment variables are loaded correctly

## 8. Cost Considerations

- **Supabase**: Free tier available, $25/month for Pro
- **Vercel**: Free tier available for small projects
- **Resend**: Free tier for limited emails
- **Payment Processors**: Transaction fees apply

---

This platform is fully self-contained and can run independently once properly configured. All data and functionality will work on your local machine or any hosting provider of your choice.
