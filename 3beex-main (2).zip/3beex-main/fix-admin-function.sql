-- Quick fix for missing is_admin_user function
-- Run this in your Supabase SQL Editor

-- Create the admin check function
CREATE OR REPLACE FUNCTION public.is_admin_user()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM auth.users 
    WHERE id = auth.uid() 
    AND email = 'admin@3beetex.com'
  );
END;
$$;

-- Verify the function was created
SELECT 'is_admin_user function created successfully!' as status; 